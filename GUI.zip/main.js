"use strict";
// This object will hold all exports.
var Haste = {};
if(typeof window === 'undefined') window = global;

/* Constructor functions for small ADTs. */
function T0(t){this._=t;}
function T1(t,a){this._=t;this.a=a;}
function T2(t,a,b){this._=t;this.a=a;this.b=b;}
function T3(t,a,b,c){this._=t;this.a=a;this.b=b;this.c=c;}
function T4(t,a,b,c,d){this._=t;this.a=a;this.b=b;this.c=c;this.d=d;}
function T5(t,a,b,c,d,e){this._=t;this.a=a;this.b=b;this.c=c;this.d=d;this.e=e;}
function T6(t,a,b,c,d,e,f){this._=t;this.a=a;this.b=b;this.c=c;this.d=d;this.e=e;this.f=f;}

/* Thunk
   Creates a thunk representing the given closure.
   If the non-updatable flag is undefined, the thunk is updatable.
*/
function T(f, nu) {
    this.f = f;
    if(nu === undefined) {
        this.x = __updatable;
    }
}

/* Hint to optimizer that an imported symbol is strict. */
function __strict(x) {return x}

// A tailcall.
function F(f) {
    this.f = f;
}

// A partially applied function. Invariant: members are never thunks.
function PAP(f, args) {
    this.f = f;
    this.args = args;
    this.arity = f.length - args.length;
}

// "Zero" object; used to avoid creating a whole bunch of new objects
// in the extremely common case of a nil-like data constructor.
var __Z = new T0(0);

// Special object used for blackholing.
var __blackhole = {};

// Used to indicate that an object is updatable.
var __updatable = {};

// Indicates that a closure-creating tail loop isn't done.
var __continue = {};

/* Generic apply.
   Applies a function *or* a partial application object to a list of arguments.
   See https://ghc.haskell.org/trac/ghc/wiki/Commentary/Rts/HaskellExecution/FunctionCalls
   for more information.
*/
function A(f, args) {
    while(true) {
        f = E(f);
        if(f instanceof Function) {
            if(args.length === f.length) {
                return f.apply(null, args);
            } else if(args.length < f.length) {
                return new PAP(f, args);
            } else {
                var f2 = f.apply(null, args.slice(0, f.length));
                args = args.slice(f.length);
                f = B(f2);
            }
        } else if(f instanceof PAP) {
            if(args.length === f.arity) {
                return f.f.apply(null, f.args.concat(args));
            } else if(args.length < f.arity) {
                return new PAP(f.f, f.args.concat(args));
            } else {
                var f2 = f.f.apply(null, f.args.concat(args.slice(0, f.arity)));
                args = args.slice(f.arity);
                f = B(f2);
            }
        } else {
            return f;
        }
    }
}

function A1(f, x) {
    f = E(f);
    if(f instanceof Function) {
        return f.length === 1 ? f(x) : new PAP(f, [x]);
    } else if(f instanceof PAP) {
        return f.arity === 1 ? f.f.apply(null, f.args.concat([x]))
                             : new PAP(f.f, f.args.concat([x]));
    } else {
        return f;
    }
}

function A2(f, x, y) {
    f = E(f);
    if(f instanceof Function) {
        switch(f.length) {
        case 2:  return f(x, y);
        case 1:  return A1(B(f(x)), y);
        default: return new PAP(f, [x,y]);
        }
    } else if(f instanceof PAP) {
        switch(f.arity) {
        case 2:  return f.f.apply(null, f.args.concat([x,y]));
        case 1:  return A1(B(f.f.apply(null, f.args.concat([x]))), y);
        default: return new PAP(f.f, f.args.concat([x,y]));
        }
    } else {
        return f;
    }
}

function A3(f, x, y, z) {
    f = E(f);
    if(f instanceof Function) {
        switch(f.length) {
        case 3:  return f(x, y, z);
        case 2:  return A1(B(f(x, y)), z);
        case 1:  return A2(B(f(x)), y, z);
        default: return new PAP(f, [x,y,z]);
        }
    } else if(f instanceof PAP) {
        switch(f.arity) {
        case 3:  return f.f.apply(null, f.args.concat([x,y,z]));
        case 2:  return A1(B(f.f.apply(null, f.args.concat([x,y]))), z);
        case 1:  return A2(B(f.f.apply(null, f.args.concat([x]))), y, z);
        default: return new PAP(f.f, f.args.concat([x,y,z]));
        }
    } else {
        return f;
    }
}

/* Eval
   Evaluate the given thunk t into head normal form.
   If the "thunk" we get isn't actually a thunk, just return it.
*/
function E(t) {
    if(t instanceof T) {
        if(t.f !== __blackhole) {
            if(t.x === __updatable) {
                var f = t.f;
                t.f = __blackhole;
                t.x = f();
            } else {
                return t.f();
            }
        }
        if(t.x === __updatable) {
            throw 'Infinite loop!';
        } else {
            return t.x;
        }
    } else {
        return t;
    }
}

/* Tail call chain counter. */
var C = 0, Cs = [];

/* Bounce
   Bounce on a trampoline for as long as we get a function back.
*/
function B(f) {
    Cs.push(C);
    while(f instanceof F) {
        var fun = f.f;
        f.f = __blackhole;
        C = 0;
        f = fun();
    }
    C = Cs.pop();
    return f;
}

// Export Haste, A, B and E. Haste because we need to preserve exports, A, B
// and E because they're handy for Haste.Foreign.
if(!window) {
    var window = {};
}
window['Haste'] = Haste;
window['A'] = A;
window['E'] = E;
window['B'] = B;


/* Throw an error.
   We need to be able to use throw as an exception so we wrap it in a function.
*/
function die(err) {
    throw E(err);
}

function quot(a, b) {
    return (a-a%b)/b;
}

function quotRemI(a, b) {
    return {_:0, a:(a-a%b)/b, b:a%b};
}

// 32 bit integer multiplication, with correct overflow behavior
// note that |0 or >>>0 needs to be applied to the result, for int and word
// respectively.
if(Math.imul) {
    var imul = Math.imul;
} else {
    var imul = function(a, b) {
        // ignore high a * high a as the result will always be truncated
        var lows = (a & 0xffff) * (b & 0xffff); // low a * low b
        var aB = (a & 0xffff) * (b & 0xffff0000); // low a * high b
        var bA = (a & 0xffff0000) * (b & 0xffff); // low b * high a
        return lows + aB + bA; // sum will not exceed 52 bits, so it's safe
    }
}

function addC(a, b) {
    var x = a+b;
    return {_:0, a:x & 0xffffffff, b:x > 0x7fffffff};
}

function subC(a, b) {
    var x = a-b;
    return {_:0, a:x & 0xffffffff, b:x < -2147483648};
}

function sinh (arg) {
    return (Math.exp(arg) - Math.exp(-arg)) / 2;
}

function tanh (arg) {
    return (Math.exp(arg) - Math.exp(-arg)) / (Math.exp(arg) + Math.exp(-arg));
}

function cosh (arg) {
    return (Math.exp(arg) + Math.exp(-arg)) / 2;
}

function isFloatFinite(x) {
    return isFinite(x);
}

function isDoubleFinite(x) {
    return isFinite(x);
}

function err(str) {
    die(toJSStr(str));
}

/* unpackCString#
   NOTE: update constructor tags if the code generator starts munging them.
*/
function unCStr(str) {return unAppCStr(str, __Z);}

function unFoldrCStr(str, f, z) {
    var acc = z;
    for(var i = str.length-1; i >= 0; --i) {
        acc = B(A(f, [str.charCodeAt(i), acc]));
    }
    return acc;
}

function unAppCStr(str, chrs) {
    var i = arguments[2] ? arguments[2] : 0;
    if(i >= str.length) {
        return E(chrs);
    } else {
        return {_:1,a:str.charCodeAt(i),b:new T(function() {
            return unAppCStr(str,chrs,i+1);
        })};
    }
}

function charCodeAt(str, i) {return str.charCodeAt(i);}

function fromJSStr(str) {
    return unCStr(E(str));
}

function toJSStr(hsstr) {
    var s = '';
    for(var str = E(hsstr); str._ == 1; str = E(str.b)) {
        s += String.fromCharCode(E(str.a));
    }
    return s;
}

// newMutVar
function nMV(val) {
    return ({x: val});
}

// readMutVar
function rMV(mv) {
    return mv.x;
}

// writeMutVar
function wMV(mv, val) {
    mv.x = val;
}

// atomicModifyMutVar
function mMV(mv, f) {
    var x = B(A(f, [mv.x]));
    mv.x = x.a;
    return x.b;
}

function localeEncoding() {
    var le = newByteArr(5);
    le['v']['i8'][0] = 'U'.charCodeAt(0);
    le['v']['i8'][1] = 'T'.charCodeAt(0);
    le['v']['i8'][2] = 'F'.charCodeAt(0);
    le['v']['i8'][3] = '-'.charCodeAt(0);
    le['v']['i8'][4] = '8'.charCodeAt(0);
    return le;
}

var isDoubleNaN = isNaN;
var isFloatNaN = isNaN;

function isDoubleInfinite(d) {
    return (d === Infinity);
}
var isFloatInfinite = isDoubleInfinite;

function isDoubleNegativeZero(x) {
    return (x===0 && (1/x)===-Infinity);
}
var isFloatNegativeZero = isDoubleNegativeZero;

function strEq(a, b) {
    return a == b;
}

function strOrd(a, b) {
    if(a < b) {
        return 0;
    } else if(a == b) {
        return 1;
    }
    return 2;
}

/* Convert a JS exception into a Haskell JSException */
function __hsException(e) {
  e = e.toString();
  var x = new Long(2904464383, 3929545892, true);
  var y = new Long(3027541338, 3270546716, true);
  var t = new T5(0, x, y
                  , new T5(0, x, y
                            , unCStr("haste-prim")
                            , unCStr("Haste.Prim.Foreign")
                            , unCStr("JSException")), __Z, __Z);
  var show = function(x) {return unCStr(E(x).a);}
  var dispEx = function(x) {return unCStr("JavaScript exception: " + E(x).a);}
  var showList = function(_, s) {return unAppCStr(e, s);}
  var showsPrec = function(_, _p, s) {return unAppCStr(e, s);}
  var showDict = new T3(0, showsPrec, show, showList);
  var self;
  var fromEx = function(_) {return new T1(1, self);}
  var dict = new T5(0, t, showDict, null /* toException */, fromEx, dispEx);
  self = new T2(0, dict, new T1(0, e));
  return self;
}

function jsCatch(act, handler) {
    try {
        return B(A(act,[0]));
    } catch(e) {
        if(typeof e._ === 'undefined') {
            e = __hsException(e);
        }
        return B(A(handler,[e, 0]));
    }
}

/* Haste represents constructors internally using 1 for the first constructor,
   2 for the second, etc.
   However, dataToTag should use 0, 1, 2, etc. Also, booleans might be unboxed.
 */
function dataToTag(x) {
    if(x instanceof Object) {
        return x._;
    } else {
        return x;
    }
}

function __word_encodeDouble(d, e) {
    return d * Math.pow(2,e);
}

var __word_encodeFloat = __word_encodeDouble;
var jsRound = Math.round, rintDouble = jsRound, rintFloat = jsRound;
var jsTrunc = Math.trunc ? Math.trunc : function(x) {
    return x < 0 ? Math.ceil(x) : Math.floor(x);
};
function jsRoundW(n) {
    return Math.abs(jsTrunc(n));
}
var realWorld = undefined;
if(typeof _ == 'undefined') {
    var _ = undefined;
}

function popCnt64(i) {
    return popCnt(i.low) + popCnt(i.high);
}

function popCnt(i) {
    i = i - ((i >> 1) & 0x55555555);
    i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
    return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
}

function __clz(bits, x) {
    x &= (Math.pow(2, bits)-1);
    if(x === 0) {
        return bits;
    } else {
        return bits - (1 + Math.floor(Math.log(x)/Math.LN2));
    }
}

// TODO: can probably be done much faster with arithmetic tricks like __clz
function __ctz(bits, x) {
    var y = 1;
    x &= (Math.pow(2, bits)-1);
    if(x === 0) {
        return bits;
    }
    for(var i = 0; i < bits; ++i) {
        if(y & x) {
            return i;
        } else {
            y <<= 1;
        }
    }
    return 0;
}

// Scratch space for byte arrays.
var rts_scratchBuf = new ArrayBuffer(8);
var rts_scratchW32 = new Uint32Array(rts_scratchBuf);
var rts_scratchFloat = new Float32Array(rts_scratchBuf);
var rts_scratchDouble = new Float64Array(rts_scratchBuf);

function decodeFloat(x) {
    if(x === 0) {
        return __decodedZeroF;
    }
    rts_scratchFloat[0] = x;
    var sign = x < 0 ? -1 : 1;
    var exp = ((rts_scratchW32[0] >> 23) & 0xff) - 150;
    var man = rts_scratchW32[0] & 0x7fffff;
    if(exp === 0) {
        ++exp;
    } else {
        man |= (1 << 23);
    }
    return {_:0, a:sign*man, b:exp};
}

var __decodedZero = {_:0,a:1,b:0,c:0,d:0};
var __decodedZeroF = {_:0,a:1,b:0};

function decodeDouble(x) {
    if(x === 0) {
        // GHC 7.10+ *really* doesn't like 0 to be represented as anything
        // but zeroes all the way.
        return __decodedZero;
    }
    rts_scratchDouble[0] = x;
    var sign = x < 0 ? -1 : 1;
    var manHigh = rts_scratchW32[1] & 0xfffff;
    var manLow = rts_scratchW32[0];
    var exp = ((rts_scratchW32[1] >> 20) & 0x7ff) - 1075;
    if(exp === 0) {
        ++exp;
    } else {
        manHigh |= (1 << 20);
    }
    return {_:0, a:sign, b:manHigh, c:manLow, d:exp};
}

function isNull(obj) {
    return obj === null;
}

function jsRead(str) {
    return Number(str);
}

function jsShowI(val) {return val.toString();}
function jsShow(val) {
    var ret = val.toString();
    return val == Math.round(val) ? ret + '.0' : ret;
}

window['jsGetMouseCoords'] = function jsGetMouseCoords(e) {
    var posx = 0;
    var posy = 0;
    if (!e) var e = window.event;
    if (e.pageX || e.pageY) 	{
	posx = e.pageX;
	posy = e.pageY;
    }
    else if (e.clientX || e.clientY) 	{
	posx = e.clientX + document.body.scrollLeft
	    + document.documentElement.scrollLeft;
	posy = e.clientY + document.body.scrollTop
	    + document.documentElement.scrollTop;
    }
    return [posx - (e.currentTarget.offsetLeft || 0),
	    posy - (e.currentTarget.offsetTop || 0)];
}

var jsRand = Math.random;

// Concatenate a Haskell list of JS strings
function jsCat(strs, sep) {
    var arr = [];
    strs = E(strs);
    while(strs._) {
        strs = E(strs);
        arr.push(E(strs.a));
        strs = E(strs.b);
    }
    return arr.join(sep);
}

// Parse a JSON message into a Haste.JSON.JSON value.
// As this pokes around inside Haskell values, it'll need to be updated if:
// * Haste.JSON.JSON changes;
// * E() starts to choke on non-thunks;
// * data constructor code generation changes; or
// * Just and Nothing change tags.
function jsParseJSON(str) {
    try {
        var js = JSON.parse(str);
        var hs = toHS(js);
    } catch(_) {
        return __Z;
    }
    return {_:1,a:hs};
}

function toHS(obj) {
    switch(typeof obj) {
    case 'number':
        return {_:0, a:jsRead(obj)};
    case 'string':
        return {_:1, a:obj};
    case 'boolean':
        return {_:2, a:obj}; // Booleans are special wrt constructor tags!
    case 'object':
        if(obj instanceof Array) {
            return {_:3, a:arr2lst_json(obj, 0)};
        } else if (obj == null) {
            return {_:5};
        } else {
            // Object type but not array - it's a dictionary.
            // The RFC doesn't say anything about the ordering of keys, but
            // considering that lots of people rely on keys being "in order" as
            // defined by "the same way someone put them in at the other end,"
            // it's probably a good idea to put some cycles into meeting their
            // misguided expectations.
            var ks = [];
            for(var k in obj) {
                ks.unshift(k);
            }
            var xs = [0];
            for(var i = 0; i < ks.length; i++) {
                xs = {_:1, a:{_:0, a:ks[i], b:toHS(obj[ks[i]])}, b:xs};
            }
            return {_:4, a:xs};
        }
    }
}

function arr2lst_json(arr, elem) {
    if(elem >= arr.length) {
        return __Z;
    }
    return {_:1, a:toHS(arr[elem]), b:new T(function() {return arr2lst_json(arr,elem+1);}),c:true}
}

/* gettimeofday(2) */
function gettimeofday(tv, _tz) {
    var t = new Date().getTime();
    writeOffAddr("i32", 4, tv, 0, (t/1000)|0);
    writeOffAddr("i32", 4, tv, 1, ((t%1000)*1000)|0);
    return 0;
}

// Create a little endian ArrayBuffer representation of something.
function toABHost(v, n, x) {
    var a = new ArrayBuffer(n);
    new window[v](a)[0] = x;
    return a;
}

function toABSwap(v, n, x) {
    var a = new ArrayBuffer(n);
    new window[v](a)[0] = x;
    var bs = new Uint8Array(a);
    for(var i = 0, j = n-1; i < j; ++i, --j) {
        var tmp = bs[i];
        bs[i] = bs[j];
        bs[j] = tmp;
    }
    return a;
}

window['toABle'] = toABHost;
window['toABbe'] = toABSwap;

// Swap byte order if host is not little endian.
var buffer = new ArrayBuffer(2);
new DataView(buffer).setInt16(0, 256, true);
if(new Int16Array(buffer)[0] !== 256) {
    window['toABle'] = toABSwap;
    window['toABbe'] = toABHost;
}

/* bn.js by Fedor Indutny, see doc/LICENSE.bn for license */
var __bn = {};
(function (module, exports) {
'use strict';

function BN(number, base, endian) {
  // May be `new BN(bn)` ?
  if (number !== null &&
      typeof number === 'object' &&
      Array.isArray(number.words)) {
    return number;
  }

  this.negative = 0;
  this.words = null;
  this.length = 0;

  if (base === 'le' || base === 'be') {
    endian = base;
    base = 10;
  }

  if (number !== null)
    this._init(number || 0, base || 10, endian || 'be');
}
if (typeof module === 'object')
  module.exports = BN;
else
  exports.BN = BN;

BN.BN = BN;
BN.wordSize = 26;

BN.max = function max(left, right) {
  if (left.cmp(right) > 0)
    return left;
  else
    return right;
};

BN.min = function min(left, right) {
  if (left.cmp(right) < 0)
    return left;
  else
    return right;
};

BN.prototype._init = function init(number, base, endian) {
  if (typeof number === 'number') {
    return this._initNumber(number, base, endian);
  } else if (typeof number === 'object') {
    return this._initArray(number, base, endian);
  }
  if (base === 'hex')
    base = 16;

  number = number.toString().replace(/\s+/g, '');
  var start = 0;
  if (number[0] === '-')
    start++;

  if (base === 16)
    this._parseHex(number, start);
  else
    this._parseBase(number, base, start);

  if (number[0] === '-')
    this.negative = 1;

  this.strip();

  if (endian !== 'le')
    return;

  this._initArray(this.toArray(), base, endian);
};

BN.prototype._initNumber = function _initNumber(number, base, endian) {
  if (number < 0) {
    this.negative = 1;
    number = -number;
  }
  if (number < 0x4000000) {
    this.words = [ number & 0x3ffffff ];
    this.length = 1;
  } else if (number < 0x10000000000000) {
    this.words = [
      number & 0x3ffffff,
      (number / 0x4000000) & 0x3ffffff
    ];
    this.length = 2;
  } else {
    this.words = [
      number & 0x3ffffff,
      (number / 0x4000000) & 0x3ffffff,
      1
    ];
    this.length = 3;
  }

  if (endian !== 'le')
    return;

  // Reverse the bytes
  this._initArray(this.toArray(), base, endian);
};

BN.prototype._initArray = function _initArray(number, base, endian) {
  if (number.length <= 0) {
    this.words = [ 0 ];
    this.length = 1;
    return this;
  }

  this.length = Math.ceil(number.length / 3);
  this.words = new Array(this.length);
  for (var i = 0; i < this.length; i++)
    this.words[i] = 0;

  var off = 0;
  if (endian === 'be') {
    for (var i = number.length - 1, j = 0; i >= 0; i -= 3) {
      var w = number[i] | (number[i - 1] << 8) | (number[i - 2] << 16);
      this.words[j] |= (w << off) & 0x3ffffff;
      this.words[j + 1] = (w >>> (26 - off)) & 0x3ffffff;
      off += 24;
      if (off >= 26) {
        off -= 26;
        j++;
      }
    }
  } else if (endian === 'le') {
    for (var i = 0, j = 0; i < number.length; i += 3) {
      var w = number[i] | (number[i + 1] << 8) | (number[i + 2] << 16);
      this.words[j] |= (w << off) & 0x3ffffff;
      this.words[j + 1] = (w >>> (26 - off)) & 0x3ffffff;
      off += 24;
      if (off >= 26) {
        off -= 26;
        j++;
      }
    }
  }
  return this.strip();
};

function parseHex(str, start, end) {
  var r = 0;
  var len = Math.min(str.length, end);
  for (var i = start; i < len; i++) {
    var c = str.charCodeAt(i) - 48;

    r <<= 4;

    // 'a' - 'f'
    if (c >= 49 && c <= 54)
      r |= c - 49 + 0xa;

    // 'A' - 'F'
    else if (c >= 17 && c <= 22)
      r |= c - 17 + 0xa;

    // '0' - '9'
    else
      r |= c & 0xf;
  }
  return r;
}

BN.prototype._parseHex = function _parseHex(number, start) {
  // Create possibly bigger array to ensure that it fits the number
  this.length = Math.ceil((number.length - start) / 6);
  this.words = new Array(this.length);
  for (var i = 0; i < this.length; i++)
    this.words[i] = 0;

  // Scan 24-bit chunks and add them to the number
  var off = 0;
  for (var i = number.length - 6, j = 0; i >= start; i -= 6) {
    var w = parseHex(number, i, i + 6);
    this.words[j] |= (w << off) & 0x3ffffff;
    this.words[j + 1] |= w >>> (26 - off) & 0x3fffff;
    off += 24;
    if (off >= 26) {
      off -= 26;
      j++;
    }
  }
  if (i + 6 !== start) {
    var w = parseHex(number, start, i + 6);
    this.words[j] |= (w << off) & 0x3ffffff;
    this.words[j + 1] |= w >>> (26 - off) & 0x3fffff;
  }
  this.strip();
};

function parseBase(str, start, end, mul) {
  var r = 0;
  var len = Math.min(str.length, end);
  for (var i = start; i < len; i++) {
    var c = str.charCodeAt(i) - 48;

    r *= mul;

    // 'a'
    if (c >= 49)
      r += c - 49 + 0xa;

    // 'A'
    else if (c >= 17)
      r += c - 17 + 0xa;

    // '0' - '9'
    else
      r += c;
  }
  return r;
}

BN.prototype._parseBase = function _parseBase(number, base, start) {
  // Initialize as zero
  this.words = [ 0 ];
  this.length = 1;

  // Find length of limb in base
  for (var limbLen = 0, limbPow = 1; limbPow <= 0x3ffffff; limbPow *= base)
    limbLen++;
  limbLen--;
  limbPow = (limbPow / base) | 0;

  var total = number.length - start;
  var mod = total % limbLen;
  var end = Math.min(total, total - mod) + start;

  var word = 0;
  for (var i = start; i < end; i += limbLen) {
    word = parseBase(number, i, i + limbLen, base);

    this.imuln(limbPow);
    if (this.words[0] + word < 0x4000000)
      this.words[0] += word;
    else
      this._iaddn(word);
  }

  if (mod !== 0) {
    var pow = 1;
    var word = parseBase(number, i, number.length, base);

    for (var i = 0; i < mod; i++)
      pow *= base;
    this.imuln(pow);
    if (this.words[0] + word < 0x4000000)
      this.words[0] += word;
    else
      this._iaddn(word);
  }
};

BN.prototype.copy = function copy(dest) {
  dest.words = new Array(this.length);
  for (var i = 0; i < this.length; i++)
    dest.words[i] = this.words[i];
  dest.length = this.length;
  dest.negative = this.negative;
};

BN.prototype.clone = function clone() {
  var r = new BN(null);
  this.copy(r);
  return r;
};

// Remove leading `0` from `this`
BN.prototype.strip = function strip() {
  while (this.length > 1 && this.words[this.length - 1] === 0)
    this.length--;
  return this._normSign();
};

BN.prototype._normSign = function _normSign() {
  // -0 = 0
  if (this.length === 1 && this.words[0] === 0)
    this.negative = 0;
  return this;
};

var zeros = [
  '',
  '0',
  '00',
  '000',
  '0000',
  '00000',
  '000000',
  '0000000',
  '00000000',
  '000000000',
  '0000000000',
  '00000000000',
  '000000000000',
  '0000000000000',
  '00000000000000',
  '000000000000000',
  '0000000000000000',
  '00000000000000000',
  '000000000000000000',
  '0000000000000000000',
  '00000000000000000000',
  '000000000000000000000',
  '0000000000000000000000',
  '00000000000000000000000',
  '000000000000000000000000',
  '0000000000000000000000000'
];

var groupSizes = [
  0, 0,
  25, 16, 12, 11, 10, 9, 8,
  8, 7, 7, 7, 7, 6, 6,
  6, 6, 6, 6, 6, 5, 5,
  5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5
];

var groupBases = [
  0, 0,
  33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216,
  43046721, 10000000, 19487171, 35831808, 62748517, 7529536, 11390625,
  16777216, 24137569, 34012224, 47045881, 64000000, 4084101, 5153632,
  6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149,
  24300000, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176
];

BN.prototype.toString = function toString(base, padding) {
  base = base || 10;
  var padding = padding | 0 || 1;
  if (base === 16 || base === 'hex') {
    var out = '';
    var off = 0;
    var carry = 0;
    for (var i = 0; i < this.length; i++) {
      var w = this.words[i];
      var word = (((w << off) | carry) & 0xffffff).toString(16);
      carry = (w >>> (24 - off)) & 0xffffff;
      if (carry !== 0 || i !== this.length - 1)
        out = zeros[6 - word.length] + word + out;
      else
        out = word + out;
      off += 2;
      if (off >= 26) {
        off -= 26;
        i--;
      }
    }
    if (carry !== 0)
      out = carry.toString(16) + out;
    while (out.length % padding !== 0)
      out = '0' + out;
    if (this.negative !== 0)
      out = '-' + out;
    return out;
  } else if (base === (base | 0) && base >= 2 && base <= 36) {
    var groupSize = groupSizes[base];
    var groupBase = groupBases[base];
    var out = '';
    var c = this.clone();
    c.negative = 0;
    while (c.cmpn(0) !== 0) {
      var r = c.modn(groupBase).toString(base);
      c = c.idivn(groupBase);

      if (c.cmpn(0) !== 0)
        out = zeros[groupSize - r.length] + r + out;
      else
        out = r + out;
    }
    if (this.cmpn(0) === 0)
      out = '0' + out;
    while (out.length % padding !== 0)
      out = '0' + out;
    if (this.negative !== 0)
      out = '-' + out;
    return out;
  } else {
    throw 'Base should be between 2 and 36';
  }
};

BN.prototype.toJSON = function toJSON() {
  return this.toString(16);
};

BN.prototype.toArray = function toArray(endian, length) {
  this.strip();
  var littleEndian = endian === 'le';
  var res = new Array(this.byteLength());
  res[0] = 0;

  var q = this.clone();
  if (!littleEndian) {
    // Assume big-endian
    for (var i = 0; q.cmpn(0) !== 0; i++) {
      var b = q.andln(0xff);
      q.iushrn(8);

      res[res.length - i - 1] = b;
    }
  } else {
    for (var i = 0; q.cmpn(0) !== 0; i++) {
      var b = q.andln(0xff);
      q.iushrn(8);

      res[i] = b;
    }
  }

  if (length) {
    while (res.length < length) {
      if (littleEndian)
        res.push(0);
      else
        res.unshift(0);
    }
  }

  return res;
};

if (Math.clz32) {
  BN.prototype._countBits = function _countBits(w) {
    return 32 - Math.clz32(w);
  };
} else {
  BN.prototype._countBits = function _countBits(w) {
    var t = w;
    var r = 0;
    if (t >= 0x1000) {
      r += 13;
      t >>>= 13;
    }
    if (t >= 0x40) {
      r += 7;
      t >>>= 7;
    }
    if (t >= 0x8) {
      r += 4;
      t >>>= 4;
    }
    if (t >= 0x02) {
      r += 2;
      t >>>= 2;
    }
    return r + t;
  };
}

// Return number of used bits in a BN
BN.prototype.bitLength = function bitLength() {
  var hi = 0;
  var w = this.words[this.length - 1];
  var hi = this._countBits(w);
  return (this.length - 1) * 26 + hi;
};

BN.prototype.byteLength = function byteLength() {
  return Math.ceil(this.bitLength() / 8);
};

// Return negative clone of `this`
BN.prototype.neg = function neg() {
  if (this.cmpn(0) === 0)
    return this.clone();

  var r = this.clone();
  r.negative = this.negative ^ 1;
  return r;
};

BN.prototype.ineg = function ineg() {
  this.negative ^= 1;
  return this;
};

// Or `num` with `this` in-place
BN.prototype.iuor = function iuor(num) {
  while (this.length < num.length)
    this.words[this.length++] = 0;

  for (var i = 0; i < num.length; i++)
    this.words[i] = this.words[i] | num.words[i];

  return this.strip();
};

BN.prototype.ior = function ior(num) {
  //assert((this.negative | num.negative) === 0);
  return this.iuor(num);
};


// Or `num` with `this`
BN.prototype.or = function or(num) {
  if (this.length > num.length)
    return this.clone().ior(num);
  else
    return num.clone().ior(this);
};

BN.prototype.uor = function uor(num) {
  if (this.length > num.length)
    return this.clone().iuor(num);
  else
    return num.clone().iuor(this);
};


// And `num` with `this` in-place
BN.prototype.iuand = function iuand(num) {
  // b = min-length(num, this)
  var b;
  if (this.length > num.length)
    b = num;
  else
    b = this;

  for (var i = 0; i < b.length; i++)
    this.words[i] = this.words[i] & num.words[i];

  this.length = b.length;

  return this.strip();
};

BN.prototype.iand = function iand(num) {
  //assert((this.negative | num.negative) === 0);
  return this.iuand(num);
};


// And `num` with `this`
BN.prototype.and = function and(num) {
  if (this.length > num.length)
    return this.clone().iand(num);
  else
    return num.clone().iand(this);
};

BN.prototype.uand = function uand(num) {
  if (this.length > num.length)
    return this.clone().iuand(num);
  else
    return num.clone().iuand(this);
};


// Xor `num` with `this` in-place
BN.prototype.iuxor = function iuxor(num) {
  // a.length > b.length
  var a;
  var b;
  if (this.length > num.length) {
    a = this;
    b = num;
  } else {
    a = num;
    b = this;
  }

  for (var i = 0; i < b.length; i++)
    this.words[i] = a.words[i] ^ b.words[i];

  if (this !== a)
    for (; i < a.length; i++)
      this.words[i] = a.words[i];

  this.length = a.length;

  return this.strip();
};

BN.prototype.ixor = function ixor(num) {
  //assert((this.negative | num.negative) === 0);
  return this.iuxor(num);
};


// Xor `num` with `this`
BN.prototype.xor = function xor(num) {
  if (this.length > num.length)
    return this.clone().ixor(num);
  else
    return num.clone().ixor(this);
};

BN.prototype.uxor = function uxor(num) {
  if (this.length > num.length)
    return this.clone().iuxor(num);
  else
    return num.clone().iuxor(this);
};


// Add `num` to `this` in-place
BN.prototype.iadd = function iadd(num) {
  // negative + positive
  if (this.negative !== 0 && num.negative === 0) {
    this.negative = 0;
    var r = this.isub(num);
    this.negative ^= 1;
    return this._normSign();

  // positive + negative
  } else if (this.negative === 0 && num.negative !== 0) {
    num.negative = 0;
    var r = this.isub(num);
    num.negative = 1;
    return r._normSign();
  }

  // a.length > b.length
  var a;
  var b;
  if (this.length > num.length) {
    a = this;
    b = num;
  } else {
    a = num;
    b = this;
  }

  var carry = 0;
  for (var i = 0; i < b.length; i++) {
    var r = (a.words[i] | 0) + (b.words[i] | 0) + carry;
    this.words[i] = r & 0x3ffffff;
    carry = r >>> 26;
  }
  for (; carry !== 0 && i < a.length; i++) {
    var r = (a.words[i] | 0) + carry;
    this.words[i] = r & 0x3ffffff;
    carry = r >>> 26;
  }

  this.length = a.length;
  if (carry !== 0) {
    this.words[this.length] = carry;
    this.length++;
  // Copy the rest of the words
  } else if (a !== this) {
    for (; i < a.length; i++)
      this.words[i] = a.words[i];
  }

  return this;
};

// Add `num` to `this`
BN.prototype.add = function add(num) {
  if (num.negative !== 0 && this.negative === 0) {
    num.negative = 0;
    var res = this.sub(num);
    num.negative ^= 1;
    return res;
  } else if (num.negative === 0 && this.negative !== 0) {
    this.negative = 0;
    var res = num.sub(this);
    this.negative = 1;
    return res;
  }

  if (this.length > num.length)
    return this.clone().iadd(num);
  else
    return num.clone().iadd(this);
};

// Subtract `num` from `this` in-place
BN.prototype.isub = function isub(num) {
  // this - (-num) = this + num
  if (num.negative !== 0) {
    num.negative = 0;
    var r = this.iadd(num);
    num.negative = 1;
    return r._normSign();

  // -this - num = -(this + num)
  } else if (this.negative !== 0) {
    this.negative = 0;
    this.iadd(num);
    this.negative = 1;
    return this._normSign();
  }

  // At this point both numbers are positive
  var cmp = this.cmp(num);

  // Optimization - zeroify
  if (cmp === 0) {
    this.negative = 0;
    this.length = 1;
    this.words[0] = 0;
    return this;
  }

  // a > b
  var a;
  var b;
  if (cmp > 0) {
    a = this;
    b = num;
  } else {
    a = num;
    b = this;
  }

  var carry = 0;
  for (var i = 0; i < b.length; i++) {
    var r = (a.words[i] | 0) - (b.words[i] | 0) + carry;
    carry = r >> 26;
    this.words[i] = r & 0x3ffffff;
  }
  for (; carry !== 0 && i < a.length; i++) {
    var r = (a.words[i] | 0) + carry;
    carry = r >> 26;
    this.words[i] = r & 0x3ffffff;
  }

  // Copy rest of the words
  if (carry === 0 && i < a.length && a !== this)
    for (; i < a.length; i++)
      this.words[i] = a.words[i];
  this.length = Math.max(this.length, i);

  if (a !== this)
    this.negative = 1;

  return this.strip();
};

// Subtract `num` from `this`
BN.prototype.sub = function sub(num) {
  return this.clone().isub(num);
};

function smallMulTo(self, num, out) {
  out.negative = num.negative ^ self.negative;
  var len = (self.length + num.length) | 0;
  out.length = len;
  len = (len - 1) | 0;

  // Peel one iteration (compiler can't do it, because of code complexity)
  var a = self.words[0] | 0;
  var b = num.words[0] | 0;
  var r = a * b;

  var lo = r & 0x3ffffff;
  var carry = (r / 0x4000000) | 0;
  out.words[0] = lo;

  for (var k = 1; k < len; k++) {
    // Sum all words with the same `i + j = k` and accumulate `ncarry`,
    // note that ncarry could be >= 0x3ffffff
    var ncarry = carry >>> 26;
    var rword = carry & 0x3ffffff;
    var maxJ = Math.min(k, num.length - 1);
    for (var j = Math.max(0, k - self.length + 1); j <= maxJ; j++) {
      var i = (k - j) | 0;
      var a = self.words[i] | 0;
      var b = num.words[j] | 0;
      var r = a * b;

      var lo = r & 0x3ffffff;
      ncarry = (ncarry + ((r / 0x4000000) | 0)) | 0;
      lo = (lo + rword) | 0;
      rword = lo & 0x3ffffff;
      ncarry = (ncarry + (lo >>> 26)) | 0;
    }
    out.words[k] = rword | 0;
    carry = ncarry | 0;
  }
  if (carry !== 0) {
    out.words[k] = carry | 0;
  } else {
    out.length--;
  }

  return out.strip();
}

function bigMulTo(self, num, out) {
  out.negative = num.negative ^ self.negative;
  out.length = self.length + num.length;

  var carry = 0;
  var hncarry = 0;
  for (var k = 0; k < out.length - 1; k++) {
    // Sum all words with the same `i + j = k` and accumulate `ncarry`,
    // note that ncarry could be >= 0x3ffffff
    var ncarry = hncarry;
    hncarry = 0;
    var rword = carry & 0x3ffffff;
    var maxJ = Math.min(k, num.length - 1);
    for (var j = Math.max(0, k - self.length + 1); j <= maxJ; j++) {
      var i = k - j;
      var a = self.words[i] | 0;
      var b = num.words[j] | 0;
      var r = a * b;

      var lo = r & 0x3ffffff;
      ncarry = (ncarry + ((r / 0x4000000) | 0)) | 0;
      lo = (lo + rword) | 0;
      rword = lo & 0x3ffffff;
      ncarry = (ncarry + (lo >>> 26)) | 0;

      hncarry += ncarry >>> 26;
      ncarry &= 0x3ffffff;
    }
    out.words[k] = rword;
    carry = ncarry;
    ncarry = hncarry;
  }
  if (carry !== 0) {
    out.words[k] = carry;
  } else {
    out.length--;
  }

  return out.strip();
}

BN.prototype.mulTo = function mulTo(num, out) {
  var res;
  if (this.length + num.length < 63)
    res = smallMulTo(this, num, out);
  else
    res = bigMulTo(this, num, out);
  return res;
};

// Multiply `this` by `num`
BN.prototype.mul = function mul(num) {
  var out = new BN(null);
  out.words = new Array(this.length + num.length);
  return this.mulTo(num, out);
};

// In-place Multiplication
BN.prototype.imul = function imul(num) {
  if (this.cmpn(0) === 0 || num.cmpn(0) === 0) {
    this.words[0] = 0;
    this.length = 1;
    return this;
  }

  var tlen = this.length;
  var nlen = num.length;

  this.negative = num.negative ^ this.negative;
  this.length = this.length + num.length;
  this.words[this.length - 1] = 0;

  for (var k = this.length - 2; k >= 0; k--) {
    // Sum all words with the same `i + j = k` and accumulate `carry`,
    // note that carry could be >= 0x3ffffff
    var carry = 0;
    var rword = 0;
    var maxJ = Math.min(k, nlen - 1);
    for (var j = Math.max(0, k - tlen + 1); j <= maxJ; j++) {
      var i = k - j;
      var a = this.words[i] | 0;
      var b = num.words[j] | 0;
      var r = a * b;

      var lo = r & 0x3ffffff;
      carry += (r / 0x4000000) | 0;
      lo += rword;
      rword = lo & 0x3ffffff;
      carry += lo >>> 26;
    }
    this.words[k] = rword;
    this.words[k + 1] += carry;
    carry = 0;
  }

  // Propagate overflows
  var carry = 0;
  for (var i = 1; i < this.length; i++) {
    var w = (this.words[i] | 0) + carry;
    this.words[i] = w & 0x3ffffff;
    carry = w >>> 26;
  }

  return this.strip();
};

BN.prototype.imuln = function imuln(num) {
  // Carry
  var carry = 0;
  for (var i = 0; i < this.length; i++) {
    var w = (this.words[i] | 0) * num;
    var lo = (w & 0x3ffffff) + (carry & 0x3ffffff);
    carry >>= 26;
    carry += (w / 0x4000000) | 0;
    // NOTE: lo is 27bit maximum
    carry += lo >>> 26;
    this.words[i] = lo & 0x3ffffff;
  }

  if (carry !== 0) {
    this.words[i] = carry;
    this.length++;
  }

  return this;
};

BN.prototype.muln = function muln(num) {
  return this.clone().imuln(num);
};

// `this` * `this`
BN.prototype.sqr = function sqr() {
  return this.mul(this);
};

// `this` * `this` in-place
BN.prototype.isqr = function isqr() {
  return this.mul(this);
};

// Shift-left in-place
BN.prototype.iushln = function iushln(bits) {
  var r = bits % 26;
  var s = (bits - r) / 26;
  var carryMask = (0x3ffffff >>> (26 - r)) << (26 - r);

  if (r !== 0) {
    var carry = 0;
    for (var i = 0; i < this.length; i++) {
      var newCarry = this.words[i] & carryMask;
      var c = ((this.words[i] | 0) - newCarry) << r;
      this.words[i] = c | carry;
      carry = newCarry >>> (26 - r);
    }
    if (carry) {
      this.words[i] = carry;
      this.length++;
    }
  }

  if (s !== 0) {
    for (var i = this.length - 1; i >= 0; i--)
      this.words[i + s] = this.words[i];
    for (var i = 0; i < s; i++)
      this.words[i] = 0;
    this.length += s;
  }

  return this.strip();
};

BN.prototype.ishln = function ishln(bits) {
  return this.iushln(bits);
};

// Shift-right in-place
BN.prototype.iushrn = function iushrn(bits, hint, extended) {
  var h;
  if (hint)
    h = (hint - (hint % 26)) / 26;
  else
    h = 0;

  var r = bits % 26;
  var s = Math.min((bits - r) / 26, this.length);
  var mask = 0x3ffffff ^ ((0x3ffffff >>> r) << r);
  var maskedWords = extended;

  h -= s;
  h = Math.max(0, h);

  // Extended mode, copy masked part
  if (maskedWords) {
    for (var i = 0; i < s; i++)
      maskedWords.words[i] = this.words[i];
    maskedWords.length = s;
  }

  if (s === 0) {
    // No-op, we should not move anything at all
  } else if (this.length > s) {
    this.length -= s;
    for (var i = 0; i < this.length; i++)
      this.words[i] = this.words[i + s];
  } else {
    this.words[0] = 0;
    this.length = 1;
  }

  var carry = 0;
  for (var i = this.length - 1; i >= 0 && (carry !== 0 || i >= h); i--) {
    var word = this.words[i] | 0;
    this.words[i] = (carry << (26 - r)) | (word >>> r);
    carry = word & mask;
  }

  // Push carried bits as a mask
  if (maskedWords && carry !== 0)
    maskedWords.words[maskedWords.length++] = carry;

  if (this.length === 0) {
    this.words[0] = 0;
    this.length = 1;
  }

  this.strip();

  return this;
};

BN.prototype.ishrn = function ishrn(bits, hint, extended) {
  return this.iushrn(bits, hint, extended);
};

// Shift-left
BN.prototype.shln = function shln(bits) {
  var x = this.clone();
  var neg = x.negative;
  x.negative = false;
  x.ishln(bits);
  x.negative = neg;
  return x;
};

BN.prototype.ushln = function ushln(bits) {
  return this.clone().iushln(bits);
};

// Shift-right
BN.prototype.shrn = function shrn(bits) {
  var x = this.clone();
  if(x.negative) {
      x.negative = false;
      x.ishrn(bits);
      x.negative = true;
      return x.isubn(1);
  } else {
      return x.ishrn(bits);
  }
};

BN.prototype.ushrn = function ushrn(bits) {
  return this.clone().iushrn(bits);
};

// Test if n bit is set
BN.prototype.testn = function testn(bit) {
  var r = bit % 26;
  var s = (bit - r) / 26;
  var q = 1 << r;

  // Fast case: bit is much higher than all existing words
  if (this.length <= s) {
    return false;
  }

  // Check bit and return
  var w = this.words[s];

  return !!(w & q);
};

// Add plain number `num` to `this`
BN.prototype.iaddn = function iaddn(num) {
  if (num < 0)
    return this.isubn(-num);

  // Possible sign change
  if (this.negative !== 0) {
    if (this.length === 1 && (this.words[0] | 0) < num) {
      this.words[0] = num - (this.words[0] | 0);
      this.negative = 0;
      return this;
    }

    this.negative = 0;
    this.isubn(num);
    this.negative = 1;
    return this;
  }

  // Add without checks
  return this._iaddn(num);
};

BN.prototype._iaddn = function _iaddn(num) {
  this.words[0] += num;

  // Carry
  for (var i = 0; i < this.length && this.words[i] >= 0x4000000; i++) {
    this.words[i] -= 0x4000000;
    if (i === this.length - 1)
      this.words[i + 1] = 1;
    else
      this.words[i + 1]++;
  }
  this.length = Math.max(this.length, i + 1);

  return this;
};

// Subtract plain number `num` from `this`
BN.prototype.isubn = function isubn(num) {
  if (num < 0)
    return this.iaddn(-num);

  if (this.negative !== 0) {
    this.negative = 0;
    this.iaddn(num);
    this.negative = 1;
    return this;
  }

  this.words[0] -= num;

  // Carry
  for (var i = 0; i < this.length && this.words[i] < 0; i++) {
    this.words[i] += 0x4000000;
    this.words[i + 1] -= 1;
  }

  return this.strip();
};

BN.prototype.addn = function addn(num) {
  return this.clone().iaddn(num);
};

BN.prototype.subn = function subn(num) {
  return this.clone().isubn(num);
};

BN.prototype.iabs = function iabs() {
  this.negative = 0;

  return this;
};

BN.prototype.abs = function abs() {
  return this.clone().iabs();
};

BN.prototype._ishlnsubmul = function _ishlnsubmul(num, mul, shift) {
  // Bigger storage is needed
  var len = num.length + shift;
  var i;
  if (this.words.length < len) {
    var t = new Array(len);
    for (var i = 0; i < this.length; i++)
      t[i] = this.words[i];
    this.words = t;
  } else {
    i = this.length;
  }

  // Zeroify rest
  this.length = Math.max(this.length, len);
  for (; i < this.length; i++)
    this.words[i] = 0;

  var carry = 0;
  for (var i = 0; i < num.length; i++) {
    var w = (this.words[i + shift] | 0) + carry;
    var right = (num.words[i] | 0) * mul;
    w -= right & 0x3ffffff;
    carry = (w >> 26) - ((right / 0x4000000) | 0);
    this.words[i + shift] = w & 0x3ffffff;
  }
  for (; i < this.length - shift; i++) {
    var w = (this.words[i + shift] | 0) + carry;
    carry = w >> 26;
    this.words[i + shift] = w & 0x3ffffff;
  }

  if (carry === 0)
    return this.strip();

  carry = 0;
  for (var i = 0; i < this.length; i++) {
    var w = -(this.words[i] | 0) + carry;
    carry = w >> 26;
    this.words[i] = w & 0x3ffffff;
  }
  this.negative = 1;

  return this.strip();
};

BN.prototype._wordDiv = function _wordDiv(num, mode) {
  var shift = this.length - num.length;

  var a = this.clone();
  var b = num;

  // Normalize
  var bhi = b.words[b.length - 1] | 0;
  var bhiBits = this._countBits(bhi);
  shift = 26 - bhiBits;
  if (shift !== 0) {
    b = b.ushln(shift);
    a.iushln(shift);
    bhi = b.words[b.length - 1] | 0;
  }

  // Initialize quotient
  var m = a.length - b.length;
  var q;

  if (mode !== 'mod') {
    q = new BN(null);
    q.length = m + 1;
    q.words = new Array(q.length);
    for (var i = 0; i < q.length; i++)
      q.words[i] = 0;
  }

  var diff = a.clone()._ishlnsubmul(b, 1, m);
  if (diff.negative === 0) {
    a = diff;
    if (q)
      q.words[m] = 1;
  }

  for (var j = m - 1; j >= 0; j--) {
    var qj = (a.words[b.length + j] | 0) * 0x4000000 +
             (a.words[b.length + j - 1] | 0);

    // NOTE: (qj / bhi) is (0x3ffffff * 0x4000000 + 0x3ffffff) / 0x2000000 max
    // (0x7ffffff)
    qj = Math.min((qj / bhi) | 0, 0x3ffffff);

    a._ishlnsubmul(b, qj, j);
    while (a.negative !== 0) {
      qj--;
      a.negative = 0;
      a._ishlnsubmul(b, 1, j);
      if (a.cmpn(0) !== 0)
        a.negative ^= 1;
    }
    if (q)
      q.words[j] = qj;
  }
  if (q)
    q.strip();
  a.strip();

  // Denormalize
  if (mode !== 'div' && shift !== 0)
    a.iushrn(shift);
  return { div: q ? q : null, mod: a };
};

BN.prototype.divmod = function divmod(num, mode, positive) {
  if (this.negative !== 0 && num.negative === 0) {
    var res = this.neg().divmod(num, mode);
    var div;
    var mod;
    if (mode !== 'mod')
      div = res.div.neg();
    if (mode !== 'div') {
      mod = res.mod.neg();
      if (positive && mod.neg)
        mod = mod.add(num);
    }
    return {
      div: div,
      mod: mod
    };
  } else if (this.negative === 0 && num.negative !== 0) {
    var res = this.divmod(num.neg(), mode);
    var div;
    if (mode !== 'mod')
      div = res.div.neg();
    return { div: div, mod: res.mod };
  } else if ((this.negative & num.negative) !== 0) {
    var res = this.neg().divmod(num.neg(), mode);
    var mod;
    if (mode !== 'div') {
      mod = res.mod.neg();
      if (positive && mod.neg)
        mod = mod.isub(num);
    }
    return {
      div: res.div,
      mod: mod
    };
  }

  // Both numbers are positive at this point

  // Strip both numbers to approximate shift value
  if (num.length > this.length || this.cmp(num) < 0)
    return { div: new BN(0), mod: this };

  // Very short reduction
  if (num.length === 1) {
    if (mode === 'div')
      return { div: this.divn(num.words[0]), mod: null };
    else if (mode === 'mod')
      return { div: null, mod: new BN(this.modn(num.words[0])) };
    return {
      div: this.divn(num.words[0]),
      mod: new BN(this.modn(num.words[0]))
    };
  }

  return this._wordDiv(num, mode);
};

// Find `this` / `num`
BN.prototype.div = function div(num) {
  return this.divmod(num, 'div', false).div;
};

// Find `this` % `num`
BN.prototype.mod = function mod(num) {
  return this.divmod(num, 'mod', false).mod;
};

BN.prototype.umod = function umod(num) {
  return this.divmod(num, 'mod', true).mod;
};

// Find Round(`this` / `num`)
BN.prototype.divRound = function divRound(num) {
  var dm = this.divmod(num);

  // Fast case - exact division
  if (dm.mod.cmpn(0) === 0)
    return dm.div;

  var mod = dm.div.negative !== 0 ? dm.mod.isub(num) : dm.mod;

  var half = num.ushrn(1);
  var r2 = num.andln(1);
  var cmp = mod.cmp(half);

  // Round down
  if (cmp < 0 || r2 === 1 && cmp === 0)
    return dm.div;

  // Round up
  return dm.div.negative !== 0 ? dm.div.isubn(1) : dm.div.iaddn(1);
};

BN.prototype.modn = function modn(num) {
  var p = (1 << 26) % num;

  var acc = 0;
  for (var i = this.length - 1; i >= 0; i--)
    acc = (p * acc + (this.words[i] | 0)) % num;

  return acc;
};

// In-place division by number
BN.prototype.idivn = function idivn(num) {
  var carry = 0;
  for (var i = this.length - 1; i >= 0; i--) {
    var w = (this.words[i] | 0) + carry * 0x4000000;
    this.words[i] = (w / num) | 0;
    carry = w % num;
  }

  return this.strip();
};

BN.prototype.divn = function divn(num) {
  return this.clone().idivn(num);
};

BN.prototype.isEven = function isEven() {
  return (this.words[0] & 1) === 0;
};

BN.prototype.isOdd = function isOdd() {
  return (this.words[0] & 1) === 1;
};

// And first word and num
BN.prototype.andln = function andln(num) {
  return this.words[0] & num;
};

BN.prototype.cmpn = function cmpn(num) {
  var negative = num < 0;
  if (negative)
    num = -num;

  if (this.negative !== 0 && !negative)
    return -1;
  else if (this.negative === 0 && negative)
    return 1;

  num &= 0x3ffffff;
  this.strip();

  var res;
  if (this.length > 1) {
    res = 1;
  } else {
    var w = this.words[0] | 0;
    res = w === num ? 0 : w < num ? -1 : 1;
  }
  if (this.negative !== 0)
    res = -res;
  return res;
};

// Compare two numbers and return:
// 1 - if `this` > `num`
// 0 - if `this` == `num`
// -1 - if `this` < `num`
BN.prototype.cmp = function cmp(num) {
  if (this.negative !== 0 && num.negative === 0)
    return -1;
  else if (this.negative === 0 && num.negative !== 0)
    return 1;

  var res = this.ucmp(num);
  if (this.negative !== 0)
    return -res;
  else
    return res;
};

// Unsigned comparison
BN.prototype.ucmp = function ucmp(num) {
  // At this point both numbers have the same sign
  if (this.length > num.length)
    return 1;
  else if (this.length < num.length)
    return -1;

  var res = 0;
  for (var i = this.length - 1; i >= 0; i--) {
    var a = this.words[i] | 0;
    var b = num.words[i] | 0;

    if (a === b)
      continue;
    if (a < b)
      res = -1;
    else if (a > b)
      res = 1;
    break;
  }
  return res;
};
})(undefined, __bn);

// MVar implementation.
// Since Haste isn't concurrent, takeMVar and putMVar don't block on empty
// and full MVars respectively, but terminate the program since they would
// otherwise be blocking forever.

function newMVar() {
    return ({empty: true});
}

function tryTakeMVar(mv) {
    if(mv.empty) {
        return {_:0, a:0, b:undefined};
    } else {
        var val = mv.x;
        mv.empty = true;
        mv.x = null;
        return {_:0, a:1, b:val};
    }
}

function takeMVar(mv) {
    if(mv.empty) {
        // TODO: real BlockedOnDeadMVar exception, perhaps?
        err("Attempted to take empty MVar!");
    }
    var val = mv.x;
    mv.empty = true;
    mv.x = null;
    return val;
}

function putMVar(mv, val) {
    if(!mv.empty) {
        // TODO: real BlockedOnDeadMVar exception, perhaps?
        err("Attempted to put full MVar!");
    }
    mv.empty = false;
    mv.x = val;
}

function tryPutMVar(mv, val) {
    if(!mv.empty) {
        return 0;
    } else {
        mv.empty = false;
        mv.x = val;
        return 1;
    }
}

function sameMVar(a, b) {
    return (a == b);
}

function isEmptyMVar(mv) {
    return mv.empty ? 1 : 0;
}

// Implementation of stable names.
// Unlike native GHC, the garbage collector isn't going to move data around
// in a way that we can detect, so each object could serve as its own stable
// name if it weren't for the fact we can't turn a JS reference into an
// integer.
// So instead, each object has a unique integer attached to it, which serves
// as its stable name.

var __next_stable_name = 1;
var __stable_table;

function makeStableName(x) {
    if(x instanceof Object) {
        if(!x.stableName) {
            x.stableName = __next_stable_name;
            __next_stable_name += 1;
        }
        return {type: 'obj', name: x.stableName};
    } else {
        return {type: 'prim', name: Number(x)};
    }
}

function eqStableName(x, y) {
    return (x.type == y.type && x.name == y.name) ? 1 : 0;
}

// TODO: inefficient compared to real fromInt?
__bn.Z = new __bn.BN(0);
__bn.ONE = new __bn.BN(1);
__bn.MOD32 = new __bn.BN(0x100000000); // 2^32
var I_fromNumber = function(x) {return new __bn.BN(x);}
var I_fromInt = I_fromNumber;
var I_fromBits = function(lo,hi) {
    var x = new __bn.BN(lo >>> 0);
    var y = new __bn.BN(hi >>> 0);
    y.ishln(32);
    x.iadd(y);
    return x;
}
var I_fromString = function(s) {return new __bn.BN(s);}
var I_toInt = function(x) {return I_toNumber(x.mod(__bn.MOD32));}
var I_toWord = function(x) {return I_toInt(x) >>> 0;};
// TODO: inefficient!
var I_toNumber = function(x) {return Number(x.toString());}
var I_equals = function(a,b) {return a.cmp(b) === 0;}
var I_compare = function(a,b) {return a.cmp(b);}
var I_compareInt = function(x,i) {return x.cmp(new __bn.BN(i));}
var I_negate = function(x) {return x.neg();}
var I_add = function(a,b) {return a.add(b);}
var I_sub = function(a,b) {return a.sub(b);}
var I_mul = function(a,b) {return a.mul(b);}
var I_mod = function(a,b) {return I_rem(I_add(b, I_rem(a, b)), b);}
var I_quotRem = function(a,b) {
    var qr = a.divmod(b);
    return {_:0, a:qr.div, b:qr.mod};
}
var I_div = function(a,b) {
    if((a.cmp(__bn.Z)>=0) != (a.cmp(__bn.Z)>=0)) {
        if(a.cmp(a.rem(b), __bn.Z) !== 0) {
            return a.div(b).sub(__bn.ONE);
        }
    }
    return a.div(b);
}
var I_divMod = function(a,b) {
    return {_:0, a:I_div(a,b), b:a.mod(b)};
}
var I_quot = function(a,b) {return a.div(b);}
var I_rem = function(a,b) {return a.mod(b);}
var I_and = function(a,b) {return a.and(b);}
var I_or = function(a,b) {return a.or(b);}
var I_xor = function(a,b) {return a.xor(b);}
var I_shiftLeft = function(a,b) {return a.shln(b);}
var I_shiftRight = function(a,b) {return a.shrn(b);}
var I_signum = function(x) {return x.cmp(new __bn.BN(0));}
var I_abs = function(x) {return x.abs();}
var I_decodeDouble = function(x) {
    var dec = decodeDouble(x);
    var mantissa = I_fromBits(dec.c, dec.b);
    if(dec.a < 0) {
        mantissa = I_negate(mantissa);
    }
    return {_:0, a:dec.d, b:mantissa};
}
var I_toString = function(x) {return x.toString();}
var I_fromRat = function(a, b) {
    return I_toNumber(a) / I_toNumber(b);
}

function I_fromInt64(x) {
    if(x.isNegative()) {
        return I_negate(I_fromInt64(x.negate()));
    } else {
        return I_fromBits(x.low, x.high);
    }
}

function I_toInt64(x) {
    if(x.negative) {
        return I_toInt64(I_negate(x)).negate();
    } else {
        return new Long(I_toInt(x), I_toInt(I_shiftRight(x,32)));
    }
}

function I_fromWord64(x) {
    return I_fromBits(x.toInt(), x.shru(32).toInt());
}

function I_toWord64(x) {
    var w = I_toInt64(x);
    w.unsigned = true;
    return w;
}

/**
 * @license long.js (c) 2013 Daniel Wirtz <dcode@dcode.io>
 * Released under the Apache License, Version 2.0
 * see: https://github.com/dcodeIO/long.js for details
 */
function Long(low, high, unsigned) {
    this.low = low | 0;
    this.high = high | 0;
    this.unsigned = !!unsigned;
}

var INT_CACHE = {};
var UINT_CACHE = {};
function cacheable(x, u) {
    return u ? 0 <= (x >>>= 0) && x < 256 : -128 <= (x |= 0) && x < 128;
}

function __fromInt(value, unsigned) {
    var obj, cachedObj, cache;
    if (unsigned) {
        if (cache = cacheable(value >>>= 0, true)) {
            cachedObj = UINT_CACHE[value];
            if (cachedObj)
                return cachedObj;
        }
        obj = new Long(value, (value | 0) < 0 ? -1 : 0, true);
        if (cache)
            UINT_CACHE[value] = obj;
        return obj;
    } else {
        if (cache = cacheable(value |= 0, false)) {
            cachedObj = INT_CACHE[value];
            if (cachedObj)
                return cachedObj;
        }
        obj = new Long(value, value < 0 ? -1 : 0, false);
        if (cache)
            INT_CACHE[value] = obj;
        return obj;
    }
}

function __fromNumber(value, unsigned) {
    if (isNaN(value) || !isFinite(value))
        return unsigned ? UZERO : ZERO;
    if (unsigned) {
        if (value < 0)
            return UZERO;
        if (value >= TWO_PWR_64_DBL)
            return MAX_UNSIGNED_VALUE;
    } else {
        if (value <= -TWO_PWR_63_DBL)
            return MIN_VALUE;
        if (value + 1 >= TWO_PWR_63_DBL)
            return MAX_VALUE;
    }
    if (value < 0)
        return __fromNumber(-value, unsigned).neg();
    return new Long((value % TWO_PWR_32_DBL) | 0, (value / TWO_PWR_32_DBL) | 0, unsigned);
}
var pow_dbl = Math.pow;
var TWO_PWR_16_DBL = 1 << 16;
var TWO_PWR_24_DBL = 1 << 24;
var TWO_PWR_32_DBL = TWO_PWR_16_DBL * TWO_PWR_16_DBL;
var TWO_PWR_64_DBL = TWO_PWR_32_DBL * TWO_PWR_32_DBL;
var TWO_PWR_63_DBL = TWO_PWR_64_DBL / 2;
var TWO_PWR_24 = __fromInt(TWO_PWR_24_DBL);
var ZERO = __fromInt(0);
Long.ZERO = ZERO;
var UZERO = __fromInt(0, true);
Long.UZERO = UZERO;
var ONE = __fromInt(1);
Long.ONE = ONE;
var UONE = __fromInt(1, true);
Long.UONE = UONE;
var NEG_ONE = __fromInt(-1);
Long.NEG_ONE = NEG_ONE;
var MAX_VALUE = new Long(0xFFFFFFFF|0, 0x7FFFFFFF|0, false);
Long.MAX_VALUE = MAX_VALUE;
var MAX_UNSIGNED_VALUE = new Long(0xFFFFFFFF|0, 0xFFFFFFFF|0, true);
Long.MAX_UNSIGNED_VALUE = MAX_UNSIGNED_VALUE;
var MIN_VALUE = new Long(0, 0x80000000|0, false);
Long.MIN_VALUE = MIN_VALUE;
var __lp = Long.prototype;
__lp.toInt = function() {return this.unsigned ? this.low >>> 0 : this.low;};
__lp.toNumber = function() {
    if (this.unsigned)
        return ((this.high >>> 0) * TWO_PWR_32_DBL) + (this.low >>> 0);
    return this.high * TWO_PWR_32_DBL + (this.low >>> 0);
};
__lp.isZero = function() {return this.high === 0 && this.low === 0;};
__lp.isNegative = function() {return !this.unsigned && this.high < 0;};
__lp.isOdd = function() {return (this.low & 1) === 1;};
__lp.eq = function(other) {
    if (this.unsigned !== other.unsigned && (this.high >>> 31) === 1 && (other.high >>> 31) === 1)
        return false;
    return this.high === other.high && this.low === other.low;
};
__lp.neq = function(other) {return !this.eq(other);};
__lp.lt = function(other) {return this.comp(other) < 0;};
__lp.lte = function(other) {return this.comp(other) <= 0;};
__lp.gt = function(other) {return this.comp(other) > 0;};
__lp.gte = function(other) {return this.comp(other) >= 0;};
__lp.compare = function(other) {
    if (this.eq(other))
        return 0;
    var thisNeg = this.isNegative(),
        otherNeg = other.isNegative();
    if (thisNeg && !otherNeg)
        return -1;
    if (!thisNeg && otherNeg)
        return 1;
    if (!this.unsigned)
        return this.sub(other).isNegative() ? -1 : 1;
    return (other.high >>> 0) > (this.high >>> 0) || (other.high === this.high && (other.low >>> 0) > (this.low >>> 0)) ? -1 : 1;
};
__lp.comp = __lp.compare;
__lp.negate = function() {
    if (!this.unsigned && this.eq(MIN_VALUE))
        return MIN_VALUE;
    return this.not().add(ONE);
};
__lp.neg = __lp.negate;
__lp.add = function(addend) {
    var a48 = this.high >>> 16;
    var a32 = this.high & 0xFFFF;
    var a16 = this.low >>> 16;
    var a00 = this.low & 0xFFFF;

    var b48 = addend.high >>> 16;
    var b32 = addend.high & 0xFFFF;
    var b16 = addend.low >>> 16;
    var b00 = addend.low & 0xFFFF;

    var c48 = 0, c32 = 0, c16 = 0, c00 = 0;
    c00 += a00 + b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 + b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 + b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 + b48;
    c48 &= 0xFFFF;
    return new Long((c16 << 16) | c00, (c48 << 16) | c32, this.unsigned);
};
__lp.subtract = function(subtrahend) {return this.add(subtrahend.neg());};
__lp.sub = __lp.subtract;
__lp.multiply = function(multiplier) {
    if (this.isZero())
        return ZERO;
    if (multiplier.isZero())
        return ZERO;
    if (this.eq(MIN_VALUE))
        return multiplier.isOdd() ? MIN_VALUE : ZERO;
    if (multiplier.eq(MIN_VALUE))
        return this.isOdd() ? MIN_VALUE : ZERO;

    if (this.isNegative()) {
        if (multiplier.isNegative())
            return this.neg().mul(multiplier.neg());
        else
            return this.neg().mul(multiplier).neg();
    } else if (multiplier.isNegative())
        return this.mul(multiplier.neg()).neg();

    if (this.lt(TWO_PWR_24) && multiplier.lt(TWO_PWR_24))
        return __fromNumber(this.toNumber() * multiplier.toNumber(), this.unsigned);

    var a48 = this.high >>> 16;
    var a32 = this.high & 0xFFFF;
    var a16 = this.low >>> 16;
    var a00 = this.low & 0xFFFF;

    var b48 = multiplier.high >>> 16;
    var b32 = multiplier.high & 0xFFFF;
    var b16 = multiplier.low >>> 16;
    var b00 = multiplier.low & 0xFFFF;

    var c48 = 0, c32 = 0, c16 = 0, c00 = 0;
    c00 += a00 * b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 * b00;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c16 += a00 * b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 * b00;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a16 * b16;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a00 * b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 * b00 + a32 * b16 + a16 * b32 + a00 * b48;
    c48 &= 0xFFFF;
    return new Long((c16 << 16) | c00, (c48 << 16) | c32, this.unsigned);
};
__lp.mul = __lp.multiply;
__lp.divide = function(divisor) {
    if (divisor.isZero())
        throw Error('division by zero');
    if (this.isZero())
        return this.unsigned ? UZERO : ZERO;
    var approx, rem, res;
    if (this.eq(MIN_VALUE)) {
        if (divisor.eq(ONE) || divisor.eq(NEG_ONE))
            return MIN_VALUE;
        else if (divisor.eq(MIN_VALUE))
            return ONE;
        else {
            var halfThis = this.shr(1);
            approx = halfThis.div(divisor).shl(1);
            if (approx.eq(ZERO)) {
                return divisor.isNegative() ? ONE : NEG_ONE;
            } else {
                rem = this.sub(divisor.mul(approx));
                res = approx.add(rem.div(divisor));
                return res;
            }
        }
    } else if (divisor.eq(MIN_VALUE))
        return this.unsigned ? UZERO : ZERO;
    if (this.isNegative()) {
        if (divisor.isNegative())
            return this.neg().div(divisor.neg());
        return this.neg().div(divisor).neg();
    } else if (divisor.isNegative())
        return this.div(divisor.neg()).neg();

    res = ZERO;
    rem = this;
    while (rem.gte(divisor)) {
        approx = Math.max(1, Math.floor(rem.toNumber() / divisor.toNumber()));
        var log2 = Math.ceil(Math.log(approx) / Math.LN2),
            delta = (log2 <= 48) ? 1 : pow_dbl(2, log2 - 48),
            approxRes = __fromNumber(approx),
            approxRem = approxRes.mul(divisor);
        while (approxRem.isNegative() || approxRem.gt(rem)) {
            approx -= delta;
            approxRes = __fromNumber(approx, this.unsigned);
            approxRem = approxRes.mul(divisor);
        }
        if (approxRes.isZero())
            approxRes = ONE;

        res = res.add(approxRes);
        rem = rem.sub(approxRem);
    }
    return res;
};
__lp.div = __lp.divide;
__lp.modulo = function(divisor) {return this.sub(this.div(divisor).mul(divisor));};
__lp.mod = __lp.modulo;
__lp.not = function not() {return new Long(~this.low, ~this.high, this.unsigned);};
__lp.and = function(other) {return new Long(this.low & other.low, this.high & other.high, this.unsigned);};
__lp.or = function(other) {return new Long(this.low | other.low, this.high | other.high, this.unsigned);};
__lp.xor = function(other) {return new Long(this.low ^ other.low, this.high ^ other.high, this.unsigned);};

__lp.shl = function(numBits) {
    if ((numBits &= 63) === 0)
        return this;
    else if (numBits < 32)
        return new Long(this.low << numBits, (this.high << numBits) | (this.low >>> (32 - numBits)), this.unsigned);
    else
        return new Long(0, this.low << (numBits - 32), this.unsigned);
};

__lp.shr = function(numBits) {
    if ((numBits &= 63) === 0)
        return this;
    else if (numBits < 32)
        return new Long((this.low >>> numBits) | (this.high << (32 - numBits)), this.high >> numBits, this.unsigned);
    else
        return new Long(this.high >> (numBits - 32), this.high >= 0 ? 0 : -1, this.unsigned);
};

__lp.shru = function(numBits) {
    numBits &= 63;
    if (numBits === 0)
        return this;
    else {
        var high = this.high;
        if (numBits < 32) {
            var low = this.low;
            return new Long((low >>> numBits) | (high << (32 - numBits)), high >>> numBits, this.unsigned);
        } else if (numBits === 32)
            return new Long(high, 0, this.unsigned);
        else
            return new Long(high >>> (numBits - 32), 0, this.unsigned);
    }
};

__lp.toSigned = function() {return this.unsigned ? new Long(this.low, this.high, false) : this;};
__lp.toUnsigned = function() {return this.unsigned ? this : new Long(this.low, this.high, true);};

// Int64
function hs_eqInt64(x, y) {return x.eq(y);}
function hs_neInt64(x, y) {return x.neq(y);}
function hs_ltInt64(x, y) {return x.lt(y);}
function hs_leInt64(x, y) {return x.lte(y);}
function hs_gtInt64(x, y) {return x.gt(y);}
function hs_geInt64(x, y) {return x.gte(y);}
function hs_quotInt64(x, y) {return x.div(y);}
function hs_remInt64(x, y) {return x.modulo(y);}
function hs_plusInt64(x, y) {return x.add(y);}
function hs_minusInt64(x, y) {return x.subtract(y);}
function hs_timesInt64(x, y) {return x.multiply(y);}
function hs_negateInt64(x) {return x.negate();}
function hs_uncheckedIShiftL64(x, bits) {return x.shl(bits);}
function hs_uncheckedIShiftRA64(x, bits) {return x.shr(bits);}
function hs_uncheckedIShiftRL64(x, bits) {return x.shru(bits);}
function hs_int64ToInt(x) {return x.toInt();}
var hs_intToInt64 = __fromInt;

// Word64
function hs_wordToWord64(x) {return __fromInt(x, true);}
function hs_word64ToWord(x) {return x.toInt(x);}
function hs_mkWord64(low, high) {return new Long(low,high,true);}
function hs_and64(a,b) {return a.and(b);};
function hs_or64(a,b) {return a.or(b);};
function hs_xor64(a,b) {return a.xor(b);};
function hs_not64(x) {return x.not();}
var hs_eqWord64 = hs_eqInt64;
var hs_neWord64 = hs_neInt64;
var hs_ltWord64 = hs_ltInt64;
var hs_leWord64 = hs_leInt64;
var hs_gtWord64 = hs_gtInt64;
var hs_geWord64 = hs_geInt64;
var hs_quotWord64 = hs_quotInt64;
var hs_remWord64 = hs_remInt64;
var hs_uncheckedShiftL64 = hs_uncheckedIShiftL64;
var hs_uncheckedShiftRL64 = hs_uncheckedIShiftRL64;
function hs_int64ToWord64(x) {return x.toUnsigned();}
function hs_word64ToInt64(x) {return x.toSigned();}

// Joseph Myers' MD5 implementation, ported to work on typed arrays.
// Used under the BSD license.
function md5cycle(x, k) {
    var a = x[0], b = x[1], c = x[2], d = x[3];

    a = ff(a, b, c, d, k[0], 7, -680876936);
    d = ff(d, a, b, c, k[1], 12, -389564586);
    c = ff(c, d, a, b, k[2], 17,  606105819);
    b = ff(b, c, d, a, k[3], 22, -1044525330);
    a = ff(a, b, c, d, k[4], 7, -176418897);
    d = ff(d, a, b, c, k[5], 12,  1200080426);
    c = ff(c, d, a, b, k[6], 17, -1473231341);
    b = ff(b, c, d, a, k[7], 22, -45705983);
    a = ff(a, b, c, d, k[8], 7,  1770035416);
    d = ff(d, a, b, c, k[9], 12, -1958414417);
    c = ff(c, d, a, b, k[10], 17, -42063);
    b = ff(b, c, d, a, k[11], 22, -1990404162);
    a = ff(a, b, c, d, k[12], 7,  1804603682);
    d = ff(d, a, b, c, k[13], 12, -40341101);
    c = ff(c, d, a, b, k[14], 17, -1502002290);
    b = ff(b, c, d, a, k[15], 22,  1236535329);

    a = gg(a, b, c, d, k[1], 5, -165796510);
    d = gg(d, a, b, c, k[6], 9, -1069501632);
    c = gg(c, d, a, b, k[11], 14,  643717713);
    b = gg(b, c, d, a, k[0], 20, -373897302);
    a = gg(a, b, c, d, k[5], 5, -701558691);
    d = gg(d, a, b, c, k[10], 9,  38016083);
    c = gg(c, d, a, b, k[15], 14, -660478335);
    b = gg(b, c, d, a, k[4], 20, -405537848);
    a = gg(a, b, c, d, k[9], 5,  568446438);
    d = gg(d, a, b, c, k[14], 9, -1019803690);
    c = gg(c, d, a, b, k[3], 14, -187363961);
    b = gg(b, c, d, a, k[8], 20,  1163531501);
    a = gg(a, b, c, d, k[13], 5, -1444681467);
    d = gg(d, a, b, c, k[2], 9, -51403784);
    c = gg(c, d, a, b, k[7], 14,  1735328473);
    b = gg(b, c, d, a, k[12], 20, -1926607734);

    a = hh(a, b, c, d, k[5], 4, -378558);
    d = hh(d, a, b, c, k[8], 11, -2022574463);
    c = hh(c, d, a, b, k[11], 16,  1839030562);
    b = hh(b, c, d, a, k[14], 23, -35309556);
    a = hh(a, b, c, d, k[1], 4, -1530992060);
    d = hh(d, a, b, c, k[4], 11,  1272893353);
    c = hh(c, d, a, b, k[7], 16, -155497632);
    b = hh(b, c, d, a, k[10], 23, -1094730640);
    a = hh(a, b, c, d, k[13], 4,  681279174);
    d = hh(d, a, b, c, k[0], 11, -358537222);
    c = hh(c, d, a, b, k[3], 16, -722521979);
    b = hh(b, c, d, a, k[6], 23,  76029189);
    a = hh(a, b, c, d, k[9], 4, -640364487);
    d = hh(d, a, b, c, k[12], 11, -421815835);
    c = hh(c, d, a, b, k[15], 16,  530742520);
    b = hh(b, c, d, a, k[2], 23, -995338651);

    a = ii(a, b, c, d, k[0], 6, -198630844);
    d = ii(d, a, b, c, k[7], 10,  1126891415);
    c = ii(c, d, a, b, k[14], 15, -1416354905);
    b = ii(b, c, d, a, k[5], 21, -57434055);
    a = ii(a, b, c, d, k[12], 6,  1700485571);
    d = ii(d, a, b, c, k[3], 10, -1894986606);
    c = ii(c, d, a, b, k[10], 15, -1051523);
    b = ii(b, c, d, a, k[1], 21, -2054922799);
    a = ii(a, b, c, d, k[8], 6,  1873313359);
    d = ii(d, a, b, c, k[15], 10, -30611744);
    c = ii(c, d, a, b, k[6], 15, -1560198380);
    b = ii(b, c, d, a, k[13], 21,  1309151649);
    a = ii(a, b, c, d, k[4], 6, -145523070);
    d = ii(d, a, b, c, k[11], 10, -1120210379);
    c = ii(c, d, a, b, k[2], 15,  718787259);
    b = ii(b, c, d, a, k[9], 21, -343485551);

    x[0] = add32(a, x[0]);
    x[1] = add32(b, x[1]);
    x[2] = add32(c, x[2]);
    x[3] = add32(d, x[3]);

}

function cmn(q, a, b, x, s, t) {
    a = add32(add32(a, q), add32(x, t));
    return add32((a << s) | (a >>> (32 - s)), b);
}

function ff(a, b, c, d, x, s, t) {
    return cmn((b & c) | ((~b) & d), a, b, x, s, t);
}

function gg(a, b, c, d, x, s, t) {
    return cmn((b & d) | (c & (~d)), a, b, x, s, t);
}

function hh(a, b, c, d, x, s, t) {
    return cmn(b ^ c ^ d, a, b, x, s, t);
}

function ii(a, b, c, d, x, s, t) {
    return cmn(c ^ (b | (~d)), a, b, x, s, t);
}

function md51(s, n) {
    var a = s['v']['w8'];
    var orig_n = n,
        state = [1732584193, -271733879, -1732584194, 271733878], i;
    for (i=64; i<=n; i+=64) {
        md5cycle(state, md5blk(a.subarray(i-64, i)));
    }
    a = a.subarray(i-64);
    n = n < (i-64) ? 0 : n-(i-64);
    var tail = [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0];
    for (i=0; i<n; i++)
        tail[i>>2] |= a[i] << ((i%4) << 3);
    tail[i>>2] |= 0x80 << ((i%4) << 3);
    if (i > 55) {
        md5cycle(state, tail);
        for (i=0; i<16; i++) tail[i] = 0;
    }
    tail[14] = orig_n*8;
    md5cycle(state, tail);
    return state;
}
window['md51'] = md51;

function md5blk(s) {
    var md5blks = [], i;
    for (i=0; i<64; i+=4) {
        md5blks[i>>2] = s[i]
            + (s[i+1] << 8)
            + (s[i+2] << 16)
            + (s[i+3] << 24);
    }
    return md5blks;
}

var hex_chr = '0123456789abcdef'.split('');

function rhex(n)
{
    var s='', j=0;
    for(; j<4; j++)
        s += hex_chr[(n >> (j * 8 + 4)) & 0x0F]
        + hex_chr[(n >> (j * 8)) & 0x0F];
    return s;
}

function hex(x) {
    for (var i=0; i<x.length; i++)
        x[i] = rhex(x[i]);
    return x.join('');
}

function md5(s, n) {
    return hex(md51(s, n));
}

window['md5'] = md5;

function add32(a, b) {
    return (a + b) & 0xFFFFFFFF;
}

function __hsbase_MD5Init(ctx) {}
// Note that this is a one time "update", since that's all that's used by
// GHC.Fingerprint.
function __hsbase_MD5Update(ctx, s, n) {
    ctx.md5 = md51(s, n);
}
function __hsbase_MD5Final(out, ctx) {
    var a = out['v']['i32'];
    a[0] = ctx.md5[0];
    a[1] = ctx.md5[1];
    a[2] = ctx.md5[2];
    a[3] = ctx.md5[3];
}

// Functions for dealing with arrays.

function newArr(n, x) {
    var arr = new Array(n);
    for(var i = 0; i < n; ++i) {
        arr[i] = x;
    }
    return arr;
}

// Create all views at once; perhaps it's wasteful, but it's better than having
// to check for the right view at each read or write.
function newByteArr(n) {
    // Pad the thing to multiples of 8.
    var padding = 8 - n % 8;
    if(padding < 8) {
        n += padding;
    }
    return new ByteArray(new ArrayBuffer(n));
}

// Wrap a JS ArrayBuffer into a ByteArray. Truncates the array length to the
// closest multiple of 8 bytes.
function wrapByteArr(buffer) {
    var diff = buffer.byteLength % 8;
    if(diff != 0) {
        var buffer = buffer.slice(0, buffer.byteLength-diff);
    }
    return new ByteArray(buffer);
}

function ByteArray(buffer) {
    var views =
        { 'i8' : new Int8Array(buffer)
        , 'i16': new Int16Array(buffer)
        , 'i32': new Int32Array(buffer)
        , 'w8' : new Uint8Array(buffer)
        , 'w16': new Uint16Array(buffer)
        , 'w32': new Uint32Array(buffer)
        , 'f32': new Float32Array(buffer)
        , 'f64': new Float64Array(buffer)
        };
    this['b'] = buffer;
    this['v'] = views;
    this['off'] = 0;
}
window['newArr'] = newArr;
window['newByteArr'] = newByteArr;
window['wrapByteArr'] = wrapByteArr;
window['ByteArray'] = ByteArray;

// An attempt at emulating pointers enough for ByteString and Text to be
// usable without patching the hell out of them.
// The general idea is that Addr# is a byte array with an associated offset.

function plusAddr(addr, off) {
    var newaddr = {};
    newaddr['off'] = addr['off'] + off;
    newaddr['b']   = addr['b'];
    newaddr['v']   = addr['v'];
    return newaddr;
}

function writeOffAddr(type, elemsize, addr, off, x) {
    addr['v'][type][addr.off/elemsize + off] = x;
}

function writeOffAddr64(addr, off, x) {
    addr['v']['w32'][addr.off/8 + off*2] = x.low;
    addr['v']['w32'][addr.off/8 + off*2 + 1] = x.high;
}

function readOffAddr(type, elemsize, addr, off) {
    return addr['v'][type][addr.off/elemsize + off];
}

function readOffAddr64(signed, addr, off) {
    var w64 = hs_mkWord64( addr['v']['w32'][addr.off/8 + off*2]
                         , addr['v']['w32'][addr.off/8 + off*2 + 1]);
    return signed ? hs_word64ToInt64(w64) : w64;
}

// Two addresses are equal if they point to the same buffer and have the same
// offset. For other comparisons, just use the offsets - nobody in their right
// mind would check if one pointer is less than another, completely unrelated,
// pointer and then act on that information anyway.
function addrEq(a, b) {
    if(a == b) {
        return true;
    }
    return a && b && a['b'] == b['b'] && a['off'] == b['off'];
}

function addrLT(a, b) {
    if(a) {
        return b && a['off'] < b['off'];
    } else {
        return (b != 0); 
    }
}

function addrGT(a, b) {
    if(b) {
        return a && a['off'] > b['off'];
    } else {
        return (a != 0);
    }
}

function withChar(f, charCode) {
    return f(String.fromCharCode(charCode)).charCodeAt(0);
}

function u_towlower(charCode) {
    return withChar(function(c) {return c.toLowerCase()}, charCode);
}

function u_towupper(charCode) {
    return withChar(function(c) {return c.toUpperCase()}, charCode);
}

var u_towtitle = u_towupper;

function u_iswupper(charCode) {
    var c = String.fromCharCode(charCode);
    return c == c.toUpperCase() && c != c.toLowerCase();
}

function u_iswlower(charCode) {
    var c = String.fromCharCode(charCode);
    return  c == c.toLowerCase() && c != c.toUpperCase();
}

function u_iswdigit(charCode) {
    return charCode >= 48 && charCode <= 57;
}

function u_iswcntrl(charCode) {
    return charCode <= 0x1f || charCode == 0x7f;
}

function u_iswspace(charCode) {
    var c = String.fromCharCode(charCode);
    return c.replace(/\s/g,'') != c;
}

function u_iswalpha(charCode) {
    var c = String.fromCharCode(charCode);
    return c.replace(__hs_alphare, '') != c;
}

function u_iswalnum(charCode) {
    return u_iswdigit(charCode) || u_iswalpha(charCode);
}

function u_iswprint(charCode) {
    return !u_iswcntrl(charCode);
}

function u_gencat(c) {
    throw 'u_gencat is only supported with --full-unicode.';
}

// Regex that matches any alphabetic character in any language. Horrible thing.
var __hs_alphare = /[\u0041-\u005A\u0061-\u007A\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]/g;

// Simulate handles.
// When implementing new handles, remember that passed strings may be thunks,
// and so need to be evaluated before use.

function jsNewHandle(init, read, write, flush, close, seek, tell) {
    var h = {
        read: read || function() {},
        write: write || function() {},
        seek: seek || function() {},
        tell: tell || function() {},
        close: close || function() {},
        flush: flush || function() {}
    };
    init.call(h);
    return h;
}

function jsReadHandle(h, len) {return h.read(len);}
function jsWriteHandle(h, str) {return h.write(str);}
function jsFlushHandle(h) {return h.flush();}
function jsCloseHandle(h) {return h.close();}

function jsMkConWriter(op) {
    return function(str) {
        str = E(str);
        var lines = (this.buf + str).split('\n');
        for(var i = 0; i < lines.length-1; ++i) {
            op.call(console, lines[i]);
        }
        this.buf = lines[lines.length-1];
    }
}

function jsMkStdout() {
    return jsNewHandle(
        function() {this.buf = '';},
        function(_) {return '';},
        jsMkConWriter(console.log),
        function() {console.log(this.buf); this.buf = '';}
    );
}

function jsMkStderr() {
    return jsNewHandle(
        function() {this.buf = '';},
        function(_) {return '';},
        jsMkConWriter(console.warn),
        function() {console.warn(this.buf); this.buf = '';}
    );
}

function jsMkStdin() {
    return jsNewHandle(
        function() {this.buf = '';},
        function(len) {
            while(this.buf.length < len) {
                this.buf += prompt('[stdin]') + '\n';
            }
            var ret = this.buf.substr(0, len);
            this.buf = this.buf.substr(len);
            return ret;
        }
    );
}

// "Weak Pointers". Mostly useless implementation since
// JS does its own GC.

function mkWeak(key, val, fin) {
    fin = !fin? function() {}: fin;
    return {key: key, val: val, fin: fin};
}

function derefWeak(w) {
    return {_:0, a:1, b:E(w).val};
}

function finalizeWeak(w) {
    return {_:0, a:B(A1(E(w).fin, __Z))};
}

/* For foreign import ccall "wrapper" */
function createAdjustor(args, f, a, b) {
    return function(){
        var x = f.apply(null, arguments);
        while(x instanceof F) {x = x.f();}
        return x;
    };
}

var __apply = function(f,as) {
    var arr = [];
    for(; as._ === 1; as = as.b) {
        arr.push(as.a);
    }
    arr.reverse();
    return f.apply(null, arr);
}
var __app0 = function(f) {return f();}
var __app1 = function(f,a) {return f(a);}
var __app2 = function(f,a,b) {return f(a,b);}
var __app3 = function(f,a,b,c) {return f(a,b,c);}
var __app4 = function(f,a,b,c,d) {return f(a,b,c,d);}
var __app5 = function(f,a,b,c,d,e) {return f(a,b,c,d,e);}
var __jsNull = function() {return null;}
var __eq = function(a,b) {return a===b;}
var __createJSFunc = function(arity, f){
    if(f instanceof Function && arity === f.length) {
        return (function() {
            var x = f.apply(null,arguments);
            if(x instanceof T) {
                if(x.f !== __blackhole) {
                    var ff = x.f;
                    x.f = __blackhole;
                    return x.x = ff();
                }
                return x.x;
            } else {
                while(x instanceof F) {
                    x = x.f();
                }
                return E(x);
            }
        });
    } else {
        return (function(){
            var as = Array.prototype.slice.call(arguments);
            as.push(0);
            return E(B(A(f,as)));
        });
    }
}


function __arr2lst(elem,arr) {
    if(elem >= arr.length) {
        return __Z;
    }
    return {_:1,
            a:arr[elem],
            b:new T(function(){return __arr2lst(elem+1,arr);})};
}

function __lst2arr(xs) {
    var arr = [];
    xs = E(xs);
    for(;xs._ === 1; xs = E(xs.b)) {
        arr.push(E(xs.a));
    }
    return arr;
}

var __new = function() {return ({});}
var __set = function(o,k,v) {o[k]=v;}
var __get = function(o,k) {return o[k];}
var __has = function(o,k) {return o[k]!==undefined;}

var _0=0,_1=function(_){return _0;},_2=function(_3,_4){while(1){var _5=E(_3);if(!_5._){return E(_4);}else{_3=_5.b;_4=_5.a;continue;}}},_6=function(_7,_8,_9){return new F(function(){return _2(_8,_7);});},_a=function(_b,_c){var _d=E(_b);return (_d._==0)?E(_c):new T2(1,_d.a,new T(function(){return B(_a(_d.b,_c));}));},_e=new T(function(){return B(unCStr("!!: negative index"));}),_f=new T(function(){return B(unCStr("Prelude."));}),_g=new T(function(){return B(_a(_f,_e));}),_h=new T(function(){return B(err(_g));}),_i=new T(function(){return B(unCStr("!!: index too large"));}),_j=new T(function(){return B(_a(_f,_i));}),_k=new T(function(){return B(err(_j));}),_l=function(_m,_n){while(1){var _o=E(_m);if(!_o._){return E(_k);}else{var _p=E(_n);if(!_p){return E(_o.a);}else{_m=_o.b;_n=_p-1|0;continue;}}}},_q=function(_r,_s){if(_s>=0){return new F(function(){return _l(_r,_s);});}else{return E(_h);}},_t=function(_u){return E(E(_u).a);},_v=function(_w,_x,_y){while(1){var _z=E(_x);if(!_z._){return (E(_y)._==0)?true:false;}else{var _A=E(_y);if(!_A._){return false;}else{if(!B(A3(_t,_w,_z.a,_A.a))){return false;}else{_x=_z.b;_y=_A.b;continue;}}}}},_B=function(_C,_D,_E,_F,_G,_H){return (_C!=_F)?true:(E(_D)!=E(_G))?true:(E(_E)!=E(_H))?true:false;},_I=function(_J,_K){var _L=E(_J),_M=E(_L.a),_N=E(_K),_O=E(_N.a);return new F(function(){return _B(E(_M.a),_M.b,_L.b,E(_O.a),_O.b,_N.b);});},_P=function(_Q,_R){return E(_Q)==E(_R);},_S=function(_T,_U,_V,_W,_X,_Y){if(_T!=_W){return false;}else{if(E(_U)!=E(_X)){return false;}else{return new F(function(){return _P(_V,_Y);});}}},_Z=function(_10,_11){var _12=E(_10),_13=E(_12.a),_14=E(_11),_15=E(_14.a);return new F(function(){return _S(E(_13.a),_13.b,_12.b,E(_15.a),_15.b,_14.b);});},_16=new T2(0,_Z,_I),_17=function(_18,_19,_1a,_1b,_1c,_1d,_1e,_1f,_1g,_1h){while(1){var _1i=E(_1h);if(!_1i._){return {_:0,a:_18,b:_19,c:_1a,d:_1b,e:_1c,f:_1d,g:_1e,h:_1f,i:_1g};}else{var _1j=_1i.b,_1k=E(_1i.a),_1l=E(_1k.h);if(_1l<=_1f){_1h=_1j;continue;}else{_18=_1k.a;_19=_1k.b;_1a=_1k.c;_1b=_1k.d;_1c=_1k.e;_1d=_1k.f;_1e=_1k.g;_1f=_1l;_1g=_1k.i;_1h=_1j;continue;}}}},_1m=function(_1n,_1o,_1p,_1q,_1r,_1s,_1t,_1u,_1v,_1w){while(1){var _1x=E(_1w);if(!_1x._){return {_:0,a:_1n,b:_1o,c:_1p,d:_1q,e:_1r,f:_1s,g:_1t,h:_1u,i:_1v};}else{var _1y=_1x.b,_1z=E(_1x.a),_1A=E(_1z.h);if(_1A>=_1u){_1w=_1y;continue;}else{_1n=_1z.a;_1o=_1z.b;_1p=_1z.c;_1q=_1z.d;_1r=_1z.e;_1s=_1z.f;_1t=_1z.g;_1u=_1A;_1v=_1z.i;_1w=_1y;continue;}}}},_1B=function(_1C){var _1D=E(_1C);if(!_1D._){return true;}else{var _1E=_1D.b,_1F=E(E(_1D.a).a),_1G=_1F.b,_1H=E(_1F.a),_1I=function(_1J){if(E(_1H)==7){if(E(_1G)==1){return false;}else{return new F(function(){return _1B(_1E);});}}else{return new F(function(){return _1B(_1E);});}};if(E(_1H)==6){if(E(_1G)==1){return false;}else{return new F(function(){return _1I(_);});}}else{return new F(function(){return _1I(_);});}}},_1K=function(_1L,_1M){var _1N=E(E(_1L).a),_1O=_1N.b,_1P=E(_1N.a),_1Q=function(_1R){if(E(_1P)==7){if(E(_1O)==1){return false;}else{return new F(function(){return _1B(_1M);});}}else{return new F(function(){return _1B(_1M);});}};if(E(_1P)==6){if(E(_1O)==1){return false;}else{return new F(function(){return _1Q(_);});}}else{return new F(function(){return _1Q(_);});}},_1S=function(_1T){var _1U=E(_1T);if(!_1U._){return true;}else{var _1V=_1U.b,_1W=E(E(_1U.a).a),_1X=_1W.b,_1Y=E(_1W.a),_1Z=function(_20){var _21=function(_22){if(E(_1Y)==4){if(E(_1X)==1){return false;}else{return new F(function(){return _1S(_1V);});}}else{return new F(function(){return _1S(_1V);});}};if(E(_1Y)==3){if(E(_1X)==1){return false;}else{return new F(function(){return _21(_);});}}else{return new F(function(){return _21(_);});}};if(E(_1Y)==2){if(E(_1X)==1){return false;}else{return new F(function(){return _1Z(_);});}}else{return new F(function(){return _1Z(_);});}}},_23=function(_24,_25){var _26=E(E(_24).a),_27=_26.b,_28=E(_26.a),_29=function(_2a){var _2b=function(_2c){if(E(_28)==4){if(E(_27)==1){return false;}else{return new F(function(){return _1S(_25);});}}else{return new F(function(){return _1S(_25);});}};if(E(_28)==3){if(E(_27)==1){return false;}else{return new F(function(){return _2b(_);});}}else{return new F(function(){return _2b(_);});}};if(E(_28)==2){if(E(_27)==1){return false;}else{return new F(function(){return _29(_);});}}else{return new F(function(){return _29(_);});}},_2d=function(_2e){var _2f=E(_2e);if(!_2f._){return true;}else{var _2g=_2f.b,_2h=E(E(_2f.a).a),_2i=_2h.b,_2j=E(_2h.a),_2k=function(_2l){if(E(_2j)==7){if(E(_2i)==8){return false;}else{return new F(function(){return _2d(_2g);});}}else{return new F(function(){return _2d(_2g);});}};if(E(_2j)==6){if(E(_2i)==8){return false;}else{return new F(function(){return _2k(_);});}}else{return new F(function(){return _2k(_);});}}},_2m=function(_2n,_2o){var _2p=E(E(_2n).a),_2q=_2p.b,_2r=E(_2p.a),_2s=function(_2t){if(E(_2r)==7){if(E(_2q)==8){return false;}else{return new F(function(){return _2d(_2o);});}}else{return new F(function(){return _2d(_2o);});}};if(E(_2r)==6){if(E(_2q)==8){return false;}else{return new F(function(){return _2s(_);});}}else{return new F(function(){return _2s(_);});}},_2u=function(_2v){var _2w=E(_2v);if(!_2w._){return true;}else{var _2x=_2w.b,_2y=E(E(_2w.a).a),_2z=_2y.b,_2A=E(_2y.a),_2B=function(_2C){var _2D=function(_2E){if(E(_2A)==4){if(E(_2z)==8){return false;}else{return new F(function(){return _2u(_2x);});}}else{return new F(function(){return _2u(_2x);});}};if(E(_2A)==3){if(E(_2z)==8){return false;}else{return new F(function(){return _2D(_);});}}else{return new F(function(){return _2D(_);});}};if(E(_2A)==2){if(E(_2z)==1){return false;}else{return new F(function(){return _2B(_);});}}else{return new F(function(){return _2B(_);});}}},_2F=function(_2G,_2H){var _2I=E(E(_2G).a),_2J=_2I.b,_2K=E(_2I.a),_2L=function(_2M){var _2N=function(_2O){if(E(_2K)==4){if(E(_2J)==8){return false;}else{return new F(function(){return _2u(_2H);});}}else{return new F(function(){return _2u(_2H);});}};if(E(_2K)==3){if(E(_2J)==8){return false;}else{return new F(function(){return _2N(_);});}}else{return new F(function(){return _2N(_);});}};if(E(_2K)==2){if(E(_2J)==1){return false;}else{return new F(function(){return _2L(_);});}}else{return new F(function(){return _2L(_);});}},_2P=__Z,_2Q=new T(function(){return B(unCStr("base"));}),_2R=new T(function(){return B(unCStr("Control.Exception.Base"));}),_2S=new T(function(){return B(unCStr("PatternMatchFail"));}),_2T=new T5(0,new Long(18445595,3739165398,true),new Long(52003073,3246954884,true),_2Q,_2R,_2S),_2U=new T5(0,new Long(18445595,3739165398,true),new Long(52003073,3246954884,true),_2T,_2P,_2P),_2V=function(_2W){return E(_2U);},_2X=function(_2Y){return E(E(_2Y).a);},_2Z=function(_30,_31,_32){var _33=B(A1(_30,_)),_34=B(A1(_31,_)),_35=hs_eqWord64(_33.a,_34.a);if(!_35){return __Z;}else{var _36=hs_eqWord64(_33.b,_34.b);return (!_36)?__Z:new T1(1,_32);}},_37=function(_38){var _39=E(_38);return new F(function(){return _2Z(B(_2X(_39.a)),_2V,_39.b);});},_3a=function(_3b){return E(E(_3b).a);},_3c=function(_3d){return new T2(0,_3e,_3d);},_3f=function(_3g,_3h){return new F(function(){return _a(E(_3g).a,_3h);});},_3i=44,_3j=93,_3k=91,_3l=function(_3m,_3n,_3o){var _3p=E(_3n);if(!_3p._){return new F(function(){return unAppCStr("[]",_3o);});}else{var _3q=new T(function(){var _3r=new T(function(){var _3s=function(_3t){var _3u=E(_3t);if(!_3u._){return E(new T2(1,_3j,_3o));}else{var _3v=new T(function(){return B(A2(_3m,_3u.a,new T(function(){return B(_3s(_3u.b));})));});return new T2(1,_3i,_3v);}};return B(_3s(_3p.b));});return B(A2(_3m,_3p.a,_3r));});return new T2(1,_3k,_3q);}},_3w=function(_3x,_3y){return new F(function(){return _3l(_3f,_3x,_3y);});},_3z=function(_3A,_3B,_3C){return new F(function(){return _a(E(_3B).a,_3C);});},_3D=new T3(0,_3z,_3a,_3w),_3e=new T(function(){return new T5(0,_2V,_3D,_3c,_37,_3a);}),_3E=new T(function(){return B(unCStr("Non-exhaustive patterns in"));}),_3F=function(_3G){return E(E(_3G).c);},_3H=function(_3I,_3J){return new F(function(){return die(new T(function(){return B(A2(_3F,_3J,_3I));}));});},_3K=function(_3L,_3M){return new F(function(){return _3H(_3L,_3M);});},_3N=function(_3O,_3P){var _3Q=E(_3P);if(!_3Q._){return new T2(0,_2P,_2P);}else{var _3R=_3Q.a;if(!B(A1(_3O,_3R))){return new T2(0,_2P,_3Q);}else{var _3S=new T(function(){var _3T=B(_3N(_3O,_3Q.b));return new T2(0,_3T.a,_3T.b);});return new T2(0,new T2(1,_3R,new T(function(){return E(E(_3S).a);})),new T(function(){return E(E(_3S).b);}));}}},_3U=32,_3V=new T(function(){return B(unCStr("\n"));}),_3W=function(_3X){return (E(_3X)==124)?false:true;},_3Y=function(_3Z,_40){var _41=B(_3N(_3W,B(unCStr(_3Z)))),_42=_41.a,_43=function(_44,_45){var _46=new T(function(){var _47=new T(function(){return B(_a(_40,new T(function(){return B(_a(_45,_3V));},1)));});return B(unAppCStr(": ",_47));},1);return new F(function(){return _a(_44,_46);});},_48=E(_41.b);if(!_48._){return new F(function(){return _43(_42,_2P);});}else{if(E(_48.a)==124){return new F(function(){return _43(_42,new T2(1,_3U,_48.b));});}else{return new F(function(){return _43(_42,_2P);});}}},_49=function(_4a){return new F(function(){return _3K(new T1(0,new T(function(){return B(_3Y(_4a,_3E));})),_3e);});},_4b=new T(function(){return B(_49("Main.hs:(90,17)-(94,194)|function myrange"));}),_4c=function(_4d,_4e){while(1){var _4f=E(_4d);if(!_4f._){return E(_4e);}else{var _4g=new T2(1,_4f.a,_4e);_4d=_4f.b;_4e=_4g;continue;}}},_4h=new T(function(){return B(_4c(_2P,_2P));}),_4i=function(_4j,_4k,_4l,_4m){var _4n=new T(function(){return _4m>_4k;}),_4o=new T(function(){return _4k>_4m;});if(_4j!=_4l){if(_4k!=_4m){if(_4j>=_4l){if(_4l>=_4j){return E(_4b);}else{if(_4k>=_4m){if(_4l<=_4j){var _4p=function(_4q){var _4r=new T(function(){if(_4q!=_4j){return B(_4p(_4q+1|0));}else{return __Z;}});if(!E(_4n)){var _4s=function(_4t){while(1){var _4u=B((function(_4v){if((_4v-_4q|0)!=(_4k-_4j|0)){if(_4v!=_4k){var _4w=_4v+1|0;_4t=_4w;return __continue;}else{return E(_4r);}}else{return new T2(1,new T2(0,_4q,_4v),new T(function(){if(_4v!=_4k){return B(_4s(_4v+1|0));}else{return E(_4r);}}));}})(_4t));if(_4u!=__continue){return _4u;}}};return new F(function(){return _4s(_4m);});}else{return E(_4r);}};return new F(function(){return _4c(B(_4p(_4l)),_2P);});}else{return E(_4h);}}else{if(_4l<=_4j){var _4x=function(_4y){var _4z=new T(function(){if(_4y!=_4j){return B(_4x(_4y+1|0));}else{return __Z;}});if(!E(_4o)){var _4A=function(_4B){while(1){var _4C=B((function(_4D){if((_4y+_4D|0)!=(_4j+_4k|0)){if(_4D!=_4m){var _4E=_4D+1|0;_4B=_4E;return __continue;}else{return E(_4z);}}else{return new T2(1,new T2(0,_4y,_4D),new T(function(){if(_4D!=_4m){return B(_4A(_4D+1|0));}else{return E(_4z);}}));}})(_4B));if(_4C!=__continue){return _4C;}}};return new F(function(){return _4A(_4k);});}else{return E(_4z);}};return new F(function(){return _4x(_4l);});}else{return __Z;}}}}else{if(_4k>=_4m){if(_4j<=_4l){var _4F=function(_4G){var _4H=new T(function(){if(_4G!=_4l){return B(_4F(_4G+1|0));}else{return __Z;}});if(!E(_4n)){var _4I=function(_4J){while(1){var _4K=B((function(_4L){if((_4G+_4L|0)!=(_4j+_4k|0)){if(_4L!=_4k){var _4M=_4L+1|0;_4J=_4M;return __continue;}else{return E(_4H);}}else{return new T2(1,new T2(0,_4G,_4L),new T(function(){if(_4L!=_4k){return B(_4I(_4L+1|0));}else{return E(_4H);}}));}})(_4J));if(_4K!=__continue){return _4K;}}};return new F(function(){return _4I(_4m);});}else{return E(_4H);}};return new F(function(){return _4c(B(_4F(_4j)),_2P);});}else{return E(_4h);}}else{if(_4j<=_4l){var _4N=function(_4O){var _4P=new T(function(){if(_4O!=_4l){return B(_4N(_4O+1|0));}else{return __Z;}});if(!E(_4o)){var _4Q=function(_4R){while(1){var _4S=B((function(_4T){if((_4T-_4O|0)!=(_4k-_4j|0)){if(_4T!=_4m){var _4U=_4T+1|0;_4R=_4U;return __continue;}else{return E(_4P);}}else{return new T2(1,new T2(0,_4O,_4T),new T(function(){if(_4T!=_4m){return B(_4Q(_4T+1|0));}else{return E(_4P);}}));}})(_4R));if(_4S!=__continue){return _4S;}}};return new F(function(){return _4Q(_4k);});}else{return E(_4P);}};return new F(function(){return _4N(_4j);});}else{return __Z;}}}}else{if(_4j>=_4l){if(_4l<=_4j){var _4V=function(_4W){var _4X=new T(function(){if(_4W!=_4j){return B(_4V(_4W+1|0));}else{return __Z;}});if(!E(_4n)){var _4Y=function(_4Z){return new T2(1,new T2(0,_4W,_4Z),new T(function(){if(_4Z!=_4k){return B(_4Y(_4Z+1|0));}else{return E(_4X);}}));};return new F(function(){return _4Y(_4m);});}else{return E(_4X);}};return new F(function(){return _4c(B(_4V(_4l)),_2P);});}else{return E(_4h);}}else{if(_4j<=_4l){var _50=function(_51){var _52=new T(function(){if(_51!=_4l){return B(_50(_51+1|0));}else{return __Z;}}),_53=function(_54){return new T2(1,new T2(0,_51,_54),new T(function(){if(_54!=_4m){return B(_53(_54+1|0));}else{return E(_52);}}));};return new F(function(){return _53(_4m);});};return new F(function(){return _50(_4j);});}else{return __Z;}}}}else{if(_4k>=_4m){if(_4l<=_4j){var _55=function(_56){var _57=new T(function(){if(_56!=_4j){return B(_55(_56+1|0));}else{return __Z;}});if(!E(_4n)){var _58=function(_59){return new T2(1,new T2(0,_56,_59),new T(function(){if(_59!=_4k){return B(_58(_59+1|0));}else{return E(_57);}}));};return new F(function(){return _58(_4m);});}else{return E(_57);}};return new F(function(){return _4c(B(_55(_4l)),_2P);});}else{return E(_4h);}}else{if(_4j<=_4l){var _5a=function(_5b){var _5c=new T(function(){if(_5b!=_4l){return B(_5a(_5b+1|0));}else{return __Z;}});if(!E(_4o)){var _5d=function(_5e){return new T2(1,new T2(0,_5b,_5e),new T(function(){if(_5e!=_4m){return B(_5d(_5e+1|0));}else{return E(_5c);}}));};return new F(function(){return _5d(_4k);});}else{return E(_5c);}};return new F(function(){return _5a(_4j);});}else{return __Z;}}}},_5f=function(_5g,_5h,_5i,_5j,_5k,_5l,_5m,_5n,_5o,_5p,_5q){var _5r=E(_5q);if(!_5r._){return {_:0,a:_5h,b:_5i,c:_5j,d:_5k,e:_5l,f:_5m,g:_5n,h:_5o,i:_5p};}else{var _5s=_5r.a,_5t=_5r.b;if(!E(_5g)){var _5u=E(_5s),_5v=E(_5u.h),_5w=E(_5o);if(_5v>=_5w){return new F(function(){return _1m(_5h,_5i,_5j,_5k,_5l,_5m,_5n,_5w,_5p,_5t);});}else{return new F(function(){return _1m(_5u.a,_5u.b,_5u.c,_5u.d,_5u.e,_5u.f,_5u.g,_5v,_5u.i,_5t);});}}else{var _5x=E(_5s),_5y=E(_5x.h),_5z=E(_5o);if(_5y<=_5z){return new F(function(){return _17(_5h,_5i,_5j,_5k,_5l,_5m,_5n,_5z,_5p,_5t);});}else{return new F(function(){return _17(_5x.a,_5x.b,_5x.c,_5x.d,_5x.e,_5x.f,_5x.g,_5y,_5x.i,_5t);});}}}},_5A=new T(function(){return B(_49("Main.hs:(198,1)-(200,70)|function replace"));}),_5B=function(_5C,_5D,_5E){var _5F=E(_5C);switch(_5F){case -1:var _5G=E(_5E);return (_5G._==0)?E(_5A):E(_5G);case 0:var _5H=E(_5E);return (_5H._==0)?E(_5A):new T2(1,_5D,_5H.b);default:var _5I=E(_5E);return (_5I._==0)?E(_5A):new T2(1,_5I.a,new T(function(){return B(_5B(_5F-1|0,_5D,_5I.b));}));}},_5J=false,_5K=__Z,_5L=true,_5M=new T(function(){return B(unCStr(": empty list"));}),_5N=function(_5O){return new F(function(){return err(B(_a(_f,new T(function(){return B(_a(_5O,_5M));},1))));});},_5P=new T(function(){return B(unCStr("head"));}),_5Q=new T(function(){return B(_5N(_5P));}),_5R=function(_5S,_5T){while(1){var _5U=B((function(_5V,_5W){var _5X=E(_5W);if(!_5X._){return __Z;}else{var _5Y=_5X.a,_5Z=_5X.b;if(!B(A1(_5V,_5Y))){var _60=_5V;_5S=_60;_5T=_5Z;return __continue;}else{return new T2(1,_5Y,new T(function(){return B(_5R(_5V,_5Z));}));}}})(_5S,_5T));if(_5U!=__continue){return _5U;}}},_61=function(_62){while(1){var _63=B((function(_64){var _65=E(_64);if(!_65._){return true;}else{var _66=_65.b,_67=E(_65.a),_68=u_iswlower(E(_67.b));if(!E(_68)){var _69=E(_67.a),_6a=_69.b,_6b=E(_69.a),_6c=function(_6d){var _6e=function(_6f){if(E(_6b)==5){if(E(_6a)==8){return false;}else{return new F(function(){return _61(_66);});}}else{return new F(function(){return _61(_66);});}};if(E(_6b)==4){if(E(_6a)==8){return false;}else{return new F(function(){return _6e(_);});}}else{return new F(function(){return _6e(_);});}};if(E(_6b)==3){if(E(_6a)==8){return false;}else{return new F(function(){return _6c(_);});}}else{return new F(function(){return _6c(_);});}}else{_62=_66;return __continue;}}})(_62));if(_63!=__continue){return _63;}}},_6g=function(_6h){while(1){var _6i=E(_6h);if(!_6i._){return true;}else{if(!B(_61(_6i.a))){return false;}else{_6h=_6i.b;continue;}}}},_6j=function(_6k){while(1){var _6l=B((function(_6m){var _6n=E(_6m);if(!_6n._){return true;}else{var _6o=_6n.b,_6p=E(_6n.a),_6q=u_iswlower(E(_6p.b));if(!E(_6q)){var _6r=E(_6p.a),_6s=_6r.b,_6t=E(_6r.a),_6u=function(_6v){var _6w=function(_6x){if(E(_6t)==7){if(E(_6s)==8){return false;}else{return new F(function(){return _6j(_6o);});}}else{return new F(function(){return _6j(_6o);});}};if(E(_6t)==6){if(E(_6s)==8){return false;}else{return new F(function(){return _6w(_);});}}else{return new F(function(){return _6w(_);});}};if(E(_6t)==5){if(E(_6s)==8){return false;}else{return new F(function(){return _6u(_);});}}else{return new F(function(){return _6u(_);});}}else{_6k=_6o;return __continue;}}})(_6k));if(_6l!=__continue){return _6l;}}},_6y=function(_6z){while(1){var _6A=E(_6z);if(!_6A._){return true;}else{if(!B(_6j(_6A.a))){return false;}else{_6z=_6A.b;continue;}}}},_6B=function(_6C){while(1){var _6D=B((function(_6E){var _6F=E(_6E);if(!_6F._){return true;}else{var _6G=_6F.b,_6H=E(_6F.a),_6I=u_iswupper(E(_6H.b));if(!E(_6I)){var _6J=E(_6H.a),_6K=_6J.b,_6L=E(_6J.a),_6M=function(_6N){var _6O=function(_6P){if(E(_6L)==5){if(E(_6K)==1){return false;}else{return new F(function(){return _6B(_6G);});}}else{return new F(function(){return _6B(_6G);});}};if(E(_6L)==4){if(E(_6K)==1){return false;}else{return new F(function(){return _6O(_);});}}else{return new F(function(){return _6O(_);});}};if(E(_6L)==3){if(E(_6K)==1){return false;}else{return new F(function(){return _6M(_);});}}else{return new F(function(){return _6M(_);});}}else{_6C=_6G;return __continue;}}})(_6C));if(_6D!=__continue){return _6D;}}},_6Q=function(_6R){while(1){var _6S=E(_6R);if(!_6S._){return true;}else{if(!B(_6B(_6S.a))){return false;}else{_6R=_6S.b;continue;}}}},_6T=function(_6U){while(1){var _6V=B((function(_6W){var _6X=E(_6W);if(!_6X._){return true;}else{var _6Y=_6X.b,_6Z=E(_6X.a),_70=u_iswupper(E(_6Z.b));if(!E(_70)){var _71=E(_6Z.a),_72=_71.b,_73=E(_71.a),_74=function(_75){var _76=function(_77){if(E(_73)==7){if(E(_72)==1){return false;}else{return new F(function(){return _6T(_6Y);});}}else{return new F(function(){return _6T(_6Y);});}};if(E(_73)==6){if(E(_72)==1){return false;}else{return new F(function(){return _76(_);});}}else{return new F(function(){return _76(_);});}};if(E(_73)==5){if(E(_72)==1){return false;}else{return new F(function(){return _74(_);});}}else{return new F(function(){return _74(_);});}}else{_6U=_6Y;return __continue;}}})(_6U));if(_6V!=__continue){return _6V;}}},_78=function(_79){while(1){var _7a=E(_79);if(!_7a._){return true;}else{if(!B(_6T(_7a.a))){return false;}else{_79=_7a.b;continue;}}}},_7b=function(_7c){while(1){var _7d=E(_7c);if(!_7d._){return true;}else{if(!E(_7d.a)){return false;}else{_7c=_7d.b;continue;}}}},_7e=function(_7f,_7g){while(1){var _7h=E(_7f);if(!_7h._){return E(_7g);}else{var _7i=_7h.b;switch(E(E(_7h.a).b)){case 66:var _7j=_7g+3.75;_7f=_7i;_7g=_7j;continue;case 78:var _7j=_7g+3.5;_7f=_7i;_7g=_7j;continue;case 80:var _7j=_7g+1;_7f=_7i;_7g=_7j;continue;case 81:var _7j=_7g+9;_7f=_7i;_7g=_7j;continue;case 82:var _7j=_7g+5;_7f=_7i;_7g=_7j;continue;case 98:var _7j=_7g+(-3.75);_7f=_7i;_7g=_7j;continue;case 110:var _7j=_7g+(-3.5);_7f=_7i;_7g=_7j;continue;case 112:var _7j=_7g+(-1);_7f=_7i;_7g=_7j;continue;case 113:var _7j=_7g+(-9);_7f=_7i;_7g=_7j;continue;case 114:var _7j=_7g+(-5);_7f=_7i;_7g=_7j;continue;default:_7f=_7i;continue;}}}},_7k=function(_7l,_7m){while(1){var _7n=E(_7l);if(!_7n._){return E(_7m);}else{var _7o=_7n.b,_7p=E(_7n.a);if(E(_7p.b)==82){switch(E(E(_7p.a).a)){case 4:var _7q=_7m+0.5;_7l=_7o;_7m=_7q;continue;case 5:var _7q=_7m+0.5;_7l=_7o;_7m=_7q;continue;default:_7l=_7o;continue;}}else{_7l=_7o;continue;}}}},_7r=function(_7s,_7t){while(1){var _7u=E(_7s);if(!_7u._){return E(_7t);}else{var _7v=_7u.b,_7w=E(_7u.a);if(E(_7w.b)==114){switch(E(E(_7w.a).a)){case 4:var _7x=_7t+(-0.5);_7s=_7v;_7t=_7x;continue;case 5:var _7x=_7t+(-0.5);_7s=_7v;_7t=_7x;continue;default:_7s=_7v;continue;}}else{_7s=_7v;continue;}}}},_7y=function(_7z,_7A){while(1){var _7B=E(_7z);if(!_7B._){return E(_7A);}else{var _7C=_7B.b,_7D=E(_7B.a);if(E(_7D.b)==80){var _7E=E(_7D.a),_7F=E(_7E.b);if(_7F<6){switch(E(_7E.a)){case 4:if(_7F<4){_7z=_7C;continue;}else{var _7G=_7A+0.6;_7z=_7C;_7A=_7G;continue;}break;case 5:if(_7F<4){_7z=_7C;continue;}else{var _7G=_7A+0.6;_7z=_7C;_7A=_7G;continue;}break;default:_7z=_7C;continue;}}else{var _7G=_7A+0.6;_7z=_7C;_7A=_7G;continue;}}else{_7z=_7C;continue;}}}},_7H=function(_7I,_7J){while(1){var _7K=E(_7I);if(!_7K._){return E(_7J);}else{var _7L=_7K.b,_7M=E(_7K.a);if(E(_7M.b)==112){var _7N=E(_7M.a),_7O=E(_7N.b);if(_7O>3){switch(E(_7N.a)){case 4:if(_7O>5){_7I=_7L;continue;}else{var _7P=_7J+(-0.6);_7I=_7L;_7J=_7P;continue;}break;case 5:if(_7O>5){_7I=_7L;continue;}else{var _7P=_7J+(-0.6);_7I=_7L;_7J=_7P;continue;}break;default:_7I=_7L;continue;}}else{var _7P=_7J+(-0.6);_7I=_7L;_7J=_7P;continue;}}else{_7I=_7L;continue;}}}},_7Q=function(_7R,_7S){while(1){var _7T=B((function(_7U,_7V){var _7W=E(_7U);if(!_7W._){return E(_7V);}else{var _7X=_7W.b,_7Y=E(_7W.a),_7Z=function(_80){if(E(E(_7Y.a).b)==1){return new F(function(){return _7Q(_7X,_80+(-0.3));});}else{return new F(function(){return _7Q(_7X,_80);});}};switch(E(_7Y.b)){case 66:return new F(function(){return _7Z(_7V);});break;case 78:return new F(function(){return _7Z(_7V);});break;default:var _81=_7V;_7R=_7X;_7S=_81;return __continue;}}})(_7R,_7S));if(_7T!=__continue){return _7T;}}},_82=function(_83,_84){while(1){var _85=B((function(_86,_87){var _88=E(_86);if(!_88._){return E(_87);}else{var _89=_88.b,_8a=E(_88.a),_8b=function(_8c){if(E(E(_8a.a).b)==8){return new F(function(){return _82(_89,_8c+0.3);});}else{return new F(function(){return _82(_89,_8c);});}};switch(E(_8a.b)){case 98:return new F(function(){return _8b(_87);});break;case 110:return new F(function(){return _8b(_87);});break;default:var _8d=_87;_83=_89;_84=_8d;return __continue;}}})(_83,_84));if(_85!=__continue){return _85;}}},_8e=function(_8f,_8g,_8h,_8i,_8j,_8k,_8l,_8m){var _8n=new T(function(){var _8o=B(_7e(_8f,0)),_8p=B(_7k(_8f,0)),_8q=B(_7r(_8f,0)),_8r=B(_7y(_8f,0)),_8s=B(_7H(_8f,0)),_8t=B(_7Q(_8f,0)),_8u=B(_82(_8f,0)),_8v=function(_8w){return (!B(_q(_8i,2)))?(!B(_q(_8i,3)))?(!B(_q(_8h,2)))?(!B(_q(_8h,3)))?_8o+_8p+_8q+_8r+_8s+_8t+_8u+_8w:_8o+_8p+_8q+_8r+_8s+_8t+_8u+_8w+0.5:(!B(_q(_8h,3)))?_8o+_8p+_8q+_8r+_8s+_8t+_8u+_8w+0.5:_8o+_8p+_8q+_8r+_8s+_8t+_8u+_8w+1:_8o+_8p+_8q+_8r+_8s+_8t+_8u+_8w+(-0.9):_8o+_8p+_8q+_8r+_8s+_8t+_8u+_8w+(-0.9);};if(!B(_q(_8i,0))){if(!B(_q(_8i,1))){var _8x=function(_8y){if(!B(_q(_8h,1))){return new F(function(){return _8v(_8y);});}else{return new F(function(){return _8v(_8y+(-0.5));});}};if(!B(_q(_8h,0))){return B(_8x(0));}else{return B(_8x(-0.5));}}else{return B(_8v(0.9));}}else{return B(_8v(0.9));}});return {_:0,a:_8f,b:_8g,c:_8h,d:_8i,e:_8j,f:_8k,g:_8n,h:_8l,i:_8m};},_8z=function(_8A){var _8B=E(_8A),_8C=B(_8e(_8B.a,_8B.b,_8B.c,_8B.d,_8B.e,_8B.f,_8B.h,_8B.i));return {_:0,a:_8C.a,b:_8C.b,c:_8C.c,d:_8C.d,e:_8C.e,f:_8C.f,g:_8C.g,h:_8C.h,i:_8C.i};},_8D=function(_8E,_8F){var _8G=E(_8F);return (_8G._==0)?__Z:new T2(1,_8E,new T(function(){return B(_8D(_8G.a,_8G.b));}));},_8H=new T(function(){return B(unCStr("init"));}),_8I=new T(function(){return B(_5N(_8H));}),_8J=function(_8K){return E(E(_8K).a);},_8L=0,_8M=2,_8N=3,_8O=4,_8P=5,_8Q=6,_8R=0,_8S=new T2(0,_8R,_8R),_8T=function(_8U,_8V){switch(E(_8U)){case 5:return (E(_8V)==1)?false:true;case 8:return (E(_8V)==1)?false:true;default:return true;}},_8W=function(_8X){var _8Y=E(E(_8X).a);return new F(function(){return _8T(E(_8Y.a),_8Y.b);});},_8Z=82,_90=1,_91=new T2(0,_8Q,_90),_92=new T2(0,_91,_8Z),_93=75,_94=7,_95=new T2(0,_94,_90),_96=new T2(0,_95,_93),_97=new T2(0,_8O,_90),_98=new T2(0,_97,_8Z),_99=new T2(0,_8N,_90),_9a=new T2(0,_99,_93),_9b=114,_9c=8,_9d=new T2(0,_8Q,_9c),_9e=new T2(0,_9d,_9b),_9f=107,_9g=new T2(0,_94,_9c),_9h=new T2(0,_9g,_9f),_9i=new T2(0,_8O,_9c),_9j=new T2(0,_9i,_8Z),_9k=new T2(0,_8N,_9c),_9l=new T2(0,_9k,_9f),_9m=function(_9n,_9o){if(_9n<=_9o){var _9p=function(_9q){return new T2(1,_9q,new T(function(){if(_9q!=_9o){return B(_9p(_9q+1|0));}else{return __Z;}}));};return new F(function(){return _9p(_9n);});}else{return __Z;}},_9r=new T(function(){return B(_9m(-8,8));}),_9s=function(_9t){var _9u=new T(function(){var _9v=E(_9t);if(_9v==8){return __Z;}else{return B(_9s(_9v+1|0));}}),_9w=function(_9x){return new T2(1,new T2(0,_9t,_9x),new T(function(){var _9y=E(_9x);if(!_9y){return E(_9u);}else{return B(_9w(_9y+1|0));}}));};return new F(function(){return _9w(0);});},_9z=new T(function(){return B(_9s(-8));}),_9A=function(_9B){var _9C=new T(function(){var _9D=E(_9B);if(!_9D){return __Z;}else{return B(_9A(_9D+1|0));}}),_9E=function(_9F){return new T2(1,new T2(0,_9B,_9F),new T(function(){var _9G=E(_9F);if(_9G==8){return E(_9C);}else{return B(_9E(_9G+1|0));}}));};return new F(function(){return _9E(-8);});},_9H=new T(function(){return B(_9A(0));}),_9I=81,_9J=78,_9K=66,_9L=function(_9M){var _9N=new T(function(){var _9O=E(_9M);if(_9O==8){return __Z;}else{return B(_9L(_9O+1|0));}}),_9P=function(_9Q){return new T2(1,new T2(0,_9M,_9Q),new T(function(){var _9R=E(_9Q);if(!_9R){return E(_9N);}else{return B(_9P(_9R+1|0));}}));};return new F(function(){return _9P(0);});},_9S=new T(function(){return B(_9L(-8));}),_9T=function(_9U){var _9V=new T(function(){var _9W=E(_9U);if(!_9W){return __Z;}else{return B(_9T(_9W+1|0));}}),_9X=function(_9Y){return new T2(1,new T2(0,_9U,_9Y),new T(function(){var _9Z=E(_9Y);if(_9Z==8){return E(_9V);}else{return B(_9X(_9Z+1|0));}}));};return new F(function(){return _9X(-8);});},_a0=new T(function(){return B(_9T(0));}),_a1=80,_a2=function(_a3){var _a4=new T(function(){var _a5=E(_a3);if(_a5==8){return __Z;}else{return B(_a2(_a5+1|0));}}),_a6=function(_a7){return new T2(1,new T2(0,_a3,_a7),new T(function(){var _a8=E(_a7);if(!_a8){return E(_a4);}else{return B(_a6(_a8+1|0));}}));};return new F(function(){return _a6(0);});},_a9=new T(function(){return B(_a2(-8));}),_aa=function(_ab){var _ac=new T(function(){var _ad=E(_ab);if(!_ad){return __Z;}else{return B(_aa(_ad+1|0));}}),_ae=function(_af){return new T2(1,new T2(0,_ab,_af),new T(function(){var _ag=E(_af);if(_ag==8){return E(_ac);}else{return B(_ae(_ag+1|0));}}));};return new F(function(){return _ae(-8);});},_ah=new T(function(){return B(_aa(0));}),_ai=113,_aj=110,_ak=98,_al=function(_am){var _an=new T(function(){var _ao=E(_am);if(_ao==8){return __Z;}else{return B(_al(_ao+1|0));}}),_ap=function(_aq){return new T2(1,new T2(0,_am,_aq),new T(function(){var _ar=E(_aq);if(!_ar){return E(_an);}else{return B(_ap(_ar+1|0));}}));};return new F(function(){return _ap(0);});},_as=new T(function(){return B(_al(-8));}),_at=function(_au){var _av=new T(function(){var _aw=E(_au);if(!_aw){return __Z;}else{return B(_at(_aw+1|0));}}),_ax=function(_ay){return new T2(1,new T2(0,_au,_ay),new T(function(){var _az=E(_ay);if(_az==8){return E(_av);}else{return B(_ax(_az+1|0));}}));};return new F(function(){return _ax(-8);});},_aA=new T(function(){return B(_at(0));}),_aB=112,_aC=-2.1472688996352e9,_aD=2.1472688986353e9,_aE=function(_aF,_aG){var _aH=E(_aG);return (_aH._==0)?__Z:new T2(1,new T(function(){return B(A1(_aF,_aH.a));}),new T(function(){return B(_aE(_aF,_aH.b));}));},_aI=function(_aJ){return (!E(_aJ))?true:false;},_aK=new T(function(){return B(unCStr("tail"));}),_aL=new T(function(){return B(_5N(_aK));}),_aM=new T2(1,_2P,_2P),_aN=function(_aO,_aP){var _aQ=function(_aR,_aS){var _aT=E(_aR);if(!_aT._){return E(_aS);}else{var _aU=_aT.a,_aV=E(_aS);if(!_aV._){return E(_aT);}else{var _aW=_aV.a;return (B(A2(_aO,_aU,_aW))==2)?new T2(1,_aW,new T(function(){return B(_aQ(_aT,_aV.b));})):new T2(1,_aU,new T(function(){return B(_aQ(_aT.b,_aV));}));}}},_aX=function(_aY){var _aZ=E(_aY);if(!_aZ._){return __Z;}else{var _b0=E(_aZ.b);return (_b0._==0)?E(_aZ):new T2(1,new T(function(){return B(_aQ(_aZ.a,_b0.a));}),new T(function(){return B(_aX(_b0.b));}));}},_b1=new T(function(){return B(_b2(B(_aX(_2P))));}),_b2=function(_b3){while(1){var _b4=E(_b3);if(!_b4._){return E(_b1);}else{if(!E(_b4.b)._){return E(_b4.a);}else{_b3=B(_aX(_b4));continue;}}}},_b5=new T(function(){return B(_b6(_2P));}),_b7=function(_b8,_b9,_ba){while(1){var _bb=B((function(_bc,_bd,_be){var _bf=E(_be);if(!_bf._){return new T2(1,new T2(1,_bc,_bd),_b5);}else{var _bg=_bf.a;if(B(A2(_aO,_bc,_bg))==2){var _bh=new T2(1,_bc,_bd);_b8=_bg;_b9=_bh;_ba=_bf.b;return __continue;}else{return new T2(1,new T2(1,_bc,_bd),new T(function(){return B(_b6(_bf));}));}}})(_b8,_b9,_ba));if(_bb!=__continue){return _bb;}}},_bi=function(_bj,_bk,_bl){while(1){var _bm=B((function(_bn,_bo,_bp){var _bq=E(_bp);if(!_bq._){return new T2(1,new T(function(){return B(A1(_bo,new T2(1,_bn,_2P)));}),_b5);}else{var _br=_bq.a,_bs=_bq.b;switch(B(A2(_aO,_bn,_br))){case 0:_bj=_br;_bk=function(_bt){return new F(function(){return A1(_bo,new T2(1,_bn,_bt));});};_bl=_bs;return __continue;case 1:_bj=_br;_bk=function(_bu){return new F(function(){return A1(_bo,new T2(1,_bn,_bu));});};_bl=_bs;return __continue;default:return new T2(1,new T(function(){return B(A1(_bo,new T2(1,_bn,_2P)));}),new T(function(){return B(_b6(_bq));}));}}})(_bj,_bk,_bl));if(_bm!=__continue){return _bm;}}},_b6=function(_bv){var _bw=E(_bv);if(!_bw._){return E(_aM);}else{var _bx=_bw.a,_by=E(_bw.b);if(!_by._){return new T2(1,_bw,_2P);}else{var _bz=_by.a,_bA=_by.b;if(B(A2(_aO,_bx,_bz))==2){return new F(function(){return _b7(_bz,new T2(1,_bx,_2P),_bA);});}else{return new F(function(){return _bi(_bz,function(_bB){return new T2(1,_bx,_bB);},_bA);});}}}};return new F(function(){return _b2(B(_b6(_aP)));});},_bC=2147483647,_bD=-2147483648,_bE=function(_bF,_bG,_bH,_bI,_bJ,_bK,_bL,_bM,_bN,_bO,_bP,_bQ){var _bR=new T(function(){return B(_q(_bL,3));}),_bS=new T(function(){return B(_q(_bL,2));}),_bT=new T(function(){return B(_q(_bL,1));}),_bU=new T(function(){return B(_q(_bL,0));});if(_bF>0){var _bV=E(_bJ);if(!_bV._){return {_:0,a:_2P,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:new T(function(){if(!E(_bK)){return E(_bD);}else{return E(_bC);}}),i:_5K};}else{var _bW=_bV.a,_bX=_bV.b,_bY=new T(function(){var _bZ=E(_bW),_c0=_bZ.a,_c1=E(_bZ.b);if(!E(_bK)){if(E(_c1)==107){return new T2(0,_c0,_c1);}else{var _c2=function(_c3){while(1){var _c4=E(_c3);if(!_c4._){return E(_5Q);}else{var _c5=E(_c4.a),_c6=E(_c5.b);if(E(_c6)==107){return new T2(0,_c5.a,_c6);}else{_c3=_c4.b;continue;}}}},_c7=B(_c2(_bX));return new T2(0,_c7.a,_c7.b);}}else{if(E(_c1)==75){return new T2(0,_c0,_c1);}else{var _c8=function(_c9){while(1){var _ca=E(_c9);if(!_ca._){return E(_5Q);}else{var _cb=E(_ca.a),_cc=E(_cb.b);if(E(_cc)==75){return new T2(0,_cb.a,_cc);}else{_c9=_ca.b;continue;}}}},_cd=B(_c8(_bX));return new T2(0,_cd.a,_cd.b);}}}),_ce=new T(function(){return B(_5B(0,_5L,B(_5B(1,_5L,_bL))));}),_cf=new T(function(){if(!B(_7b(_bL))){var _cg=function(_ch){var _ci=function(_cj){var _ck=function(_cl){if(!E(_bK)){if(!E(_bR)){if(!B(_2F(_bW,_bX))){return __Z;}else{var _cm=new T(function(){var _cn=function(_co){var _cp=E(_co),_cq=E(_cp.a),_cr=_cq.b,_cs=E(_cq.a),_ct=function(_cu){var _cv=E(_bY),_cw=E(_cv.a);return (_cs!=E(_cw.a))?true:(E(_cr)!=E(_cw.b))?true:(E(_cp.b)!=E(_cv.b))?true:false;};if(E(_cs)==1){if(E(_cr)==8){return false;}else{return new F(function(){return _ct(_);});}}else{return new F(function(){return _ct(_);});}};return B(_5R(_cn,_bV));});return new T2(1,{_:0,a:new T2(1,_9l,new T2(1,_9j,_cm)),b:_5L,c:new T(function(){return B(_5B(2,_5L,B(_5B(3,_5L,_bL))));}),d:new T(function(){return B(_5B(3,_5L,_bM));}),e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_2P);}}else{return __Z;}}else{return __Z;}};if(!E(_bK)){if(!E(_bS)){if(!B(_2m(_bW,_bX))){return new F(function(){return _ck(_);});}else{var _cx=new T(function(){var _cy=function(_cz){var _cA=E(_cz),_cB=E(_cA.a),_cC=_cB.b,_cD=E(_cB.a),_cE=function(_cF){var _cG=E(_bY),_cH=E(_cG.a);return (_cD!=E(_cH.a))?true:(E(_cC)!=E(_cH.b))?true:(E(_cA.b)!=E(_cG.b))?true:false;};if(E(_cD)==8){if(E(_cC)==8){return false;}else{return new F(function(){return _cE(_);});}}else{return new F(function(){return _cE(_);});}};return B(_5R(_cy,_bV));});return new T2(1,{_:0,a:new T2(1,_9h,new T2(1,_9e,_cx)),b:_5L,c:new T(function(){return B(_5B(2,_5L,B(_5B(3,_5L,_bL))));}),d:new T(function(){return B(_5B(2,_5L,_bM));}),e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_2P);}}else{return new F(function(){return _ck(_);});}}else{return new F(function(){return _ck(_);});}};if(!E(_bK)){return new F(function(){return _ci(_);});}else{if(!E(_bT)){if(!B(_23(_bW,_bX))){return new F(function(){return _ci(_);});}else{var _cI=new T(function(){var _cJ=function(_cK){var _cL=E(_cK),_cM=E(_cL.a),_cN=_cM.b,_cO=E(_cM.a),_cP=function(_cQ){var _cR=E(_bY),_cS=E(_cR.a);return (_cO!=E(_cS.a))?true:(E(_cN)!=E(_cS.b))?true:(E(_cL.b)!=E(_cR.b))?true:false;};if(E(_cO)==1){if(E(_cN)==1){return false;}else{return new F(function(){return _cP(_);});}}else{return new F(function(){return _cP(_);});}};return B(_5R(_cJ,_bV));});return new T2(1,{_:0,a:new T2(1,_9a,new T2(1,_98,_cI)),b:_5J,c:_ce,d:new T(function(){return B(_5B(1,_5L,_bM));}),e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_2P);}}else{return new F(function(){return _ci(_);});}}};if(!E(_bK)){return B(_cg(_));}else{if(!E(_bU)){if(!B(_1K(_bW,_bX))){return B(_cg(_));}else{return new T2(1,{_:0,a:new T2(1,_96,new T2(1,_92,new T(function(){return B(_5R(_8W,_bV));}))),b:_5J,c:_ce,d:new T(function(){return B(_5B(0,_5L,_bM));}),e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_2P);}}else{return B(_cg(_));}}}else{return __Z;}});if(!E(_bK)){var _cT=new T(function(){var _cU=new T(function(){var _cV=new T(function(){var _cW=new T(function(){var _cX=new T(function(){var _cY=new T(function(){var _cZ=new T(function(){var _d0=new T(function(){var _d1=new T(function(){return B(_5B(3,_5L,B(_5B(2,_5L,_bL))));}),_d2=function(_d3,_d4,_d5){var _d6=E(_bY),_d7=E(_d6.a),_d8=E(_d7.a),_d9=_d8+_d3|0;if(_d9<1){return E(_d5);}else{if(_d9>8){return E(_d5);}else{var _da=E(_d7.b),_db=_da+_d4|0;if(_db<1){return E(_d5);}else{if(_db>8){return E(_d5);}else{var _dc=function(_dd){while(1){var _de=E(_dd);if(!_de._){return true;}else{var _df=_de.b,_dg=E(_de.a),_dh=E(_dg.a);if(E(_dh.a)!=_d9){_dd=_df;continue;}else{if(E(_dh.b)!=_db){_dd=_df;continue;}else{var _di=u_iswupper(E(_dg.b));if(!E(_di)){return false;}else{_dd=_df;continue;}}}}}};if(!B((function(_dj,_dk){var _dl=E(_dj),_dm=E(_dl.a);if(E(_dm.a)!=_d9){return new F(function(){return _dc(_dk);});}else{if(E(_dm.b)!=_db){return new F(function(){return _dc(_dk);});}else{var _dn=u_iswupper(E(_dl.b));if(!E(_dn)){return false;}else{return new F(function(){return _dc(_dk);});}}}})(_bW,_bX))){return E(_d5);}else{var _do=new T(function(){var _dp=function(_dq){while(1){var _dr=E(_dq);if(!_dr._){return false;}else{var _ds=_dr.b,_dt=E(E(_dr.a).a);if(E(_dt.a)!=_d9){_dq=_ds;continue;}else{if(E(_dt.b)!=_db){_dq=_ds;continue;}else{return true;}}}}};if(!B((function(_du,_dv){var _dw=E(E(_du).a);if(E(_dw.a)!=_d9){return new F(function(){return _dp(_dv);});}else{if(E(_dw.b)!=_db){return new F(function(){return _dp(_dv);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_dx=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_d9)==8){if(E(_db)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_d9)==1){if(E(_db)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_d1))));}),_dy=new T(function(){var _dz=function(_dA){var _dB=E(_dA),_dC=E(_dB.a),_dD=_dC.b,_dE=E(_dC.a),_dF=function(_dG){return (_dE!=_d8)?true:(E(_dD)!=_da)?true:(E(_dB.b)!=E(_d6.b))?true:false;};if(_dE!=_d9){return new F(function(){return _dF(_);});}else{if(E(_dD)!=_db){return new F(function(){return _dF(_);});}else{return false;}}};return B(_5R(_dz,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_d9,_db),_9f),_dy),b:_5L,c:_dx,d:_bM,e:_do,f:_8S,g:_8L,h:_8L,i:_5K},_d5);}}}}}},_dH=new T(function(){var _dI=new T(function(){var _dJ=new T(function(){var _dK=new T(function(){var _dL=new T(function(){var _dM=new T(function(){return B(_d2(-1,-1,new T(function(){return B(_d2(-1,0,_cf));})));});return B(_d2(0,-1,_dM));});return B(_d2(1,-1,_dL));});return B(_d2(1,0,_dK));});return B(_d2(1,1,_dJ));});return B(_d2(0,1,_dI));});return B(_d2(-1,1,_dH));}),_dN=function(_dO){while(1){var _dP=B((function(_dQ){var _dR=E(_dQ);if(!_dR._){return true;}else{var _dS=_dR.b,_dT=E(E(_bW).a),_dU=E(_dR.a),_dV=_dU.b,_dW=E(_dU.a);if(E(_dT.a)!=_dW){var _dX=function(_dY){while(1){var _dZ=E(_dY);if(!_dZ._){return true;}else{var _e0=_dZ.b,_e1=E(E(_dZ.a).a);if(E(_e1.a)!=_dW){_dY=_e0;continue;}else{if(E(_e1.b)!=E(_dV)){_dY=_e0;continue;}else{return false;}}}}};if(!B(_dX(_bX))){return false;}else{_dO=_dS;return __continue;}}else{var _e2=E(_dV);if(E(_dT.b)!=_e2){var _e3=function(_e4){while(1){var _e5=E(_e4);if(!_e5._){return true;}else{var _e6=_e5.b,_e7=E(E(_e5.a).a);if(E(_e7.a)!=_dW){_e4=_e6;continue;}else{if(E(_e7.b)!=_e2){_e4=_e6;continue;}else{return false;}}}}};if(!B(_e3(_bX))){return false;}else{_dO=_dS;return __continue;}}else{return false;}}}})(_dO));if(_dP!=__continue){return _dP;}}},_e8=function(_e9){var _ea=E(_e9);if(!_ea._){return E(_d0);}else{var _eb=E(_ea.a),_ec=_eb.a,_ed=new T(function(){return B(_e8(_ea.b));});if(E(_eb.b)==113){var _ee=function(_ef,_eg,_eh){var _ei=E(_ec),_ej=E(_ei.a),_ek=_ej+_ef|0;if(_ek<1){return E(_eh);}else{if(_ek>8){return E(_eh);}else{var _el=E(_ei.b),_em=_el+_eg|0;if(_em<1){return E(_eh);}else{if(_em>8){return E(_eh);}else{var _en=B(_4i(_ej,_el,_ek,_em));if(!_en._){return E(_aL);}else{var _eo=E(_en.b);if(!_eo._){return E(_8I);}else{if(!B(_dN(B(_8D(_eo.a,_eo.b))))){return E(_eh);}else{var _ep=function(_eq){while(1){var _er=E(_eq);if(!_er._){return true;}else{var _es=_er.b,_et=E(_er.a),_eu=E(_et.a);if(E(_eu.a)!=_ek){_eq=_es;continue;}else{if(E(_eu.b)!=_em){_eq=_es;continue;}else{var _ev=u_iswupper(E(_et.b));if(!E(_ev)){return false;}else{_eq=_es;continue;}}}}}};if(!B((function(_ew,_ex){var _ey=E(_ew),_ez=E(_ey.a);if(E(_ez.a)!=_ek){return new F(function(){return _ep(_ex);});}else{if(E(_ez.b)!=_em){return new F(function(){return _ep(_ex);});}else{var _eA=u_iswupper(E(_ey.b));if(!E(_eA)){return false;}else{return new F(function(){return _ep(_ex);});}}}})(_bW,_bX))){return E(_eh);}else{var _eB=new T(function(){var _eC=function(_eD){while(1){var _eE=E(_eD);if(!_eE._){return false;}else{var _eF=_eE.b,_eG=E(E(_eE.a).a);if(E(_eG.a)!=_ek){_eD=_eF;continue;}else{if(E(_eG.b)!=_em){_eD=_eF;continue;}else{return true;}}}}};if(!B((function(_eH,_eI){var _eJ=E(E(_eH).a);if(E(_eJ.a)!=_ek){return new F(function(){return _eC(_eI);});}else{if(E(_eJ.b)!=_em){return new F(function(){return _eC(_eI);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_eK=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_ek)==8){if(E(_em)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_ek)==1){if(E(_em)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_eL=new T(function(){var _eM=function(_eN){var _eO=E(_eN),_eP=E(_eO.a),_eQ=_eP.b,_eR=E(_eP.a),_eS=function(_eT){return (_eR!=_ej)?true:(E(_eQ)!=_el)?true:(E(_eO.b)==113)?false:true;};if(_eR!=_ek){return new F(function(){return _eS(_);});}else{if(E(_eQ)!=_em){return new F(function(){return _eS(_);});}else{return false;}}};return B(_5R(_eM,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_ek,_em),_ai),_eL),b:_5L,c:_eK,d:_bM,e:_eB,f:_8S,g:_8L,h:_8L,i:_5K},_eh);}}}}}}}}},_eU=new T(function(){var _eV=new T(function(){var _eW=function(_eX,_eY,_eZ){var _f0=E(_eX);if(!_f0){var _f1=E(_eY);if(!_f1){return E(_eZ);}else{return new F(function(){return _ee(0,_f1,_eZ);});}}else{var _f2=E(_ec),_f3=E(_f2.a),_f4=_f3+_f0|0;if(_f4<1){return E(_eZ);}else{if(_f4>8){return E(_eZ);}else{var _f5=E(_f2.b),_f6=_f5+E(_eY)|0;if(_f6<1){return E(_eZ);}else{if(_f6>8){return E(_eZ);}else{var _f7=B(_4i(_f3,_f5,_f4,_f6));if(!_f7._){return E(_aL);}else{var _f8=E(_f7.b);if(!_f8._){return E(_8I);}else{if(!B(_dN(B(_8D(_f8.a,_f8.b))))){return E(_eZ);}else{var _f9=function(_fa){while(1){var _fb=E(_fa);if(!_fb._){return true;}else{var _fc=_fb.b,_fd=E(_fb.a),_fe=E(_fd.a);if(E(_fe.a)!=_f4){_fa=_fc;continue;}else{if(E(_fe.b)!=_f6){_fa=_fc;continue;}else{var _ff=u_iswupper(E(_fd.b));if(!E(_ff)){return false;}else{_fa=_fc;continue;}}}}}};if(!B((function(_fg,_fh){var _fi=E(_fg),_fj=E(_fi.a);if(E(_fj.a)!=_f4){return new F(function(){return _f9(_fh);});}else{if(E(_fj.b)!=_f6){return new F(function(){return _f9(_fh);});}else{var _fk=u_iswupper(E(_fi.b));if(!E(_fk)){return false;}else{return new F(function(){return _f9(_fh);});}}}})(_bW,_bX))){return E(_eZ);}else{var _fl=new T(function(){var _fm=function(_fn){while(1){var _fo=E(_fn);if(!_fo._){return false;}else{var _fp=_fo.b,_fq=E(E(_fo.a).a);if(E(_fq.a)!=_f4){_fn=_fp;continue;}else{if(E(_fq.b)!=_f6){_fn=_fp;continue;}else{return true;}}}}};if(!B((function(_fr,_fs){var _ft=E(E(_fr).a);if(E(_ft.a)!=_f4){return new F(function(){return _fm(_fs);});}else{if(E(_ft.b)!=_f6){return new F(function(){return _fm(_fs);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_fu=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_f4)==8){if(E(_f6)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_f4)==1){if(E(_f6)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_fv=new T(function(){var _fw=function(_fx){var _fy=E(_fx),_fz=E(_fy.a),_fA=_fz.b,_fB=E(_fz.a),_fC=function(_fD){return (_fB!=_f3)?true:(E(_fA)!=_f5)?true:(E(_fy.b)==113)?false:true;};if(_fB!=_f4){return new F(function(){return _fC(_);});}else{if(E(_fA)!=_f6){return new F(function(){return _fC(_);});}else{return false;}}};return B(_5R(_fw,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_f4,_f6),_ai),_fv),b:_5L,c:_fu,d:_bM,e:_fl,f:_8S,g:_8L,h:_8L,i:_5K},_eZ);}}}}}}}}}},_fE=new T(function(){var _fF=function(_fG){var _fH=E(_fG);if(!_fH._){return E(_ed);}else{var _fI=E(_fH.a);return new F(function(){return _eW(E(_fI.a),_fI.b,new T(function(){return B(_fF(_fH.b));}));});}};return B(_fF(_ah));}),_fJ=function(_fK){var _fL=E(_fK);if(!_fL._){return E(_fE);}else{var _fM=E(_fL.a);return new F(function(){return _eW(E(_fM.a),_fM.b,new T(function(){return B(_fJ(_fL.b));}));});}};return B(_fJ(_a9));}),_fN=function(_fO){while(1){var _fP=B((function(_fQ){var _fR=E(_fQ);if(!_fR._){return E(_eV);}else{var _fS=_fR.b,_fT=E(_fR.a);if(!_fT){_fO=_fS;return __continue;}else{return new F(function(){return _ee(_fT, -_fT,new T(function(){return B(_fN(_fS));}));});}}})(_fO));if(_fP!=__continue){return _fP;}}};return B(_fN(_9r));}),_fU=function(_fV){while(1){var _fW=B((function(_fX){var _fY=E(_fX);if(!_fY._){return E(_eU);}else{var _fZ=_fY.b,_g0=E(_fY.a);if(!_g0){_fV=_fZ;return __continue;}else{return new F(function(){return _ee(_g0,_g0,new T(function(){return B(_fU(_fZ));}));});}}})(_fV));if(_fW!=__continue){return _fW;}}};return new F(function(){return _fU(_9r);});}else{return E(_ed);}}},_g1=function(_g2,_g3){var _g4=E(_g2),_g5=_g4.a,_g6=new T(function(){return B(_e8(_g3));});if(E(_g4.b)==113){var _g7=function(_g8,_g9,_ga){var _gb=E(_g5),_gc=E(_gb.a),_gd=_gc+_g8|0;if(_gd<1){return E(_ga);}else{if(_gd>8){return E(_ga);}else{var _ge=E(_gb.b),_gf=_ge+_g9|0;if(_gf<1){return E(_ga);}else{if(_gf>8){return E(_ga);}else{var _gg=B(_4i(_gc,_ge,_gd,_gf));if(!_gg._){return E(_aL);}else{var _gh=E(_gg.b);if(!_gh._){return E(_8I);}else{if(!B(_dN(B(_8D(_gh.a,_gh.b))))){return E(_ga);}else{var _gi=function(_gj){while(1){var _gk=E(_gj);if(!_gk._){return true;}else{var _gl=_gk.b,_gm=E(_gk.a),_gn=E(_gm.a);if(E(_gn.a)!=_gd){_gj=_gl;continue;}else{if(E(_gn.b)!=_gf){_gj=_gl;continue;}else{var _go=u_iswupper(E(_gm.b));if(!E(_go)){return false;}else{_gj=_gl;continue;}}}}}};if(!B(_gi(_bV))){return E(_ga);}else{var _gp=new T(function(){var _gq=function(_gr){while(1){var _gs=E(_gr);if(!_gs._){return false;}else{var _gt=_gs.b,_gu=E(E(_gs.a).a);if(E(_gu.a)!=_gd){_gr=_gt;continue;}else{if(E(_gu.b)!=_gf){_gr=_gt;continue;}else{return true;}}}}};if(!B(_gq(_bV))){return E(_8M);}else{return E(_90);}}),_gv=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_gd)==8){if(E(_gf)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_gd)==1){if(E(_gf)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_gw=new T(function(){var _gx=function(_gy){var _gz=E(_gy),_gA=E(_gz.a),_gB=_gA.b,_gC=E(_gA.a),_gD=function(_gE){return (_gC!=_gc)?true:(E(_gB)!=_ge)?true:(E(_gz.b)==113)?false:true;};if(_gC!=_gd){return new F(function(){return _gD(_);});}else{if(E(_gB)!=_gf){return new F(function(){return _gD(_);});}else{return false;}}};return B(_5R(_gx,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_gd,_gf),_ai),_gw),b:_5L,c:_gv,d:_bM,e:_gp,f:_8S,g:_8L,h:_8L,i:_5K},_ga);}}}}}}}}},_gF=new T(function(){var _gG=new T(function(){var _gH=function(_gI,_gJ,_gK){var _gL=E(_gI);if(!_gL){var _gM=E(_gJ);if(!_gM){return E(_gK);}else{return new F(function(){return _g7(0,_gM,_gK);});}}else{var _gN=E(_g5),_gO=E(_gN.a),_gP=_gO+_gL|0;if(_gP<1){return E(_gK);}else{if(_gP>8){return E(_gK);}else{var _gQ=E(_gN.b),_gR=_gQ+E(_gJ)|0;if(_gR<1){return E(_gK);}else{if(_gR>8){return E(_gK);}else{var _gS=B(_4i(_gO,_gQ,_gP,_gR));if(!_gS._){return E(_aL);}else{var _gT=E(_gS.b);if(!_gT._){return E(_8I);}else{if(!B(_dN(B(_8D(_gT.a,_gT.b))))){return E(_gK);}else{var _gU=function(_gV){while(1){var _gW=E(_gV);if(!_gW._){return true;}else{var _gX=_gW.b,_gY=E(_gW.a),_gZ=E(_gY.a);if(E(_gZ.a)!=_gP){_gV=_gX;continue;}else{if(E(_gZ.b)!=_gR){_gV=_gX;continue;}else{var _h0=u_iswupper(E(_gY.b));if(!E(_h0)){return false;}else{_gV=_gX;continue;}}}}}};if(!B((function(_h1,_h2){var _h3=E(_h1),_h4=E(_h3.a);if(E(_h4.a)!=_gP){return new F(function(){return _gU(_h2);});}else{if(E(_h4.b)!=_gR){return new F(function(){return _gU(_h2);});}else{var _h5=u_iswupper(E(_h3.b));if(!E(_h5)){return false;}else{return new F(function(){return _gU(_h2);});}}}})(_bW,_bX))){return E(_gK);}else{var _h6=new T(function(){var _h7=function(_h8){while(1){var _h9=E(_h8);if(!_h9._){return false;}else{var _ha=_h9.b,_hb=E(E(_h9.a).a);if(E(_hb.a)!=_gP){_h8=_ha;continue;}else{if(E(_hb.b)!=_gR){_h8=_ha;continue;}else{return true;}}}}};if(!B((function(_hc,_hd){var _he=E(E(_hc).a);if(E(_he.a)!=_gP){return new F(function(){return _h7(_hd);});}else{if(E(_he.b)!=_gR){return new F(function(){return _h7(_hd);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_hf=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_gP)==8){if(E(_gR)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_gP)==1){if(E(_gR)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_hg=new T(function(){var _hh=function(_hi){var _hj=E(_hi),_hk=E(_hj.a),_hl=_hk.b,_hm=E(_hk.a),_hn=function(_ho){return (_hm!=_gO)?true:(E(_hl)!=_gQ)?true:(E(_hj.b)==113)?false:true;};if(_hm!=_gP){return new F(function(){return _hn(_);});}else{if(E(_hl)!=_gR){return new F(function(){return _hn(_);});}else{return false;}}};return B(_5R(_hh,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_gP,_gR),_ai),_hg),b:_5L,c:_hf,d:_bM,e:_h6,f:_8S,g:_8L,h:_8L,i:_5K},_gK);}}}}}}}}}},_hp=new T(function(){var _hq=function(_hr){var _hs=E(_hr);if(!_hs._){return E(_g6);}else{var _ht=E(_hs.a);return new F(function(){return _gH(E(_ht.a),_ht.b,new T(function(){return B(_hq(_hs.b));}));});}};return B(_hq(_ah));}),_hu=function(_hv){var _hw=E(_hv);if(!_hw._){return E(_hp);}else{var _hx=E(_hw.a);return new F(function(){return _gH(E(_hx.a),_hx.b,new T(function(){return B(_hu(_hw.b));}));});}};return B(_hu(_a9));}),_hy=function(_hz){while(1){var _hA=B((function(_hB){var _hC=E(_hB);if(!_hC._){return E(_gG);}else{var _hD=_hC.b,_hE=E(_hC.a);if(!_hE){_hz=_hD;return __continue;}else{return new F(function(){return _g7(_hE, -_hE,new T(function(){return B(_hy(_hD));}));});}}})(_hz));if(_hA!=__continue){return _hA;}}};return B(_hy(_9r));}),_hF=function(_hG){while(1){var _hH=B((function(_hI){var _hJ=E(_hI);if(!_hJ._){return E(_gF);}else{var _hK=_hJ.b,_hL=E(_hJ.a);if(!_hL){_hG=_hK;return __continue;}else{return new F(function(){return _g7(_hL,_hL,new T(function(){return B(_hF(_hK));}));});}}})(_hG));if(_hH!=__continue){return _hH;}}};return new F(function(){return _hF(_9r);});}else{return E(_g6);}};return B(_g1(_bW,_bX));}),_hM=function(_hN){while(1){var _hO=B((function(_hP){var _hQ=E(_hP);if(!_hQ._){return E(_cZ);}else{var _hR=_hQ.b,_hS=E(_hQ.a);if(E(_hS.b)==110){var _hT=function(_hU,_hV,_hW){var _hX=E(_hS.a),_hY=E(_hX.a),_hZ=_hY+_hU|0;if(_hZ<1){return E(_hW);}else{if(_hZ>8){return E(_hW);}else{var _i0=E(_hX.b),_i1=_i0+_hV|0;if(_i1<1){return E(_hW);}else{if(_i1>8){return E(_hW);}else{var _i2=function(_i3){while(1){var _i4=E(_i3);if(!_i4._){return true;}else{var _i5=_i4.b,_i6=E(_i4.a),_i7=E(_i6.a);if(E(_i7.a)!=_hZ){_i3=_i5;continue;}else{if(E(_i7.b)!=_i1){_i3=_i5;continue;}else{var _i8=u_iswupper(E(_i6.b));if(!E(_i8)){return false;}else{_i3=_i5;continue;}}}}}};if(!B((function(_i9,_ia){var _ib=E(_i9),_ic=E(_ib.a);if(E(_ic.a)!=_hZ){return new F(function(){return _i2(_ia);});}else{if(E(_ic.b)!=_i1){return new F(function(){return _i2(_ia);});}else{var _id=u_iswupper(E(_ib.b));if(!E(_id)){return false;}else{return new F(function(){return _i2(_ia);});}}}})(_bW,_bX))){return E(_hW);}else{var _ie=new T(function(){var _if=function(_ig){while(1){var _ih=E(_ig);if(!_ih._){return false;}else{var _ii=_ih.b,_ij=E(E(_ih.a).a);if(E(_ij.a)!=_hZ){_ig=_ii;continue;}else{if(E(_ij.b)!=_i1){_ig=_ii;continue;}else{return true;}}}}};if(!B((function(_ik,_il){var _im=E(E(_ik).a);if(E(_im.a)!=_hZ){return new F(function(){return _if(_il);});}else{if(E(_im.b)!=_i1){return new F(function(){return _if(_il);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_in=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_hZ)==8){if(E(_i1)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_hZ)==1){if(E(_i1)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_io=new T(function(){var _ip=function(_iq){var _ir=E(_iq),_is=E(_ir.a),_it=_is.b,_iu=E(_is.a),_iv=function(_iw){return (_iu!=_hY)?true:(E(_it)!=_i0)?true:(E(_ir.b)==110)?false:true;};if(_iu!=_hZ){return new F(function(){return _iv(_);});}else{if(E(_it)!=_i1){return new F(function(){return _iv(_);});}else{return false;}}};return B(_5R(_ip,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_hZ,_i1),_aj),_io),b:_5L,c:_in,d:_bM,e:_ie,f:_8S,g:_8L,h:_8L,i:_5K},_hW);}}}}}},_ix=new T(function(){var _iy=new T(function(){var _iz=new T(function(){var _iA=new T(function(){var _iB=new T(function(){var _iC=new T(function(){var _iD=new T(function(){return B(_hT(-2,-1,new T(function(){return B(_hM(_hR));})));});return B(_hT(-1,-2,_iD));});return B(_hT(2,-1,_iC));});return B(_hT(-1,2,_iB));});return B(_hT(-2,1,_iA));});return B(_hT(1,-2,_iz));});return B(_hT(2,1,_iy));});return new F(function(){return _hT(1,2,_ix);});}else{_hN=_hR;return __continue;}}})(_hN));if(_hO!=__continue){return _hO;}}},_iE=function(_iF,_iG){var _iH=E(_iF);if(E(_iH.b)==110){var _iI=function(_iJ,_iK,_iL){var _iM=E(_iH.a),_iN=E(_iM.a),_iO=_iN+_iJ|0;if(_iO<1){return E(_iL);}else{if(_iO>8){return E(_iL);}else{var _iP=E(_iM.b),_iQ=_iP+_iK|0;if(_iQ<1){return E(_iL);}else{if(_iQ>8){return E(_iL);}else{var _iR=function(_iS){while(1){var _iT=E(_iS);if(!_iT._){return true;}else{var _iU=_iT.b,_iV=E(_iT.a),_iW=E(_iV.a);if(E(_iW.a)!=_iO){_iS=_iU;continue;}else{if(E(_iW.b)!=_iQ){_iS=_iU;continue;}else{var _iX=u_iswupper(E(_iV.b));if(!E(_iX)){return false;}else{_iS=_iU;continue;}}}}}};if(!B(_iR(_bV))){return E(_iL);}else{var _iY=new T(function(){var _iZ=function(_j0){while(1){var _j1=E(_j0);if(!_j1._){return false;}else{var _j2=_j1.b,_j3=E(E(_j1.a).a);if(E(_j3.a)!=_iO){_j0=_j2;continue;}else{if(E(_j3.b)!=_iQ){_j0=_j2;continue;}else{return true;}}}}};if(!B(_iZ(_bV))){return E(_8M);}else{return E(_90);}}),_j4=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_iO)==8){if(E(_iQ)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_iO)==1){if(E(_iQ)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_j5=new T(function(){var _j6=function(_j7){var _j8=E(_j7),_j9=E(_j8.a),_ja=_j9.b,_jb=E(_j9.a),_jc=function(_jd){return (_jb!=_iN)?true:(E(_ja)!=_iP)?true:(E(_j8.b)==110)?false:true;};if(_jb!=_iO){return new F(function(){return _jc(_);});}else{if(E(_ja)!=_iQ){return new F(function(){return _jc(_);});}else{return false;}}};return B(_5R(_j6,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_iO,_iQ),_aj),_j5),b:_5L,c:_j4,d:_bM,e:_iY,f:_8S,g:_8L,h:_8L,i:_5K},_iL);}}}}}},_je=new T(function(){var _jf=new T(function(){var _jg=new T(function(){var _jh=new T(function(){var _ji=new T(function(){var _jj=new T(function(){var _jk=new T(function(){return B(_iI(-2,-1,new T(function(){return B(_hM(_iG));})));});return B(_iI(-1,-2,_jk));});return B(_iI(2,-1,_jj));});return B(_iI(-1,2,_ji));});return B(_iI(-2,1,_jh));});return B(_iI(1,-2,_jg));});return B(_iI(2,1,_jf));});return new F(function(){return _iI(1,2,_je);});}else{return new F(function(){return _hM(_iG);});}};return B(_iE(_bW,_bX));}),_jl=function(_jm){while(1){var _jn=B((function(_jo){var _jp=E(_jo);if(!_jp._){return true;}else{var _jq=_jp.b,_jr=E(E(_bW).a),_js=E(_jp.a),_jt=_js.b,_ju=E(_js.a);if(E(_jr.a)!=_ju){var _jv=function(_jw){while(1){var _jx=E(_jw);if(!_jx._){return true;}else{var _jy=_jx.b,_jz=E(E(_jx.a).a);if(E(_jz.a)!=_ju){_jw=_jy;continue;}else{if(E(_jz.b)!=E(_jt)){_jw=_jy;continue;}else{return false;}}}}};if(!B(_jv(_bX))){return false;}else{_jm=_jq;return __continue;}}else{var _jA=E(_jt);if(E(_jr.b)!=_jA){var _jB=function(_jC){while(1){var _jD=E(_jC);if(!_jD._){return true;}else{var _jE=_jD.b,_jF=E(E(_jD.a).a);if(E(_jF.a)!=_ju){_jC=_jE;continue;}else{if(E(_jF.b)!=_jA){_jC=_jE;continue;}else{return false;}}}}};if(!B(_jB(_bX))){return false;}else{_jm=_jq;return __continue;}}else{return false;}}}})(_jm));if(_jn!=__continue){return _jn;}}},_jG=function(_jH){var _jI=E(_jH);if(!_jI._){return E(_cY);}else{var _jJ=E(_jI.a),_jK=new T(function(){return B(_jG(_jI.b));});if(E(_jJ.b)==98){var _jL=function(_jM,_jN,_jO){var _jP=E(_jJ.a),_jQ=E(_jP.a),_jR=_jQ+_jM|0;if(_jR<1){return E(_jO);}else{if(_jR>8){return E(_jO);}else{var _jS=E(_jP.b),_jT=_jS+_jN|0;if(_jT<1){return E(_jO);}else{if(_jT>8){return E(_jO);}else{var _jU=B(_4i(_jQ,_jS,_jR,_jT));if(!_jU._){return E(_aL);}else{var _jV=E(_jU.b);if(!_jV._){return E(_8I);}else{if(!B(_jl(B(_8D(_jV.a,_jV.b))))){return E(_jO);}else{var _jW=function(_jX){while(1){var _jY=E(_jX);if(!_jY._){return true;}else{var _jZ=_jY.b,_k0=E(_jY.a),_k1=E(_k0.a);if(E(_k1.a)!=_jR){_jX=_jZ;continue;}else{if(E(_k1.b)!=_jT){_jX=_jZ;continue;}else{var _k2=u_iswupper(E(_k0.b));if(!E(_k2)){return false;}else{_jX=_jZ;continue;}}}}}};if(!B((function(_k3,_k4){var _k5=E(_k3),_k6=E(_k5.a);if(E(_k6.a)!=_jR){return new F(function(){return _jW(_k4);});}else{if(E(_k6.b)!=_jT){return new F(function(){return _jW(_k4);});}else{var _k7=u_iswupper(E(_k5.b));if(!E(_k7)){return false;}else{return new F(function(){return _jW(_k4);});}}}})(_bW,_bX))){return E(_jO);}else{var _k8=new T(function(){var _k9=function(_ka){while(1){var _kb=E(_ka);if(!_kb._){return false;}else{var _kc=_kb.b,_kd=E(E(_kb.a).a);if(E(_kd.a)!=_jR){_ka=_kc;continue;}else{if(E(_kd.b)!=_jT){_ka=_kc;continue;}else{return true;}}}}};if(!B((function(_ke,_kf){var _kg=E(E(_ke).a);if(E(_kg.a)!=_jR){return new F(function(){return _k9(_kf);});}else{if(E(_kg.b)!=_jT){return new F(function(){return _k9(_kf);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_kh=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_jR)==8){if(E(_jT)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_jR)==1){if(E(_jT)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_ki=new T(function(){var _kj=function(_kk){var _kl=E(_kk),_km=E(_kl.a),_kn=_km.b,_ko=E(_km.a),_kp=function(_kq){return (_ko!=_jQ)?true:(E(_kn)!=_jS)?true:(E(_kl.b)==98)?false:true;};if(_ko!=_jR){return new F(function(){return _kp(_);});}else{if(E(_kn)!=_jT){return new F(function(){return _kp(_);});}else{return false;}}};return B(_5R(_kj,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_jR,_jT),_ak),_ki),b:_5L,c:_kh,d:_bM,e:_k8,f:_8S,g:_8L,h:_8L,i:_5K},_jO);}}}}}}}}},_kr=new T(function(){var _ks=function(_kt){while(1){var _ku=B((function(_kv){var _kw=E(_kv);if(!_kw._){return E(_jK);}else{var _kx=_kw.b,_ky=E(_kw.a);if(!_ky){_kt=_kx;return __continue;}else{return new F(function(){return _jL(_ky, -_ky,new T(function(){return B(_ks(_kx));}));});}}})(_kt));if(_ku!=__continue){return _ku;}}};return B(_ks(_9r));}),_kz=function(_kA){while(1){var _kB=B((function(_kC){var _kD=E(_kC);if(!_kD._){return E(_kr);}else{var _kE=_kD.b,_kF=E(_kD.a);if(!_kF){_kA=_kE;return __continue;}else{return new F(function(){return _jL(_kF,_kF,new T(function(){return B(_kz(_kE));}));});}}})(_kA));if(_kB!=__continue){return _kB;}}};return new F(function(){return _kz(_9r);});}else{return E(_jK);}}},_kG=function(_kH,_kI){var _kJ=E(_kH),_kK=new T(function(){return B(_jG(_kI));});if(E(_kJ.b)==98){var _kL=function(_kM,_kN,_kO){var _kP=E(_kJ.a),_kQ=E(_kP.a),_kR=_kQ+_kM|0;if(_kR<1){return E(_kO);}else{if(_kR>8){return E(_kO);}else{var _kS=E(_kP.b),_kT=_kS+_kN|0;if(_kT<1){return E(_kO);}else{if(_kT>8){return E(_kO);}else{var _kU=B(_4i(_kQ,_kS,_kR,_kT));if(!_kU._){return E(_aL);}else{var _kV=E(_kU.b);if(!_kV._){return E(_8I);}else{if(!B(_jl(B(_8D(_kV.a,_kV.b))))){return E(_kO);}else{var _kW=function(_kX){while(1){var _kY=E(_kX);if(!_kY._){return true;}else{var _kZ=_kY.b,_l0=E(_kY.a),_l1=E(_l0.a);if(E(_l1.a)!=_kR){_kX=_kZ;continue;}else{if(E(_l1.b)!=_kT){_kX=_kZ;continue;}else{var _l2=u_iswupper(E(_l0.b));if(!E(_l2)){return false;}else{_kX=_kZ;continue;}}}}}};if(!B(_kW(_bV))){return E(_kO);}else{var _l3=new T(function(){var _l4=function(_l5){while(1){var _l6=E(_l5);if(!_l6._){return false;}else{var _l7=_l6.b,_l8=E(E(_l6.a).a);if(E(_l8.a)!=_kR){_l5=_l7;continue;}else{if(E(_l8.b)!=_kT){_l5=_l7;continue;}else{return true;}}}}};if(!B(_l4(_bV))){return E(_8M);}else{return E(_90);}}),_l9=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_kR)==8){if(E(_kT)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_kR)==1){if(E(_kT)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_la=new T(function(){var _lb=function(_lc){var _ld=E(_lc),_le=E(_ld.a),_lf=_le.b,_lg=E(_le.a),_lh=function(_li){return (_lg!=_kQ)?true:(E(_lf)!=_kS)?true:(E(_ld.b)==98)?false:true;};if(_lg!=_kR){return new F(function(){return _lh(_);});}else{if(E(_lf)!=_kT){return new F(function(){return _lh(_);});}else{return false;}}};return B(_5R(_lb,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_kR,_kT),_ak),_la),b:_5L,c:_l9,d:_bM,e:_l3,f:_8S,g:_8L,h:_8L,i:_5K},_kO);}}}}}}}}},_lj=new T(function(){var _lk=function(_ll){while(1){var _lm=B((function(_ln){var _lo=E(_ln);if(!_lo._){return E(_kK);}else{var _lp=_lo.b,_lq=E(_lo.a);if(!_lq){_ll=_lp;return __continue;}else{return new F(function(){return _kL(_lq, -_lq,new T(function(){return B(_lk(_lp));}));});}}})(_ll));if(_lm!=__continue){return _lm;}}};return B(_lk(_9r));}),_lr=function(_ls){while(1){var _lt=B((function(_lu){var _lv=E(_lu);if(!_lv._){return E(_lj);}else{var _lw=_lv.b,_lx=E(_lv.a);if(!_lx){_ls=_lw;return __continue;}else{return new F(function(){return _kL(_lx,_lx,new T(function(){return B(_lr(_lw));}));});}}})(_ls));if(_lt!=__continue){return _lt;}}};return new F(function(){return _lr(_9r);});}else{return E(_kK);}};return B(_kG(_bW,_bX));}),_ly=function(_lz){while(1){var _lA=B((function(_lB){var _lC=E(_lB);if(!_lC._){return true;}else{var _lD=_lC.b,_lE=E(E(_bW).a),_lF=E(_lC.a),_lG=_lF.b,_lH=E(_lF.a);if(E(_lE.a)!=_lH){var _lI=function(_lJ){while(1){var _lK=E(_lJ);if(!_lK._){return true;}else{var _lL=_lK.b,_lM=E(E(_lK.a).a);if(E(_lM.a)!=_lH){_lJ=_lL;continue;}else{if(E(_lM.b)!=E(_lG)){_lJ=_lL;continue;}else{return false;}}}}};if(!B(_lI(_bX))){return false;}else{_lz=_lD;return __continue;}}else{var _lN=E(_lG);if(E(_lE.b)!=_lN){var _lO=function(_lP){while(1){var _lQ=E(_lP);if(!_lQ._){return true;}else{var _lR=_lQ.b,_lS=E(E(_lQ.a).a);if(E(_lS.a)!=_lH){_lP=_lR;continue;}else{if(E(_lS.b)!=_lN){_lP=_lR;continue;}else{return false;}}}}};if(!B(_lO(_bX))){return false;}else{_lz=_lD;return __continue;}}else{return false;}}}})(_lz));if(_lA!=__continue){return _lA;}}},_lT=function(_lU){var _lV=E(_lU);if(!_lV._){return E(_cX);}else{var _lW=E(_lV.a),_lX=_lW.a,_lY=new T(function(){return B(_lT(_lV.b));});if(E(_lW.b)==114){var _lZ=new T(function(){return B(_5B(2,new T(function(){var _m0=E(_lX);if(E(_m0.a)==8){if(E(_m0.b)==8){return true;}else{return E(_bS);}}else{return E(_bS);}}),B(_5B(3,new T(function(){var _m1=E(_lX);if(E(_m1.a)==1){if(E(_m1.b)==8){return true;}else{return E(_bR);}}else{return E(_bR);}}),_bL))));}),_m2=function(_m3,_m4,_m5){var _m6=E(_m3);if(!_m6){var _m7=E(_m4);if(!_m7){return E(_m5);}else{var _m8=E(_lX),_m9=E(_m8.a);if(_m9<1){return E(_m5);}else{if(_m9>8){return E(_m5);}else{var _ma=E(_m8.b),_mb=_ma+_m7|0;if(_mb<1){return E(_m5);}else{if(_mb>8){return E(_m5);}else{var _mc=B(_4i(_m9,_ma,_m9,_mb));if(!_mc._){return E(_aL);}else{var _md=E(_mc.b);if(!_md._){return E(_8I);}else{if(!B(_ly(B(_8D(_md.a,_md.b))))){return E(_m5);}else{var _me=function(_mf){while(1){var _mg=E(_mf);if(!_mg._){return true;}else{var _mh=_mg.b,_mi=E(_mg.a),_mj=E(_mi.a);if(E(_mj.a)!=_m9){_mf=_mh;continue;}else{if(E(_mj.b)!=_mb){_mf=_mh;continue;}else{var _mk=u_iswupper(E(_mi.b));if(!E(_mk)){return false;}else{_mf=_mh;continue;}}}}}};if(!B((function(_ml,_mm){var _mn=E(_ml),_mo=E(_mn.a);if(E(_mo.a)!=_m9){return new F(function(){return _me(_mm);});}else{if(E(_mo.b)!=_mb){return new F(function(){return _me(_mm);});}else{var _mp=u_iswupper(E(_mn.b));if(!E(_mp)){return false;}else{return new F(function(){return _me(_mm);});}}}})(_bW,_bX))){return E(_m5);}else{var _mq=new T(function(){var _mr=function(_ms){while(1){var _mt=E(_ms);if(!_mt._){return false;}else{var _mu=_mt.b,_mv=E(E(_mt.a).a);if(E(_mv.a)!=_m9){_ms=_mu;continue;}else{if(E(_mv.b)!=_mb){_ms=_mu;continue;}else{return true;}}}}};if(!B((function(_mw,_mx){var _my=E(E(_mw).a);if(E(_my.a)!=_m9){return new F(function(){return _mr(_mx);});}else{if(E(_my.b)!=_mb){return new F(function(){return _mr(_mx);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_mz=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_m9)==8){if(E(_mb)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_m9)==1){if(E(_mb)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_lZ))));}),_mA=new T(function(){var _mB=function(_mC){var _mD=E(_mC),_mE=E(_mD.a),_mF=_mE.b,_mG=E(_mE.a),_mH=function(_mI){return (_mG!=_m9)?true:(E(_mF)!=_ma)?true:(E(_mD.b)==114)?false:true;};if(_mG!=_m9){return new F(function(){return _mH(_);});}else{if(E(_mF)!=_mb){return new F(function(){return _mH(_);});}else{return false;}}};return B(_5R(_mB,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_m9,_mb),_9b),_mA),b:_5L,c:_mz,d:_bM,e:_mq,f:_8S,g:_8L,h:_8L,i:_5K},_m5);}}}}}}}}}}else{var _mJ=E(_lX),_mK=E(_mJ.a),_mL=_mK+_m6|0;if(_mL<1){return E(_m5);}else{if(_mL>8){return E(_m5);}else{var _mM=E(_mJ.b),_mN=_mM+E(_m4)|0;if(_mN<1){return E(_m5);}else{if(_mN>8){return E(_m5);}else{var _mO=B(_4i(_mK,_mM,_mL,_mN));if(!_mO._){return E(_aL);}else{var _mP=E(_mO.b);if(!_mP._){return E(_8I);}else{if(!B(_ly(B(_8D(_mP.a,_mP.b))))){return E(_m5);}else{var _mQ=function(_mR){while(1){var _mS=E(_mR);if(!_mS._){return true;}else{var _mT=_mS.b,_mU=E(_mS.a),_mV=E(_mU.a);if(E(_mV.a)!=_mL){_mR=_mT;continue;}else{if(E(_mV.b)!=_mN){_mR=_mT;continue;}else{var _mW=u_iswupper(E(_mU.b));if(!E(_mW)){return false;}else{_mR=_mT;continue;}}}}}};if(!B((function(_mX,_mY){var _mZ=E(_mX),_n0=E(_mZ.a);if(E(_n0.a)!=_mL){return new F(function(){return _mQ(_mY);});}else{if(E(_n0.b)!=_mN){return new F(function(){return _mQ(_mY);});}else{var _n1=u_iswupper(E(_mZ.b));if(!E(_n1)){return false;}else{return new F(function(){return _mQ(_mY);});}}}})(_bW,_bX))){return E(_m5);}else{var _n2=new T(function(){var _n3=function(_n4){while(1){var _n5=E(_n4);if(!_n5._){return false;}else{var _n6=_n5.b,_n7=E(E(_n5.a).a);if(E(_n7.a)!=_mL){_n4=_n6;continue;}else{if(E(_n7.b)!=_mN){_n4=_n6;continue;}else{return true;}}}}};if(!B((function(_n8,_n9){var _na=E(E(_n8).a);if(E(_na.a)!=_mL){return new F(function(){return _n3(_n9);});}else{if(E(_na.b)!=_mN){return new F(function(){return _n3(_n9);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_nb=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_mL)==8){if(E(_mN)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_mL)==1){if(E(_mN)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_lZ))));}),_nc=new T(function(){var _nd=function(_ne){var _nf=E(_ne),_ng=E(_nf.a),_nh=_ng.b,_ni=E(_ng.a),_nj=function(_nk){return (_ni!=_mK)?true:(E(_nh)!=_mM)?true:(E(_nf.b)==114)?false:true;};if(_ni!=_mL){return new F(function(){return _nj(_);});}else{if(E(_nh)!=_mN){return new F(function(){return _nj(_);});}else{return false;}}};return B(_5R(_nd,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_mL,_mN),_9b),_nc),b:_5L,c:_nb,d:_bM,e:_n2,f:_8S,g:_8L,h:_8L,i:_5K},_m5);}}}}}}}}}},_nl=new T(function(){var _nm=function(_nn){var _no=E(_nn);if(!_no._){return E(_lY);}else{var _np=E(_no.a);return new F(function(){return _m2(E(_np.a),_np.b,new T(function(){return B(_nm(_no.b));}));});}};return B(_nm(_aA));}),_nq=function(_nr){var _ns=E(_nr);if(!_ns._){return E(_nl);}else{var _nt=E(_ns.a);return new F(function(){return _m2(E(_nt.a),_nt.b,new T(function(){return B(_nq(_ns.b));}));});}};return new F(function(){return _nq(_as);});}else{return E(_lY);}}},_nu=function(_nv,_nw){var _nx=E(_nv),_ny=_nx.a,_nz=new T(function(){return B(_lT(_nw));});if(E(_nx.b)==114){var _nA=new T(function(){return B(_5B(2,new T(function(){var _nB=E(_ny);if(E(_nB.a)==8){if(E(_nB.b)==8){return true;}else{return E(_bS);}}else{return E(_bS);}}),B(_5B(3,new T(function(){var _nC=E(_ny);if(E(_nC.a)==1){if(E(_nC.b)==8){return true;}else{return E(_bR);}}else{return E(_bR);}}),_bL))));}),_nD=function(_nE,_nF,_nG){var _nH=E(_nE);if(!_nH){var _nI=E(_nF);if(!_nI){return E(_nG);}else{var _nJ=E(_ny),_nK=E(_nJ.a);if(_nK<1){return E(_nG);}else{if(_nK>8){return E(_nG);}else{var _nL=E(_nJ.b),_nM=_nL+_nI|0;if(_nM<1){return E(_nG);}else{if(_nM>8){return E(_nG);}else{var _nN=B(_4i(_nK,_nL,_nK,_nM));if(!_nN._){return E(_aL);}else{var _nO=E(_nN.b);if(!_nO._){return E(_8I);}else{if(!B(_ly(B(_8D(_nO.a,_nO.b))))){return E(_nG);}else{var _nP=function(_nQ){while(1){var _nR=E(_nQ);if(!_nR._){return true;}else{var _nS=_nR.b,_nT=E(_nR.a),_nU=E(_nT.a);if(E(_nU.a)!=_nK){_nQ=_nS;continue;}else{if(E(_nU.b)!=_nM){_nQ=_nS;continue;}else{var _nV=u_iswupper(E(_nT.b));if(!E(_nV)){return false;}else{_nQ=_nS;continue;}}}}}};if(!B(_nP(_bV))){return E(_nG);}else{var _nW=new T(function(){var _nX=function(_nY){while(1){var _nZ=E(_nY);if(!_nZ._){return false;}else{var _o0=_nZ.b,_o1=E(E(_nZ.a).a);if(E(_o1.a)!=_nK){_nY=_o0;continue;}else{if(E(_o1.b)!=_nM){_nY=_o0;continue;}else{return true;}}}}};if(!B(_nX(_bV))){return E(_8M);}else{return E(_90);}}),_o2=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_nK)==8){if(E(_nM)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_nK)==1){if(E(_nM)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_nA))));}),_o3=new T(function(){var _o4=function(_o5){var _o6=E(_o5),_o7=E(_o6.a),_o8=_o7.b,_o9=E(_o7.a),_oa=function(_ob){return (_o9!=_nK)?true:(E(_o8)!=_nL)?true:(E(_o6.b)==114)?false:true;};if(_o9!=_nK){return new F(function(){return _oa(_);});}else{if(E(_o8)!=_nM){return new F(function(){return _oa(_);});}else{return false;}}};return B(_5R(_o4,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_nK,_nM),_9b),_o3),b:_5L,c:_o2,d:_bM,e:_nW,f:_8S,g:_8L,h:_8L,i:_5K},_nG);}}}}}}}}}}else{var _oc=E(_ny),_od=E(_oc.a),_oe=_od+_nH|0;if(_oe<1){return E(_nG);}else{if(_oe>8){return E(_nG);}else{var _of=E(_oc.b),_og=_of+E(_nF)|0;if(_og<1){return E(_nG);}else{if(_og>8){return E(_nG);}else{var _oh=B(_4i(_od,_of,_oe,_og));if(!_oh._){return E(_aL);}else{var _oi=E(_oh.b);if(!_oi._){return E(_8I);}else{if(!B(_ly(B(_8D(_oi.a,_oi.b))))){return E(_nG);}else{var _oj=function(_ok){while(1){var _ol=E(_ok);if(!_ol._){return true;}else{var _om=_ol.b,_on=E(_ol.a),_oo=E(_on.a);if(E(_oo.a)!=_oe){_ok=_om;continue;}else{if(E(_oo.b)!=_og){_ok=_om;continue;}else{var _op=u_iswupper(E(_on.b));if(!E(_op)){return false;}else{_ok=_om;continue;}}}}}};if(!B((function(_oq,_or){var _os=E(_oq),_ot=E(_os.a);if(E(_ot.a)!=_oe){return new F(function(){return _oj(_or);});}else{if(E(_ot.b)!=_og){return new F(function(){return _oj(_or);});}else{var _ou=u_iswupper(E(_os.b));if(!E(_ou)){return false;}else{return new F(function(){return _oj(_or);});}}}})(_bW,_bX))){return E(_nG);}else{var _ov=new T(function(){var _ow=function(_ox){while(1){var _oy=E(_ox);if(!_oy._){return false;}else{var _oz=_oy.b,_oA=E(E(_oy.a).a);if(E(_oA.a)!=_oe){_ox=_oz;continue;}else{if(E(_oA.b)!=_og){_ox=_oz;continue;}else{return true;}}}}};if(!B((function(_oB,_oC){var _oD=E(E(_oB).a);if(E(_oD.a)!=_oe){return new F(function(){return _ow(_oC);});}else{if(E(_oD.b)!=_og){return new F(function(){return _ow(_oC);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_oE=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_oe)==8){if(E(_og)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_oe)==1){if(E(_og)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_nA))));}),_oF=new T(function(){var _oG=function(_oH){var _oI=E(_oH),_oJ=E(_oI.a),_oK=_oJ.b,_oL=E(_oJ.a),_oM=function(_oN){return (_oL!=_od)?true:(E(_oK)!=_of)?true:(E(_oI.b)==114)?false:true;};if(_oL!=_oe){return new F(function(){return _oM(_);});}else{if(E(_oK)!=_og){return new F(function(){return _oM(_);});}else{return false;}}};return B(_5R(_oG,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_oe,_og),_9b),_oF),b:_5L,c:_oE,d:_bM,e:_ov,f:_8S,g:_8L,h:_8L,i:_5K},_nG);}}}}}}}}}},_oO=new T(function(){var _oP=function(_oQ){var _oR=E(_oQ);if(!_oR._){return E(_nz);}else{var _oS=E(_oR.a);return new F(function(){return _nD(E(_oS.a),_oS.b,new T(function(){return B(_oP(_oR.b));}));});}};return B(_oP(_aA));}),_oT=function(_oU){var _oV=E(_oU);if(!_oV._){return E(_oO);}else{var _oW=E(_oV.a);return new F(function(){return _nD(E(_oW.a),_oW.b,new T(function(){return B(_oT(_oV.b));}));});}};return new F(function(){return _oT(_as);});}else{return E(_nz);}};return B(_nu(_bW,_bX));}),_oX=function(_oY){while(1){var _oZ=B((function(_p0){var _p1=E(_p0);if(!_p1._){return E(_cW);}else{var _p2=_p1.b,_p3=E(_p1.a),_p4=_p3.a;if(E(_p3.b)==112){var _p5=new T(function(){return E(E(_p4).b)-1|0;}),_p6=function(_p7,_p8){var _p9=E(_bO),_pa=E(_p4),_pb=E(_pa.a),_pc=_pb+_p7|0;if(_pc!=E(_p9.a)){return E(_p8);}else{var _pd=E(_p5);if(_pd!=E(_p9.b)){return E(_p8);}else{var _pe=new T(function(){var _pf=function(_pg){var _ph=E(_pg),_pi=E(_ph.a),_pj=_pi.b,_pk=E(_pi.a),_pl=function(_pm){return (_pk!=_pb)?true:(E(_pj)!=E(_pa.b))?true:(E(_ph.b)==112)?false:true;};if(_pk!=_pc){return new F(function(){return _pl(_);});}else{if(E(_pj)!=(_pd+1|0)){return new F(function(){return _pl(_);});}else{return false;}}};return B(_5R(_pf,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_pc,_pd),_aB),_pe),b:_5L,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_p8);}}},_pn=new T(function(){return B(_p6(1,new T(function(){return B(_oX(_p2));})));});return new F(function(){return _p6(-1,_pn);});}else{_oY=_p2;return __continue;}}})(_oY));if(_oZ!=__continue){return _oZ;}}},_po=function(_pp,_pq){var _pr=E(_pp),_ps=_pr.a;if(E(_pr.b)==112){var _pt=new T(function(){return E(E(_ps).b)-1|0;}),_pu=function(_pv,_pw){var _px=E(_bO),_py=E(_ps),_pz=E(_py.a),_pA=_pz+_pv|0;if(_pA!=E(_px.a)){return E(_pw);}else{var _pB=E(_pt);if(_pB!=E(_px.b)){return E(_pw);}else{var _pC=new T(function(){var _pD=function(_pE){var _pF=E(_pE),_pG=E(_pF.a),_pH=_pG.b,_pI=E(_pG.a),_pJ=function(_pK){return (_pI!=_pz)?true:(E(_pH)!=E(_py.b))?true:(E(_pF.b)==112)?false:true;};if(_pI!=_pA){return new F(function(){return _pJ(_);});}else{if(E(_pH)!=(_pB+1|0)){return new F(function(){return _pJ(_);});}else{return false;}}};return B(_5R(_pD,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_pA,_pB),_aB),_pC),b:_5L,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_pw);}}},_pL=new T(function(){return B(_pu(1,new T(function(){return B(_oX(_pq));})));});return new F(function(){return _pu(-1,_pL);});}else{return new F(function(){return _oX(_pq);});}};return B(_po(_bW,_bX));}),_pM=function(_pN){while(1){var _pO=B((function(_pP){var _pQ=E(_pP);if(!_pQ._){return E(_cV);}else{var _pR=_pQ.b,_pS=E(_pQ.a),_pT=_pS.a;if(E(_pS.b)==112){var _pU=new T(function(){return E(E(_pT).b)-1|0;}),_pV=function(_pW,_pX){var _pY=E(_pT),_pZ=_pY.b,_q0=E(_pY.a),_q1=_q0+_pW|0;if(_q1<1){return E(_pX);}else{if(_q1>8){return E(_pX);}else{var _q2=E(_pU);if(_q2<1){return E(_pX);}else{if(_q2>8){return E(_pX);}else{var _q3=function(_q4){while(1){var _q5=E(_q4);if(!_q5._){return false;}else{var _q6=_q5.b,_q7=E(_q5.a),_q8=E(_q7.a);if(E(_q8.a)!=_q1){_q4=_q6;continue;}else{if(E(_q8.b)!=_q2){_q4=_q6;continue;}else{var _q9=u_iswupper(E(_q7.b));if(!E(_q9)){_q4=_q6;continue;}else{return true;}}}}}};if(!B((function(_qa,_qb){var _qc=E(_qa),_qd=E(_qc.a);if(E(_qd.a)!=_q1){return new F(function(){return _q3(_qb);});}else{if(E(_qd.b)!=_q2){return new F(function(){return _q3(_qb);});}else{var _qe=u_iswupper(E(_qc.b));if(!E(_qe)){return new F(function(){return _q3(_qb);});}else{return true;}}}})(_bW,_bX))){return E(_pX);}else{var _qf=new T2(0,_q1,_q2),_qg=E(_q2);if(_qg==1){var _qh=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_q1)==8){return true;}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_q1)==1){return true;}else{return false;}}else{return true;}}),_bL))));}),_qi=new T(function(){var _qj=function(_qk){var _ql=E(_qk),_qm=E(_ql.a),_qn=_qm.b,_qo=E(_qm.a),_qp=function(_qq){return (_qo!=_q0)?true:(E(_qn)!=E(_pZ))?true:(E(_ql.b)==112)?false:true;};if(_qo!=_q1){return new F(function(){return _qp(_);});}else{if(E(_qn)==1){return false;}else{return new F(function(){return _qp(_);});}}};return B(_5R(_qj,_bV));}),_qr=new T(function(){var _qs=function(_qt){var _qu=E(_qt),_qv=E(_qu.a),_qw=_qv.b,_qx=E(_qv.a),_qy=function(_qz){return (_qx!=_q0)?true:(E(_qw)!=E(_pZ))?true:(E(_qu.b)==112)?false:true;};if(_qx!=_q1){return new F(function(){return _qy(_);});}else{if(E(_qw)==1){return false;}else{return new F(function(){return _qy(_);});}}};return B(_5R(_qs,_bV));}),_qA=new T(function(){var _qB=function(_qC){var _qD=E(_qC),_qE=E(_qD.a),_qF=_qE.b,_qG=E(_qE.a),_qH=function(_qI){return (_qG!=_q0)?true:(E(_qF)!=E(_pZ))?true:(E(_qD.b)==112)?false:true;};if(_qG!=_q1){return new F(function(){return _qH(_);});}else{if(E(_qF)==1){return false;}else{return new F(function(){return _qH(_);});}}};return B(_5R(_qB,_bV));}),_qJ=new T(function(){var _qK=function(_qL){var _qM=E(_qL),_qN=E(_qM.a),_qO=_qN.b,_qP=E(_qN.a),_qQ=function(_qR){return (_qP!=_q0)?true:(E(_qO)!=E(_pZ))?true:(E(_qM.b)==112)?false:true;};if(_qP!=_q1){return new F(function(){return _qQ(_);});}else{if(E(_qO)==1){return false;}else{return new F(function(){return _qQ(_);});}}};return B(_5R(_qK,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_qf,_ai),_qJ),b:_5L,c:_qh,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_qf,_9b),_qA),b:_5L,c:_qh,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_qf,_ak),_qr),b:_5L,c:_qh,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_qf,_aj),_qi),b:_5L,c:_qh,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},_pX))));}else{var _qS=new T(function(){var _qT=function(_qU){var _qV=E(_qU),_qW=E(_qV.a),_qX=_qW.b,_qY=E(_qW.a),_qZ=function(_r0){return (_qY!=_q0)?true:(E(_qX)!=E(_pZ))?true:(E(_qV.b)==112)?false:true;};if(_qY!=_q1){return new F(function(){return _qZ(_);});}else{if(E(_qX)!=_qg){return new F(function(){return _qZ(_);});}else{return false;}}};return B(_5R(_qT,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_qf,_aB),_qS),b:_5L,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_pX);}}}}}}},_r1=new T(function(){return B(_pV(1,new T(function(){return B(_pM(_pR));})));});return new F(function(){return _pV(-1,_r1);});}else{_pN=_pR;return __continue;}}})(_pN));if(_pO!=__continue){return _pO;}}},_r2=function(_r3,_r4){var _r5=E(_r3),_r6=_r5.a;if(E(_r5.b)==112){var _r7=new T(function(){return E(E(_r6).b)-1|0;}),_r8=function(_r9,_ra){var _rb=E(_r6),_rc=_rb.b,_rd=E(_rb.a),_re=_rd+_r9|0;if(_re<1){return E(_ra);}else{if(_re>8){return E(_ra);}else{var _rf=E(_r7);if(_rf<1){return E(_ra);}else{if(_rf>8){return E(_ra);}else{var _rg=function(_rh){while(1){var _ri=E(_rh);if(!_ri._){return false;}else{var _rj=_ri.b,_rk=E(_ri.a),_rl=E(_rk.a);if(E(_rl.a)!=_re){_rh=_rj;continue;}else{if(E(_rl.b)!=_rf){_rh=_rj;continue;}else{var _rm=u_iswupper(E(_rk.b));if(!E(_rm)){_rh=_rj;continue;}else{return true;}}}}}};if(!B((function(_rn,_ro){var _rp=E(_rn),_rq=E(_rp.a);if(E(_rq.a)!=_re){return new F(function(){return _rg(_ro);});}else{if(E(_rq.b)!=_rf){return new F(function(){return _rg(_ro);});}else{var _rr=u_iswupper(E(_rp.b));if(!E(_rr)){return new F(function(){return _rg(_ro);});}else{return true;}}}})(_bW,_bX))){return E(_ra);}else{var _rs=new T2(0,_re,_rf),_rt=E(_rf);if(_rt==1){var _ru=new T(function(){return B(_5B(0,new T(function(){if(!E(_bU)){if(E(_re)==8){return true;}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_re)==1){return true;}else{return false;}}else{return true;}}),_bL))));}),_rv=new T(function(){var _rw=function(_rx){var _ry=E(_rx),_rz=E(_ry.a),_rA=_rz.b,_rB=E(_rz.a),_rC=function(_rD){return (_rB!=_rd)?true:(E(_rA)!=E(_rc))?true:(E(_ry.b)==112)?false:true;};if(_rB!=_re){return new F(function(){return _rC(_);});}else{if(E(_rA)==1){return false;}else{return new F(function(){return _rC(_);});}}};return B(_5R(_rw,_bV));}),_rE=new T(function(){var _rF=function(_rG){var _rH=E(_rG),_rI=E(_rH.a),_rJ=_rI.b,_rK=E(_rI.a),_rL=function(_rM){return (_rK!=_rd)?true:(E(_rJ)!=E(_rc))?true:(E(_rH.b)==112)?false:true;};if(_rK!=_re){return new F(function(){return _rL(_);});}else{if(E(_rJ)==1){return false;}else{return new F(function(){return _rL(_);});}}};return B(_5R(_rF,_bV));}),_rN=new T(function(){var _rO=function(_rP){var _rQ=E(_rP),_rR=E(_rQ.a),_rS=_rR.b,_rT=E(_rR.a),_rU=function(_rV){return (_rT!=_rd)?true:(E(_rS)!=E(_rc))?true:(E(_rQ.b)==112)?false:true;};if(_rT!=_re){return new F(function(){return _rU(_);});}else{if(E(_rS)==1){return false;}else{return new F(function(){return _rU(_);});}}};return B(_5R(_rO,_bV));}),_rW=new T(function(){var _rX=function(_rY){var _rZ=E(_rY),_s0=E(_rZ.a),_s1=_s0.b,_s2=E(_s0.a),_s3=function(_s4){return (_s2!=_rd)?true:(E(_s1)!=E(_rc))?true:(E(_rZ.b)==112)?false:true;};if(_s2!=_re){return new F(function(){return _s3(_);});}else{if(E(_s1)==1){return false;}else{return new F(function(){return _s3(_);});}}};return B(_5R(_rX,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_rs,_ai),_rW),b:_5L,c:_ru,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_rs,_9b),_rN),b:_5L,c:_ru,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_rs,_ak),_rE),b:_5L,c:_ru,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_rs,_aj),_rv),b:_5L,c:_ru,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},_ra))));}else{var _s5=new T(function(){var _s6=function(_s7){var _s8=E(_s7),_s9=E(_s8.a),_sa=_s9.b,_sb=E(_s9.a),_sc=function(_sd){return (_sb!=_rd)?true:(E(_sa)!=E(_rc))?true:(E(_s8.b)==112)?false:true;};if(_sb!=_re){return new F(function(){return _sc(_);});}else{if(E(_sa)!=_rt){return new F(function(){return _sc(_);});}else{return false;}}};return B(_5R(_s6,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_rs,_aB),_s5),b:_5L,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_ra);}}}}}}},_se=new T(function(){return B(_r8(1,new T(function(){return B(_pM(_r4));})));});return new F(function(){return _r8(-1,_se);});}else{return new F(function(){return _pM(_r4);});}};return B(_r2(_bW,_bX));}),_sf=function(_sg){while(1){var _sh=B((function(_si){var _sj=E(_si);if(!_sj._){return E(_cU);}else{var _sk=_sj.b,_sl=E(_sj.a);if(E(_sl.b)==112){var _sm=E(_sl.a);if(E(_sm.b)==7){var _sn=E(E(_bW).a),_so=_sn.b,_sp=E(_sn.a),_sq=E(_sm.a),_sr=function(_ss){if(_sp!=_sq){var _st=function(_su){var _sv=E(_su);if(!_sv._){return true;}else{var _sw=_sv.b,_sx=E(E(_sv.a).a),_sy=_sx.b,_sz=E(_sx.a),_sA=function(_sB){if(_sz!=_sq){return new F(function(){return _st(_sw);});}else{if(E(_sy)==6){return false;}else{return new F(function(){return _st(_sw);});}}};if(_sz!=_sq){return new F(function(){return _sA(_);});}else{if(E(_sy)==5){return false;}else{return new F(function(){return _sA(_);});}}}};return new F(function(){return _st(_bX);});}else{if(E(_so)==6){return false;}else{var _sC=function(_sD){var _sE=E(_sD);if(!_sE._){return true;}else{var _sF=_sE.b,_sG=E(E(_sE.a).a),_sH=_sG.b,_sI=E(_sG.a),_sJ=function(_sK){if(_sI!=_sq){return new F(function(){return _sC(_sF);});}else{if(E(_sH)==6){return false;}else{return new F(function(){return _sC(_sF);});}}};if(_sI!=_sq){return new F(function(){return _sJ(_);});}else{if(E(_sH)==5){return false;}else{return new F(function(){return _sJ(_);});}}}};return new F(function(){return _sC(_bX);});}}},_sL=function(_sM){var _sN=new T(function(){return B(_5R(function(_sO){var _sP=E(_sO),_sQ=E(_sP.a);return (E(_sQ.a)!=_sq)?true:(E(_sQ.b)==7)?(E(_sP.b)==112)?false:true:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_sq,_8P),_aB),_sN),b:_5L,c:_bL,d:_bM,e:_8M,f:new T2(0,_sq,_8Q),g:_8L,h:_8L,i:_5K},new T(function(){return B(_sf(_sk));}));};if(_sp!=_sq){if(!B(_sr(_))){_sg=_sk;return __continue;}else{return new F(function(){return _sL(_);});}}else{if(E(_so)==5){_sg=_sk;return __continue;}else{if(!B(_sr(_))){_sg=_sk;return __continue;}else{return new F(function(){return _sL(_);});}}}}else{_sg=_sk;return __continue;}}else{_sg=_sk;return __continue;}}})(_sg));if(_sh!=__continue){return _sh;}}},_sR=function(_sS,_sT){var _sU=E(_sS);if(E(_sU.b)==112){var _sV=E(_sU.a);if(E(_sV.b)==7){var _sW=E(E(_bW).a),_sX=_sW.b,_sY=E(_sW.a),_sZ=E(_sV.a),_t0=function(_t1){if(_sY!=_sZ){var _t2=function(_t3){var _t4=E(_t3);if(!_t4._){return true;}else{var _t5=_t4.b,_t6=E(E(_t4.a).a),_t7=_t6.b,_t8=E(_t6.a),_t9=function(_ta){if(_t8!=_sZ){return new F(function(){return _t2(_t5);});}else{if(E(_t7)==6){return false;}else{return new F(function(){return _t2(_t5);});}}};if(_t8!=_sZ){return new F(function(){return _t9(_);});}else{if(E(_t7)==5){return false;}else{return new F(function(){return _t9(_);});}}}};return new F(function(){return _t2(_bX);});}else{if(E(_sX)==6){return false;}else{var _tb=function(_tc){var _td=E(_tc);if(!_td._){return true;}else{var _te=_td.b,_tf=E(E(_td.a).a),_tg=_tf.b,_th=E(_tf.a),_ti=function(_tj){if(_th!=_sZ){return new F(function(){return _tb(_te);});}else{if(E(_tg)==6){return false;}else{return new F(function(){return _tb(_te);});}}};if(_th!=_sZ){return new F(function(){return _ti(_);});}else{if(E(_tg)==5){return false;}else{return new F(function(){return _ti(_);});}}}};return new F(function(){return _tb(_bX);});}}},_tk=function(_tl){var _tm=new T(function(){return B(_5R(function(_tn){var _to=E(_tn),_tp=E(_to.a);return (E(_tp.a)!=_sZ)?true:(E(_tp.b)==7)?(E(_to.b)==112)?false:true:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_sZ,_8P),_aB),_tm),b:_5L,c:_bL,d:_bM,e:_8M,f:new T2(0,_sZ,_8Q),g:_8L,h:_8L,i:_5K},new T(function(){return B(_sf(_sT));}));};if(_sY!=_sZ){if(!B(_t0(_))){return new F(function(){return _sf(_sT);});}else{return new F(function(){return _tk(_);});}}else{if(E(_sX)==5){return new F(function(){return _sf(_sT);});}else{if(!B(_t0(_))){return new F(function(){return _sf(_sT);});}else{return new F(function(){return _tk(_);});}}}}else{return new F(function(){return _sf(_sT);});}}else{return new F(function(){return _sf(_sT);});}};return B(_sR(_bW,_bX));}),_tq=function(_tr){while(1){var _ts=B((function(_tt){var _tu=E(_tt);if(!_tu._){return E(_cT);}else{var _tv=_tu.b,_tw=E(_tu.a),_tx=_tw.a;if(E(_tw.b)==112){var _ty=new T(function(){return E(E(_tx).b)-1|0;}),_tz=E(E(_bW).a),_tA=E(_tx),_tB=_tA.b,_tC=E(_tA.a),_tD=function(_tE){var _tF=E(_ty),_tG=new T2(0,_tC,_tF);if(E(_tF)==1){var _tH=new T(function(){return B(_5R(function(_tI){var _tJ=E(_tI),_tK=E(_tJ.a);return (E(_tK.a)!=_tC)?true:(E(_tK.b)!=E(_tB))?true:(E(_tJ.b)==112)?false:true;},_bV));}),_tL=new T(function(){return B(_5R(function(_tM){var _tN=E(_tM),_tO=E(_tN.a);return (E(_tO.a)!=_tC)?true:(E(_tO.b)!=E(_tB))?true:(E(_tN.b)==112)?false:true;},_bV));}),_tP=new T(function(){return B(_5R(function(_tQ){var _tR=E(_tQ),_tS=E(_tR.a);return (E(_tS.a)!=_tC)?true:(E(_tS.b)!=E(_tB))?true:(E(_tR.b)==112)?false:true;},_bV));}),_tT=new T(function(){return B(_5R(function(_tU){var _tV=E(_tU),_tW=E(_tV.a);return (E(_tW.a)!=_tC)?true:(E(_tW.b)!=E(_tB))?true:(E(_tV.b)==112)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_tG,_ai),_tT),b:_5L,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_tG,_9b),_tP),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_tG,_ak),_tL),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_tG,_aj),_tH),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_tq(_tv));})))));}else{var _tX=new T(function(){return B(_5R(function(_tY){var _tZ=E(_tY),_u0=E(_tZ.a);return (E(_u0.a)!=_tC)?true:(E(_u0.b)!=E(_tB))?true:(E(_tZ.b)==112)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_tG,_aB),_tX),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_tq(_tv));}));}};if(E(_tz.a)!=_tC){var _u1=function(_u2){while(1){var _u3=E(_u2);if(!_u3._){return true;}else{var _u4=_u3.b,_u5=E(E(_u3.a).a);if(E(_u5.a)!=_tC){_u2=_u4;continue;}else{if(E(_u5.b)!=E(_ty)){_u2=_u4;continue;}else{return false;}}}}};if(!B(_u1(_bX))){_tr=_tv;return __continue;}else{return new F(function(){return _tD(_);});}}else{var _u6=E(_ty);if(E(_tz.b)!=_u6){var _u7=function(_u8){while(1){var _u9=E(_u8);if(!_u9._){return true;}else{var _ua=_u9.b,_ub=E(E(_u9.a).a);if(E(_ub.a)!=_tC){_u8=_ua;continue;}else{if(E(_ub.b)!=_u6){_u8=_ua;continue;}else{return false;}}}}};if(!B(_u7(_bX))){_tr=_tv;return __continue;}else{return new F(function(){return _tD(_);});}}else{_tr=_tv;return __continue;}}}else{_tr=_tv;return __continue;}}})(_tr));if(_ts!=__continue){return _ts;}}},_uc=function(_ud,_ue){var _uf=E(_ud),_ug=_uf.a;if(E(_uf.b)==112){var _uh=new T(function(){return E(E(_ug).b)-1|0;}),_ui=E(E(_bW).a),_uj=E(_ug),_uk=_uj.b,_ul=E(_uj.a),_um=function(_un){var _uo=E(_uh),_up=new T2(0,_ul,_uo);if(E(_uo)==1){var _uq=new T(function(){return B(_5R(function(_ur){var _us=E(_ur),_ut=E(_us.a);return (E(_ut.a)!=_ul)?true:(E(_ut.b)!=E(_uk))?true:(E(_us.b)==112)?false:true;},_bV));}),_uu=new T(function(){return B(_5R(function(_uv){var _uw=E(_uv),_ux=E(_uw.a);return (E(_ux.a)!=_ul)?true:(E(_ux.b)!=E(_uk))?true:(E(_uw.b)==112)?false:true;},_bV));}),_uy=new T(function(){return B(_5R(function(_uz){var _uA=E(_uz),_uB=E(_uA.a);return (E(_uB.a)!=_ul)?true:(E(_uB.b)!=E(_uk))?true:(E(_uA.b)==112)?false:true;},_bV));}),_uC=new T(function(){return B(_5R(function(_uD){var _uE=E(_uD),_uF=E(_uE.a);return (E(_uF.a)!=_ul)?true:(E(_uF.b)!=E(_uk))?true:(E(_uE.b)==112)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_up,_ai),_uC),b:_5L,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_up,_9b),_uy),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_up,_ak),_uu),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_up,_aj),_uq),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_tq(_ue));})))));}else{var _uG=new T(function(){return B(_5R(function(_uH){var _uI=E(_uH),_uJ=E(_uI.a);return (E(_uJ.a)!=_ul)?true:(E(_uJ.b)!=E(_uk))?true:(E(_uI.b)==112)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_up,_aB),_uG),b:_5L,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_tq(_ue));}));}};if(E(_ui.a)!=_ul){var _uK=function(_uL){while(1){var _uM=E(_uL);if(!_uM._){return true;}else{var _uN=_uM.b,_uO=E(E(_uM.a).a);if(E(_uO.a)!=_ul){_uL=_uN;continue;}else{if(E(_uO.b)!=E(_uh)){_uL=_uN;continue;}else{return false;}}}}};if(!B(_uK(_bX))){return new F(function(){return _tq(_ue);});}else{return new F(function(){return _um(_);});}}else{var _uP=E(_uh);if(E(_ui.b)!=_uP){var _uQ=function(_uR){while(1){var _uS=E(_uR);if(!_uS._){return true;}else{var _uT=_uS.b,_uU=E(E(_uS.a).a);if(E(_uU.a)!=_ul){_uR=_uT;continue;}else{if(E(_uU.b)!=_uP){_uR=_uT;continue;}else{return false;}}}}};if(!B(_uQ(_bX))){return new F(function(){return _tq(_ue);});}else{return new F(function(){return _um(_);});}}else{return new F(function(){return _tq(_ue);});}}}else{return new F(function(){return _tq(_ue);});}},_uV=B(_uc(_bW,_bX));}else{var _uW=new T(function(){var _uX=new T(function(){var _uY=new T(function(){var _uZ=new T(function(){var _v0=new T(function(){var _v1=new T(function(){var _v2=new T(function(){var _v3=new T(function(){var _v4=function(_v5,_v6,_v7){var _v8=E(_bY),_v9=E(_v8.a),_va=E(_v9.a),_vb=_va+_v5|0;if(_vb<1){return E(_v7);}else{if(_vb>8){return E(_v7);}else{var _vc=E(_v9.b),_vd=_vc+_v6|0;if(_vd<1){return E(_v7);}else{if(_vd>8){return E(_v7);}else{var _ve=function(_vf){while(1){var _vg=E(_vf);if(!_vg._){return true;}else{var _vh=_vg.b,_vi=E(_vg.a),_vj=E(_vi.a);if(E(_vj.a)!=_vb){_vf=_vh;continue;}else{if(E(_vj.b)!=_vd){_vf=_vh;continue;}else{var _vk=u_iswlower(E(_vi.b));if(!E(_vk)){return false;}else{_vf=_vh;continue;}}}}}};if(!B((function(_vl,_vm){var _vn=E(_vl),_vo=E(_vn.a);if(E(_vo.a)!=_vb){return new F(function(){return _ve(_vm);});}else{if(E(_vo.b)!=_vd){return new F(function(){return _ve(_vm);});}else{var _vp=u_iswlower(E(_vn.b));if(!E(_vp)){return false;}else{return new F(function(){return _ve(_vm);});}}}})(_bW,_bX))){return E(_v7);}else{var _vq=new T(function(){var _vr=function(_vs){while(1){var _vt=E(_vs);if(!_vt._){return false;}else{var _vu=_vt.b,_vv=E(E(_vt.a).a);if(E(_vv.a)!=_vb){_vs=_vu;continue;}else{if(E(_vv.b)!=_vd){_vs=_vu;continue;}else{return true;}}}}};if(!B((function(_vw,_vx){var _vy=E(E(_vw).a);if(E(_vy.a)!=_vb){return new F(function(){return _vr(_vx);});}else{if(E(_vy.b)!=_vd){return new F(function(){return _vr(_vx);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_vz=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_vb)==8){if(E(_vd)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_vb)==1){if(E(_vd)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_ce))));}),_vA=new T(function(){var _vB=function(_vC){var _vD=E(_vC),_vE=E(_vD.a),_vF=_vE.b,_vG=E(_vE.a),_vH=function(_vI){return (_vG!=_va)?true:(E(_vF)!=_vc)?true:(E(_vD.b)!=E(_v8.b))?true:false;};if(_vG!=_vb){return new F(function(){return _vH(_);});}else{if(E(_vF)!=_vd){return new F(function(){return _vH(_);});}else{return false;}}};return B(_5R(_vB,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_vb,_vd),_93),_vA),b:_5J,c:_vz,d:_bM,e:_vq,f:_8S,g:_8L,h:_8L,i:_5K},_v7);}}}}}},_vJ=new T(function(){var _vK=new T(function(){var _vL=new T(function(){var _vM=new T(function(){var _vN=new T(function(){var _vO=new T(function(){return B(_v4(-1,-1,new T(function(){return B(_v4(-1,0,_cf));})));});return B(_v4(0,-1,_vO));});return B(_v4(1,-1,_vN));});return B(_v4(1,0,_vM));});return B(_v4(1,1,_vL));});return B(_v4(0,1,_vK));});return B(_v4(-1,1,_vJ));}),_vP=function(_vQ){while(1){var _vR=B((function(_vS){var _vT=E(_vS);if(!_vT._){return true;}else{var _vU=_vT.b,_vV=E(E(_bW).a),_vW=E(_vT.a),_vX=_vW.b,_vY=E(_vW.a);if(E(_vV.a)!=_vY){var _vZ=function(_w0){while(1){var _w1=E(_w0);if(!_w1._){return true;}else{var _w2=_w1.b,_w3=E(E(_w1.a).a);if(E(_w3.a)!=_vY){_w0=_w2;continue;}else{if(E(_w3.b)!=E(_vX)){_w0=_w2;continue;}else{return false;}}}}};if(!B(_vZ(_bX))){return false;}else{_vQ=_vU;return __continue;}}else{var _w4=E(_vX);if(E(_vV.b)!=_w4){var _w5=function(_w6){while(1){var _w7=E(_w6);if(!_w7._){return true;}else{var _w8=_w7.b,_w9=E(E(_w7.a).a);if(E(_w9.a)!=_vY){_w6=_w8;continue;}else{if(E(_w9.b)!=_w4){_w6=_w8;continue;}else{return false;}}}}};if(!B(_w5(_bX))){return false;}else{_vQ=_vU;return __continue;}}else{return false;}}}})(_vQ));if(_vR!=__continue){return _vR;}}},_wa=function(_wb){var _wc=E(_wb);if(!_wc._){return E(_v3);}else{var _wd=E(_wc.a),_we=_wd.a,_wf=new T(function(){return B(_wa(_wc.b));});if(E(_wd.b)==81){var _wg=function(_wh,_wi,_wj){var _wk=E(_we),_wl=E(_wk.a),_wm=_wl+_wh|0;if(_wm<1){return E(_wj);}else{if(_wm>8){return E(_wj);}else{var _wn=E(_wk.b),_wo=_wn+_wi|0;if(_wo<1){return E(_wj);}else{if(_wo>8){return E(_wj);}else{var _wp=B(_4i(_wl,_wn,_wm,_wo));if(!_wp._){return E(_aL);}else{var _wq=E(_wp.b);if(!_wq._){return E(_8I);}else{if(!B(_vP(B(_8D(_wq.a,_wq.b))))){return E(_wj);}else{var _wr=function(_ws){while(1){var _wt=E(_ws);if(!_wt._){return true;}else{var _wu=_wt.b,_wv=E(_wt.a),_ww=E(_wv.a);if(E(_ww.a)!=_wm){_ws=_wu;continue;}else{if(E(_ww.b)!=_wo){_ws=_wu;continue;}else{var _wx=u_iswlower(E(_wv.b));if(!E(_wx)){return false;}else{_ws=_wu;continue;}}}}}};if(!B((function(_wy,_wz){var _wA=E(_wy),_wB=E(_wA.a);if(E(_wB.a)!=_wm){return new F(function(){return _wr(_wz);});}else{if(E(_wB.b)!=_wo){return new F(function(){return _wr(_wz);});}else{var _wC=u_iswlower(E(_wA.b));if(!E(_wC)){return false;}else{return new F(function(){return _wr(_wz);});}}}})(_bW,_bX))){return E(_wj);}else{var _wD=new T(function(){var _wE=function(_wF){while(1){var _wG=E(_wF);if(!_wG._){return false;}else{var _wH=_wG.b,_wI=E(E(_wG.a).a);if(E(_wI.a)!=_wm){_wF=_wH;continue;}else{if(E(_wI.b)!=_wo){_wF=_wH;continue;}else{return true;}}}}};if(!B((function(_wJ,_wK){var _wL=E(E(_wJ).a);if(E(_wL.a)!=_wm){return new F(function(){return _wE(_wK);});}else{if(E(_wL.b)!=_wo){return new F(function(){return _wE(_wK);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_wM=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_wm)==8){if(E(_wo)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_wm)==1){if(E(_wo)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_wN=new T(function(){var _wO=function(_wP){var _wQ=E(_wP),_wR=E(_wQ.a),_wS=_wR.b,_wT=E(_wR.a),_wU=function(_wV){return (_wT!=_wl)?true:(E(_wS)!=_wn)?true:(E(_wQ.b)==81)?false:true;};if(_wT!=_wm){return new F(function(){return _wU(_);});}else{if(E(_wS)!=_wo){return new F(function(){return _wU(_);});}else{return false;}}};return B(_5R(_wO,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_wm,_wo),_9I),_wN),b:_5J,c:_wM,d:_bM,e:_wD,f:_8S,g:_8L,h:_8L,i:_5K},_wj);}}}}}}}}},_wW=new T(function(){var _wX=new T(function(){var _wY=function(_wZ,_x0,_x1){var _x2=E(_wZ);if(!_x2){var _x3=E(_x0);if(!_x3){return E(_x1);}else{return new F(function(){return _wg(0,_x3,_x1);});}}else{var _x4=E(_we),_x5=E(_x4.a),_x6=_x5+_x2|0;if(_x6<1){return E(_x1);}else{if(_x6>8){return E(_x1);}else{var _x7=E(_x4.b),_x8=_x7+E(_x0)|0;if(_x8<1){return E(_x1);}else{if(_x8>8){return E(_x1);}else{var _x9=B(_4i(_x5,_x7,_x6,_x8));if(!_x9._){return E(_aL);}else{var _xa=E(_x9.b);if(!_xa._){return E(_8I);}else{if(!B(_vP(B(_8D(_xa.a,_xa.b))))){return E(_x1);}else{var _xb=function(_xc){while(1){var _xd=E(_xc);if(!_xd._){return true;}else{var _xe=_xd.b,_xf=E(_xd.a),_xg=E(_xf.a);if(E(_xg.a)!=_x6){_xc=_xe;continue;}else{if(E(_xg.b)!=_x8){_xc=_xe;continue;}else{var _xh=u_iswlower(E(_xf.b));if(!E(_xh)){return false;}else{_xc=_xe;continue;}}}}}};if(!B((function(_xi,_xj){var _xk=E(_xi),_xl=E(_xk.a);if(E(_xl.a)!=_x6){return new F(function(){return _xb(_xj);});}else{if(E(_xl.b)!=_x8){return new F(function(){return _xb(_xj);});}else{var _xm=u_iswlower(E(_xk.b));if(!E(_xm)){return false;}else{return new F(function(){return _xb(_xj);});}}}})(_bW,_bX))){return E(_x1);}else{var _xn=new T(function(){var _xo=function(_xp){while(1){var _xq=E(_xp);if(!_xq._){return false;}else{var _xr=_xq.b,_xs=E(E(_xq.a).a);if(E(_xs.a)!=_x6){_xp=_xr;continue;}else{if(E(_xs.b)!=_x8){_xp=_xr;continue;}else{return true;}}}}};if(!B((function(_xt,_xu){var _xv=E(E(_xt).a);if(E(_xv.a)!=_x6){return new F(function(){return _xo(_xu);});}else{if(E(_xv.b)!=_x8){return new F(function(){return _xo(_xu);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_xw=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_x6)==8){if(E(_x8)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_x6)==1){if(E(_x8)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_xx=new T(function(){var _xy=function(_xz){var _xA=E(_xz),_xB=E(_xA.a),_xC=_xB.b,_xD=E(_xB.a),_xE=function(_xF){return (_xD!=_x5)?true:(E(_xC)!=_x7)?true:(E(_xA.b)==81)?false:true;};if(_xD!=_x6){return new F(function(){return _xE(_);});}else{if(E(_xC)!=_x8){return new F(function(){return _xE(_);});}else{return false;}}};return B(_5R(_xy,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_x6,_x8),_9I),_xx),b:_5J,c:_xw,d:_bM,e:_xn,f:_8S,g:_8L,h:_8L,i:_5K},_x1);}}}}}}}}}},_xG=new T(function(){var _xH=function(_xI){var _xJ=E(_xI);if(!_xJ._){return E(_wf);}else{var _xK=E(_xJ.a);return new F(function(){return _wY(E(_xK.a),_xK.b,new T(function(){return B(_xH(_xJ.b));}));});}};return B(_xH(_9H));}),_xL=function(_xM){var _xN=E(_xM);if(!_xN._){return E(_xG);}else{var _xO=E(_xN.a);return new F(function(){return _wY(E(_xO.a),_xO.b,new T(function(){return B(_xL(_xN.b));}));});}};return B(_xL(_9z));}),_xP=function(_xQ){while(1){var _xR=B((function(_xS){var _xT=E(_xS);if(!_xT._){return E(_wX);}else{var _xU=_xT.b,_xV=E(_xT.a);if(!_xV){_xQ=_xU;return __continue;}else{return new F(function(){return _wg(_xV, -_xV,new T(function(){return B(_xP(_xU));}));});}}})(_xQ));if(_xR!=__continue){return _xR;}}};return B(_xP(_9r));}),_xW=function(_xX){while(1){var _xY=B((function(_xZ){var _y0=E(_xZ);if(!_y0._){return E(_wW);}else{var _y1=_y0.b,_y2=E(_y0.a);if(!_y2){_xX=_y1;return __continue;}else{return new F(function(){return _wg(_y2,_y2,new T(function(){return B(_xW(_y1));}));});}}})(_xX));if(_xY!=__continue){return _xY;}}};return new F(function(){return _xW(_9r);});}else{return E(_wf);}}},_y3=function(_y4,_y5){var _y6=E(_y4),_y7=_y6.a,_y8=new T(function(){return B(_wa(_y5));});if(E(_y6.b)==81){var _y9=function(_ya,_yb,_yc){var _yd=E(_y7),_ye=E(_yd.a),_yf=_ye+_ya|0;if(_yf<1){return E(_yc);}else{if(_yf>8){return E(_yc);}else{var _yg=E(_yd.b),_yh=_yg+_yb|0;if(_yh<1){return E(_yc);}else{if(_yh>8){return E(_yc);}else{var _yi=B(_4i(_ye,_yg,_yf,_yh));if(!_yi._){return E(_aL);}else{var _yj=E(_yi.b);if(!_yj._){return E(_8I);}else{if(!B(_vP(B(_8D(_yj.a,_yj.b))))){return E(_yc);}else{var _yk=function(_yl){while(1){var _ym=E(_yl);if(!_ym._){return true;}else{var _yn=_ym.b,_yo=E(_ym.a),_yp=E(_yo.a);if(E(_yp.a)!=_yf){_yl=_yn;continue;}else{if(E(_yp.b)!=_yh){_yl=_yn;continue;}else{var _yq=u_iswlower(E(_yo.b));if(!E(_yq)){return false;}else{_yl=_yn;continue;}}}}}};if(!B(_yk(_bV))){return E(_yc);}else{var _yr=new T(function(){var _ys=function(_yt){while(1){var _yu=E(_yt);if(!_yu._){return false;}else{var _yv=_yu.b,_yw=E(E(_yu.a).a);if(E(_yw.a)!=_yf){_yt=_yv;continue;}else{if(E(_yw.b)!=_yh){_yt=_yv;continue;}else{return true;}}}}};if(!B(_ys(_bV))){return E(_8M);}else{return E(_90);}}),_yx=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_yf)==8){if(E(_yh)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_yf)==1){if(E(_yh)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_yy=new T(function(){var _yz=function(_yA){var _yB=E(_yA),_yC=E(_yB.a),_yD=_yC.b,_yE=E(_yC.a),_yF=function(_yG){return (_yE!=_ye)?true:(E(_yD)!=_yg)?true:(E(_yB.b)==81)?false:true;};if(_yE!=_yf){return new F(function(){return _yF(_);});}else{if(E(_yD)!=_yh){return new F(function(){return _yF(_);});}else{return false;}}};return B(_5R(_yz,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_yf,_yh),_9I),_yy),b:_5J,c:_yx,d:_bM,e:_yr,f:_8S,g:_8L,h:_8L,i:_5K},_yc);}}}}}}}}},_yH=new T(function(){var _yI=new T(function(){var _yJ=function(_yK,_yL,_yM){var _yN=E(_yK);if(!_yN){var _yO=E(_yL);if(!_yO){return E(_yM);}else{return new F(function(){return _y9(0,_yO,_yM);});}}else{var _yP=E(_y7),_yQ=E(_yP.a),_yR=_yQ+_yN|0;if(_yR<1){return E(_yM);}else{if(_yR>8){return E(_yM);}else{var _yS=E(_yP.b),_yT=_yS+E(_yL)|0;if(_yT<1){return E(_yM);}else{if(_yT>8){return E(_yM);}else{var _yU=B(_4i(_yQ,_yS,_yR,_yT));if(!_yU._){return E(_aL);}else{var _yV=E(_yU.b);if(!_yV._){return E(_8I);}else{if(!B(_vP(B(_8D(_yV.a,_yV.b))))){return E(_yM);}else{var _yW=function(_yX){while(1){var _yY=E(_yX);if(!_yY._){return true;}else{var _yZ=_yY.b,_z0=E(_yY.a),_z1=E(_z0.a);if(E(_z1.a)!=_yR){_yX=_yZ;continue;}else{if(E(_z1.b)!=_yT){_yX=_yZ;continue;}else{var _z2=u_iswlower(E(_z0.b));if(!E(_z2)){return false;}else{_yX=_yZ;continue;}}}}}};if(!B((function(_z3,_z4){var _z5=E(_z3),_z6=E(_z5.a);if(E(_z6.a)!=_yR){return new F(function(){return _yW(_z4);});}else{if(E(_z6.b)!=_yT){return new F(function(){return _yW(_z4);});}else{var _z7=u_iswlower(E(_z5.b));if(!E(_z7)){return false;}else{return new F(function(){return _yW(_z4);});}}}})(_bW,_bX))){return E(_yM);}else{var _z8=new T(function(){var _z9=function(_za){while(1){var _zb=E(_za);if(!_zb._){return false;}else{var _zc=_zb.b,_zd=E(E(_zb.a).a);if(E(_zd.a)!=_yR){_za=_zc;continue;}else{if(E(_zd.b)!=_yT){_za=_zc;continue;}else{return true;}}}}};if(!B((function(_ze,_zf){var _zg=E(E(_ze).a);if(E(_zg.a)!=_yR){return new F(function(){return _z9(_zf);});}else{if(E(_zg.b)!=_yT){return new F(function(){return _z9(_zf);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_zh=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_yR)==8){if(E(_yT)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_yR)==1){if(E(_yT)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_zi=new T(function(){var _zj=function(_zk){var _zl=E(_zk),_zm=E(_zl.a),_zn=_zm.b,_zo=E(_zm.a),_zp=function(_zq){return (_zo!=_yQ)?true:(E(_zn)!=_yS)?true:(E(_zl.b)==81)?false:true;};if(_zo!=_yR){return new F(function(){return _zp(_);});}else{if(E(_zn)!=_yT){return new F(function(){return _zp(_);});}else{return false;}}};return B(_5R(_zj,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_yR,_yT),_9I),_zi),b:_5J,c:_zh,d:_bM,e:_z8,f:_8S,g:_8L,h:_8L,i:_5K},_yM);}}}}}}}}}},_zr=new T(function(){var _zs=function(_zt){var _zu=E(_zt);if(!_zu._){return E(_y8);}else{var _zv=E(_zu.a);return new F(function(){return _yJ(E(_zv.a),_zv.b,new T(function(){return B(_zs(_zu.b));}));});}};return B(_zs(_9H));}),_zw=function(_zx){var _zy=E(_zx);if(!_zy._){return E(_zr);}else{var _zz=E(_zy.a);return new F(function(){return _yJ(E(_zz.a),_zz.b,new T(function(){return B(_zw(_zy.b));}));});}};return B(_zw(_9z));}),_zA=function(_zB){while(1){var _zC=B((function(_zD){var _zE=E(_zD);if(!_zE._){return E(_yI);}else{var _zF=_zE.b,_zG=E(_zE.a);if(!_zG){_zB=_zF;return __continue;}else{return new F(function(){return _y9(_zG, -_zG,new T(function(){return B(_zA(_zF));}));});}}})(_zB));if(_zC!=__continue){return _zC;}}};return B(_zA(_9r));}),_zH=function(_zI){while(1){var _zJ=B((function(_zK){var _zL=E(_zK);if(!_zL._){return E(_yH);}else{var _zM=_zL.b,_zN=E(_zL.a);if(!_zN){_zI=_zM;return __continue;}else{return new F(function(){return _y9(_zN,_zN,new T(function(){return B(_zH(_zM));}));});}}})(_zI));if(_zJ!=__continue){return _zJ;}}};return new F(function(){return _zH(_9r);});}else{return E(_y8);}};return B(_y3(_bW,_bX));}),_zO=function(_zP){while(1){var _zQ=B((function(_zR){var _zS=E(_zR);if(!_zS._){return E(_v2);}else{var _zT=_zS.b,_zU=E(_zS.a);if(E(_zU.b)==78){var _zV=function(_zW,_zX,_zY){var _zZ=E(_zU.a),_A0=E(_zZ.a),_A1=_A0+_zW|0;if(_A1<1){return E(_zY);}else{if(_A1>8){return E(_zY);}else{var _A2=E(_zZ.b),_A3=_A2+_zX|0;if(_A3<1){return E(_zY);}else{if(_A3>8){return E(_zY);}else{var _A4=function(_A5){while(1){var _A6=E(_A5);if(!_A6._){return true;}else{var _A7=_A6.b,_A8=E(_A6.a),_A9=E(_A8.a);if(E(_A9.a)!=_A1){_A5=_A7;continue;}else{if(E(_A9.b)!=_A3){_A5=_A7;continue;}else{var _Aa=u_iswlower(E(_A8.b));if(!E(_Aa)){return false;}else{_A5=_A7;continue;}}}}}};if(!B((function(_Ab,_Ac){var _Ad=E(_Ab),_Ae=E(_Ad.a);if(E(_Ae.a)!=_A1){return new F(function(){return _A4(_Ac);});}else{if(E(_Ae.b)!=_A3){return new F(function(){return _A4(_Ac);});}else{var _Af=u_iswlower(E(_Ad.b));if(!E(_Af)){return false;}else{return new F(function(){return _A4(_Ac);});}}}})(_bW,_bX))){return E(_zY);}else{var _Ag=new T(function(){var _Ah=function(_Ai){while(1){var _Aj=E(_Ai);if(!_Aj._){return false;}else{var _Ak=_Aj.b,_Al=E(E(_Aj.a).a);if(E(_Al.a)!=_A1){_Ai=_Ak;continue;}else{if(E(_Al.b)!=_A3){_Ai=_Ak;continue;}else{return true;}}}}};if(!B((function(_Am,_An){var _Ao=E(E(_Am).a);if(E(_Ao.a)!=_A1){return new F(function(){return _Ah(_An);});}else{if(E(_Ao.b)!=_A3){return new F(function(){return _Ah(_An);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_Ap=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_A1)==8){if(E(_A3)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_A1)==1){if(E(_A3)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_Aq=new T(function(){var _Ar=function(_As){var _At=E(_As),_Au=E(_At.a),_Av=_Au.b,_Aw=E(_Au.a),_Ax=function(_Ay){return (_Aw!=_A0)?true:(E(_Av)!=_A2)?true:(E(_At.b)==78)?false:true;};if(_Aw!=_A1){return new F(function(){return _Ax(_);});}else{if(E(_Av)!=_A3){return new F(function(){return _Ax(_);});}else{return false;}}};return B(_5R(_Ar,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_A1,_A3),_9J),_Aq),b:_5J,c:_Ap,d:_bM,e:_Ag,f:_8S,g:_8L,h:_8L,i:_5K},_zY);}}}}}},_Az=new T(function(){var _AA=new T(function(){var _AB=new T(function(){var _AC=new T(function(){var _AD=new T(function(){var _AE=new T(function(){var _AF=new T(function(){return B(_zV(-2,-1,new T(function(){return B(_zO(_zT));})));});return B(_zV(-1,-2,_AF));});return B(_zV(2,-1,_AE));});return B(_zV(-1,2,_AD));});return B(_zV(-2,1,_AC));});return B(_zV(1,-2,_AB));});return B(_zV(2,1,_AA));});return new F(function(){return _zV(1,2,_Az);});}else{_zP=_zT;return __continue;}}})(_zP));if(_zQ!=__continue){return _zQ;}}},_AG=function(_AH,_AI){var _AJ=E(_AH);if(E(_AJ.b)==78){var _AK=function(_AL,_AM,_AN){var _AO=E(_AJ.a),_AP=E(_AO.a),_AQ=_AP+_AL|0;if(_AQ<1){return E(_AN);}else{if(_AQ>8){return E(_AN);}else{var _AR=E(_AO.b),_AS=_AR+_AM|0;if(_AS<1){return E(_AN);}else{if(_AS>8){return E(_AN);}else{var _AT=function(_AU){while(1){var _AV=E(_AU);if(!_AV._){return true;}else{var _AW=_AV.b,_AX=E(_AV.a),_AY=E(_AX.a);if(E(_AY.a)!=_AQ){_AU=_AW;continue;}else{if(E(_AY.b)!=_AS){_AU=_AW;continue;}else{var _AZ=u_iswlower(E(_AX.b));if(!E(_AZ)){return false;}else{_AU=_AW;continue;}}}}}};if(!B(_AT(_bV))){return E(_AN);}else{var _B0=new T(function(){var _B1=function(_B2){while(1){var _B3=E(_B2);if(!_B3._){return false;}else{var _B4=_B3.b,_B5=E(E(_B3.a).a);if(E(_B5.a)!=_AQ){_B2=_B4;continue;}else{if(E(_B5.b)!=_AS){_B2=_B4;continue;}else{return true;}}}}};if(!B(_B1(_bV))){return E(_8M);}else{return E(_90);}}),_B6=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_AQ)==8){if(E(_AS)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_AQ)==1){if(E(_AS)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_B7=new T(function(){var _B8=function(_B9){var _Ba=E(_B9),_Bb=E(_Ba.a),_Bc=_Bb.b,_Bd=E(_Bb.a),_Be=function(_Bf){return (_Bd!=_AP)?true:(E(_Bc)!=_AR)?true:(E(_Ba.b)==78)?false:true;};if(_Bd!=_AQ){return new F(function(){return _Be(_);});}else{if(E(_Bc)!=_AS){return new F(function(){return _Be(_);});}else{return false;}}};return B(_5R(_B8,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_AQ,_AS),_9J),_B7),b:_5J,c:_B6,d:_bM,e:_B0,f:_8S,g:_8L,h:_8L,i:_5K},_AN);}}}}}},_Bg=new T(function(){var _Bh=new T(function(){var _Bi=new T(function(){var _Bj=new T(function(){var _Bk=new T(function(){var _Bl=new T(function(){var _Bm=new T(function(){return B(_AK(-2,-1,new T(function(){return B(_zO(_AI));})));});return B(_AK(-1,-2,_Bm));});return B(_AK(2,-1,_Bl));});return B(_AK(-1,2,_Bk));});return B(_AK(-2,1,_Bj));});return B(_AK(1,-2,_Bi));});return B(_AK(2,1,_Bh));});return new F(function(){return _AK(1,2,_Bg);});}else{return new F(function(){return _zO(_AI);});}};return B(_AG(_bW,_bX));}),_Bn=function(_Bo){while(1){var _Bp=B((function(_Bq){var _Br=E(_Bq);if(!_Br._){return true;}else{var _Bs=_Br.b,_Bt=E(E(_bW).a),_Bu=E(_Br.a),_Bv=_Bu.b,_Bw=E(_Bu.a);if(E(_Bt.a)!=_Bw){var _Bx=function(_By){while(1){var _Bz=E(_By);if(!_Bz._){return true;}else{var _BA=_Bz.b,_BB=E(E(_Bz.a).a);if(E(_BB.a)!=_Bw){_By=_BA;continue;}else{if(E(_BB.b)!=E(_Bv)){_By=_BA;continue;}else{return false;}}}}};if(!B(_Bx(_bX))){return false;}else{_Bo=_Bs;return __continue;}}else{var _BC=E(_Bv);if(E(_Bt.b)!=_BC){var _BD=function(_BE){while(1){var _BF=E(_BE);if(!_BF._){return true;}else{var _BG=_BF.b,_BH=E(E(_BF.a).a);if(E(_BH.a)!=_Bw){_BE=_BG;continue;}else{if(E(_BH.b)!=_BC){_BE=_BG;continue;}else{return false;}}}}};if(!B(_BD(_bX))){return false;}else{_Bo=_Bs;return __continue;}}else{return false;}}}})(_Bo));if(_Bp!=__continue){return _Bp;}}},_BI=function(_BJ){var _BK=E(_BJ);if(!_BK._){return E(_v1);}else{var _BL=E(_BK.a),_BM=new T(function(){return B(_BI(_BK.b));});if(E(_BL.b)==66){var _BN=function(_BO,_BP,_BQ){var _BR=E(_BL.a),_BS=E(_BR.a),_BT=_BS+_BO|0;if(_BT<1){return E(_BQ);}else{if(_BT>8){return E(_BQ);}else{var _BU=E(_BR.b),_BV=_BU+_BP|0;if(_BV<1){return E(_BQ);}else{if(_BV>8){return E(_BQ);}else{var _BW=B(_4i(_BS,_BU,_BT,_BV));if(!_BW._){return E(_aL);}else{var _BX=E(_BW.b);if(!_BX._){return E(_8I);}else{if(!B(_Bn(B(_8D(_BX.a,_BX.b))))){return E(_BQ);}else{var _BY=function(_BZ){while(1){var _C0=E(_BZ);if(!_C0._){return true;}else{var _C1=_C0.b,_C2=E(_C0.a),_C3=E(_C2.a);if(E(_C3.a)!=_BT){_BZ=_C1;continue;}else{if(E(_C3.b)!=_BV){_BZ=_C1;continue;}else{var _C4=u_iswlower(E(_C2.b));if(!E(_C4)){return false;}else{_BZ=_C1;continue;}}}}}};if(!B((function(_C5,_C6){var _C7=E(_C5),_C8=E(_C7.a);if(E(_C8.a)!=_BT){return new F(function(){return _BY(_C6);});}else{if(E(_C8.b)!=_BV){return new F(function(){return _BY(_C6);});}else{var _C9=u_iswlower(E(_C7.b));if(!E(_C9)){return false;}else{return new F(function(){return _BY(_C6);});}}}})(_bW,_bX))){return E(_BQ);}else{var _Ca=new T(function(){var _Cb=function(_Cc){while(1){var _Cd=E(_Cc);if(!_Cd._){return false;}else{var _Ce=_Cd.b,_Cf=E(E(_Cd.a).a);if(E(_Cf.a)!=_BT){_Cc=_Ce;continue;}else{if(E(_Cf.b)!=_BV){_Cc=_Ce;continue;}else{return true;}}}}};if(!B((function(_Cg,_Ch){var _Ci=E(E(_Cg).a);if(E(_Ci.a)!=_BT){return new F(function(){return _Cb(_Ch);});}else{if(E(_Ci.b)!=_BV){return new F(function(){return _Cb(_Ch);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_Cj=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_BT)==8){if(E(_BV)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_BT)==1){if(E(_BV)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_Ck=new T(function(){var _Cl=function(_Cm){var _Cn=E(_Cm),_Co=E(_Cn.a),_Cp=_Co.b,_Cq=E(_Co.a),_Cr=function(_Cs){return (_Cq!=_BS)?true:(E(_Cp)!=_BU)?true:(E(_Cn.b)==66)?false:true;};if(_Cq!=_BT){return new F(function(){return _Cr(_);});}else{if(E(_Cp)!=_BV){return new F(function(){return _Cr(_);});}else{return false;}}};return B(_5R(_Cl,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_BT,_BV),_9K),_Ck),b:_5J,c:_Cj,d:_bM,e:_Ca,f:_8S,g:_8L,h:_8L,i:_5K},_BQ);}}}}}}}}},_Ct=new T(function(){var _Cu=function(_Cv){while(1){var _Cw=B((function(_Cx){var _Cy=E(_Cx);if(!_Cy._){return E(_BM);}else{var _Cz=_Cy.b,_CA=E(_Cy.a);if(!_CA){_Cv=_Cz;return __continue;}else{return new F(function(){return _BN(_CA, -_CA,new T(function(){return B(_Cu(_Cz));}));});}}})(_Cv));if(_Cw!=__continue){return _Cw;}}};return B(_Cu(_9r));}),_CB=function(_CC){while(1){var _CD=B((function(_CE){var _CF=E(_CE);if(!_CF._){return E(_Ct);}else{var _CG=_CF.b,_CH=E(_CF.a);if(!_CH){_CC=_CG;return __continue;}else{return new F(function(){return _BN(_CH,_CH,new T(function(){return B(_CB(_CG));}));});}}})(_CC));if(_CD!=__continue){return _CD;}}};return new F(function(){return _CB(_9r);});}else{return E(_BM);}}},_CI=function(_CJ,_CK){var _CL=E(_CJ),_CM=new T(function(){return B(_BI(_CK));});if(E(_CL.b)==66){var _CN=function(_CO,_CP,_CQ){var _CR=E(_CL.a),_CS=E(_CR.a),_CT=_CS+_CO|0;if(_CT<1){return E(_CQ);}else{if(_CT>8){return E(_CQ);}else{var _CU=E(_CR.b),_CV=_CU+_CP|0;if(_CV<1){return E(_CQ);}else{if(_CV>8){return E(_CQ);}else{var _CW=B(_4i(_CS,_CU,_CT,_CV));if(!_CW._){return E(_aL);}else{var _CX=E(_CW.b);if(!_CX._){return E(_8I);}else{if(!B(_Bn(B(_8D(_CX.a,_CX.b))))){return E(_CQ);}else{var _CY=function(_CZ){while(1){var _D0=E(_CZ);if(!_D0._){return true;}else{var _D1=_D0.b,_D2=E(_D0.a),_D3=E(_D2.a);if(E(_D3.a)!=_CT){_CZ=_D1;continue;}else{if(E(_D3.b)!=_CV){_CZ=_D1;continue;}else{var _D4=u_iswlower(E(_D2.b));if(!E(_D4)){return false;}else{_CZ=_D1;continue;}}}}}};if(!B(_CY(_bV))){return E(_CQ);}else{var _D5=new T(function(){var _D6=function(_D7){while(1){var _D8=E(_D7);if(!_D8._){return false;}else{var _D9=_D8.b,_Da=E(E(_D8.a).a);if(E(_Da.a)!=_CT){_D7=_D9;continue;}else{if(E(_Da.b)!=_CV){_D7=_D9;continue;}else{return true;}}}}};if(!B(_D6(_bV))){return E(_8M);}else{return E(_90);}}),_Db=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_CT)==8){if(E(_CV)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_CT)==1){if(E(_CV)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bL))));}),_Dc=new T(function(){var _Dd=function(_De){var _Df=E(_De),_Dg=E(_Df.a),_Dh=_Dg.b,_Di=E(_Dg.a),_Dj=function(_Dk){return (_Di!=_CS)?true:(E(_Dh)!=_CU)?true:(E(_Df.b)==66)?false:true;};if(_Di!=_CT){return new F(function(){return _Dj(_);});}else{if(E(_Dh)!=_CV){return new F(function(){return _Dj(_);});}else{return false;}}};return B(_5R(_Dd,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_CT,_CV),_9K),_Dc),b:_5J,c:_Db,d:_bM,e:_D5,f:_8S,g:_8L,h:_8L,i:_5K},_CQ);}}}}}}}}},_Dl=new T(function(){var _Dm=function(_Dn){while(1){var _Do=B((function(_Dp){var _Dq=E(_Dp);if(!_Dq._){return E(_CM);}else{var _Dr=_Dq.b,_Ds=E(_Dq.a);if(!_Ds){_Dn=_Dr;return __continue;}else{return new F(function(){return _CN(_Ds, -_Ds,new T(function(){return B(_Dm(_Dr));}));});}}})(_Dn));if(_Do!=__continue){return _Do;}}};return B(_Dm(_9r));}),_Dt=function(_Du){while(1){var _Dv=B((function(_Dw){var _Dx=E(_Dw);if(!_Dx._){return E(_Dl);}else{var _Dy=_Dx.b,_Dz=E(_Dx.a);if(!_Dz){_Du=_Dy;return __continue;}else{return new F(function(){return _CN(_Dz,_Dz,new T(function(){return B(_Dt(_Dy));}));});}}})(_Du));if(_Dv!=__continue){return _Dv;}}};return new F(function(){return _Dt(_9r);});}else{return E(_CM);}};return B(_CI(_bW,_bX));}),_DA=function(_DB){while(1){var _DC=B((function(_DD){var _DE=E(_DD);if(!_DE._){return true;}else{var _DF=_DE.b,_DG=E(E(_bW).a),_DH=E(_DE.a),_DI=_DH.b,_DJ=E(_DH.a);if(E(_DG.a)!=_DJ){var _DK=function(_DL){while(1){var _DM=E(_DL);if(!_DM._){return true;}else{var _DN=_DM.b,_DO=E(E(_DM.a).a);if(E(_DO.a)!=_DJ){_DL=_DN;continue;}else{if(E(_DO.b)!=E(_DI)){_DL=_DN;continue;}else{return false;}}}}};if(!B(_DK(_bX))){return false;}else{_DB=_DF;return __continue;}}else{var _DP=E(_DI);if(E(_DG.b)!=_DP){var _DQ=function(_DR){while(1){var _DS=E(_DR);if(!_DS._){return true;}else{var _DT=_DS.b,_DU=E(E(_DS.a).a);if(E(_DU.a)!=_DJ){_DR=_DT;continue;}else{if(E(_DU.b)!=_DP){_DR=_DT;continue;}else{return false;}}}}};if(!B(_DQ(_bX))){return false;}else{_DB=_DF;return __continue;}}else{return false;}}}})(_DB));if(_DC!=__continue){return _DC;}}},_DV=function(_DW){var _DX=E(_DW);if(!_DX._){return E(_v0);}else{var _DY=E(_DX.a),_DZ=_DY.a,_E0=new T(function(){return B(_DV(_DX.b));});if(E(_DY.b)==82){var _E1=new T(function(){return B(_5B(0,new T(function(){var _E2=E(_DZ);if(E(_E2.a)==8){if(E(_E2.b)==1){return true;}else{return E(_bU);}}else{return E(_bU);}}),B(_5B(1,new T(function(){var _E3=E(_DZ);if(E(_E3.a)==1){if(E(_E3.b)==1){return true;}else{return E(_bT);}}else{return E(_bT);}}),_bL))));}),_E4=function(_E5,_E6,_E7){var _E8=E(_E5);if(!_E8){var _E9=E(_E6);if(!_E9){return E(_E7);}else{var _Ea=E(_DZ),_Eb=E(_Ea.a);if(_Eb<1){return E(_E7);}else{if(_Eb>8){return E(_E7);}else{var _Ec=E(_Ea.b),_Ed=_Ec+_E9|0;if(_Ed<1){return E(_E7);}else{if(_Ed>8){return E(_E7);}else{var _Ee=B(_4i(_Eb,_Ec,_Eb,_Ed));if(!_Ee._){return E(_aL);}else{var _Ef=E(_Ee.b);if(!_Ef._){return E(_8I);}else{if(!B(_DA(B(_8D(_Ef.a,_Ef.b))))){return E(_E7);}else{var _Eg=function(_Eh){while(1){var _Ei=E(_Eh);if(!_Ei._){return true;}else{var _Ej=_Ei.b,_Ek=E(_Ei.a),_El=E(_Ek.a);if(E(_El.a)!=_Eb){_Eh=_Ej;continue;}else{if(E(_El.b)!=_Ed){_Eh=_Ej;continue;}else{var _Em=u_iswlower(E(_Ek.b));if(!E(_Em)){return false;}else{_Eh=_Ej;continue;}}}}}};if(!B((function(_En,_Eo){var _Ep=E(_En),_Eq=E(_Ep.a);if(E(_Eq.a)!=_Eb){return new F(function(){return _Eg(_Eo);});}else{if(E(_Eq.b)!=_Ed){return new F(function(){return _Eg(_Eo);});}else{var _Er=u_iswlower(E(_Ep.b));if(!E(_Er)){return false;}else{return new F(function(){return _Eg(_Eo);});}}}})(_bW,_bX))){return E(_E7);}else{var _Es=new T(function(){var _Et=function(_Eu){while(1){var _Ev=E(_Eu);if(!_Ev._){return false;}else{var _Ew=_Ev.b,_Ex=E(E(_Ev.a).a);if(E(_Ex.a)!=_Eb){_Eu=_Ew;continue;}else{if(E(_Ex.b)!=_Ed){_Eu=_Ew;continue;}else{return true;}}}}};if(!B((function(_Ey,_Ez){var _EA=E(E(_Ey).a);if(E(_EA.a)!=_Eb){return new F(function(){return _Et(_Ez);});}else{if(E(_EA.b)!=_Ed){return new F(function(){return _Et(_Ez);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_EB=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_Eb)==8){if(E(_Ed)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_Eb)==1){if(E(_Ed)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_E1))));}),_EC=new T(function(){var _ED=function(_EE){var _EF=E(_EE),_EG=E(_EF.a),_EH=_EG.b,_EI=E(_EG.a),_EJ=function(_EK){return (_EI!=_Eb)?true:(E(_EH)!=_Ec)?true:(E(_EF.b)==82)?false:true;};if(_EI!=_Eb){return new F(function(){return _EJ(_);});}else{if(E(_EH)!=_Ed){return new F(function(){return _EJ(_);});}else{return false;}}};return B(_5R(_ED,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_Eb,_Ed),_8Z),_EC),b:_5J,c:_EB,d:_bM,e:_Es,f:_8S,g:_8L,h:_8L,i:_5K},_E7);}}}}}}}}}}else{var _EL=E(_DZ),_EM=E(_EL.a),_EN=_EM+_E8|0;if(_EN<1){return E(_E7);}else{if(_EN>8){return E(_E7);}else{var _EO=E(_EL.b),_EP=_EO+E(_E6)|0;if(_EP<1){return E(_E7);}else{if(_EP>8){return E(_E7);}else{var _EQ=B(_4i(_EM,_EO,_EN,_EP));if(!_EQ._){return E(_aL);}else{var _ER=E(_EQ.b);if(!_ER._){return E(_8I);}else{if(!B(_DA(B(_8D(_ER.a,_ER.b))))){return E(_E7);}else{var _ES=function(_ET){while(1){var _EU=E(_ET);if(!_EU._){return true;}else{var _EV=_EU.b,_EW=E(_EU.a),_EX=E(_EW.a);if(E(_EX.a)!=_EN){_ET=_EV;continue;}else{if(E(_EX.b)!=_EP){_ET=_EV;continue;}else{var _EY=u_iswlower(E(_EW.b));if(!E(_EY)){return false;}else{_ET=_EV;continue;}}}}}};if(!B((function(_EZ,_F0){var _F1=E(_EZ),_F2=E(_F1.a);if(E(_F2.a)!=_EN){return new F(function(){return _ES(_F0);});}else{if(E(_F2.b)!=_EP){return new F(function(){return _ES(_F0);});}else{var _F3=u_iswlower(E(_F1.b));if(!E(_F3)){return false;}else{return new F(function(){return _ES(_F0);});}}}})(_bW,_bX))){return E(_E7);}else{var _F4=new T(function(){var _F5=function(_F6){while(1){var _F7=E(_F6);if(!_F7._){return false;}else{var _F8=_F7.b,_F9=E(E(_F7.a).a);if(E(_F9.a)!=_EN){_F6=_F8;continue;}else{if(E(_F9.b)!=_EP){_F6=_F8;continue;}else{return true;}}}}};if(!B((function(_Fa,_Fb){var _Fc=E(E(_Fa).a);if(E(_Fc.a)!=_EN){return new F(function(){return _F5(_Fb);});}else{if(E(_Fc.b)!=_EP){return new F(function(){return _F5(_Fb);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_Fd=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_EN)==8){if(E(_EP)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_EN)==1){if(E(_EP)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_E1))));}),_Fe=new T(function(){var _Ff=function(_Fg){var _Fh=E(_Fg),_Fi=E(_Fh.a),_Fj=_Fi.b,_Fk=E(_Fi.a),_Fl=function(_Fm){return (_Fk!=_EM)?true:(E(_Fj)!=_EO)?true:(E(_Fh.b)==82)?false:true;};if(_Fk!=_EN){return new F(function(){return _Fl(_);});}else{if(E(_Fj)!=_EP){return new F(function(){return _Fl(_);});}else{return false;}}};return B(_5R(_Ff,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_EN,_EP),_8Z),_Fe),b:_5J,c:_Fd,d:_bM,e:_F4,f:_8S,g:_8L,h:_8L,i:_5K},_E7);}}}}}}}}}},_Fn=new T(function(){var _Fo=function(_Fp){var _Fq=E(_Fp);if(!_Fq._){return E(_E0);}else{var _Fr=E(_Fq.a);return new F(function(){return _E4(E(_Fr.a),_Fr.b,new T(function(){return B(_Fo(_Fq.b));}));});}};return B(_Fo(_a0));}),_Fs=function(_Ft){var _Fu=E(_Ft);if(!_Fu._){return E(_Fn);}else{var _Fv=E(_Fu.a);return new F(function(){return _E4(E(_Fv.a),_Fv.b,new T(function(){return B(_Fs(_Fu.b));}));});}};return new F(function(){return _Fs(_9S);});}else{return E(_E0);}}},_Fw=function(_Fx,_Fy){var _Fz=E(_Fx),_FA=_Fz.a,_FB=new T(function(){return B(_DV(_Fy));});if(E(_Fz.b)==82){var _FC=new T(function(){return B(_5B(0,new T(function(){var _FD=E(_FA);if(E(_FD.a)==8){if(E(_FD.b)==1){return true;}else{return E(_bU);}}else{return E(_bU);}}),B(_5B(1,new T(function(){var _FE=E(_FA);if(E(_FE.a)==1){if(E(_FE.b)==1){return true;}else{return E(_bT);}}else{return E(_bT);}}),_bL))));}),_FF=function(_FG,_FH,_FI){var _FJ=E(_FG);if(!_FJ){var _FK=E(_FH);if(!_FK){return E(_FI);}else{var _FL=E(_FA),_FM=E(_FL.a);if(_FM<1){return E(_FI);}else{if(_FM>8){return E(_FI);}else{var _FN=E(_FL.b),_FO=_FN+_FK|0;if(_FO<1){return E(_FI);}else{if(_FO>8){return E(_FI);}else{var _FP=B(_4i(_FM,_FN,_FM,_FO));if(!_FP._){return E(_aL);}else{var _FQ=E(_FP.b);if(!_FQ._){return E(_8I);}else{if(!B(_DA(B(_8D(_FQ.a,_FQ.b))))){return E(_FI);}else{var _FR=function(_FS){while(1){var _FT=E(_FS);if(!_FT._){return true;}else{var _FU=_FT.b,_FV=E(_FT.a),_FW=E(_FV.a);if(E(_FW.a)!=_FM){_FS=_FU;continue;}else{if(E(_FW.b)!=_FO){_FS=_FU;continue;}else{var _FX=u_iswlower(E(_FV.b));if(!E(_FX)){return false;}else{_FS=_FU;continue;}}}}}};if(!B(_FR(_bV))){return E(_FI);}else{var _FY=new T(function(){var _FZ=function(_G0){while(1){var _G1=E(_G0);if(!_G1._){return false;}else{var _G2=_G1.b,_G3=E(E(_G1.a).a);if(E(_G3.a)!=_FM){_G0=_G2;continue;}else{if(E(_G3.b)!=_FO){_G0=_G2;continue;}else{return true;}}}}};if(!B(_FZ(_bV))){return E(_8M);}else{return E(_90);}}),_G4=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_FM)==8){if(E(_FO)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_FM)==1){if(E(_FO)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_FC))));}),_G5=new T(function(){var _G6=function(_G7){var _G8=E(_G7),_G9=E(_G8.a),_Ga=_G9.b,_Gb=E(_G9.a),_Gc=function(_Gd){return (_Gb!=_FM)?true:(E(_Ga)!=_FN)?true:(E(_G8.b)==82)?false:true;};if(_Gb!=_FM){return new F(function(){return _Gc(_);});}else{if(E(_Ga)!=_FO){return new F(function(){return _Gc(_);});}else{return false;}}};return B(_5R(_G6,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_FM,_FO),_8Z),_G5),b:_5J,c:_G4,d:_bM,e:_FY,f:_8S,g:_8L,h:_8L,i:_5K},_FI);}}}}}}}}}}else{var _Ge=E(_FA),_Gf=E(_Ge.a),_Gg=_Gf+_FJ|0;if(_Gg<1){return E(_FI);}else{if(_Gg>8){return E(_FI);}else{var _Gh=E(_Ge.b),_Gi=_Gh+E(_FH)|0;if(_Gi<1){return E(_FI);}else{if(_Gi>8){return E(_FI);}else{var _Gj=B(_4i(_Gf,_Gh,_Gg,_Gi));if(!_Gj._){return E(_aL);}else{var _Gk=E(_Gj.b);if(!_Gk._){return E(_8I);}else{if(!B(_DA(B(_8D(_Gk.a,_Gk.b))))){return E(_FI);}else{var _Gl=function(_Gm){while(1){var _Gn=E(_Gm);if(!_Gn._){return true;}else{var _Go=_Gn.b,_Gp=E(_Gn.a),_Gq=E(_Gp.a);if(E(_Gq.a)!=_Gg){_Gm=_Go;continue;}else{if(E(_Gq.b)!=_Gi){_Gm=_Go;continue;}else{var _Gr=u_iswlower(E(_Gp.b));if(!E(_Gr)){return false;}else{_Gm=_Go;continue;}}}}}};if(!B((function(_Gs,_Gt){var _Gu=E(_Gs),_Gv=E(_Gu.a);if(E(_Gv.a)!=_Gg){return new F(function(){return _Gl(_Gt);});}else{if(E(_Gv.b)!=_Gi){return new F(function(){return _Gl(_Gt);});}else{var _Gw=u_iswlower(E(_Gu.b));if(!E(_Gw)){return false;}else{return new F(function(){return _Gl(_Gt);});}}}})(_bW,_bX))){return E(_FI);}else{var _Gx=new T(function(){var _Gy=function(_Gz){while(1){var _GA=E(_Gz);if(!_GA._){return false;}else{var _GB=_GA.b,_GC=E(E(_GA.a).a);if(E(_GC.a)!=_Gg){_Gz=_GB;continue;}else{if(E(_GC.b)!=_Gi){_Gz=_GB;continue;}else{return true;}}}}};if(!B((function(_GD,_GE){var _GF=E(E(_GD).a);if(E(_GF.a)!=_Gg){return new F(function(){return _Gy(_GE);});}else{if(E(_GF.b)!=_Gi){return new F(function(){return _Gy(_GE);});}else{return true;}}})(_bW,_bX))){return E(_8M);}else{return E(_90);}}),_GG=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_Gg)==8){if(E(_Gi)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_Gg)==1){if(E(_Gi)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_FC))));}),_GH=new T(function(){var _GI=function(_GJ){var _GK=E(_GJ),_GL=E(_GK.a),_GM=_GL.b,_GN=E(_GL.a),_GO=function(_GP){return (_GN!=_Gf)?true:(E(_GM)!=_Gh)?true:(E(_GK.b)==82)?false:true;};if(_GN!=_Gg){return new F(function(){return _GO(_);});}else{if(E(_GM)!=_Gi){return new F(function(){return _GO(_);});}else{return false;}}};return B(_5R(_GI,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_Gg,_Gi),_8Z),_GH),b:_5J,c:_GG,d:_bM,e:_Gx,f:_8S,g:_8L,h:_8L,i:_5K},_FI);}}}}}}}}}},_GQ=new T(function(){var _GR=function(_GS){var _GT=E(_GS);if(!_GT._){return E(_FB);}else{var _GU=E(_GT.a);return new F(function(){return _FF(E(_GU.a),_GU.b,new T(function(){return B(_GR(_GT.b));}));});}};return B(_GR(_a0));}),_GV=function(_GW){var _GX=E(_GW);if(!_GX._){return E(_GQ);}else{var _GY=E(_GX.a);return new F(function(){return _FF(E(_GY.a),_GY.b,new T(function(){return B(_GV(_GX.b));}));});}};return new F(function(){return _GV(_9S);});}else{return E(_FB);}};return B(_Fw(_bW,_bX));}),_GZ=function(_H0){while(1){var _H1=B((function(_H2){var _H3=E(_H2);if(!_H3._){return E(_uZ);}else{var _H4=_H3.b,_H5=E(_H3.a),_H6=_H5.a;if(E(_H5.b)==80){var _H7=new T(function(){return E(E(_H6).b)+1|0;}),_H8=function(_H9,_Ha){var _Hb=E(_bO),_Hc=E(_H6),_Hd=E(_Hc.a),_He=_Hd+_H9|0;if(_He!=E(_Hb.a)){return E(_Ha);}else{var _Hf=E(_H7);if(_Hf!=E(_Hb.b)){return E(_Ha);}else{var _Hg=new T(function(){var _Hh=function(_Hi){var _Hj=E(_Hi),_Hk=E(_Hj.a),_Hl=_Hk.b,_Hm=E(_Hk.a),_Hn=function(_Ho){return (_Hm!=_Hd)?true:(E(_Hl)!=E(_Hc.b))?true:(E(_Hj.b)==80)?false:true;};if(_Hm!=_He){return new F(function(){return _Hn(_);});}else{if(E(_Hl)!=(_Hf-1|0)){return new F(function(){return _Hn(_);});}else{return false;}}};return B(_5R(_Hh,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_He,_Hf),_a1),_Hg),b:_5J,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_Ha);}}},_Hp=new T(function(){return B(_H8(1,new T(function(){return B(_GZ(_H4));})));});return new F(function(){return _H8(-1,_Hp);});}else{_H0=_H4;return __continue;}}})(_H0));if(_H1!=__continue){return _H1;}}},_Hq=function(_Hr,_Hs){var _Ht=E(_Hr),_Hu=_Ht.a;if(E(_Ht.b)==80){var _Hv=new T(function(){return E(E(_Hu).b)+1|0;}),_Hw=function(_Hx,_Hy){var _Hz=E(_bO),_HA=E(_Hu),_HB=E(_HA.a),_HC=_HB+_Hx|0;if(_HC!=E(_Hz.a)){return E(_Hy);}else{var _HD=E(_Hv);if(_HD!=E(_Hz.b)){return E(_Hy);}else{var _HE=new T(function(){var _HF=function(_HG){var _HH=E(_HG),_HI=E(_HH.a),_HJ=_HI.b,_HK=E(_HI.a),_HL=function(_HM){return (_HK!=_HB)?true:(E(_HJ)!=E(_HA.b))?true:(E(_HH.b)==80)?false:true;};if(_HK!=_HC){return new F(function(){return _HL(_);});}else{if(E(_HJ)!=(_HD-1|0)){return new F(function(){return _HL(_);});}else{return false;}}};return B(_5R(_HF,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_HC,_HD),_a1),_HE),b:_5J,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_Hy);}}},_HN=new T(function(){return B(_Hw(1,new T(function(){return B(_GZ(_Hs));})));});return new F(function(){return _Hw(-1,_HN);});}else{return new F(function(){return _GZ(_Hs);});}};return B(_Hq(_bW,_bX));}),_HO=function(_HP){while(1){var _HQ=B((function(_HR){var _HS=E(_HR);if(!_HS._){return E(_uY);}else{var _HT=_HS.b,_HU=E(_HS.a),_HV=_HU.a;if(E(_HU.b)==80){var _HW=new T(function(){return E(E(_HV).b)+1|0;}),_HX=function(_HY,_HZ){var _I0=E(_HV),_I1=_I0.b,_I2=E(_I0.a),_I3=_I2+_HY|0;if(_I3<1){return E(_HZ);}else{if(_I3>8){return E(_HZ);}else{var _I4=E(_HW);if(_I4<1){return E(_HZ);}else{if(_I4>8){return E(_HZ);}else{var _I5=function(_I6){while(1){var _I7=E(_I6);if(!_I7._){return false;}else{var _I8=_I7.b,_I9=E(_I7.a),_Ia=E(_I9.a);if(E(_Ia.a)!=_I3){_I6=_I8;continue;}else{if(E(_Ia.b)!=_I4){_I6=_I8;continue;}else{var _Ib=u_iswlower(E(_I9.b));if(!E(_Ib)){_I6=_I8;continue;}else{return true;}}}}}};if(!B((function(_Ic,_Id){var _Ie=E(_Ic),_If=E(_Ie.a);if(E(_If.a)!=_I3){return new F(function(){return _I5(_Id);});}else{if(E(_If.b)!=_I4){return new F(function(){return _I5(_Id);});}else{var _Ig=u_iswlower(E(_Ie.b));if(!E(_Ig)){return new F(function(){return _I5(_Id);});}else{return true;}}}})(_bW,_bX))){return E(_HZ);}else{var _Ih=new T2(0,_I3,_I4),_Ii=E(_I4);if(_Ii==8){var _Ij=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_I3)==8){return true;}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_I3)==1){return true;}else{return false;}}else{return true;}}),_bL))));}),_Ik=new T(function(){var _Il=function(_Im){var _In=E(_Im),_Io=E(_In.a),_Ip=_Io.b,_Iq=E(_Io.a),_Ir=function(_Is){return (_Iq!=_I2)?true:(E(_Ip)!=E(_I1))?true:(E(_In.b)==80)?false:true;};if(_Iq!=_I3){return new F(function(){return _Ir(_);});}else{if(E(_Ip)==8){return false;}else{return new F(function(){return _Ir(_);});}}};return B(_5R(_Il,_bV));}),_It=new T(function(){var _Iu=function(_Iv){var _Iw=E(_Iv),_Ix=E(_Iw.a),_Iy=_Ix.b,_Iz=E(_Ix.a),_IA=function(_IB){return (_Iz!=_I2)?true:(E(_Iy)!=E(_I1))?true:(E(_Iw.b)==80)?false:true;};if(_Iz!=_I3){return new F(function(){return _IA(_);});}else{if(E(_Iy)==8){return false;}else{return new F(function(){return _IA(_);});}}};return B(_5R(_Iu,_bV));}),_IC=new T(function(){var _ID=function(_IE){var _IF=E(_IE),_IG=E(_IF.a),_IH=_IG.b,_II=E(_IG.a),_IJ=function(_IK){return (_II!=_I2)?true:(E(_IH)!=E(_I1))?true:(E(_IF.b)==80)?false:true;};if(_II!=_I3){return new F(function(){return _IJ(_);});}else{if(E(_IH)==8){return false;}else{return new F(function(){return _IJ(_);});}}};return B(_5R(_ID,_bV));}),_IL=new T(function(){var _IM=function(_IN){var _IO=E(_IN),_IP=E(_IO.a),_IQ=_IP.b,_IR=E(_IP.a),_IS=function(_IT){return (_IR!=_I2)?true:(E(_IQ)!=E(_I1))?true:(E(_IO.b)==80)?false:true;};if(_IR!=_I3){return new F(function(){return _IS(_);});}else{if(E(_IQ)==8){return false;}else{return new F(function(){return _IS(_);});}}};return B(_5R(_IM,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Ih,_9I),_IL),b:_5J,c:_Ij,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Ih,_8Z),_IC),b:_5J,c:_Ij,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Ih,_9K),_It),b:_5J,c:_Ij,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Ih,_9J),_Ik),b:_5J,c:_Ij,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},_HZ))));}else{var _IU=new T(function(){var _IV=function(_IW){var _IX=E(_IW),_IY=E(_IX.a),_IZ=_IY.b,_J0=E(_IY.a),_J1=function(_J2){return (_J0!=_I2)?true:(E(_IZ)!=E(_I1))?true:(E(_IX.b)==80)?false:true;};if(_J0!=_I3){return new F(function(){return _J1(_);});}else{if(E(_IZ)!=_Ii){return new F(function(){return _J1(_);});}else{return false;}}};return B(_5R(_IV,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Ih,_a1),_IU),b:_5J,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_HZ);}}}}}}},_J3=new T(function(){return B(_HX(1,new T(function(){return B(_HO(_HT));})));});return new F(function(){return _HX(-1,_J3);});}else{_HP=_HT;return __continue;}}})(_HP));if(_HQ!=__continue){return _HQ;}}},_J4=function(_J5,_J6){var _J7=E(_J5),_J8=_J7.a;if(E(_J7.b)==80){var _J9=new T(function(){return E(E(_J8).b)+1|0;}),_Ja=function(_Jb,_Jc){var _Jd=E(_J8),_Je=_Jd.b,_Jf=E(_Jd.a),_Jg=_Jf+_Jb|0;if(_Jg<1){return E(_Jc);}else{if(_Jg>8){return E(_Jc);}else{var _Jh=E(_J9);if(_Jh<1){return E(_Jc);}else{if(_Jh>8){return E(_Jc);}else{var _Ji=function(_Jj){while(1){var _Jk=E(_Jj);if(!_Jk._){return false;}else{var _Jl=_Jk.b,_Jm=E(_Jk.a),_Jn=E(_Jm.a);if(E(_Jn.a)!=_Jg){_Jj=_Jl;continue;}else{if(E(_Jn.b)!=_Jh){_Jj=_Jl;continue;}else{var _Jo=u_iswlower(E(_Jm.b));if(!E(_Jo)){_Jj=_Jl;continue;}else{return true;}}}}}};if(!B((function(_Jp,_Jq){var _Jr=E(_Jp),_Js=E(_Jr.a);if(E(_Js.a)!=_Jg){return new F(function(){return _Ji(_Jq);});}else{if(E(_Js.b)!=_Jh){return new F(function(){return _Ji(_Jq);});}else{var _Jt=u_iswlower(E(_Jr.b));if(!E(_Jt)){return new F(function(){return _Ji(_Jq);});}else{return true;}}}})(_bW,_bX))){return E(_Jc);}else{var _Ju=new T2(0,_Jg,_Jh),_Jv=E(_Jh);if(_Jv==8){var _Jw=new T(function(){return B(_5B(2,new T(function(){if(!E(_bS)){if(E(_Jg)==8){return true;}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_Jg)==1){return true;}else{return false;}}else{return true;}}),_bL))));}),_Jx=new T(function(){var _Jy=function(_Jz){var _JA=E(_Jz),_JB=E(_JA.a),_JC=_JB.b,_JD=E(_JB.a),_JE=function(_JF){return (_JD!=_Jf)?true:(E(_JC)!=E(_Je))?true:(E(_JA.b)==80)?false:true;};if(_JD!=_Jg){return new F(function(){return _JE(_);});}else{if(E(_JC)==8){return false;}else{return new F(function(){return _JE(_);});}}};return B(_5R(_Jy,_bV));}),_JG=new T(function(){var _JH=function(_JI){var _JJ=E(_JI),_JK=E(_JJ.a),_JL=_JK.b,_JM=E(_JK.a),_JN=function(_JO){return (_JM!=_Jf)?true:(E(_JL)!=E(_Je))?true:(E(_JJ.b)==80)?false:true;};if(_JM!=_Jg){return new F(function(){return _JN(_);});}else{if(E(_JL)==8){return false;}else{return new F(function(){return _JN(_);});}}};return B(_5R(_JH,_bV));}),_JP=new T(function(){var _JQ=function(_JR){var _JS=E(_JR),_JT=E(_JS.a),_JU=_JT.b,_JV=E(_JT.a),_JW=function(_JX){return (_JV!=_Jf)?true:(E(_JU)!=E(_Je))?true:(E(_JS.b)==80)?false:true;};if(_JV!=_Jg){return new F(function(){return _JW(_);});}else{if(E(_JU)==8){return false;}else{return new F(function(){return _JW(_);});}}};return B(_5R(_JQ,_bV));}),_JY=new T(function(){var _JZ=function(_K0){var _K1=E(_K0),_K2=E(_K1.a),_K3=_K2.b,_K4=E(_K2.a),_K5=function(_K6){return (_K4!=_Jf)?true:(E(_K3)!=E(_Je))?true:(E(_K1.b)==80)?false:true;};if(_K4!=_Jg){return new F(function(){return _K5(_);});}else{if(E(_K3)==8){return false;}else{return new F(function(){return _K5(_);});}}};return B(_5R(_JZ,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Ju,_9I),_JY),b:_5J,c:_Jw,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Ju,_8Z),_JP),b:_5J,c:_Jw,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Ju,_9K),_JG),b:_5J,c:_Jw,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Ju,_9J),_Jx),b:_5J,c:_Jw,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},_Jc))));}else{var _K7=new T(function(){var _K8=function(_K9){var _Ka=E(_K9),_Kb=E(_Ka.a),_Kc=_Kb.b,_Kd=E(_Kb.a),_Ke=function(_Kf){return (_Kd!=_Jf)?true:(E(_Kc)!=E(_Je))?true:(E(_Ka.b)==80)?false:true;};if(_Kd!=_Jg){return new F(function(){return _Ke(_);});}else{if(E(_Kc)!=_Jv){return new F(function(){return _Ke(_);});}else{return false;}}};return B(_5R(_K8,_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Ju,_a1),_K7),b:_5J,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},_Jc);}}}}}}},_Kg=new T(function(){return B(_Ja(1,new T(function(){return B(_HO(_J6));})));});return new F(function(){return _Ja(-1,_Kg);});}else{return new F(function(){return _HO(_J6);});}};return B(_J4(_bW,_bX));}),_Kh=function(_Ki){while(1){var _Kj=B((function(_Kk){var _Kl=E(_Kk);if(!_Kl._){return E(_uX);}else{var _Km=_Kl.b,_Kn=E(_Kl.a);if(E(_Kn.b)==80){var _Ko=E(_Kn.a);if(E(_Ko.b)==2){var _Kp=E(E(_bW).a),_Kq=_Kp.b,_Kr=E(_Kp.a),_Ks=E(_Ko.a),_Kt=function(_Ku){if(_Kr!=_Ks){var _Kv=function(_Kw){var _Kx=E(_Kw);if(!_Kx._){return true;}else{var _Ky=_Kx.b,_Kz=E(E(_Kx.a).a),_KA=_Kz.b,_KB=E(_Kz.a),_KC=function(_KD){if(_KB!=_Ks){return new F(function(){return _Kv(_Ky);});}else{if(E(_KA)==3){return false;}else{return new F(function(){return _Kv(_Ky);});}}};if(_KB!=_Ks){return new F(function(){return _KC(_);});}else{if(E(_KA)==4){return false;}else{return new F(function(){return _KC(_);});}}}};return new F(function(){return _Kv(_bX);});}else{if(E(_Kq)==3){return false;}else{var _KE=function(_KF){var _KG=E(_KF);if(!_KG._){return true;}else{var _KH=_KG.b,_KI=E(E(_KG.a).a),_KJ=_KI.b,_KK=E(_KI.a),_KL=function(_KM){if(_KK!=_Ks){return new F(function(){return _KE(_KH);});}else{if(E(_KJ)==3){return false;}else{return new F(function(){return _KE(_KH);});}}};if(_KK!=_Ks){return new F(function(){return _KL(_);});}else{if(E(_KJ)==4){return false;}else{return new F(function(){return _KL(_);});}}}};return new F(function(){return _KE(_bX);});}}},_KN=function(_KO){var _KP=new T(function(){return B(_5R(function(_KQ){var _KR=E(_KQ),_KS=E(_KR.a);return (E(_KS.a)!=_Ks)?true:(E(_KS.b)==2)?(E(_KR.b)==80)?false:true:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_Ks,_8O),_a1),_KP),b:_5J,c:_bL,d:_bM,e:_8M,f:new T2(0,_Ks,_8N),g:_8L,h:_8L,i:_5K},new T(function(){return B(_Kh(_Km));}));};if(_Kr!=_Ks){if(!B(_Kt(_))){_Ki=_Km;return __continue;}else{return new F(function(){return _KN(_);});}}else{if(E(_Kq)==4){_Ki=_Km;return __continue;}else{if(!B(_Kt(_))){_Ki=_Km;return __continue;}else{return new F(function(){return _KN(_);});}}}}else{_Ki=_Km;return __continue;}}else{_Ki=_Km;return __continue;}}})(_Ki));if(_Kj!=__continue){return _Kj;}}},_KT=function(_KU,_KV){var _KW=E(_KU);if(E(_KW.b)==80){var _KX=E(_KW.a);if(E(_KX.b)==2){var _KY=E(E(_bW).a),_KZ=_KY.b,_L0=E(_KY.a),_L1=E(_KX.a),_L2=function(_L3){if(_L0!=_L1){var _L4=function(_L5){var _L6=E(_L5);if(!_L6._){return true;}else{var _L7=_L6.b,_L8=E(E(_L6.a).a),_L9=_L8.b,_La=E(_L8.a),_Lb=function(_Lc){if(_La!=_L1){return new F(function(){return _L4(_L7);});}else{if(E(_L9)==3){return false;}else{return new F(function(){return _L4(_L7);});}}};if(_La!=_L1){return new F(function(){return _Lb(_);});}else{if(E(_L9)==4){return false;}else{return new F(function(){return _Lb(_);});}}}};return new F(function(){return _L4(_bX);});}else{if(E(_KZ)==3){return false;}else{var _Ld=function(_Le){var _Lf=E(_Le);if(!_Lf._){return true;}else{var _Lg=_Lf.b,_Lh=E(E(_Lf.a).a),_Li=_Lh.b,_Lj=E(_Lh.a),_Lk=function(_Ll){if(_Lj!=_L1){return new F(function(){return _Ld(_Lg);});}else{if(E(_Li)==3){return false;}else{return new F(function(){return _Ld(_Lg);});}}};if(_Lj!=_L1){return new F(function(){return _Lk(_);});}else{if(E(_Li)==4){return false;}else{return new F(function(){return _Lk(_);});}}}};return new F(function(){return _Ld(_bX);});}}},_Lm=function(_Ln){var _Lo=new T(function(){return B(_5R(function(_Lp){var _Lq=E(_Lp),_Lr=E(_Lq.a);return (E(_Lr.a)!=_L1)?true:(E(_Lr.b)==2)?(E(_Lq.b)==80)?false:true:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_L1,_8O),_a1),_Lo),b:_5J,c:_bL,d:_bM,e:_8M,f:new T2(0,_L1,_8N),g:_8L,h:_8L,i:_5K},new T(function(){return B(_Kh(_KV));}));};if(_L0!=_L1){if(!B(_L2(_))){return new F(function(){return _Kh(_KV);});}else{return new F(function(){return _Lm(_);});}}else{if(E(_KZ)==4){return new F(function(){return _Kh(_KV);});}else{if(!B(_L2(_))){return new F(function(){return _Kh(_KV);});}else{return new F(function(){return _Lm(_);});}}}}else{return new F(function(){return _Kh(_KV);});}}else{return new F(function(){return _Kh(_KV);});}};return B(_KT(_bW,_bX));}),_Ls=function(_Lt){while(1){var _Lu=B((function(_Lv){var _Lw=E(_Lv);if(!_Lw._){return E(_uW);}else{var _Lx=_Lw.b,_Ly=E(_Lw.a),_Lz=_Ly.a;if(E(_Ly.b)==80){var _LA=new T(function(){return E(E(_Lz).b)+1|0;}),_LB=E(E(_bW).a),_LC=E(_Lz),_LD=_LC.b,_LE=E(_LC.a),_LF=function(_LG){var _LH=E(_LA),_LI=new T2(0,_LE,_LH);if(E(_LH)==8){var _LJ=new T(function(){return B(_5R(function(_LK){var _LL=E(_LK),_LM=E(_LL.a);return (E(_LM.a)!=_LE)?true:(E(_LM.b)!=E(_LD))?true:(E(_LL.b)==80)?false:true;},_bV));}),_LN=new T(function(){return B(_5R(function(_LO){var _LP=E(_LO),_LQ=E(_LP.a);return (E(_LQ.a)!=_LE)?true:(E(_LQ.b)!=E(_LD))?true:(E(_LP.b)==80)?false:true;},_bV));}),_LR=new T(function(){return B(_5R(function(_LS){var _LT=E(_LS),_LU=E(_LT.a);return (E(_LU.a)!=_LE)?true:(E(_LU.b)!=E(_LD))?true:(E(_LT.b)==80)?false:true;},_bV));}),_LV=new T(function(){return B(_5R(function(_LW){var _LX=E(_LW),_LY=E(_LX.a);return (E(_LY.a)!=_LE)?true:(E(_LY.b)!=E(_LD))?true:(E(_LX.b)==80)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_LI,_9I),_LV),b:_5J,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_LI,_8Z),_LR),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_LI,_9K),_LN),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_LI,_9J),_LJ),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_Ls(_Lx));})))));}else{var _LZ=new T(function(){return B(_5R(function(_M0){var _M1=E(_M0),_M2=E(_M1.a);return (E(_M2.a)!=_LE)?true:(E(_M2.b)!=E(_LD))?true:(E(_M1.b)==80)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_LI,_a1),_LZ),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_Ls(_Lx));}));}};if(E(_LB.a)!=_LE){var _M3=function(_M4){while(1){var _M5=E(_M4);if(!_M5._){return true;}else{var _M6=_M5.b,_M7=E(E(_M5.a).a);if(E(_M7.a)!=_LE){_M4=_M6;continue;}else{if(E(_M7.b)!=E(_LA)){_M4=_M6;continue;}else{return false;}}}}};if(!B(_M3(_bX))){_Lt=_Lx;return __continue;}else{return new F(function(){return _LF(_);});}}else{var _M8=E(_LA);if(E(_LB.b)!=_M8){var _M9=function(_Ma){while(1){var _Mb=E(_Ma);if(!_Mb._){return true;}else{var _Mc=_Mb.b,_Md=E(E(_Mb.a).a);if(E(_Md.a)!=_LE){_Ma=_Mc;continue;}else{if(E(_Md.b)!=_M8){_Ma=_Mc;continue;}else{return false;}}}}};if(!B(_M9(_bX))){_Lt=_Lx;return __continue;}else{return new F(function(){return _LF(_);});}}else{_Lt=_Lx;return __continue;}}}else{_Lt=_Lx;return __continue;}}})(_Lt));if(_Lu!=__continue){return _Lu;}}},_Me=function(_Mf,_Mg){var _Mh=E(_Mf),_Mi=_Mh.a;if(E(_Mh.b)==80){var _Mj=new T(function(){return E(E(_Mi).b)+1|0;}),_Mk=E(E(_bW).a),_Ml=E(_Mi),_Mm=_Ml.b,_Mn=E(_Ml.a),_Mo=function(_Mp){var _Mq=E(_Mj),_Mr=new T2(0,_Mn,_Mq);if(E(_Mq)==8){var _Ms=new T(function(){return B(_5R(function(_Mt){var _Mu=E(_Mt),_Mv=E(_Mu.a);return (E(_Mv.a)!=_Mn)?true:(E(_Mv.b)!=E(_Mm))?true:(E(_Mu.b)==80)?false:true;},_bV));}),_Mw=new T(function(){return B(_5R(function(_Mx){var _My=E(_Mx),_Mz=E(_My.a);return (E(_Mz.a)!=_Mn)?true:(E(_Mz.b)!=E(_Mm))?true:(E(_My.b)==80)?false:true;},_bV));}),_MA=new T(function(){return B(_5R(function(_MB){var _MC=E(_MB),_MD=E(_MC.a);return (E(_MD.a)!=_Mn)?true:(E(_MD.b)!=E(_Mm))?true:(E(_MC.b)==80)?false:true;},_bV));}),_ME=new T(function(){return B(_5R(function(_MF){var _MG=E(_MF),_MH=E(_MG.a);return (E(_MH.a)!=_Mn)?true:(E(_MH.b)!=E(_Mm))?true:(E(_MG.b)==80)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Mr,_9I),_ME),b:_5J,c:_bL,d:_bM,e:_90,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Mr,_8Z),_MA),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Mr,_9K),_Mw),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T2(1,{_:0,a:new T2(1,new T2(0,_Mr,_9J),_Ms),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_Ls(_Mg));})))));}else{var _MI=new T(function(){return B(_5R(function(_MJ){var _MK=E(_MJ),_ML=E(_MK.a);return (E(_ML.a)!=_Mn)?true:(E(_ML.b)!=E(_Mm))?true:(E(_MK.b)==80)?false:true;},_bV));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Mr,_a1),_MI),b:_5J,c:_bL,d:_bM,e:_8M,f:_8S,g:_8L,h:_8L,i:_5K},new T(function(){return B(_Ls(_Mg));}));}};if(E(_Mk.a)!=_Mn){var _MM=function(_MN){while(1){var _MO=E(_MN);if(!_MO._){return true;}else{var _MP=_MO.b,_MQ=E(E(_MO.a).a);if(E(_MQ.a)!=_Mn){_MN=_MP;continue;}else{if(E(_MQ.b)!=E(_Mj)){_MN=_MP;continue;}else{return false;}}}}};if(!B(_MM(_bX))){return new F(function(){return _Ls(_Mg);});}else{return new F(function(){return _Mo(_);});}}else{var _MR=E(_Mj);if(E(_Mk.b)!=_MR){var _MS=function(_MT){while(1){var _MU=E(_MT);if(!_MU._){return true;}else{var _MV=_MU.b,_MW=E(E(_MU.a).a);if(E(_MW.a)!=_Mn){_MT=_MV;continue;}else{if(E(_MW.b)!=_MR){_MT=_MV;continue;}else{return false;}}}}};if(!B(_MS(_bX))){return new F(function(){return _Ls(_Mg);});}else{return new F(function(){return _Mo(_);});}}else{return new F(function(){return _Ls(_Mg);});}}}else{return new F(function(){return _Ls(_Mg);});}},_uV=B(_Me(_bW,_bX));}var _MX=function(_MY){var _MZ=new T(function(){var _N0=new T(function(){return B(_aN(function(_N1,_N2){var _N3=E(E(_N1).g),_N4=E(E(_N2).g);return (_N3<=_N4)?(_N3>=_N4)?1:(!E(_bK))?0:2:(!E(_bK))?2:0;},B(_aE(_8z,_uV))));}),_N5=new T(function(){return (E(_bH)-5.0000000000000044e-2*E(_bP))/0.95;}),_N6=new T(function(){return E(_N5)-1.0e-5;}),_N7=new T(function(){return (E(_bI)-5.0000000000000044e-2*E(_bP))/0.95;}),_N8=new T(function(){return E(_N7)+1.0e-5;}),_N9=function(_Na,_Nb){var _Nc=E(_Nb);if(!_Nc._){return __Z;}else{var _Nd=_Nc.a,_Ne=_Nc.b;if(!E(_bK)){var _Nf=E(_Na),_Ng=E(_N6);if(_Nf>=_Ng){var _Nh=new T(function(){var _Ni=E(_Nd),_Nj=E(_Ni.e),_Nk=B(_bE(_bF-_Nj|0,_bM,_N5,_Nf,_Ni.a,_Ni.b,_Ni.c,_Ni.d,_Nj,_Ni.f,_Ni.g,_Ni.i));return {_:0,a:_Nk.a,b:_Nk.b,c:_Nk.c,d:_Nk.d,e:_Nk.e,f:_Nk.f,g:_Nk.g,h:_Nk.h,i:_Nk.i};}),_Nl=new T(function(){var _Nm=function(_Nn,_No){var _Np=E(_No);if(!_Np._){return __Z;}else{var _Nq=E(_Nn);if(_Nq>=_Ng){var _Nr=new T(function(){var _Ns=E(_Np.a),_Nt=_Ns.a,_Nu=_Ns.b,_Nv=_Ns.c,_Nw=_Ns.d,_Nx=_Ns.f,_Ny=_Ns.g,_Nz=_Ns.i,_NA=E(_Ns.e),_NB=B(_bE(_bF-_NA|0,_bM,_Nq,_Nq,_Nt,_Nu,_Nv,_Nw,_NA,_Nx,_Ny,_Nz)),_NC=_NB.a,_ND=_NB.b,_NE=_NB.c,_NF=_NB.d,_NG=_NB.e,_NH=_NB.f,_NI=_NB.g,_NJ=_NB.i,_NK=E(_N5),_NL=E(_NB.h);if(_NK>=_NL){return {_:0,a:_NC,b:_ND,c:_NE,d:_NF,e:_NG,f:_NH,g:_NI,h:_NL,i:_NJ};}else{if(_NL>=_Nq){return {_:0,a:_NC,b:_ND,c:_NE,d:_NF,e:_NG,f:_NH,g:_NI,h:_NL,i:_NJ};}else{var _NM=B(_bE(_bF-_NA|0,_bM,_NK,_NL,_Nt,_Nu,_Nv,_Nw,_NA,_Nx,_Ny,_Nz));return {_:0,a:_NM.a,b:_NM.b,c:_NM.c,d:_NM.d,e:_NM.e,f:_NM.f,g:_NM.g,h:_NM.h,i:_NM.i};}}}),_NN=new T(function(){return B(_Nm(new T(function(){var _NO=E(E(_Nr).h);if(_Nq>_NO){return E(_NO);}else{return E(_Nq);}},1),_Np.b));});return new T2(1,_Nr,_NN);}else{return __Z;}}};return B(_Nm(new T(function(){var _NP=E(E(_Nh).h);if(_Nf>_NP){return E(_NP);}else{return E(_Nf);}},1),_Ne));});return new T2(1,_Nh,_Nl);}else{return __Z;}}else{var _NQ=E(_Na),_NR=E(_N8);if(_NQ<=_NR){var _NS=new T(function(){var _NT=E(_Nd),_NU=E(_NT.e),_NV=B(_bE(_bF-_NU|0,_bM,_NQ,_N7,_NT.a,_NT.b,_NT.c,_NT.d,_NU,_NT.f,_NT.g,_NT.i));return {_:0,a:_NV.a,b:_NV.b,c:_NV.c,d:_NV.d,e:_NV.e,f:_NV.f,g:_NV.g,h:_NV.h,i:_NV.i};}),_NW=new T(function(){var _NX=function(_NY,_NZ){var _O0=E(_NZ);if(!_O0._){return __Z;}else{var _O1=E(_NY);if(_O1<=_NR){var _O2=new T(function(){var _O3=E(_O0.a),_O4=_O3.a,_O5=_O3.b,_O6=_O3.c,_O7=_O3.d,_O8=_O3.f,_O9=_O3.g,_Oa=_O3.i,_Ob=E(_O3.e),_Oc=B(_bE(_bF-_Ob|0,_bM,_O1,_O1,_O4,_O5,_O6,_O7,_Ob,_O8,_O9,_Oa)),_Od=_Oc.a,_Oe=_Oc.b,_Of=_Oc.c,_Og=_Oc.d,_Oh=_Oc.e,_Oi=_Oc.f,_Oj=_Oc.g,_Ok=_Oc.i,_Ol=E(_Oc.h);if(_O1>=_Ol){return {_:0,a:_Od,b:_Oe,c:_Of,d:_Og,e:_Oh,f:_Oi,g:_Oj,h:_Ol,i:_Ok};}else{var _Om=E(_N7);if(_Ol>=_Om){return {_:0,a:_Od,b:_Oe,c:_Of,d:_Og,e:_Oh,f:_Oi,g:_Oj,h:_Ol,i:_Ok};}else{var _On=B(_bE(_bF-_Ob|0,_bM,_Ol,_Om,_O4,_O5,_O6,_O7,_Ob,_O8,_O9,_Oa));return {_:0,a:_On.a,b:_On.b,c:_On.c,d:_On.d,e:_On.e,f:_On.f,g:_On.g,h:_On.h,i:_On.i};}}}),_Oo=new T(function(){return B(_NX(new T(function(){var _Op=E(E(_O2).h);if(_O1>_Op){return E(_O1);}else{return E(_Op);}},1),_O0.b));});return new T2(1,_O2,_Oo);}else{return __Z;}}};return B(_NX(new T(function(){var _Oq=E(E(_NS).h);if(_NQ>_Oq){return E(_NQ);}else{return E(_Oq);}},1),_Ne));});return new T2(1,_NS,_NW);}else{return __Z;}}}},_Or=E(_bQ);if(!_Or._){var _Os=B(_5f(_bK,_2P,new T(function(){if(!E(_bK)){return true;}else{return false;}}),_2P,_2P,_8R,_8S,_8L,new T(function(){if(!E(_bK)){return E(_aD);}else{return E(_aC);}}),_5K,B(_N9(new T(function(){if(!E(_bK)){return E(_N7);}else{return E(_N5);}},1),_N0))));return {_:0,a:_Os.a,b:_Os.b,c:_Os.c,d:_Os.d,e:_Os.e,f:_Os.f,g:_Os.g,h:_Os.h,i:_Os.i};}else{var _Ot=E(_Or.a),_Ou=_Ot.b,_Ov=_Ot.c,_Ow=_Ot.d,_Ox=_Ot.e,_Oy=_Ot.f,_Oz=_Ot.g,_OA=_Ot.i,_OB=E(_Ot.a);if(!_OB._){var _OC=B(_5f(_bK,_2P,new T(function(){if(!E(_bK)){return true;}else{return false;}}),_2P,_2P,_8R,_8S,_8L,new T(function(){if(!E(_bK)){return E(_aD);}else{return E(_aC);}}),_5K,B(_N9(new T(function(){if(!E(_bK)){return E(_N7);}else{return E(_N5);}},1),_N0))));return {_:0,a:_OC.a,b:_OC.b,c:_OC.c,d:_OC.d,e:_OC.e,f:_OC.f,g:_OC.g,h:_OC.h,i:_OC.i};}else{var _OD=new T(function(){return B(_5R(function(_OE){return (!B(_v(_16,E(_OE).a,_OB)))?true:false;},_N0));});if(!E(_bK)){var _OF=E(_N7),_OG=E(_N6);if(_OF>=_OG){var _OH=new T(function(){var _OI=E(_Ox),_OJ=B(_bE(_bF-_OI|0,_bM,_N5,_OF,_OB,_Ou,_Ov,_Ow,_OI,_Oy,_Oz,_OA));return {_:0,a:_OJ.a,b:_OJ.b,c:_OJ.c,d:_OJ.d,e:_OJ.e,f:_OJ.f,g:_OJ.g,h:_OJ.h,i:_OJ.i};}),_OK=function(_OL,_OM){var _ON=E(_OM);if(!_ON._){return __Z;}else{var _OO=E(_OL);if(_OO>=_OG){var _OP=new T(function(){var _OQ=E(_ON.a),_OR=_OQ.a,_OS=_OQ.b,_OT=_OQ.c,_OU=_OQ.d,_OV=_OQ.f,_OW=_OQ.g,_OX=_OQ.i,_OY=E(_OQ.e),_OZ=B(_bE(_bF-_OY|0,_bM,_OO,_OO,_OR,_OS,_OT,_OU,_OY,_OV,_OW,_OX)),_P0=_OZ.a,_P1=_OZ.b,_P2=_OZ.c,_P3=_OZ.d,_P4=_OZ.e,_P5=_OZ.f,_P6=_OZ.g,_P7=_OZ.i,_P8=E(_N5),_P9=E(_OZ.h);if(_P8>=_P9){return {_:0,a:_P0,b:_P1,c:_P2,d:_P3,e:_P4,f:_P5,g:_P6,h:_P9,i:_P7};}else{if(_P9>=_OO){return {_:0,a:_P0,b:_P1,c:_P2,d:_P3,e:_P4,f:_P5,g:_P6,h:_P9,i:_P7};}else{var _Pa=B(_bE(_bF-_OY|0,_bM,_P8,_P9,_OR,_OS,_OT,_OU,_OY,_OV,_OW,_OX));return {_:0,a:_Pa.a,b:_Pa.b,c:_Pa.c,d:_Pa.d,e:_Pa.e,f:_Pa.f,g:_Pa.g,h:_Pa.h,i:_Pa.i};}}}),_Pb=new T(function(){return B(_OK(new T(function(){var _Pc=E(E(_OP).h);if(_OO>_Pc){return E(_Pc);}else{return E(_OO);}},1),_ON.b));});return new T2(1,_OP,_Pb);}else{return __Z;}}},_Pd=B(_OK(new T(function(){var _Pe=E(E(_OH).h);if(_OF>_Pe){return E(_Pe);}else{return E(_OF);}},1),_OD)),_Pf=E(_OH),_Pg=E(_Pf.h);if(_Pg>=2.1472688986353e9){var _Ph=B(_1m(_2P,_5L,_2P,_2P,_8R,_8S,_8L,2.1472688986353e9,_5K,_Pd));return {_:0,a:_Ph.a,b:_Ph.b,c:_Ph.c,d:_Ph.d,e:_Ph.e,f:_Ph.f,g:_Ph.g,h:_Ph.h,i:_Ph.i};}else{var _Pi=B(_1m(_Pf.a,_Pf.b,_Pf.c,_Pf.d,_Pf.e,_Pf.f,_Pf.g,_Pg,_Pf.i,_Pd));return {_:0,a:_Pi.a,b:_Pi.b,c:_Pi.c,d:_Pi.d,e:_Pi.e,f:_Pi.f,g:_Pi.g,h:_Pi.h,i:_Pi.i};}}else{return {_:0,a:_2P,b:_5L,c:_2P,d:_2P,e:_8R,f:_8S,g:_8L,h:_aD,i:_5K};}}else{var _Pj=E(_N5),_Pk=E(_N8);if(_Pj<=_Pk){var _Pl=new T(function(){var _Pm=E(_Ox),_Pn=B(_bE(_bF-_Pm|0,_bM,_Pj,_N7,_OB,_Ou,_Ov,_Ow,_Pm,_Oy,_Oz,_OA));return {_:0,a:_Pn.a,b:_Pn.b,c:_Pn.c,d:_Pn.d,e:_Pn.e,f:_Pn.f,g:_Pn.g,h:_Pn.h,i:_Pn.i};}),_Po=function(_Pp,_Pq){var _Pr=E(_Pq);if(!_Pr._){return __Z;}else{var _Ps=E(_Pp);if(_Ps<=_Pk){var _Pt=new T(function(){var _Pu=E(_Pr.a),_Pv=_Pu.a,_Pw=_Pu.b,_Px=_Pu.c,_Py=_Pu.d,_Pz=_Pu.f,_PA=_Pu.g,_PB=_Pu.i,_PC=E(_Pu.e),_PD=B(_bE(_bF-_PC|0,_bM,_Ps,_Ps,_Pv,_Pw,_Px,_Py,_PC,_Pz,_PA,_PB)),_PE=_PD.a,_PF=_PD.b,_PG=_PD.c,_PH=_PD.d,_PI=_PD.e,_PJ=_PD.f,_PK=_PD.g,_PL=_PD.i,_PM=E(_PD.h);if(_Ps>=_PM){return {_:0,a:_PE,b:_PF,c:_PG,d:_PH,e:_PI,f:_PJ,g:_PK,h:_PM,i:_PL};}else{var _PN=E(_N7);if(_PM>=_PN){return {_:0,a:_PE,b:_PF,c:_PG,d:_PH,e:_PI,f:_PJ,g:_PK,h:_PM,i:_PL};}else{var _PO=B(_bE(_bF-_PC|0,_bM,_PM,_PN,_Pv,_Pw,_Px,_Py,_PC,_Pz,_PA,_PB));return {_:0,a:_PO.a,b:_PO.b,c:_PO.c,d:_PO.d,e:_PO.e,f:_PO.f,g:_PO.g,h:_PO.h,i:_PO.i};}}}),_PP=new T(function(){return B(_Po(new T(function(){var _PQ=E(E(_Pt).h);if(_Ps>_PQ){return E(_Ps);}else{return E(_PQ);}},1),_Pr.b));});return new T2(1,_Pt,_PP);}else{return __Z;}}},_PR=B(_Po(new T(function(){var _PS=E(E(_Pl).h);if(_Pj>_PS){return E(_Pj);}else{return E(_PS);}},1),_OD)),_PT=E(_Pl),_PU=E(_PT.h);if(_PU<=(-2.1472688996352e9)){var _PV=B(_17(_2P,_5J,_2P,_2P,_8R,_8S,_8L,-2.1472688996352e9,_5K,_PR));return {_:0,a:_PV.a,b:_PV.b,c:_PV.c,d:_PV.d,e:_PV.e,f:_PV.f,g:_PV.g,h:_PV.h,i:_PV.i};}else{var _PW=B(_17(_PT.a,_PT.b,_PT.c,_PT.d,_PT.e,_PT.f,_PT.g,_PU,_PT.i,_PR));return {_:0,a:_PW.a,b:_PW.b,c:_PW.c,d:_PW.d,e:_PW.e,f:_PW.f,g:_PW.g,h:_PW.h,i:_PW.i};}}else{return {_:0,a:_2P,b:_5J,c:_2P,d:_2P,e:_8R,f:_8S,g:_8L,h:_aC,i:_5K};}}}}}),_PX=new T(function(){var _PY=function(_PZ){var _Q0=E(B(_bE(1,_bM,_bD,_bC,_bV,new T(function(){return B(_aI(_bK));}),_bL,_bM,_bN,_bO,_bP,_bQ)).h);return (!E(_bK))?(_Q0>=2.145336163353e9)?5.0000000000000044e-2*E(_bP)+0.95*E(E(_MZ).h):0:(_Q0<=(-2.145336164352e9))?5.0000000000000044e-2*E(_bP)+0.95*E(E(_MZ).h):0;};if(!E(_bK)){var _Q1=E(E(_MZ).h);if(_Q1<=2.145336163353e9){return 5.0000000000000044e-2*E(_bP)+0.95*_Q1;}else{return B(_PY(_));}}else{var _Q2=E(E(_MZ).h);if(_Q2>=(-2.145336164352e9)){return 5.0000000000000044e-2*E(_bP)+0.95*_Q2;}else{return B(_PY(_));}}});return {_:0,a:_bV,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:_PX,i:new T1(1,_MZ)};},_Q3=function(_Q4){var _Q5=function(_Q6){var _Q7=function(_Q8){var _Q9=function(_Qa){var _Qb=function(_Qc){while(1){var _Qd=B((function(_Qe){var _Qf=E(_Qe);if(!_Qf._){return true;}else{var _Qg=_Qf.b,_Qh=E(_Qf.a);if(!_Qh._){return false;}else{var _Qi=_Qh.b,_Qj=E(E(_Qh.a).b);if(!E(_bK)){if(E(_Qj)==75){_Qc=_Qg;return __continue;}else{var _Qk=function(_Ql){while(1){var _Qm=E(_Ql);if(!_Qm._){return false;}else{if(E(E(_Qm.a).b)==75){return true;}else{_Ql=_Qm.b;continue;}}}};if(!B(_Qk(_Qi))){return false;}else{_Qc=_Qg;return __continue;}}}else{if(E(_Qj)==107){_Qc=_Qg;return __continue;}else{var _Qn=function(_Qo){while(1){var _Qp=E(_Qo);if(!_Qp._){return false;}else{if(E(E(_Qp.a).b)==107){return true;}else{_Qo=_Qp.b;continue;}}}};if(!B(_Qn(_Qi))){return false;}else{_Qc=_Qg;return __continue;}}}}}})(_Qc));if(_Qd!=__continue){return _Qd;}}};if(!B(_Qb(B(_aE(_8J,_uV))))){return {_:0,a:_bV,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:new T(function(){if(!E(_bK)){return E(_bD);}else{return E(_bC);}}),i:_5K};}else{return new F(function(){return _MX(_);});}},_Qq=function(_Qr){if(!B(_6g(B(_aE(_8J,_uV))))){return {_:0,a:_bV,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:new T(function(){if(!E(_bK)){return E(_bD);}else{return E(_bC);}}),i:_5K};}else{return new F(function(){return _MX(_);});}};if(!B(_q(_bG,3))){if(!B(_q(_bM,3))){return new F(function(){return _Q9(_);});}else{return new F(function(){return _Qq(_);});}}else{if(!B(_q(_bM,3))){return new F(function(){return _Qq(_);});}else{return new F(function(){return _Q9(_);});}}},_Qs=function(_Qt){if(!B(_6y(B(_aE(_8J,_uV))))){return {_:0,a:_bV,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:new T(function(){if(!E(_bK)){return E(_bD);}else{return E(_bC);}}),i:_5K};}else{return new F(function(){return _MX(_);});}};if(!B(_q(_bG,2))){if(!B(_q(_bM,2))){return new F(function(){return _Q7(_);});}else{return new F(function(){return _Qs(_);});}}else{if(!B(_q(_bM,2))){return new F(function(){return _Qs(_);});}else{return new F(function(){return _Q7(_);});}}},_Qu=function(_Qv){if(!B(_6Q(B(_aE(_8J,_uV))))){return {_:0,a:_bV,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:new T(function(){if(!E(_bK)){return E(_bD);}else{return E(_bC);}}),i:_5K};}else{return new F(function(){return _MX(_);});}};if(!B(_q(_bG,1))){if(!B(_q(_bM,1))){return new F(function(){return _Q5(_);});}else{return new F(function(){return _Qu(_);});}}else{if(!B(_q(_bM,1))){return new F(function(){return _Qu(_);});}else{return new F(function(){return _Q5(_);});}}},_Qw=function(_Qx){if(!B(_78(B(_aE(_8J,_uV))))){return {_:0,a:_bV,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:new T(function(){if(!E(_bK)){return E(_bD);}else{return E(_bC);}}),i:_5K};}else{return new F(function(){return _MX(_);});}};if(!B(_q(_bG,0))){if(!B(_q(_bM,0))){return new F(function(){return _Q3(_);});}else{return new F(function(){return _Qw(_);});}}else{if(!B(_q(_bM,0))){return new F(function(){return _Qw(_);});}else{return new F(function(){return _Q3(_);});}}}}else{return {_:0,a:_bJ,b:_bK,c:_bL,d:_bM,e:_bN,f:_bO,g:_bP,h:_bP,i:_5K};}},_Qy=new T2(1,_5J,_2P),_Qz=new T2(1,_5J,_Qy),_QA=new T2(1,_5J,_Qz),_QB=new T2(1,_5J,_QA),_QC=function(_QD,_QE,_QF,_QG,_QH,_QI,_QJ,_QK,_QL){var _QM=E(_QD);if(!_QM){return new F(function(){return _bE(0,_QB,_bD,_bC,_QE,_QF,_QG,_QH,_QI,_QJ,_QK,_QL);});}else{var _QN=B(_QC(_QM-1|0,_QE,_QF,_QG,_QH,_QI,_QJ,_QK,_QL));return new F(function(){return _bE(_QM,_QB,_bD,_bC,_QN.a,_QN.b,_QN.c,_QN.d,_QN.e,_QN.f,_QN.g,_QN.i);});}},_QO=function(_QP,_QQ){while(1){var _QR=E(_QP);if(!_QR._){return E(_QQ);}else{var _QS=_QQ+1|0;_QP=_QR.b;_QQ=_QS;continue;}}},_QT=new T(function(){return B(unCStr("ACK"));}),_QU=new T(function(){return B(unCStr("BEL"));}),_QV=new T(function(){return B(unCStr("BS"));}),_QW=new T(function(){return B(unCStr("SP"));}),_QX=new T2(1,_QW,_2P),_QY=new T(function(){return B(unCStr("US"));}),_QZ=new T2(1,_QY,_QX),_R0=new T(function(){return B(unCStr("RS"));}),_R1=new T2(1,_R0,_QZ),_R2=new T(function(){return B(unCStr("GS"));}),_R3=new T2(1,_R2,_R1),_R4=new T(function(){return B(unCStr("FS"));}),_R5=new T2(1,_R4,_R3),_R6=new T(function(){return B(unCStr("ESC"));}),_R7=new T2(1,_R6,_R5),_R8=new T(function(){return B(unCStr("SUB"));}),_R9=new T2(1,_R8,_R7),_Ra=new T(function(){return B(unCStr("EM"));}),_Rb=new T2(1,_Ra,_R9),_Rc=new T(function(){return B(unCStr("CAN"));}),_Rd=new T2(1,_Rc,_Rb),_Re=new T(function(){return B(unCStr("ETB"));}),_Rf=new T2(1,_Re,_Rd),_Rg=new T(function(){return B(unCStr("SYN"));}),_Rh=new T2(1,_Rg,_Rf),_Ri=new T(function(){return B(unCStr("NAK"));}),_Rj=new T2(1,_Ri,_Rh),_Rk=new T(function(){return B(unCStr("DC4"));}),_Rl=new T2(1,_Rk,_Rj),_Rm=new T(function(){return B(unCStr("DC3"));}),_Rn=new T2(1,_Rm,_Rl),_Ro=new T(function(){return B(unCStr("DC2"));}),_Rp=new T2(1,_Ro,_Rn),_Rq=new T(function(){return B(unCStr("DC1"));}),_Rr=new T2(1,_Rq,_Rp),_Rs=new T(function(){return B(unCStr("DLE"));}),_Rt=new T2(1,_Rs,_Rr),_Ru=new T(function(){return B(unCStr("SI"));}),_Rv=new T2(1,_Ru,_Rt),_Rw=new T(function(){return B(unCStr("SO"));}),_Rx=new T2(1,_Rw,_Rv),_Ry=new T(function(){return B(unCStr("CR"));}),_Rz=new T2(1,_Ry,_Rx),_RA=new T(function(){return B(unCStr("FF"));}),_RB=new T2(1,_RA,_Rz),_RC=new T(function(){return B(unCStr("VT"));}),_RD=new T2(1,_RC,_RB),_RE=new T(function(){return B(unCStr("LF"));}),_RF=new T2(1,_RE,_RD),_RG=new T(function(){return B(unCStr("HT"));}),_RH=new T2(1,_RG,_RF),_RI=new T2(1,_QV,_RH),_RJ=new T2(1,_QU,_RI),_RK=new T2(1,_QT,_RJ),_RL=new T(function(){return B(unCStr("ENQ"));}),_RM=new T2(1,_RL,_RK),_RN=new T(function(){return B(unCStr("EOT"));}),_RO=new T2(1,_RN,_RM),_RP=new T(function(){return B(unCStr("ETX"));}),_RQ=new T2(1,_RP,_RO),_RR=new T(function(){return B(unCStr("STX"));}),_RS=new T2(1,_RR,_RQ),_RT=new T(function(){return B(unCStr("SOH"));}),_RU=new T2(1,_RT,_RS),_RV=new T(function(){return B(unCStr("NUL"));}),_RW=new T2(1,_RV,_RU),_RX=92,_RY=new T(function(){return B(unCStr("\\DEL"));}),_RZ=new T(function(){return B(unCStr("\\a"));}),_S0=new T(function(){return B(unCStr("\\\\"));}),_S1=new T(function(){return B(unCStr("\\SO"));}),_S2=new T(function(){return B(unCStr("\\r"));}),_S3=new T(function(){return B(unCStr("\\f"));}),_S4=new T(function(){return B(unCStr("\\v"));}),_S5=new T(function(){return B(unCStr("\\n"));}),_S6=new T(function(){return B(unCStr("\\t"));}),_S7=new T(function(){return B(unCStr("\\b"));}),_S8=function(_S9,_Sa){if(_S9<=127){var _Sb=E(_S9);switch(_Sb){case 92:return new F(function(){return _a(_S0,_Sa);});break;case 127:return new F(function(){return _a(_RY,_Sa);});break;default:if(_Sb<32){var _Sc=E(_Sb);switch(_Sc){case 7:return new F(function(){return _a(_RZ,_Sa);});break;case 8:return new F(function(){return _a(_S7,_Sa);});break;case 9:return new F(function(){return _a(_S6,_Sa);});break;case 10:return new F(function(){return _a(_S5,_Sa);});break;case 11:return new F(function(){return _a(_S4,_Sa);});break;case 12:return new F(function(){return _a(_S3,_Sa);});break;case 13:return new F(function(){return _a(_S2,_Sa);});break;case 14:return new F(function(){return _a(_S1,new T(function(){var _Sd=E(_Sa);if(!_Sd._){return __Z;}else{if(E(_Sd.a)==72){return B(unAppCStr("\\&",_Sd));}else{return E(_Sd);}}},1));});break;default:return new F(function(){return _a(new T2(1,_RX,new T(function(){return B(_q(_RW,_Sc));})),_Sa);});}}else{return new T2(1,_Sb,_Sa);}}}else{var _Se=new T(function(){var _Sf=jsShowI(_S9);return B(_a(fromJSStr(_Sf),new T(function(){var _Sg=E(_Sa);if(!_Sg._){return __Z;}else{var _Sh=E(_Sg.a);if(_Sh<48){return E(_Sg);}else{if(_Sh>57){return E(_Sg);}else{return B(unAppCStr("\\&",_Sg));}}}},1)));});return new T2(1,_RX,_Se);}},_Si=new T(function(){return B(unCStr("\'\\\'\'"));}),_Sj=39,_Sk=function(_Sl,_Sm){var _Sn=E(_Sl);if(_Sn==39){return new F(function(){return _a(_Si,_Sm);});}else{return new T2(1,_Sj,new T(function(){return B(_S8(_Sn,new T2(1,_Sj,_Sm)));}));}},_So=function(_Sp){return new F(function(){return err(B(unAppCStr("Char.digitToInt: not a digit ",new T(function(){return B(_Sk(_Sp,_2P));}))));});},_Sq=function(_Sr){var _Ss=_Sr-48|0;if(_Ss>>>0>9){var _St=_Sr-97|0;if(_St>>>0>5){var _Su=_Sr-65|0;if(_Su>>>0>5){return new F(function(){return _So(_Sr);});}else{return _Su+10|0;}}else{return _St+10|0;}}else{return E(_Ss);}},_Sv=function(_Sw){return new F(function(){return err(B(unAppCStr("Char.intToDigit: not a digit ",new T(function(){if(_Sw>=0){var _Sx=jsShowI(_Sw);return fromJSStr(_Sx);}else{var _Sy=jsShowI(_Sw);return fromJSStr(_Sy);}}))));});},_Sz=function(_SA){var _SB=function(_SC){if(_SA<10){return new F(function(){return _Sv(_SA);});}else{if(_SA>15){return new F(function(){return _Sv(_SA);});}else{return (97+_SA|0)-10|0;}}};if(_SA<0){return new F(function(){return _SB(_);});}else{if(_SA>9){return new F(function(){return _SB(_);});}else{return 48+_SA|0;}}},_SD=function(_SE,_SF,_SG,_SH,_SI,_SJ,_SK,_SL,_SM,_SN,_SO,_SP,_SQ){while(1){var _SR=B((function(_SS,_ST,_SU,_SV,_SW,_SX,_SY,_SZ,_T0,_T1,_T2,_T3,_T4){var _T5=E(_SS),_T6=E(_T5);switch(_T6){case 32:return {_:0,a:_SW,b:_SX,c:_SY,d:_SZ,e:_T0,f:_T1,g:_T2,h:_T3,i:_T4};case 47:return new F(function(){return _T7(_ST,1,_SV-1|0,_SW,_SX,_SY,_SZ,_T0,_T1,_T2,_T3,_T4);});break;default:if((_T6-48|0)>>>0>9){return new F(function(){return _T7(_ST,_SU+1|0,_SV,new T2(1,new T2(0,new T2(0,_SU,_SV),_T5),_SW),_SX,_SY,_SZ,_T0,_T1,_T2,_T3,_T4);});}else{var _T8=E(_T6);if(_T8==49){return new F(function(){return _T7(_ST,_SU+1|0,_SV,_SW,_SX,_SY,_SZ,_T0,_T1,_T2,_T3,_T4);});}else{var _T9=_ST,_Ta=_SU+1|0,_Tb=_SV,_Tc=_SW,_Td=_SX,_Te=_SY,_Tf=_SZ,_Tg=_T0,_Th=_T1,_Ti=_T2,_Tj=_T3,_Tk=_T4;_SE=new T(function(){return B(_Sz(B(_Sq(_T8))-1|0));});_SF=_T9;_SG=_Ta;_SH=_Tb;_SI=_Tc;_SJ=_Td;_SK=_Te;_SL=_Tf;_SM=_Tg;_SN=_Th;_SO=_Ti;_SP=_Tj;_SQ=_Tk;return __continue;}}}})(_SE,_SF,_SG,_SH,_SI,_SJ,_SK,_SL,_SM,_SN,_SO,_SP,_SQ));if(_SR!=__continue){return _SR;}}},_T7=function(_Tl,_Tm,_Tn,_To,_Tp,_Tq,_Tr,_Ts,_Tt,_Tu,_Tv,_Tw){while(1){var _Tx=B((function(_Ty,_Tz,_TA,_TB,_TC,_TD,_TE,_TF,_TG,_TH,_TI,_TJ){var _TK=E(_Ty);if(!_TK._){return E(_5Q);}else{var _TL=_TK.b,_TM=E(_TK.a),_TN=E(_TM);switch(_TN){case 32:return {_:0,a:_TB,b:_TC,c:_TD,d:_TE,e:_TF,f:_TG,g:_TH,h:_TI,i:_TJ};case 47:var _TO=_TA-1|0,_TP=_TB,_TQ=_TC,_TR=_TD,_TS=_TE,_TT=_TF,_TU=_TG,_TV=_TH,_TW=_TI,_TX=_TJ;_Tl=_TL;_Tm=1;_Tn=_TO;_To=_TP;_Tp=_TQ;_Tq=_TR;_Tr=_TS;_Ts=_TT;_Tt=_TU;_Tu=_TV;_Tv=_TW;_Tw=_TX;return __continue;default:if((_TN-48|0)>>>0>9){var _TY=_Tz+1|0,_TO=_TA,_TP=new T2(1,new T2(0,new T2(0,_Tz,_TA),_TM),_TB),_TQ=_TC,_TR=_TD,_TS=_TE,_TT=_TF,_TU=_TG,_TV=_TH,_TW=_TI,_TX=_TJ;_Tl=_TL;_Tm=_TY;_Tn=_TO;_To=_TP;_Tp=_TQ;_Tq=_TR;_Tr=_TS;_Ts=_TT;_Tt=_TU;_Tu=_TV;_Tv=_TW;_Tw=_TX;return __continue;}else{var _TZ=E(_TN);if(_TZ==49){var _TY=_Tz+1|0,_TO=_TA,_TP=_TB,_TQ=_TC,_TR=_TD,_TS=_TE,_TT=_TF,_TU=_TG,_TV=_TH,_TW=_TI,_TX=_TJ;_Tl=_TL;_Tm=_TY;_Tn=_TO;_To=_TP;_Tp=_TQ;_Tq=_TR;_Tr=_TS;_Ts=_TT;_Tt=_TU;_Tu=_TV;_Tv=_TW;_Tw=_TX;return __continue;}else{return new F(function(){return _SD(new T(function(){return B(_Sz(B(_Sq(_TZ))-1|0));}),_TL,_Tz+1|0,_TA,_TB,_TC,_TD,_TE,_TF,_TG,_TH,_TI,_TJ);});}}}}})(_Tl,_Tm,_Tn,_To,_Tp,_Tq,_Tr,_Ts,_Tt,_Tu,_Tv,_Tw));if(_Tx!=__continue){return _Tx;}}},_U0=new T(function(){return B(_49("Main.hs:(173,9)-(179,120)|function castler"));}),_U1=function(_U2,_U3,_U4,_U5,_U6,_U7,_U8,_U9,_Ua,_Ub){while(1){var _Uc=B((function(_Ud,_Ue,_Uf,_Ug,_Uh,_Ui,_Uj,_Uk,_Ul,_Um){var _Un=E(_Ud);if(!_Un._){return E(_5Q);}else{var _Uo=_Un.b;switch(E(_Un.a)){case 32:return {_:0,a:_Ue,b:_Uf,c:_Ug,d:_Uh,e:_Ui,f:_Uj,g:_Uk,h:_Ul,i:_Um};case 45:return {_:0,a:_Ue,b:_Uf,c:_Ug,d:_Uh,e:_Ui,f:_Uj,g:_Uk,h:_Ul,i:_Um};case 75:var _Up=_Ue,_Uq=_Uf,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul,_Uw=_Um;_U2=_Uo;_U3=_Up;_U4=_Uq;_U5=new T(function(){return B(_5B(0,_5J,_Ug));});_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;_Ub=_Uw;return __continue;case 81:var _Up=_Ue,_Uq=_Uf,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul,_Uw=_Um;_U2=_Uo;_U3=_Up;_U4=_Uq;_U5=new T(function(){return B(_5B(1,_5J,_Ug));});_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;_Ub=_Uw;return __continue;case 107:var _Up=_Ue,_Uq=_Uf,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul,_Uw=_Um;_U2=_Uo;_U3=_Up;_U4=_Uq;_U5=new T(function(){return B(_5B(2,_5J,_Ug));});_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;_Ub=_Uw;return __continue;case 113:var _Up=_Ue,_Uq=_Uf,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul,_Uw=_Um;_U2=_Uo;_U3=_Up;_U4=_Uq;_U5=new T(function(){return B(_5B(3,_5J,_Ug));});_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;_Ub=_Uw;return __continue;default:return E(_U0);}}})(_U2,_U3,_U4,_U5,_U6,_U7,_U8,_U9,_Ua,_Ub));if(_Uc!=__continue){return _Uc;}}},_Ux=function(_Uy){while(1){var _Uz=E(_Uy);if(!_Uz._){return E(_5Q);}else{var _UA=_Uz.b;if(E(_Uz.a)==32){return E(_UA);}else{_Uy=_UA;continue;}}}},_UB=new T(function(){return B(_49("Main.hs:(162,49)-(170,101)|case"));}),_UC=new T2(1,_5L,_2P),_UD=new T2(1,_5L,_UC),_UE=new T2(1,_5L,_UD),_UF=new T2(1,_5L,_UE),_UG=function(_UH){var _UI=B(_Ux(_UH)),_UJ=B(_Ux(_UI)),_UK=B(_Ux(_UJ));if(!_UK._){return E(_5Q);}else{var _UL=_UK.b,_UM=B(_T7(_UH,1,8,_2P,_5L,_UF,_QB,_8R,_8S,_8L,_8L,_5K)),_UN=B(_U1(_UJ,_UM.a,new T(function(){var _UO=E(_UI);if(!_UO._){return E(_5Q);}else{if(E(_UO.a)==119){return true;}else{return false;}}}),_UM.c,_UM.d,_UM.e,_UM.f,_UM.g,_UM.h,_UM.i)),_UP=_UN.a,_UQ=_UN.b,_UR=_UN.c,_US=_UN.d,_UT=_UN.e,_UU=_UN.h,_UV=_UN.i;switch(E(_UK.a)){case 45:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,_UN.f,_UU,_UV);});break;case 97:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_90,new T(function(){var _UW=E(_UL);if(!_UW._){return E(_5Q);}else{return B(_Sq(E(_UW.a)));}})),_UU,_UV);});break;case 98:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_8M,new T(function(){var _UX=E(_UL);if(!_UX._){return E(_5Q);}else{return B(_Sq(E(_UX.a)));}})),_UU,_UV);});break;case 99:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_8N,new T(function(){var _UY=E(_UL);if(!_UY._){return E(_5Q);}else{return B(_Sq(E(_UY.a)));}})),_UU,_UV);});break;case 100:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_8O,new T(function(){var _UZ=E(_UL);if(!_UZ._){return E(_5Q);}else{return B(_Sq(E(_UZ.a)));}})),_UU,_UV);});break;case 101:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_8P,new T(function(){var _V0=E(_UL);if(!_V0._){return E(_5Q);}else{return B(_Sq(E(_V0.a)));}})),_UU,_UV);});break;case 102:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_8Q,new T(function(){var _V1=E(_UL);if(!_V1._){return E(_5Q);}else{return B(_Sq(E(_V1.a)));}})),_UU,_UV);});break;case 103:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_94,new T(function(){var _V2=E(_UL);if(!_V2._){return E(_5Q);}else{return B(_Sq(E(_V2.a)));}})),_UU,_UV);});break;case 104:return new F(function(){return _8e(_UP,_UQ,_UR,_US,_UT,new T2(0,_9c,new T(function(){var _V3=E(_UL);if(!_V3._){return E(_5Q);}else{return B(_Sq(E(_V3.a)));}})),_UU,_UV);});break;default:return E(_UB);}}},_V4=new T(function(){return B(unCStr("(Array.!): undefined array element"));}),_V5=new T(function(){return B(err(_V4));}),_V6=new T(function(){return B(unCStr("Error in array index"));}),_V7=new T(function(){return B(err(_V6));}),_V8=new T2(0,_90,_90),_V9=new T2(0,_9c,_9c),_Va=95,_Vb=new T(function(){return B(_9m(1,8));}),_Vc=function(_Vd){var _Ve=B(A1(_Vd,_));return E(_Ve);},_Vf=function(_Vg){var _Vh=function(_){var _Vi=newArr(64,_V5),_Vj=_Vi,_Vk=function(_Vl,_){while(1){var _Vm=E(_Vl);if(!_Vm._){return new T4(0,E(_V8),E(_V9),64,_Vj);}else{var _Vn=E(_Vm.a),_Vo=E(_Vn.a),_Vp=E(_Vo.a);if(1>_Vp){return E(_V7);}else{if(_Vp>8){return E(_V7);}else{var _Vq=E(_Vo.b);if(1>_Vq){return E(_V7);}else{if(_Vq>8){return E(_V7);}else{var _=_Vj[(imul(_Vp-1|0,8)|0)+(_Vq-1|0)|0]=_Vn.b;_Vl=_Vm.b;continue;}}}}}}},_Vr=function(_Vs,_){while(1){var _Vt=B((function(_Vu,_){var _Vv=E(_Vb);if(!_Vv._){var _Vw=E(_Vu);if(_Vw==8){return new F(function(){return _Vk(_Vg,_);});}else{_Vs=_Vw+1|0;return __continue;}}else{if(1>_Vu){return E(_V7);}else{if(_Vu>8){return E(_V7);}else{var _Vx=E(_Vv.a);if(1>_Vx){return E(_V7);}else{if(_Vx>8){return E(_V7);}else{var _=_Vj[(imul(_Vu-1|0,8)|0)+(_Vx-1|0)|0]=_Va,_Vy=function(_Vz,_){while(1){var _VA=E(_Vz);if(!_VA._){var _VB=E(_Vu);if(_VB==8){return new F(function(){return _Vk(_Vg,_);});}else{return new F(function(){return _Vr(_VB+1|0,_);});}}else{var _VC=E(_VA.a);if(1>_VC){return E(_V7);}else{if(_VC>8){return E(_V7);}else{var _=_Vj[(imul(_Vu-1|0,8)|0)+(_VC-1|0)|0]=_Va;_Vz=_VA.b;continue;}}}}};return new F(function(){return _Vy(_Vv.b,_);});}}}}}})(_Vs,_));if(_Vt!=__continue){return _Vt;}}};return new F(function(){return _Vr(1,_);});};return new F(function(){return _Vc(_Vh);});},_VD=new T(function(){return B(unCStr("Maybe.fromJust: Nothing"));}),_VE=new T(function(){return B(err(_VD));}),_VF=new T(function(){return B(unCStr("last"));}),_VG=new T(function(){return B(_5N(_VF));}),_VH=new T(function(){return B(_9m(0,63));}),_VI=new T(function(){return B(_49("Main.hs:(142,49)-(150,265)|case"));}),_VJ=new T(function(){return B(_49("Main.hs:(142,74)-(145,106)|case"));}),_VK=function(_VL,_VM){var _VN=_VL%_VM;if(_VL<=0){if(_VL>=0){return E(_VN);}else{if(_VM<=0){return E(_VN);}else{var _VO=E(_VN);return (_VO==0)?0:_VO+_VM|0;}}}else{if(_VM>=0){if(_VL>=0){return E(_VN);}else{if(_VM<=0){return E(_VN);}else{var _VP=E(_VN);return (_VP==0)?0:_VP+_VM|0;}}}else{var _VQ=E(_VN);return (_VQ==0)?0:_VQ+_VM|0;}}},_VR=function(_VS,_VT){var _VU=new T(function(){var _VV=B(_UG(_VS)),_VW=B(_QC(E(_VT),_VV.a,_VV.b,_VV.c,_VV.d,_VV.e,_VV.f,_VV.g,_VV.i));return {_:0,a:_VW.a,b:_VW.b,c:_VW.c,d:_VW.d,e:_VW.e,f:_VW.f,g:_VW.g,h:_VW.h,i:_VW.i};}),_VX=new T(function(){var _VY=E(E(_VU).i);if(!_VY._){return E(_VE);}else{var _VZ=B(_Vf(E(_VY.a).a)),_W0=_VZ.d,_W1=E(_VZ.a),_W2=E(_VZ.b),_W3=E(_W1.a),_W4=E(_W2.a);if(_W3<=_W4){var _W5=E(_W1.b),_W6=E(_W2.b),_W7=new T(function(){if(_W3!=_W4){var _W8=function(_W9){var _Wa=new T(function(){if(_W9!=_W4){return B(_W8(_W9+1|0));}else{return __Z;}});if(_W5<=_W6){var _Wb=new T(function(){return _W3<=_W9;}),_Wc=new T(function(){return _W9<=_W4;}),_Wd=function(_We){return new T2(1,new T2(0,new T2(0,_W9,_We),new T(function(){if(!E(_Wb)){return E(_V7);}else{if(!E(_Wc)){return E(_V7);}else{if(_W5>_We){return E(_V7);}else{if(_We>_W6){return E(_V7);}else{return E(_W0[(imul(_W9-_W3|0,(_W6-_W5|0)+1|0)|0)+(_We-_W5|0)|0]);}}}}})),new T(function(){if(_We!=_W6){return B(_Wd(_We+1|0));}else{return E(_Wa);}}));};return new F(function(){return _Wd(_W5);});}else{return E(_Wa);}};return B(_W8(_W3+1|0));}else{return __Z;}});if(_W5<=_W6){var _Wf=new T(function(){return _W3<=_W4;}),_Wg=function(_Wh){return new T2(1,new T2(0,new T2(0,_W3,_Wh),new T(function(){if(!E(_Wf)){return E(_V7);}else{if(_W5>_Wh){return E(_V7);}else{if(_Wh>_W6){return E(_V7);}else{return E(_W0[_Wh-_W5|0]);}}}})),new T(function(){if(_Wh!=_W6){return B(_Wg(_Wh+1|0));}else{return E(_W7);}}));};return B(_Wg(_W5));}else{return E(_W7);}}else{return __Z;}}}),_Wi=new T(function(){var _Wj=B(_Vf(E(_VU).a)),_Wk=_Wj.d,_Wl=E(_Wj.a),_Wm=E(_Wj.b),_Wn=E(_Wl.a),_Wo=E(_Wm.a);if(_Wn<=_Wo){var _Wp=E(_Wl.b),_Wq=E(_Wm.b),_Wr=new T(function(){if(_Wn!=_Wo){var _Ws=function(_Wt){var _Wu=new T(function(){if(_Wt!=_Wo){return B(_Ws(_Wt+1|0));}else{return __Z;}});if(_Wp<=_Wq){var _Wv=new T(function(){return _Wn<=_Wt;}),_Ww=new T(function(){return _Wt<=_Wo;}),_Wx=function(_Wy){return new T2(1,new T2(0,new T2(0,_Wt,_Wy),new T(function(){if(!E(_Wv)){return E(_V7);}else{if(!E(_Ww)){return E(_V7);}else{if(_Wp>_Wy){return E(_V7);}else{if(_Wy>_Wq){return E(_V7);}else{return E(_Wk[(imul(_Wt-_Wn|0,(_Wq-_Wp|0)+1|0)|0)+(_Wy-_Wp|0)|0]);}}}}})),new T(function(){if(_Wy!=_Wq){return B(_Wx(_Wy+1|0));}else{return E(_Wu);}}));};return new F(function(){return _Wx(_Wp);});}else{return E(_Wu);}};return B(_Ws(_Wn+1|0));}else{return __Z;}});if(_Wp<=_Wq){var _Wz=new T(function(){return _Wn<=_Wo;}),_WA=function(_WB){return new T2(1,new T2(0,new T2(0,_Wn,_WB),new T(function(){if(!E(_Wz)){return E(_V7);}else{if(_Wp>_WB){return E(_V7);}else{if(_WB>_Wq){return E(_V7);}else{return E(_Wk[_WB-_Wp|0]);}}}})),new T(function(){if(_WB!=_Wq){return B(_WA(_WB+1|0));}else{return E(_Wr);}}));};return B(_WA(_Wp));}else{return E(_Wr);}}else{return __Z;}}),_WC=B(_5R(function(_WD){var _WE=E(_WD),_WF=B(_q(_Wi,_WE)),_WG=B(_q(_VX,_WE)),_WH=E(_WF.a),_WI=E(_WG.a);return (E(_WH.a)!=E(_WI.a))?true:(E(_WH.b)!=E(_WI.b))?true:(E(_WF.b)!=E(_WG.b))?true:false;},_VH));switch(B(_QO(_WC,0))){case 2:var _WJ=E(_WC);return (_WJ._==0)?E(_5Q):(E(B(_q(_VX,E(_WJ.a))).b)==95)?new T4(0,new T(function(){return B(_VK(B(_q(_WJ,0)),8))+1|0;}),new T(function(){return quot(B(_q(_WJ,0)),8)+1|0;}),new T(function(){return B(_VK(B(_q(_WJ,1)),8))+1|0;}),new T(function(){return quot(B(_q(_WJ,1)),8)+1|0;})):new T4(0,new T(function(){return B(_VK(B(_q(_WJ,1)),8))+1|0;}),new T(function(){return quot(B(_q(_WJ,1)),8)+1|0;}),new T(function(){return B(_VK(B(_q(_WJ,0)),8))+1|0;}),new T(function(){return quot(B(_q(_WJ,0)),8)+1|0;}));case 3:var _WK=E(_WC);if(!_WK._){return E(_5Q);}else{var _WL=E(_WK.a),_WM=B(_VK(_WL,8));if(_WM>3){return (B(_VK(B(_6(_WL,_WK.b,_VG)),8))==5)?new T4(0,_WM+1|0,quot(_WL,8)+1|0,_WM+2|0,quot(_WL,8)+2|0):new T4(0,_WM+1|0,quot(_WL,8)+2|0,_WM+2|0,quot(_WL,8)+1|0);}else{var _WN=E(_WM);return (_WN==3)?new T4(0,4,quot(_WL,8)+1|0,3,quot(_WL,8)+2|0):new T4(0,_WN+2|0,quot(_WL,8)+2|0,_WN+1|0,quot(_WL,8)+1|0);}}break;case 4:var _WO=E(_WC);if(!_WO._){return E(_5Q);}else{switch(E(_WO.a)){case 0:return new T4(0,_90,_8P,_90,_8N);case 7:return new T4(0,_9c,_8P,_9c,_8N);case 32:return new T4(0,_90,_8P,_90,_94);case 39:return new T4(0,_9c,_8P,_9c,_94);default:return E(_VJ);}}break;default:return E(_VI);}},_WP=new T(function(){return eval("(function(s,f){Haste[s] = f;})");}),_WQ=function(_WR){return E(_WR);},_WS=function(_){var _WT=function(_WU){var _WV=new T(function(){var _WW=String(E(_WU));return fromJSStr(_WW);}),_WX=function(_WY){var _WZ=B(_VR(_WV,new T(function(){var _X0=Number(E(_WY));return jsTrunc(_X0);},1)));return new F(function(){return __lst2arr(B(_aE(_WQ,new T2(1,_WZ.a,new T2(1,_WZ.b,new T2(1,_WZ.c,new T2(1,_WZ.d,_2P)))))));});};return E(_WX);},_X1=__createJSFunc(2,E(_WT)),_X2=__app2(E(_WP),"mover",_X1);return new F(function(){return _1(_);});},_X3=function(_){return new F(function(){return _WS(_);});};
var hasteMain = function() {B(A(_X3, [0]));};window.onload = hasteMain;