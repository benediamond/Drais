"use strict";
// This object will hold all exports.
var Haste = {};
if(typeof window === 'undefined') window = global;

/* Constructor functions for small ADTs. */
function T0(t){this._=t;}
function T1(t,a){this._=t;this.a=a;}
function T2(t,a,b){this._=t;this.a=a;this.b=b;}
function T3(t,a,b,c){this._=t;this.a=a;this.b=b;this.c=c;}
function T4(t,a,b,c,d){this._=t;this.a=a;this.b=b;this.c=c;this.d=d;}
function T5(t,a,b,c,d,e){this._=t;this.a=a;this.b=b;this.c=c;this.d=d;this.e=e;}
function T6(t,a,b,c,d,e,f){this._=t;this.a=a;this.b=b;this.c=c;this.d=d;this.e=e;this.f=f;}

/* Thunk
   Creates a thunk representing the given closure.
   If the non-updatable flag is undefined, the thunk is updatable.
*/
function T(f, nu) {
    this.f = f;
    if(nu === undefined) {
        this.x = __updatable;
    }
}

/* Hint to optimizer that an imported symbol is strict. */
function __strict(x) {return x}

// A tailcall.
function F(f) {
    this.f = f;
}

// A partially applied function. Invariant: members are never thunks.
function PAP(f, args) {
    this.f = f;
    this.args = args;
    this.arity = f.length - args.length;
}

// "Zero" object; used to avoid creating a whole bunch of new objects
// in the extremely common case of a nil-like data constructor.
var __Z = new T0(0);

// Special object used for blackholing.
var __blackhole = {};

// Used to indicate that an object is updatable.
var __updatable = {};

// Indicates that a closure-creating tail loop isn't done.
var __continue = {};

/* Generic apply.
   Applies a function *or* a partial application object to a list of arguments.
   See https://ghc.haskell.org/trac/ghc/wiki/Commentary/Rts/HaskellExecution/FunctionCalls
   for more information.
*/
function A(f, args) {
    while(true) {
        f = E(f);
        if(f instanceof Function) {
            if(args.length === f.length) {
                return f.apply(null, args);
            } else if(args.length < f.length) {
                return new PAP(f, args);
            } else {
                var f2 = f.apply(null, args.slice(0, f.length));
                args = args.slice(f.length);
                f = B(f2);
            }
        } else if(f instanceof PAP) {
            if(args.length === f.arity) {
                return f.f.apply(null, f.args.concat(args));
            } else if(args.length < f.arity) {
                return new PAP(f.f, f.args.concat(args));
            } else {
                var f2 = f.f.apply(null, f.args.concat(args.slice(0, f.arity)));
                args = args.slice(f.arity);
                f = B(f2);
            }
        } else {
            return f;
        }
    }
}

function A1(f, x) {
    f = E(f);
    if(f instanceof Function) {
        return f.length === 1 ? f(x) : new PAP(f, [x]);
    } else if(f instanceof PAP) {
        return f.arity === 1 ? f.f.apply(null, f.args.concat([x]))
                             : new PAP(f.f, f.args.concat([x]));
    } else {
        return f;
    }
}

function A2(f, x, y) {
    f = E(f);
    if(f instanceof Function) {
        switch(f.length) {
        case 2:  return f(x, y);
        case 1:  return A1(B(f(x)), y);
        default: return new PAP(f, [x,y]);
        }
    } else if(f instanceof PAP) {
        switch(f.arity) {
        case 2:  return f.f.apply(null, f.args.concat([x,y]));
        case 1:  return A1(B(f.f.apply(null, f.args.concat([x]))), y);
        default: return new PAP(f.f, f.args.concat([x,y]));
        }
    } else {
        return f;
    }
}

function A3(f, x, y, z) {
    f = E(f);
    if(f instanceof Function) {
        switch(f.length) {
        case 3:  return f(x, y, z);
        case 2:  return A1(B(f(x, y)), z);
        case 1:  return A2(B(f(x)), y, z);
        default: return new PAP(f, [x,y,z]);
        }
    } else if(f instanceof PAP) {
        switch(f.arity) {
        case 3:  return f.f.apply(null, f.args.concat([x,y,z]));
        case 2:  return A1(B(f.f.apply(null, f.args.concat([x,y]))), z);
        case 1:  return A2(B(f.f.apply(null, f.args.concat([x]))), y, z);
        default: return new PAP(f.f, f.args.concat([x,y,z]));
        }
    } else {
        return f;
    }
}

/* Eval
   Evaluate the given thunk t into head normal form.
   If the "thunk" we get isn't actually a thunk, just return it.
*/
function E(t) {
    if(t instanceof T) {
        if(t.f !== __blackhole) {
            if(t.x === __updatable) {
                var f = t.f;
                t.f = __blackhole;
                t.x = f();
            } else {
                return t.f();
            }
        }
        if(t.x === __updatable) {
            throw 'Infinite loop!';
        } else {
            return t.x;
        }
    } else {
        return t;
    }
}

/* Tail call chain counter. */
var C = 0, Cs = [];

/* Bounce
   Bounce on a trampoline for as long as we get a function back.
*/
function B(f) {
    Cs.push(C);
    while(f instanceof F) {
        var fun = f.f;
        f.f = __blackhole;
        C = 0;
        f = fun();
    }
    C = Cs.pop();
    return f;
}

// Export Haste, A, B and E. Haste because we need to preserve exports, A, B
// and E because they're handy for Haste.Foreign.
if(!window) {
    var window = {};
}
window['Haste'] = Haste;
window['A'] = A;
window['E'] = E;
window['B'] = B;


/* Throw an error.
   We need to be able to use throw as an exception so we wrap it in a function.
*/
function die(err) {
    throw E(err);
}

function quot(a, b) {
    return (a-a%b)/b;
}

function quotRemI(a, b) {
    return {_:0, a:(a-a%b)/b, b:a%b};
}

// 32 bit integer multiplication, with correct overflow behavior
// note that |0 or >>>0 needs to be applied to the result, for int and word
// respectively.
if(Math.imul) {
    var imul = Math.imul;
} else {
    var imul = function(a, b) {
        // ignore high a * high a as the result will always be truncated
        var lows = (a & 0xffff) * (b & 0xffff); // low a * low b
        var aB = (a & 0xffff) * (b & 0xffff0000); // low a * high b
        var bA = (a & 0xffff0000) * (b & 0xffff); // low b * high a
        return lows + aB + bA; // sum will not exceed 52 bits, so it's safe
    }
}

function addC(a, b) {
    var x = a+b;
    return {_:0, a:x & 0xffffffff, b:x > 0x7fffffff};
}

function subC(a, b) {
    var x = a-b;
    return {_:0, a:x & 0xffffffff, b:x < -2147483648};
}

function sinh (arg) {
    return (Math.exp(arg) - Math.exp(-arg)) / 2;
}

function tanh (arg) {
    return (Math.exp(arg) - Math.exp(-arg)) / (Math.exp(arg) + Math.exp(-arg));
}

function cosh (arg) {
    return (Math.exp(arg) + Math.exp(-arg)) / 2;
}

function isFloatFinite(x) {
    return isFinite(x);
}

function isDoubleFinite(x) {
    return isFinite(x);
}

function err(str) {
    die(toJSStr(str));
}

/* unpackCString#
   NOTE: update constructor tags if the code generator starts munging them.
*/
function unCStr(str) {return unAppCStr(str, __Z);}

function unFoldrCStr(str, f, z) {
    var acc = z;
    for(var i = str.length-1; i >= 0; --i) {
        acc = B(A(f, [str.charCodeAt(i), acc]));
    }
    return acc;
}

function unAppCStr(str, chrs) {
    var i = arguments[2] ? arguments[2] : 0;
    if(i >= str.length) {
        return E(chrs);
    } else {
        return {_:1,a:str.charCodeAt(i),b:new T(function() {
            return unAppCStr(str,chrs,i+1);
        })};
    }
}

function charCodeAt(str, i) {return str.charCodeAt(i);}

function fromJSStr(str) {
    return unCStr(E(str));
}

function toJSStr(hsstr) {
    var s = '';
    for(var str = E(hsstr); str._ == 1; str = E(str.b)) {
        s += String.fromCharCode(E(str.a));
    }
    return s;
}

// newMutVar
function nMV(val) {
    return ({x: val});
}

// readMutVar
function rMV(mv) {
    return mv.x;
}

// writeMutVar
function wMV(mv, val) {
    mv.x = val;
}

// atomicModifyMutVar
function mMV(mv, f) {
    var x = B(A(f, [mv.x]));
    mv.x = x.a;
    return x.b;
}

function localeEncoding() {
    var le = newByteArr(5);
    le['v']['i8'][0] = 'U'.charCodeAt(0);
    le['v']['i8'][1] = 'T'.charCodeAt(0);
    le['v']['i8'][2] = 'F'.charCodeAt(0);
    le['v']['i8'][3] = '-'.charCodeAt(0);
    le['v']['i8'][4] = '8'.charCodeAt(0);
    return le;
}

var isDoubleNaN = isNaN;
var isFloatNaN = isNaN;

function isDoubleInfinite(d) {
    return (d === Infinity);
}
var isFloatInfinite = isDoubleInfinite;

function isDoubleNegativeZero(x) {
    return (x===0 && (1/x)===-Infinity);
}
var isFloatNegativeZero = isDoubleNegativeZero;

function strEq(a, b) {
    return a == b;
}

function strOrd(a, b) {
    if(a < b) {
        return 0;
    } else if(a == b) {
        return 1;
    }
    return 2;
}

/* Convert a JS exception into a Haskell JSException */
function __hsException(e) {
  e = e.toString();
  var x = new Long(2904464383, 3929545892, true);
  var y = new Long(3027541338, 3270546716, true);
  var t = new T5(0, x, y
                  , new T5(0, x, y
                            , unCStr("haste-prim")
                            , unCStr("Haste.Prim.Foreign")
                            , unCStr("JSException")), __Z, __Z);
  var show = function(x) {return unCStr(E(x).a);}
  var dispEx = function(x) {return unCStr("JavaScript exception: " + E(x).a);}
  var showList = function(_, s) {return unAppCStr(e, s);}
  var showsPrec = function(_, _p, s) {return unAppCStr(e, s);}
  var showDict = new T3(0, showsPrec, show, showList);
  var self;
  var fromEx = function(_) {return new T1(1, self);}
  var dict = new T5(0, t, showDict, null /* toException */, fromEx, dispEx);
  self = new T2(0, dict, new T1(0, e));
  return self;
}

function jsCatch(act, handler) {
    try {
        return B(A(act,[0]));
    } catch(e) {
        if(typeof e._ === 'undefined') {
            e = __hsException(e);
        }
        return B(A(handler,[e, 0]));
    }
}

/* Haste represents constructors internally using 1 for the first constructor,
   2 for the second, etc.
   However, dataToTag should use 0, 1, 2, etc. Also, booleans might be unboxed.
 */
function dataToTag(x) {
    if(x instanceof Object) {
        return x._;
    } else {
        return x;
    }
}

function __word_encodeDouble(d, e) {
    return d * Math.pow(2,e);
}

var __word_encodeFloat = __word_encodeDouble;
var jsRound = Math.round, rintDouble = jsRound, rintFloat = jsRound;
var jsTrunc = Math.trunc ? Math.trunc : function(x) {
    return x < 0 ? Math.ceil(x) : Math.floor(x);
};
function jsRoundW(n) {
    return Math.abs(jsTrunc(n));
}
var realWorld = undefined;
if(typeof _ == 'undefined') {
    var _ = undefined;
}

function popCnt64(i) {
    return popCnt(i.low) + popCnt(i.high);
}

function popCnt(i) {
    i = i - ((i >> 1) & 0x55555555);
    i = (i & 0x33333333) + ((i >> 2) & 0x33333333);
    return (((i + (i >> 4)) & 0x0F0F0F0F) * 0x01010101) >> 24;
}

function __clz(bits, x) {
    x &= (Math.pow(2, bits)-1);
    if(x === 0) {
        return bits;
    } else {
        return bits - (1 + Math.floor(Math.log(x)/Math.LN2));
    }
}

// TODO: can probably be done much faster with arithmetic tricks like __clz
function __ctz(bits, x) {
    var y = 1;
    x &= (Math.pow(2, bits)-1);
    if(x === 0) {
        return bits;
    }
    for(var i = 0; i < bits; ++i) {
        if(y & x) {
            return i;
        } else {
            y <<= 1;
        }
    }
    return 0;
}

// Scratch space for byte arrays.
var rts_scratchBuf = new ArrayBuffer(8);
var rts_scratchW32 = new Uint32Array(rts_scratchBuf);
var rts_scratchFloat = new Float32Array(rts_scratchBuf);
var rts_scratchDouble = new Float64Array(rts_scratchBuf);

function decodeFloat(x) {
    if(x === 0) {
        return __decodedZeroF;
    }
    rts_scratchFloat[0] = x;
    var sign = x < 0 ? -1 : 1;
    var exp = ((rts_scratchW32[0] >> 23) & 0xff) - 150;
    var man = rts_scratchW32[0] & 0x7fffff;
    if(exp === 0) {
        ++exp;
    } else {
        man |= (1 << 23);
    }
    return {_:0, a:sign*man, b:exp};
}

var __decodedZero = {_:0,a:1,b:0,c:0,d:0};
var __decodedZeroF = {_:0,a:1,b:0};

function decodeDouble(x) {
    if(x === 0) {
        // GHC 7.10+ *really* doesn't like 0 to be represented as anything
        // but zeroes all the way.
        return __decodedZero;
    }
    rts_scratchDouble[0] = x;
    var sign = x < 0 ? -1 : 1;
    var manHigh = rts_scratchW32[1] & 0xfffff;
    var manLow = rts_scratchW32[0];
    var exp = ((rts_scratchW32[1] >> 20) & 0x7ff) - 1075;
    if(exp === 0) {
        ++exp;
    } else {
        manHigh |= (1 << 20);
    }
    return {_:0, a:sign, b:manHigh, c:manLow, d:exp};
}

function isNull(obj) {
    return obj === null;
}

function jsRead(str) {
    return Number(str);
}

function jsShowI(val) {return val.toString();}
function jsShow(val) {
    var ret = val.toString();
    return val == Math.round(val) ? ret + '.0' : ret;
}

window['jsGetMouseCoords'] = function jsGetMouseCoords(e) {
    var posx = 0;
    var posy = 0;
    if (!e) var e = window.event;
    if (e.pageX || e.pageY) 	{
	posx = e.pageX;
	posy = e.pageY;
    }
    else if (e.clientX || e.clientY) 	{
	posx = e.clientX + document.body.scrollLeft
	    + document.documentElement.scrollLeft;
	posy = e.clientY + document.body.scrollTop
	    + document.documentElement.scrollTop;
    }
    return [posx - (e.currentTarget.offsetLeft || 0),
	    posy - (e.currentTarget.offsetTop || 0)];
}

var jsRand = Math.random;

// Concatenate a Haskell list of JS strings
function jsCat(strs, sep) {
    var arr = [];
    strs = E(strs);
    while(strs._) {
        strs = E(strs);
        arr.push(E(strs.a));
        strs = E(strs.b);
    }
    return arr.join(sep);
}

// Parse a JSON message into a Haste.JSON.JSON value.
// As this pokes around inside Haskell values, it'll need to be updated if:
// * Haste.JSON.JSON changes;
// * E() starts to choke on non-thunks;
// * data constructor code generation changes; or
// * Just and Nothing change tags.
function jsParseJSON(str) {
    try {
        var js = JSON.parse(str);
        var hs = toHS(js);
    } catch(_) {
        return __Z;
    }
    return {_:1,a:hs};
}

function toHS(obj) {
    switch(typeof obj) {
    case 'number':
        return {_:0, a:jsRead(obj)};
    case 'string':
        return {_:1, a:obj};
    case 'boolean':
        return {_:2, a:obj}; // Booleans are special wrt constructor tags!
    case 'object':
        if(obj instanceof Array) {
            return {_:3, a:arr2lst_json(obj, 0)};
        } else if (obj == null) {
            return {_:5};
        } else {
            // Object type but not array - it's a dictionary.
            // The RFC doesn't say anything about the ordering of keys, but
            // considering that lots of people rely on keys being "in order" as
            // defined by "the same way someone put them in at the other end,"
            // it's probably a good idea to put some cycles into meeting their
            // misguided expectations.
            var ks = [];
            for(var k in obj) {
                ks.unshift(k);
            }
            var xs = [0];
            for(var i = 0; i < ks.length; i++) {
                xs = {_:1, a:{_:0, a:ks[i], b:toHS(obj[ks[i]])}, b:xs};
            }
            return {_:4, a:xs};
        }
    }
}

function arr2lst_json(arr, elem) {
    if(elem >= arr.length) {
        return __Z;
    }
    return {_:1, a:toHS(arr[elem]), b:new T(function() {return arr2lst_json(arr,elem+1);}),c:true}
}

/* gettimeofday(2) */
function gettimeofday(tv, _tz) {
    var t = new Date().getTime();
    writeOffAddr("i32", 4, tv, 0, (t/1000)|0);
    writeOffAddr("i32", 4, tv, 1, ((t%1000)*1000)|0);
    return 0;
}

// Create a little endian ArrayBuffer representation of something.
function toABHost(v, n, x) {
    var a = new ArrayBuffer(n);
    new window[v](a)[0] = x;
    return a;
}

function toABSwap(v, n, x) {
    var a = new ArrayBuffer(n);
    new window[v](a)[0] = x;
    var bs = new Uint8Array(a);
    for(var i = 0, j = n-1; i < j; ++i, --j) {
        var tmp = bs[i];
        bs[i] = bs[j];
        bs[j] = tmp;
    }
    return a;
}

window['toABle'] = toABHost;
window['toABbe'] = toABSwap;

// Swap byte order if host is not little endian.
var buffer = new ArrayBuffer(2);
new DataView(buffer).setInt16(0, 256, true);
if(new Int16Array(buffer)[0] !== 256) {
    window['toABle'] = toABSwap;
    window['toABbe'] = toABHost;
}

/* bn.js by Fedor Indutny, see doc/LICENSE.bn for license */
var __bn = {};
(function (module, exports) {
'use strict';

function BN(number, base, endian) {
  // May be `new BN(bn)` ?
  if (number !== null &&
      typeof number === 'object' &&
      Array.isArray(number.words)) {
    return number;
  }

  this.negative = 0;
  this.words = null;
  this.length = 0;

  if (base === 'le' || base === 'be') {
    endian = base;
    base = 10;
  }

  if (number !== null)
    this._init(number || 0, base || 10, endian || 'be');
}
if (typeof module === 'object')
  module.exports = BN;
else
  exports.BN = BN;

BN.BN = BN;
BN.wordSize = 26;

BN.max = function max(left, right) {
  if (left.cmp(right) > 0)
    return left;
  else
    return right;
};

BN.min = function min(left, right) {
  if (left.cmp(right) < 0)
    return left;
  else
    return right;
};

BN.prototype._init = function init(number, base, endian) {
  if (typeof number === 'number') {
    return this._initNumber(number, base, endian);
  } else if (typeof number === 'object') {
    return this._initArray(number, base, endian);
  }
  if (base === 'hex')
    base = 16;

  number = number.toString().replace(/\s+/g, '');
  var start = 0;
  if (number[0] === '-')
    start++;

  if (base === 16)
    this._parseHex(number, start);
  else
    this._parseBase(number, base, start);

  if (number[0] === '-')
    this.negative = 1;

  this.strip();

  if (endian !== 'le')
    return;

  this._initArray(this.toArray(), base, endian);
};

BN.prototype._initNumber = function _initNumber(number, base, endian) {
  if (number < 0) {
    this.negative = 1;
    number = -number;
  }
  if (number < 0x4000000) {
    this.words = [ number & 0x3ffffff ];
    this.length = 1;
  } else if (number < 0x10000000000000) {
    this.words = [
      number & 0x3ffffff,
      (number / 0x4000000) & 0x3ffffff
    ];
    this.length = 2;
  } else {
    this.words = [
      number & 0x3ffffff,
      (number / 0x4000000) & 0x3ffffff,
      1
    ];
    this.length = 3;
  }

  if (endian !== 'le')
    return;

  // Reverse the bytes
  this._initArray(this.toArray(), base, endian);
};

BN.prototype._initArray = function _initArray(number, base, endian) {
  if (number.length <= 0) {
    this.words = [ 0 ];
    this.length = 1;
    return this;
  }

  this.length = Math.ceil(number.length / 3);
  this.words = new Array(this.length);
  for (var i = 0; i < this.length; i++)
    this.words[i] = 0;

  var off = 0;
  if (endian === 'be') {
    for (var i = number.length - 1, j = 0; i >= 0; i -= 3) {
      var w = number[i] | (number[i - 1] << 8) | (number[i - 2] << 16);
      this.words[j] |= (w << off) & 0x3ffffff;
      this.words[j + 1] = (w >>> (26 - off)) & 0x3ffffff;
      off += 24;
      if (off >= 26) {
        off -= 26;
        j++;
      }
    }
  } else if (endian === 'le') {
    for (var i = 0, j = 0; i < number.length; i += 3) {
      var w = number[i] | (number[i + 1] << 8) | (number[i + 2] << 16);
      this.words[j] |= (w << off) & 0x3ffffff;
      this.words[j + 1] = (w >>> (26 - off)) & 0x3ffffff;
      off += 24;
      if (off >= 26) {
        off -= 26;
        j++;
      }
    }
  }
  return this.strip();
};

function parseHex(str, start, end) {
  var r = 0;
  var len = Math.min(str.length, end);
  for (var i = start; i < len; i++) {
    var c = str.charCodeAt(i) - 48;

    r <<= 4;

    // 'a' - 'f'
    if (c >= 49 && c <= 54)
      r |= c - 49 + 0xa;

    // 'A' - 'F'
    else if (c >= 17 && c <= 22)
      r |= c - 17 + 0xa;

    // '0' - '9'
    else
      r |= c & 0xf;
  }
  return r;
}

BN.prototype._parseHex = function _parseHex(number, start) {
  // Create possibly bigger array to ensure that it fits the number
  this.length = Math.ceil((number.length - start) / 6);
  this.words = new Array(this.length);
  for (var i = 0; i < this.length; i++)
    this.words[i] = 0;

  // Scan 24-bit chunks and add them to the number
  var off = 0;
  for (var i = number.length - 6, j = 0; i >= start; i -= 6) {
    var w = parseHex(number, i, i + 6);
    this.words[j] |= (w << off) & 0x3ffffff;
    this.words[j + 1] |= w >>> (26 - off) & 0x3fffff;
    off += 24;
    if (off >= 26) {
      off -= 26;
      j++;
    }
  }
  if (i + 6 !== start) {
    var w = parseHex(number, start, i + 6);
    this.words[j] |= (w << off) & 0x3ffffff;
    this.words[j + 1] |= w >>> (26 - off) & 0x3fffff;
  }
  this.strip();
};

function parseBase(str, start, end, mul) {
  var r = 0;
  var len = Math.min(str.length, end);
  for (var i = start; i < len; i++) {
    var c = str.charCodeAt(i) - 48;

    r *= mul;

    // 'a'
    if (c >= 49)
      r += c - 49 + 0xa;

    // 'A'
    else if (c >= 17)
      r += c - 17 + 0xa;

    // '0' - '9'
    else
      r += c;
  }
  return r;
}

BN.prototype._parseBase = function _parseBase(number, base, start) {
  // Initialize as zero
  this.words = [ 0 ];
  this.length = 1;

  // Find length of limb in base
  for (var limbLen = 0, limbPow = 1; limbPow <= 0x3ffffff; limbPow *= base)
    limbLen++;
  limbLen--;
  limbPow = (limbPow / base) | 0;

  var total = number.length - start;
  var mod = total % limbLen;
  var end = Math.min(total, total - mod) + start;

  var word = 0;
  for (var i = start; i < end; i += limbLen) {
    word = parseBase(number, i, i + limbLen, base);

    this.imuln(limbPow);
    if (this.words[0] + word < 0x4000000)
      this.words[0] += word;
    else
      this._iaddn(word);
  }

  if (mod !== 0) {
    var pow = 1;
    var word = parseBase(number, i, number.length, base);

    for (var i = 0; i < mod; i++)
      pow *= base;
    this.imuln(pow);
    if (this.words[0] + word < 0x4000000)
      this.words[0] += word;
    else
      this._iaddn(word);
  }
};

BN.prototype.copy = function copy(dest) {
  dest.words = new Array(this.length);
  for (var i = 0; i < this.length; i++)
    dest.words[i] = this.words[i];
  dest.length = this.length;
  dest.negative = this.negative;
};

BN.prototype.clone = function clone() {
  var r = new BN(null);
  this.copy(r);
  return r;
};

// Remove leading `0` from `this`
BN.prototype.strip = function strip() {
  while (this.length > 1 && this.words[this.length - 1] === 0)
    this.length--;
  return this._normSign();
};

BN.prototype._normSign = function _normSign() {
  // -0 = 0
  if (this.length === 1 && this.words[0] === 0)
    this.negative = 0;
  return this;
};

var zeros = [
  '',
  '0',
  '00',
  '000',
  '0000',
  '00000',
  '000000',
  '0000000',
  '00000000',
  '000000000',
  '0000000000',
  '00000000000',
  '000000000000',
  '0000000000000',
  '00000000000000',
  '000000000000000',
  '0000000000000000',
  '00000000000000000',
  '000000000000000000',
  '0000000000000000000',
  '00000000000000000000',
  '000000000000000000000',
  '0000000000000000000000',
  '00000000000000000000000',
  '000000000000000000000000',
  '0000000000000000000000000'
];

var groupSizes = [
  0, 0,
  25, 16, 12, 11, 10, 9, 8,
  8, 7, 7, 7, 7, 6, 6,
  6, 6, 6, 6, 6, 5, 5,
  5, 5, 5, 5, 5, 5, 5,
  5, 5, 5, 5, 5, 5, 5
];

var groupBases = [
  0, 0,
  33554432, 43046721, 16777216, 48828125, 60466176, 40353607, 16777216,
  43046721, 10000000, 19487171, 35831808, 62748517, 7529536, 11390625,
  16777216, 24137569, 34012224, 47045881, 64000000, 4084101, 5153632,
  6436343, 7962624, 9765625, 11881376, 14348907, 17210368, 20511149,
  24300000, 28629151, 33554432, 39135393, 45435424, 52521875, 60466176
];

BN.prototype.toString = function toString(base, padding) {
  base = base || 10;
  var padding = padding | 0 || 1;
  if (base === 16 || base === 'hex') {
    var out = '';
    var off = 0;
    var carry = 0;
    for (var i = 0; i < this.length; i++) {
      var w = this.words[i];
      var word = (((w << off) | carry) & 0xffffff).toString(16);
      carry = (w >>> (24 - off)) & 0xffffff;
      if (carry !== 0 || i !== this.length - 1)
        out = zeros[6 - word.length] + word + out;
      else
        out = word + out;
      off += 2;
      if (off >= 26) {
        off -= 26;
        i--;
      }
    }
    if (carry !== 0)
      out = carry.toString(16) + out;
    while (out.length % padding !== 0)
      out = '0' + out;
    if (this.negative !== 0)
      out = '-' + out;
    return out;
  } else if (base === (base | 0) && base >= 2 && base <= 36) {
    var groupSize = groupSizes[base];
    var groupBase = groupBases[base];
    var out = '';
    var c = this.clone();
    c.negative = 0;
    while (c.cmpn(0) !== 0) {
      var r = c.modn(groupBase).toString(base);
      c = c.idivn(groupBase);

      if (c.cmpn(0) !== 0)
        out = zeros[groupSize - r.length] + r + out;
      else
        out = r + out;
    }
    if (this.cmpn(0) === 0)
      out = '0' + out;
    while (out.length % padding !== 0)
      out = '0' + out;
    if (this.negative !== 0)
      out = '-' + out;
    return out;
  } else {
    throw 'Base should be between 2 and 36';
  }
};

BN.prototype.toJSON = function toJSON() {
  return this.toString(16);
};

BN.prototype.toArray = function toArray(endian, length) {
  this.strip();
  var littleEndian = endian === 'le';
  var res = new Array(this.byteLength());
  res[0] = 0;

  var q = this.clone();
  if (!littleEndian) {
    // Assume big-endian
    for (var i = 0; q.cmpn(0) !== 0; i++) {
      var b = q.andln(0xff);
      q.iushrn(8);

      res[res.length - i - 1] = b;
    }
  } else {
    for (var i = 0; q.cmpn(0) !== 0; i++) {
      var b = q.andln(0xff);
      q.iushrn(8);

      res[i] = b;
    }
  }

  if (length) {
    while (res.length < length) {
      if (littleEndian)
        res.push(0);
      else
        res.unshift(0);
    }
  }

  return res;
};

if (Math.clz32) {
  BN.prototype._countBits = function _countBits(w) {
    return 32 - Math.clz32(w);
  };
} else {
  BN.prototype._countBits = function _countBits(w) {
    var t = w;
    var r = 0;
    if (t >= 0x1000) {
      r += 13;
      t >>>= 13;
    }
    if (t >= 0x40) {
      r += 7;
      t >>>= 7;
    }
    if (t >= 0x8) {
      r += 4;
      t >>>= 4;
    }
    if (t >= 0x02) {
      r += 2;
      t >>>= 2;
    }
    return r + t;
  };
}

// Return number of used bits in a BN
BN.prototype.bitLength = function bitLength() {
  var hi = 0;
  var w = this.words[this.length - 1];
  var hi = this._countBits(w);
  return (this.length - 1) * 26 + hi;
};

BN.prototype.byteLength = function byteLength() {
  return Math.ceil(this.bitLength() / 8);
};

// Return negative clone of `this`
BN.prototype.neg = function neg() {
  if (this.cmpn(0) === 0)
    return this.clone();

  var r = this.clone();
  r.negative = this.negative ^ 1;
  return r;
};

BN.prototype.ineg = function ineg() {
  this.negative ^= 1;
  return this;
};

// Or `num` with `this` in-place
BN.prototype.iuor = function iuor(num) {
  while (this.length < num.length)
    this.words[this.length++] = 0;

  for (var i = 0; i < num.length; i++)
    this.words[i] = this.words[i] | num.words[i];

  return this.strip();
};

BN.prototype.ior = function ior(num) {
  //assert((this.negative | num.negative) === 0);
  return this.iuor(num);
};


// Or `num` with `this`
BN.prototype.or = function or(num) {
  if (this.length > num.length)
    return this.clone().ior(num);
  else
    return num.clone().ior(this);
};

BN.prototype.uor = function uor(num) {
  if (this.length > num.length)
    return this.clone().iuor(num);
  else
    return num.clone().iuor(this);
};


// And `num` with `this` in-place
BN.prototype.iuand = function iuand(num) {
  // b = min-length(num, this)
  var b;
  if (this.length > num.length)
    b = num;
  else
    b = this;

  for (var i = 0; i < b.length; i++)
    this.words[i] = this.words[i] & num.words[i];

  this.length = b.length;

  return this.strip();
};

BN.prototype.iand = function iand(num) {
  //assert((this.negative | num.negative) === 0);
  return this.iuand(num);
};


// And `num` with `this`
BN.prototype.and = function and(num) {
  if (this.length > num.length)
    return this.clone().iand(num);
  else
    return num.clone().iand(this);
};

BN.prototype.uand = function uand(num) {
  if (this.length > num.length)
    return this.clone().iuand(num);
  else
    return num.clone().iuand(this);
};


// Xor `num` with `this` in-place
BN.prototype.iuxor = function iuxor(num) {
  // a.length > b.length
  var a;
  var b;
  if (this.length > num.length) {
    a = this;
    b = num;
  } else {
    a = num;
    b = this;
  }

  for (var i = 0; i < b.length; i++)
    this.words[i] = a.words[i] ^ b.words[i];

  if (this !== a)
    for (; i < a.length; i++)
      this.words[i] = a.words[i];

  this.length = a.length;

  return this.strip();
};

BN.prototype.ixor = function ixor(num) {
  //assert((this.negative | num.negative) === 0);
  return this.iuxor(num);
};


// Xor `num` with `this`
BN.prototype.xor = function xor(num) {
  if (this.length > num.length)
    return this.clone().ixor(num);
  else
    return num.clone().ixor(this);
};

BN.prototype.uxor = function uxor(num) {
  if (this.length > num.length)
    return this.clone().iuxor(num);
  else
    return num.clone().iuxor(this);
};


// Add `num` to `this` in-place
BN.prototype.iadd = function iadd(num) {
  // negative + positive
  if (this.negative !== 0 && num.negative === 0) {
    this.negative = 0;
    var r = this.isub(num);
    this.negative ^= 1;
    return this._normSign();

  // positive + negative
  } else if (this.negative === 0 && num.negative !== 0) {
    num.negative = 0;
    var r = this.isub(num);
    num.negative = 1;
    return r._normSign();
  }

  // a.length > b.length
  var a;
  var b;
  if (this.length > num.length) {
    a = this;
    b = num;
  } else {
    a = num;
    b = this;
  }

  var carry = 0;
  for (var i = 0; i < b.length; i++) {
    var r = (a.words[i] | 0) + (b.words[i] | 0) + carry;
    this.words[i] = r & 0x3ffffff;
    carry = r >>> 26;
  }
  for (; carry !== 0 && i < a.length; i++) {
    var r = (a.words[i] | 0) + carry;
    this.words[i] = r & 0x3ffffff;
    carry = r >>> 26;
  }

  this.length = a.length;
  if (carry !== 0) {
    this.words[this.length] = carry;
    this.length++;
  // Copy the rest of the words
  } else if (a !== this) {
    for (; i < a.length; i++)
      this.words[i] = a.words[i];
  }

  return this;
};

// Add `num` to `this`
BN.prototype.add = function add(num) {
  if (num.negative !== 0 && this.negative === 0) {
    num.negative = 0;
    var res = this.sub(num);
    num.negative ^= 1;
    return res;
  } else if (num.negative === 0 && this.negative !== 0) {
    this.negative = 0;
    var res = num.sub(this);
    this.negative = 1;
    return res;
  }

  if (this.length > num.length)
    return this.clone().iadd(num);
  else
    return num.clone().iadd(this);
};

// Subtract `num` from `this` in-place
BN.prototype.isub = function isub(num) {
  // this - (-num) = this + num
  if (num.negative !== 0) {
    num.negative = 0;
    var r = this.iadd(num);
    num.negative = 1;
    return r._normSign();

  // -this - num = -(this + num)
  } else if (this.negative !== 0) {
    this.negative = 0;
    this.iadd(num);
    this.negative = 1;
    return this._normSign();
  }

  // At this point both numbers are positive
  var cmp = this.cmp(num);

  // Optimization - zeroify
  if (cmp === 0) {
    this.negative = 0;
    this.length = 1;
    this.words[0] = 0;
    return this;
  }

  // a > b
  var a;
  var b;
  if (cmp > 0) {
    a = this;
    b = num;
  } else {
    a = num;
    b = this;
  }

  var carry = 0;
  for (var i = 0; i < b.length; i++) {
    var r = (a.words[i] | 0) - (b.words[i] | 0) + carry;
    carry = r >> 26;
    this.words[i] = r & 0x3ffffff;
  }
  for (; carry !== 0 && i < a.length; i++) {
    var r = (a.words[i] | 0) + carry;
    carry = r >> 26;
    this.words[i] = r & 0x3ffffff;
  }

  // Copy rest of the words
  if (carry === 0 && i < a.length && a !== this)
    for (; i < a.length; i++)
      this.words[i] = a.words[i];
  this.length = Math.max(this.length, i);

  if (a !== this)
    this.negative = 1;

  return this.strip();
};

// Subtract `num` from `this`
BN.prototype.sub = function sub(num) {
  return this.clone().isub(num);
};

function smallMulTo(self, num, out) {
  out.negative = num.negative ^ self.negative;
  var len = (self.length + num.length) | 0;
  out.length = len;
  len = (len - 1) | 0;

  // Peel one iteration (compiler can't do it, because of code complexity)
  var a = self.words[0] | 0;
  var b = num.words[0] | 0;
  var r = a * b;

  var lo = r & 0x3ffffff;
  var carry = (r / 0x4000000) | 0;
  out.words[0] = lo;

  for (var k = 1; k < len; k++) {
    // Sum all words with the same `i + j = k` and accumulate `ncarry`,
    // note that ncarry could be >= 0x3ffffff
    var ncarry = carry >>> 26;
    var rword = carry & 0x3ffffff;
    var maxJ = Math.min(k, num.length - 1);
    for (var j = Math.max(0, k - self.length + 1); j <= maxJ; j++) {
      var i = (k - j) | 0;
      var a = self.words[i] | 0;
      var b = num.words[j] | 0;
      var r = a * b;

      var lo = r & 0x3ffffff;
      ncarry = (ncarry + ((r / 0x4000000) | 0)) | 0;
      lo = (lo + rword) | 0;
      rword = lo & 0x3ffffff;
      ncarry = (ncarry + (lo >>> 26)) | 0;
    }
    out.words[k] = rword | 0;
    carry = ncarry | 0;
  }
  if (carry !== 0) {
    out.words[k] = carry | 0;
  } else {
    out.length--;
  }

  return out.strip();
}

function bigMulTo(self, num, out) {
  out.negative = num.negative ^ self.negative;
  out.length = self.length + num.length;

  var carry = 0;
  var hncarry = 0;
  for (var k = 0; k < out.length - 1; k++) {
    // Sum all words with the same `i + j = k` and accumulate `ncarry`,
    // note that ncarry could be >= 0x3ffffff
    var ncarry = hncarry;
    hncarry = 0;
    var rword = carry & 0x3ffffff;
    var maxJ = Math.min(k, num.length - 1);
    for (var j = Math.max(0, k - self.length + 1); j <= maxJ; j++) {
      var i = k - j;
      var a = self.words[i] | 0;
      var b = num.words[j] | 0;
      var r = a * b;

      var lo = r & 0x3ffffff;
      ncarry = (ncarry + ((r / 0x4000000) | 0)) | 0;
      lo = (lo + rword) | 0;
      rword = lo & 0x3ffffff;
      ncarry = (ncarry + (lo >>> 26)) | 0;

      hncarry += ncarry >>> 26;
      ncarry &= 0x3ffffff;
    }
    out.words[k] = rword;
    carry = ncarry;
    ncarry = hncarry;
  }
  if (carry !== 0) {
    out.words[k] = carry;
  } else {
    out.length--;
  }

  return out.strip();
}

BN.prototype.mulTo = function mulTo(num, out) {
  var res;
  if (this.length + num.length < 63)
    res = smallMulTo(this, num, out);
  else
    res = bigMulTo(this, num, out);
  return res;
};

// Multiply `this` by `num`
BN.prototype.mul = function mul(num) {
  var out = new BN(null);
  out.words = new Array(this.length + num.length);
  return this.mulTo(num, out);
};

// In-place Multiplication
BN.prototype.imul = function imul(num) {
  if (this.cmpn(0) === 0 || num.cmpn(0) === 0) {
    this.words[0] = 0;
    this.length = 1;
    return this;
  }

  var tlen = this.length;
  var nlen = num.length;

  this.negative = num.negative ^ this.negative;
  this.length = this.length + num.length;
  this.words[this.length - 1] = 0;

  for (var k = this.length - 2; k >= 0; k--) {
    // Sum all words with the same `i + j = k` and accumulate `carry`,
    // note that carry could be >= 0x3ffffff
    var carry = 0;
    var rword = 0;
    var maxJ = Math.min(k, nlen - 1);
    for (var j = Math.max(0, k - tlen + 1); j <= maxJ; j++) {
      var i = k - j;
      var a = this.words[i] | 0;
      var b = num.words[j] | 0;
      var r = a * b;

      var lo = r & 0x3ffffff;
      carry += (r / 0x4000000) | 0;
      lo += rword;
      rword = lo & 0x3ffffff;
      carry += lo >>> 26;
    }
    this.words[k] = rword;
    this.words[k + 1] += carry;
    carry = 0;
  }

  // Propagate overflows
  var carry = 0;
  for (var i = 1; i < this.length; i++) {
    var w = (this.words[i] | 0) + carry;
    this.words[i] = w & 0x3ffffff;
    carry = w >>> 26;
  }

  return this.strip();
};

BN.prototype.imuln = function imuln(num) {
  // Carry
  var carry = 0;
  for (var i = 0; i < this.length; i++) {
    var w = (this.words[i] | 0) * num;
    var lo = (w & 0x3ffffff) + (carry & 0x3ffffff);
    carry >>= 26;
    carry += (w / 0x4000000) | 0;
    // NOTE: lo is 27bit maximum
    carry += lo >>> 26;
    this.words[i] = lo & 0x3ffffff;
  }

  if (carry !== 0) {
    this.words[i] = carry;
    this.length++;
  }

  return this;
};

BN.prototype.muln = function muln(num) {
  return this.clone().imuln(num);
};

// `this` * `this`
BN.prototype.sqr = function sqr() {
  return this.mul(this);
};

// `this` * `this` in-place
BN.prototype.isqr = function isqr() {
  return this.mul(this);
};

// Shift-left in-place
BN.prototype.iushln = function iushln(bits) {
  var r = bits % 26;
  var s = (bits - r) / 26;
  var carryMask = (0x3ffffff >>> (26 - r)) << (26 - r);

  if (r !== 0) {
    var carry = 0;
    for (var i = 0; i < this.length; i++) {
      var newCarry = this.words[i] & carryMask;
      var c = ((this.words[i] | 0) - newCarry) << r;
      this.words[i] = c | carry;
      carry = newCarry >>> (26 - r);
    }
    if (carry) {
      this.words[i] = carry;
      this.length++;
    }
  }

  if (s !== 0) {
    for (var i = this.length - 1; i >= 0; i--)
      this.words[i + s] = this.words[i];
    for (var i = 0; i < s; i++)
      this.words[i] = 0;
    this.length += s;
  }

  return this.strip();
};

BN.prototype.ishln = function ishln(bits) {
  return this.iushln(bits);
};

// Shift-right in-place
BN.prototype.iushrn = function iushrn(bits, hint, extended) {
  var h;
  if (hint)
    h = (hint - (hint % 26)) / 26;
  else
    h = 0;

  var r = bits % 26;
  var s = Math.min((bits - r) / 26, this.length);
  var mask = 0x3ffffff ^ ((0x3ffffff >>> r) << r);
  var maskedWords = extended;

  h -= s;
  h = Math.max(0, h);

  // Extended mode, copy masked part
  if (maskedWords) {
    for (var i = 0; i < s; i++)
      maskedWords.words[i] = this.words[i];
    maskedWords.length = s;
  }

  if (s === 0) {
    // No-op, we should not move anything at all
  } else if (this.length > s) {
    this.length -= s;
    for (var i = 0; i < this.length; i++)
      this.words[i] = this.words[i + s];
  } else {
    this.words[0] = 0;
    this.length = 1;
  }

  var carry = 0;
  for (var i = this.length - 1; i >= 0 && (carry !== 0 || i >= h); i--) {
    var word = this.words[i] | 0;
    this.words[i] = (carry << (26 - r)) | (word >>> r);
    carry = word & mask;
  }

  // Push carried bits as a mask
  if (maskedWords && carry !== 0)
    maskedWords.words[maskedWords.length++] = carry;

  if (this.length === 0) {
    this.words[0] = 0;
    this.length = 1;
  }

  this.strip();

  return this;
};

BN.prototype.ishrn = function ishrn(bits, hint, extended) {
  return this.iushrn(bits, hint, extended);
};

// Shift-left
BN.prototype.shln = function shln(bits) {
  var x = this.clone();
  var neg = x.negative;
  x.negative = false;
  x.ishln(bits);
  x.negative = neg;
  return x;
};

BN.prototype.ushln = function ushln(bits) {
  return this.clone().iushln(bits);
};

// Shift-right
BN.prototype.shrn = function shrn(bits) {
  var x = this.clone();
  if(x.negative) {
      x.negative = false;
      x.ishrn(bits);
      x.negative = true;
      return x.isubn(1);
  } else {
      return x.ishrn(bits);
  }
};

BN.prototype.ushrn = function ushrn(bits) {
  return this.clone().iushrn(bits);
};

// Test if n bit is set
BN.prototype.testn = function testn(bit) {
  var r = bit % 26;
  var s = (bit - r) / 26;
  var q = 1 << r;

  // Fast case: bit is much higher than all existing words
  if (this.length <= s) {
    return false;
  }

  // Check bit and return
  var w = this.words[s];

  return !!(w & q);
};

// Add plain number `num` to `this`
BN.prototype.iaddn = function iaddn(num) {
  if (num < 0)
    return this.isubn(-num);

  // Possible sign change
  if (this.negative !== 0) {
    if (this.length === 1 && (this.words[0] | 0) < num) {
      this.words[0] = num - (this.words[0] | 0);
      this.negative = 0;
      return this;
    }

    this.negative = 0;
    this.isubn(num);
    this.negative = 1;
    return this;
  }

  // Add without checks
  return this._iaddn(num);
};

BN.prototype._iaddn = function _iaddn(num) {
  this.words[0] += num;

  // Carry
  for (var i = 0; i < this.length && this.words[i] >= 0x4000000; i++) {
    this.words[i] -= 0x4000000;
    if (i === this.length - 1)
      this.words[i + 1] = 1;
    else
      this.words[i + 1]++;
  }
  this.length = Math.max(this.length, i + 1);

  return this;
};

// Subtract plain number `num` from `this`
BN.prototype.isubn = function isubn(num) {
  if (num < 0)
    return this.iaddn(-num);

  if (this.negative !== 0) {
    this.negative = 0;
    this.iaddn(num);
    this.negative = 1;
    return this;
  }

  this.words[0] -= num;

  // Carry
  for (var i = 0; i < this.length && this.words[i] < 0; i++) {
    this.words[i] += 0x4000000;
    this.words[i + 1] -= 1;
  }

  return this.strip();
};

BN.prototype.addn = function addn(num) {
  return this.clone().iaddn(num);
};

BN.prototype.subn = function subn(num) {
  return this.clone().isubn(num);
};

BN.prototype.iabs = function iabs() {
  this.negative = 0;

  return this;
};

BN.prototype.abs = function abs() {
  return this.clone().iabs();
};

BN.prototype._ishlnsubmul = function _ishlnsubmul(num, mul, shift) {
  // Bigger storage is needed
  var len = num.length + shift;
  var i;
  if (this.words.length < len) {
    var t = new Array(len);
    for (var i = 0; i < this.length; i++)
      t[i] = this.words[i];
    this.words = t;
  } else {
    i = this.length;
  }

  // Zeroify rest
  this.length = Math.max(this.length, len);
  for (; i < this.length; i++)
    this.words[i] = 0;

  var carry = 0;
  for (var i = 0; i < num.length; i++) {
    var w = (this.words[i + shift] | 0) + carry;
    var right = (num.words[i] | 0) * mul;
    w -= right & 0x3ffffff;
    carry = (w >> 26) - ((right / 0x4000000) | 0);
    this.words[i + shift] = w & 0x3ffffff;
  }
  for (; i < this.length - shift; i++) {
    var w = (this.words[i + shift] | 0) + carry;
    carry = w >> 26;
    this.words[i + shift] = w & 0x3ffffff;
  }

  if (carry === 0)
    return this.strip();

  carry = 0;
  for (var i = 0; i < this.length; i++) {
    var w = -(this.words[i] | 0) + carry;
    carry = w >> 26;
    this.words[i] = w & 0x3ffffff;
  }
  this.negative = 1;

  return this.strip();
};

BN.prototype._wordDiv = function _wordDiv(num, mode) {
  var shift = this.length - num.length;

  var a = this.clone();
  var b = num;

  // Normalize
  var bhi = b.words[b.length - 1] | 0;
  var bhiBits = this._countBits(bhi);
  shift = 26 - bhiBits;
  if (shift !== 0) {
    b = b.ushln(shift);
    a.iushln(shift);
    bhi = b.words[b.length - 1] | 0;
  }

  // Initialize quotient
  var m = a.length - b.length;
  var q;

  if (mode !== 'mod') {
    q = new BN(null);
    q.length = m + 1;
    q.words = new Array(q.length);
    for (var i = 0; i < q.length; i++)
      q.words[i] = 0;
  }

  var diff = a.clone()._ishlnsubmul(b, 1, m);
  if (diff.negative === 0) {
    a = diff;
    if (q)
      q.words[m] = 1;
  }

  for (var j = m - 1; j >= 0; j--) {
    var qj = (a.words[b.length + j] | 0) * 0x4000000 +
             (a.words[b.length + j - 1] | 0);

    // NOTE: (qj / bhi) is (0x3ffffff * 0x4000000 + 0x3ffffff) / 0x2000000 max
    // (0x7ffffff)
    qj = Math.min((qj / bhi) | 0, 0x3ffffff);

    a._ishlnsubmul(b, qj, j);
    while (a.negative !== 0) {
      qj--;
      a.negative = 0;
      a._ishlnsubmul(b, 1, j);
      if (a.cmpn(0) !== 0)
        a.negative ^= 1;
    }
    if (q)
      q.words[j] = qj;
  }
  if (q)
    q.strip();
  a.strip();

  // Denormalize
  if (mode !== 'div' && shift !== 0)
    a.iushrn(shift);
  return { div: q ? q : null, mod: a };
};

BN.prototype.divmod = function divmod(num, mode, positive) {
  if (this.negative !== 0 && num.negative === 0) {
    var res = this.neg().divmod(num, mode);
    var div;
    var mod;
    if (mode !== 'mod')
      div = res.div.neg();
    if (mode !== 'div') {
      mod = res.mod.neg();
      if (positive && mod.neg)
        mod = mod.add(num);
    }
    return {
      div: div,
      mod: mod
    };
  } else if (this.negative === 0 && num.negative !== 0) {
    var res = this.divmod(num.neg(), mode);
    var div;
    if (mode !== 'mod')
      div = res.div.neg();
    return { div: div, mod: res.mod };
  } else if ((this.negative & num.negative) !== 0) {
    var res = this.neg().divmod(num.neg(), mode);
    var mod;
    if (mode !== 'div') {
      mod = res.mod.neg();
      if (positive && mod.neg)
        mod = mod.isub(num);
    }
    return {
      div: res.div,
      mod: mod
    };
  }

  // Both numbers are positive at this point

  // Strip both numbers to approximate shift value
  if (num.length > this.length || this.cmp(num) < 0)
    return { div: new BN(0), mod: this };

  // Very short reduction
  if (num.length === 1) {
    if (mode === 'div')
      return { div: this.divn(num.words[0]), mod: null };
    else if (mode === 'mod')
      return { div: null, mod: new BN(this.modn(num.words[0])) };
    return {
      div: this.divn(num.words[0]),
      mod: new BN(this.modn(num.words[0]))
    };
  }

  return this._wordDiv(num, mode);
};

// Find `this` / `num`
BN.prototype.div = function div(num) {
  return this.divmod(num, 'div', false).div;
};

// Find `this` % `num`
BN.prototype.mod = function mod(num) {
  return this.divmod(num, 'mod', false).mod;
};

BN.prototype.umod = function umod(num) {
  return this.divmod(num, 'mod', true).mod;
};

// Find Round(`this` / `num`)
BN.prototype.divRound = function divRound(num) {
  var dm = this.divmod(num);

  // Fast case - exact division
  if (dm.mod.cmpn(0) === 0)
    return dm.div;

  var mod = dm.div.negative !== 0 ? dm.mod.isub(num) : dm.mod;

  var half = num.ushrn(1);
  var r2 = num.andln(1);
  var cmp = mod.cmp(half);

  // Round down
  if (cmp < 0 || r2 === 1 && cmp === 0)
    return dm.div;

  // Round up
  return dm.div.negative !== 0 ? dm.div.isubn(1) : dm.div.iaddn(1);
};

BN.prototype.modn = function modn(num) {
  var p = (1 << 26) % num;

  var acc = 0;
  for (var i = this.length - 1; i >= 0; i--)
    acc = (p * acc + (this.words[i] | 0)) % num;

  return acc;
};

// In-place division by number
BN.prototype.idivn = function idivn(num) {
  var carry = 0;
  for (var i = this.length - 1; i >= 0; i--) {
    var w = (this.words[i] | 0) + carry * 0x4000000;
    this.words[i] = (w / num) | 0;
    carry = w % num;
  }

  return this.strip();
};

BN.prototype.divn = function divn(num) {
  return this.clone().idivn(num);
};

BN.prototype.isEven = function isEven() {
  return (this.words[0] & 1) === 0;
};

BN.prototype.isOdd = function isOdd() {
  return (this.words[0] & 1) === 1;
};

// And first word and num
BN.prototype.andln = function andln(num) {
  return this.words[0] & num;
};

BN.prototype.cmpn = function cmpn(num) {
  var negative = num < 0;
  if (negative)
    num = -num;

  if (this.negative !== 0 && !negative)
    return -1;
  else if (this.negative === 0 && negative)
    return 1;

  num &= 0x3ffffff;
  this.strip();

  var res;
  if (this.length > 1) {
    res = 1;
  } else {
    var w = this.words[0] | 0;
    res = w === num ? 0 : w < num ? -1 : 1;
  }
  if (this.negative !== 0)
    res = -res;
  return res;
};

// Compare two numbers and return:
// 1 - if `this` > `num`
// 0 - if `this` == `num`
// -1 - if `this` < `num`
BN.prototype.cmp = function cmp(num) {
  if (this.negative !== 0 && num.negative === 0)
    return -1;
  else if (this.negative === 0 && num.negative !== 0)
    return 1;

  var res = this.ucmp(num);
  if (this.negative !== 0)
    return -res;
  else
    return res;
};

// Unsigned comparison
BN.prototype.ucmp = function ucmp(num) {
  // At this point both numbers have the same sign
  if (this.length > num.length)
    return 1;
  else if (this.length < num.length)
    return -1;

  var res = 0;
  for (var i = this.length - 1; i >= 0; i--) {
    var a = this.words[i] | 0;
    var b = num.words[i] | 0;

    if (a === b)
      continue;
    if (a < b)
      res = -1;
    else if (a > b)
      res = 1;
    break;
  }
  return res;
};
})(undefined, __bn);

// MVar implementation.
// Since Haste isn't concurrent, takeMVar and putMVar don't block on empty
// and full MVars respectively, but terminate the program since they would
// otherwise be blocking forever.

function newMVar() {
    return ({empty: true});
}

function tryTakeMVar(mv) {
    if(mv.empty) {
        return {_:0, a:0, b:undefined};
    } else {
        var val = mv.x;
        mv.empty = true;
        mv.x = null;
        return {_:0, a:1, b:val};
    }
}

function takeMVar(mv) {
    if(mv.empty) {
        // TODO: real BlockedOnDeadMVar exception, perhaps?
        err("Attempted to take empty MVar!");
    }
    var val = mv.x;
    mv.empty = true;
    mv.x = null;
    return val;
}

function putMVar(mv, val) {
    if(!mv.empty) {
        // TODO: real BlockedOnDeadMVar exception, perhaps?
        err("Attempted to put full MVar!");
    }
    mv.empty = false;
    mv.x = val;
}

function tryPutMVar(mv, val) {
    if(!mv.empty) {
        return 0;
    } else {
        mv.empty = false;
        mv.x = val;
        return 1;
    }
}

function sameMVar(a, b) {
    return (a == b);
}

function isEmptyMVar(mv) {
    return mv.empty ? 1 : 0;
}

// Implementation of stable names.
// Unlike native GHC, the garbage collector isn't going to move data around
// in a way that we can detect, so each object could serve as its own stable
// name if it weren't for the fact we can't turn a JS reference into an
// integer.
// So instead, each object has a unique integer attached to it, which serves
// as its stable name.

var __next_stable_name = 1;
var __stable_table;

function makeStableName(x) {
    if(x instanceof Object) {
        if(!x.stableName) {
            x.stableName = __next_stable_name;
            __next_stable_name += 1;
        }
        return {type: 'obj', name: x.stableName};
    } else {
        return {type: 'prim', name: Number(x)};
    }
}

function eqStableName(x, y) {
    return (x.type == y.type && x.name == y.name) ? 1 : 0;
}

// TODO: inefficient compared to real fromInt?
__bn.Z = new __bn.BN(0);
__bn.ONE = new __bn.BN(1);
__bn.MOD32 = new __bn.BN(0x100000000); // 2^32
var I_fromNumber = function(x) {return new __bn.BN(x);}
var I_fromInt = I_fromNumber;
var I_fromBits = function(lo,hi) {
    var x = new __bn.BN(lo >>> 0);
    var y = new __bn.BN(hi >>> 0);
    y.ishln(32);
    x.iadd(y);
    return x;
}
var I_fromString = function(s) {return new __bn.BN(s);}
var I_toInt = function(x) {return I_toNumber(x.mod(__bn.MOD32));}
var I_toWord = function(x) {return I_toInt(x) >>> 0;};
// TODO: inefficient!
var I_toNumber = function(x) {return Number(x.toString());}
var I_equals = function(a,b) {return a.cmp(b) === 0;}
var I_compare = function(a,b) {return a.cmp(b);}
var I_compareInt = function(x,i) {return x.cmp(new __bn.BN(i));}
var I_negate = function(x) {return x.neg();}
var I_add = function(a,b) {return a.add(b);}
var I_sub = function(a,b) {return a.sub(b);}
var I_mul = function(a,b) {return a.mul(b);}
var I_mod = function(a,b) {return I_rem(I_add(b, I_rem(a, b)), b);}
var I_quotRem = function(a,b) {
    var qr = a.divmod(b);
    return {_:0, a:qr.div, b:qr.mod};
}
var I_div = function(a,b) {
    if((a.cmp(__bn.Z)>=0) != (a.cmp(__bn.Z)>=0)) {
        if(a.cmp(a.rem(b), __bn.Z) !== 0) {
            return a.div(b).sub(__bn.ONE);
        }
    }
    return a.div(b);
}
var I_divMod = function(a,b) {
    return {_:0, a:I_div(a,b), b:a.mod(b)};
}
var I_quot = function(a,b) {return a.div(b);}
var I_rem = function(a,b) {return a.mod(b);}
var I_and = function(a,b) {return a.and(b);}
var I_or = function(a,b) {return a.or(b);}
var I_xor = function(a,b) {return a.xor(b);}
var I_shiftLeft = function(a,b) {return a.shln(b);}
var I_shiftRight = function(a,b) {return a.shrn(b);}
var I_signum = function(x) {return x.cmp(new __bn.BN(0));}
var I_abs = function(x) {return x.abs();}
var I_decodeDouble = function(x) {
    var dec = decodeDouble(x);
    var mantissa = I_fromBits(dec.c, dec.b);
    if(dec.a < 0) {
        mantissa = I_negate(mantissa);
    }
    return {_:0, a:dec.d, b:mantissa};
}
var I_toString = function(x) {return x.toString();}
var I_fromRat = function(a, b) {
    return I_toNumber(a) / I_toNumber(b);
}

function I_fromInt64(x) {
    if(x.isNegative()) {
        return I_negate(I_fromInt64(x.negate()));
    } else {
        return I_fromBits(x.low, x.high);
    }
}

function I_toInt64(x) {
    if(x.negative) {
        return I_toInt64(I_negate(x)).negate();
    } else {
        return new Long(I_toInt(x), I_toInt(I_shiftRight(x,32)));
    }
}

function I_fromWord64(x) {
    return I_fromBits(x.toInt(), x.shru(32).toInt());
}

function I_toWord64(x) {
    var w = I_toInt64(x);
    w.unsigned = true;
    return w;
}

/**
 * @license long.js (c) 2013 Daniel Wirtz <dcode@dcode.io>
 * Released under the Apache License, Version 2.0
 * see: https://github.com/dcodeIO/long.js for details
 */
function Long(low, high, unsigned) {
    this.low = low | 0;
    this.high = high | 0;
    this.unsigned = !!unsigned;
}

var INT_CACHE = {};
var UINT_CACHE = {};
function cacheable(x, u) {
    return u ? 0 <= (x >>>= 0) && x < 256 : -128 <= (x |= 0) && x < 128;
}

function __fromInt(value, unsigned) {
    var obj, cachedObj, cache;
    if (unsigned) {
        if (cache = cacheable(value >>>= 0, true)) {
            cachedObj = UINT_CACHE[value];
            if (cachedObj)
                return cachedObj;
        }
        obj = new Long(value, (value | 0) < 0 ? -1 : 0, true);
        if (cache)
            UINT_CACHE[value] = obj;
        return obj;
    } else {
        if (cache = cacheable(value |= 0, false)) {
            cachedObj = INT_CACHE[value];
            if (cachedObj)
                return cachedObj;
        }
        obj = new Long(value, value < 0 ? -1 : 0, false);
        if (cache)
            INT_CACHE[value] = obj;
        return obj;
    }
}

function __fromNumber(value, unsigned) {
    if (isNaN(value) || !isFinite(value))
        return unsigned ? UZERO : ZERO;
    if (unsigned) {
        if (value < 0)
            return UZERO;
        if (value >= TWO_PWR_64_DBL)
            return MAX_UNSIGNED_VALUE;
    } else {
        if (value <= -TWO_PWR_63_DBL)
            return MIN_VALUE;
        if (value + 1 >= TWO_PWR_63_DBL)
            return MAX_VALUE;
    }
    if (value < 0)
        return __fromNumber(-value, unsigned).neg();
    return new Long((value % TWO_PWR_32_DBL) | 0, (value / TWO_PWR_32_DBL) | 0, unsigned);
}
var pow_dbl = Math.pow;
var TWO_PWR_16_DBL = 1 << 16;
var TWO_PWR_24_DBL = 1 << 24;
var TWO_PWR_32_DBL = TWO_PWR_16_DBL * TWO_PWR_16_DBL;
var TWO_PWR_64_DBL = TWO_PWR_32_DBL * TWO_PWR_32_DBL;
var TWO_PWR_63_DBL = TWO_PWR_64_DBL / 2;
var TWO_PWR_24 = __fromInt(TWO_PWR_24_DBL);
var ZERO = __fromInt(0);
Long.ZERO = ZERO;
var UZERO = __fromInt(0, true);
Long.UZERO = UZERO;
var ONE = __fromInt(1);
Long.ONE = ONE;
var UONE = __fromInt(1, true);
Long.UONE = UONE;
var NEG_ONE = __fromInt(-1);
Long.NEG_ONE = NEG_ONE;
var MAX_VALUE = new Long(0xFFFFFFFF|0, 0x7FFFFFFF|0, false);
Long.MAX_VALUE = MAX_VALUE;
var MAX_UNSIGNED_VALUE = new Long(0xFFFFFFFF|0, 0xFFFFFFFF|0, true);
Long.MAX_UNSIGNED_VALUE = MAX_UNSIGNED_VALUE;
var MIN_VALUE = new Long(0, 0x80000000|0, false);
Long.MIN_VALUE = MIN_VALUE;
var __lp = Long.prototype;
__lp.toInt = function() {return this.unsigned ? this.low >>> 0 : this.low;};
__lp.toNumber = function() {
    if (this.unsigned)
        return ((this.high >>> 0) * TWO_PWR_32_DBL) + (this.low >>> 0);
    return this.high * TWO_PWR_32_DBL + (this.low >>> 0);
};
__lp.isZero = function() {return this.high === 0 && this.low === 0;};
__lp.isNegative = function() {return !this.unsigned && this.high < 0;};
__lp.isOdd = function() {return (this.low & 1) === 1;};
__lp.eq = function(other) {
    if (this.unsigned !== other.unsigned && (this.high >>> 31) === 1 && (other.high >>> 31) === 1)
        return false;
    return this.high === other.high && this.low === other.low;
};
__lp.neq = function(other) {return !this.eq(other);};
__lp.lt = function(other) {return this.comp(other) < 0;};
__lp.lte = function(other) {return this.comp(other) <= 0;};
__lp.gt = function(other) {return this.comp(other) > 0;};
__lp.gte = function(other) {return this.comp(other) >= 0;};
__lp.compare = function(other) {
    if (this.eq(other))
        return 0;
    var thisNeg = this.isNegative(),
        otherNeg = other.isNegative();
    if (thisNeg && !otherNeg)
        return -1;
    if (!thisNeg && otherNeg)
        return 1;
    if (!this.unsigned)
        return this.sub(other).isNegative() ? -1 : 1;
    return (other.high >>> 0) > (this.high >>> 0) || (other.high === this.high && (other.low >>> 0) > (this.low >>> 0)) ? -1 : 1;
};
__lp.comp = __lp.compare;
__lp.negate = function() {
    if (!this.unsigned && this.eq(MIN_VALUE))
        return MIN_VALUE;
    return this.not().add(ONE);
};
__lp.neg = __lp.negate;
__lp.add = function(addend) {
    var a48 = this.high >>> 16;
    var a32 = this.high & 0xFFFF;
    var a16 = this.low >>> 16;
    var a00 = this.low & 0xFFFF;

    var b48 = addend.high >>> 16;
    var b32 = addend.high & 0xFFFF;
    var b16 = addend.low >>> 16;
    var b00 = addend.low & 0xFFFF;

    var c48 = 0, c32 = 0, c16 = 0, c00 = 0;
    c00 += a00 + b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 + b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 + b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 + b48;
    c48 &= 0xFFFF;
    return new Long((c16 << 16) | c00, (c48 << 16) | c32, this.unsigned);
};
__lp.subtract = function(subtrahend) {return this.add(subtrahend.neg());};
__lp.sub = __lp.subtract;
__lp.multiply = function(multiplier) {
    if (this.isZero())
        return ZERO;
    if (multiplier.isZero())
        return ZERO;
    if (this.eq(MIN_VALUE))
        return multiplier.isOdd() ? MIN_VALUE : ZERO;
    if (multiplier.eq(MIN_VALUE))
        return this.isOdd() ? MIN_VALUE : ZERO;

    if (this.isNegative()) {
        if (multiplier.isNegative())
            return this.neg().mul(multiplier.neg());
        else
            return this.neg().mul(multiplier).neg();
    } else if (multiplier.isNegative())
        return this.mul(multiplier.neg()).neg();

    if (this.lt(TWO_PWR_24) && multiplier.lt(TWO_PWR_24))
        return __fromNumber(this.toNumber() * multiplier.toNumber(), this.unsigned);

    var a48 = this.high >>> 16;
    var a32 = this.high & 0xFFFF;
    var a16 = this.low >>> 16;
    var a00 = this.low & 0xFFFF;

    var b48 = multiplier.high >>> 16;
    var b32 = multiplier.high & 0xFFFF;
    var b16 = multiplier.low >>> 16;
    var b00 = multiplier.low & 0xFFFF;

    var c48 = 0, c32 = 0, c16 = 0, c00 = 0;
    c00 += a00 * b00;
    c16 += c00 >>> 16;
    c00 &= 0xFFFF;
    c16 += a16 * b00;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c16 += a00 * b16;
    c32 += c16 >>> 16;
    c16 &= 0xFFFF;
    c32 += a32 * b00;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a16 * b16;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c32 += a00 * b32;
    c48 += c32 >>> 16;
    c32 &= 0xFFFF;
    c48 += a48 * b00 + a32 * b16 + a16 * b32 + a00 * b48;
    c48 &= 0xFFFF;
    return new Long((c16 << 16) | c00, (c48 << 16) | c32, this.unsigned);
};
__lp.mul = __lp.multiply;
__lp.divide = function(divisor) {
    if (divisor.isZero())
        throw Error('division by zero');
    if (this.isZero())
        return this.unsigned ? UZERO : ZERO;
    var approx, rem, res;
    if (this.eq(MIN_VALUE)) {
        if (divisor.eq(ONE) || divisor.eq(NEG_ONE))
            return MIN_VALUE;
        else if (divisor.eq(MIN_VALUE))
            return ONE;
        else {
            var halfThis = this.shr(1);
            approx = halfThis.div(divisor).shl(1);
            if (approx.eq(ZERO)) {
                return divisor.isNegative() ? ONE : NEG_ONE;
            } else {
                rem = this.sub(divisor.mul(approx));
                res = approx.add(rem.div(divisor));
                return res;
            }
        }
    } else if (divisor.eq(MIN_VALUE))
        return this.unsigned ? UZERO : ZERO;
    if (this.isNegative()) {
        if (divisor.isNegative())
            return this.neg().div(divisor.neg());
        return this.neg().div(divisor).neg();
    } else if (divisor.isNegative())
        return this.div(divisor.neg()).neg();

    res = ZERO;
    rem = this;
    while (rem.gte(divisor)) {
        approx = Math.max(1, Math.floor(rem.toNumber() / divisor.toNumber()));
        var log2 = Math.ceil(Math.log(approx) / Math.LN2),
            delta = (log2 <= 48) ? 1 : pow_dbl(2, log2 - 48),
            approxRes = __fromNumber(approx),
            approxRem = approxRes.mul(divisor);
        while (approxRem.isNegative() || approxRem.gt(rem)) {
            approx -= delta;
            approxRes = __fromNumber(approx, this.unsigned);
            approxRem = approxRes.mul(divisor);
        }
        if (approxRes.isZero())
            approxRes = ONE;

        res = res.add(approxRes);
        rem = rem.sub(approxRem);
    }
    return res;
};
__lp.div = __lp.divide;
__lp.modulo = function(divisor) {return this.sub(this.div(divisor).mul(divisor));};
__lp.mod = __lp.modulo;
__lp.not = function not() {return new Long(~this.low, ~this.high, this.unsigned);};
__lp.and = function(other) {return new Long(this.low & other.low, this.high & other.high, this.unsigned);};
__lp.or = function(other) {return new Long(this.low | other.low, this.high | other.high, this.unsigned);};
__lp.xor = function(other) {return new Long(this.low ^ other.low, this.high ^ other.high, this.unsigned);};

__lp.shl = function(numBits) {
    if ((numBits &= 63) === 0)
        return this;
    else if (numBits < 32)
        return new Long(this.low << numBits, (this.high << numBits) | (this.low >>> (32 - numBits)), this.unsigned);
    else
        return new Long(0, this.low << (numBits - 32), this.unsigned);
};

__lp.shr = function(numBits) {
    if ((numBits &= 63) === 0)
        return this;
    else if (numBits < 32)
        return new Long((this.low >>> numBits) | (this.high << (32 - numBits)), this.high >> numBits, this.unsigned);
    else
        return new Long(this.high >> (numBits - 32), this.high >= 0 ? 0 : -1, this.unsigned);
};

__lp.shru = function(numBits) {
    numBits &= 63;
    if (numBits === 0)
        return this;
    else {
        var high = this.high;
        if (numBits < 32) {
            var low = this.low;
            return new Long((low >>> numBits) | (high << (32 - numBits)), high >>> numBits, this.unsigned);
        } else if (numBits === 32)
            return new Long(high, 0, this.unsigned);
        else
            return new Long(high >>> (numBits - 32), 0, this.unsigned);
    }
};

__lp.toSigned = function() {return this.unsigned ? new Long(this.low, this.high, false) : this;};
__lp.toUnsigned = function() {return this.unsigned ? this : new Long(this.low, this.high, true);};

// Int64
function hs_eqInt64(x, y) {return x.eq(y);}
function hs_neInt64(x, y) {return x.neq(y);}
function hs_ltInt64(x, y) {return x.lt(y);}
function hs_leInt64(x, y) {return x.lte(y);}
function hs_gtInt64(x, y) {return x.gt(y);}
function hs_geInt64(x, y) {return x.gte(y);}
function hs_quotInt64(x, y) {return x.div(y);}
function hs_remInt64(x, y) {return x.modulo(y);}
function hs_plusInt64(x, y) {return x.add(y);}
function hs_minusInt64(x, y) {return x.subtract(y);}
function hs_timesInt64(x, y) {return x.multiply(y);}
function hs_negateInt64(x) {return x.negate();}
function hs_uncheckedIShiftL64(x, bits) {return x.shl(bits);}
function hs_uncheckedIShiftRA64(x, bits) {return x.shr(bits);}
function hs_uncheckedIShiftRL64(x, bits) {return x.shru(bits);}
function hs_int64ToInt(x) {return x.toInt();}
var hs_intToInt64 = __fromInt;

// Word64
function hs_wordToWord64(x) {return __fromInt(x, true);}
function hs_word64ToWord(x) {return x.toInt(x);}
function hs_mkWord64(low, high) {return new Long(low,high,true);}
function hs_and64(a,b) {return a.and(b);};
function hs_or64(a,b) {return a.or(b);};
function hs_xor64(a,b) {return a.xor(b);};
function hs_not64(x) {return x.not();}
var hs_eqWord64 = hs_eqInt64;
var hs_neWord64 = hs_neInt64;
var hs_ltWord64 = hs_ltInt64;
var hs_leWord64 = hs_leInt64;
var hs_gtWord64 = hs_gtInt64;
var hs_geWord64 = hs_geInt64;
var hs_quotWord64 = hs_quotInt64;
var hs_remWord64 = hs_remInt64;
var hs_uncheckedShiftL64 = hs_uncheckedIShiftL64;
var hs_uncheckedShiftRL64 = hs_uncheckedIShiftRL64;
function hs_int64ToWord64(x) {return x.toUnsigned();}
function hs_word64ToInt64(x) {return x.toSigned();}

// Joseph Myers' MD5 implementation, ported to work on typed arrays.
// Used under the BSD license.
function md5cycle(x, k) {
    var a = x[0], b = x[1], c = x[2], d = x[3];

    a = ff(a, b, c, d, k[0], 7, -680876936);
    d = ff(d, a, b, c, k[1], 12, -389564586);
    c = ff(c, d, a, b, k[2], 17,  606105819);
    b = ff(b, c, d, a, k[3], 22, -1044525330);
    a = ff(a, b, c, d, k[4], 7, -176418897);
    d = ff(d, a, b, c, k[5], 12,  1200080426);
    c = ff(c, d, a, b, k[6], 17, -1473231341);
    b = ff(b, c, d, a, k[7], 22, -45705983);
    a = ff(a, b, c, d, k[8], 7,  1770035416);
    d = ff(d, a, b, c, k[9], 12, -1958414417);
    c = ff(c, d, a, b, k[10], 17, -42063);
    b = ff(b, c, d, a, k[11], 22, -1990404162);
    a = ff(a, b, c, d, k[12], 7,  1804603682);
    d = ff(d, a, b, c, k[13], 12, -40341101);
    c = ff(c, d, a, b, k[14], 17, -1502002290);
    b = ff(b, c, d, a, k[15], 22,  1236535329);

    a = gg(a, b, c, d, k[1], 5, -165796510);
    d = gg(d, a, b, c, k[6], 9, -1069501632);
    c = gg(c, d, a, b, k[11], 14,  643717713);
    b = gg(b, c, d, a, k[0], 20, -373897302);
    a = gg(a, b, c, d, k[5], 5, -701558691);
    d = gg(d, a, b, c, k[10], 9,  38016083);
    c = gg(c, d, a, b, k[15], 14, -660478335);
    b = gg(b, c, d, a, k[4], 20, -405537848);
    a = gg(a, b, c, d, k[9], 5,  568446438);
    d = gg(d, a, b, c, k[14], 9, -1019803690);
    c = gg(c, d, a, b, k[3], 14, -187363961);
    b = gg(b, c, d, a, k[8], 20,  1163531501);
    a = gg(a, b, c, d, k[13], 5, -1444681467);
    d = gg(d, a, b, c, k[2], 9, -51403784);
    c = gg(c, d, a, b, k[7], 14,  1735328473);
    b = gg(b, c, d, a, k[12], 20, -1926607734);

    a = hh(a, b, c, d, k[5], 4, -378558);
    d = hh(d, a, b, c, k[8], 11, -2022574463);
    c = hh(c, d, a, b, k[11], 16,  1839030562);
    b = hh(b, c, d, a, k[14], 23, -35309556);
    a = hh(a, b, c, d, k[1], 4, -1530992060);
    d = hh(d, a, b, c, k[4], 11,  1272893353);
    c = hh(c, d, a, b, k[7], 16, -155497632);
    b = hh(b, c, d, a, k[10], 23, -1094730640);
    a = hh(a, b, c, d, k[13], 4,  681279174);
    d = hh(d, a, b, c, k[0], 11, -358537222);
    c = hh(c, d, a, b, k[3], 16, -722521979);
    b = hh(b, c, d, a, k[6], 23,  76029189);
    a = hh(a, b, c, d, k[9], 4, -640364487);
    d = hh(d, a, b, c, k[12], 11, -421815835);
    c = hh(c, d, a, b, k[15], 16,  530742520);
    b = hh(b, c, d, a, k[2], 23, -995338651);

    a = ii(a, b, c, d, k[0], 6, -198630844);
    d = ii(d, a, b, c, k[7], 10,  1126891415);
    c = ii(c, d, a, b, k[14], 15, -1416354905);
    b = ii(b, c, d, a, k[5], 21, -57434055);
    a = ii(a, b, c, d, k[12], 6,  1700485571);
    d = ii(d, a, b, c, k[3], 10, -1894986606);
    c = ii(c, d, a, b, k[10], 15, -1051523);
    b = ii(b, c, d, a, k[1], 21, -2054922799);
    a = ii(a, b, c, d, k[8], 6,  1873313359);
    d = ii(d, a, b, c, k[15], 10, -30611744);
    c = ii(c, d, a, b, k[6], 15, -1560198380);
    b = ii(b, c, d, a, k[13], 21,  1309151649);
    a = ii(a, b, c, d, k[4], 6, -145523070);
    d = ii(d, a, b, c, k[11], 10, -1120210379);
    c = ii(c, d, a, b, k[2], 15,  718787259);
    b = ii(b, c, d, a, k[9], 21, -343485551);

    x[0] = add32(a, x[0]);
    x[1] = add32(b, x[1]);
    x[2] = add32(c, x[2]);
    x[3] = add32(d, x[3]);

}

function cmn(q, a, b, x, s, t) {
    a = add32(add32(a, q), add32(x, t));
    return add32((a << s) | (a >>> (32 - s)), b);
}

function ff(a, b, c, d, x, s, t) {
    return cmn((b & c) | ((~b) & d), a, b, x, s, t);
}

function gg(a, b, c, d, x, s, t) {
    return cmn((b & d) | (c & (~d)), a, b, x, s, t);
}

function hh(a, b, c, d, x, s, t) {
    return cmn(b ^ c ^ d, a, b, x, s, t);
}

function ii(a, b, c, d, x, s, t) {
    return cmn(c ^ (b | (~d)), a, b, x, s, t);
}

function md51(s, n) {
    var a = s['v']['w8'];
    var orig_n = n,
        state = [1732584193, -271733879, -1732584194, 271733878], i;
    for (i=64; i<=n; i+=64) {
        md5cycle(state, md5blk(a.subarray(i-64, i)));
    }
    a = a.subarray(i-64);
    n = n < (i-64) ? 0 : n-(i-64);
    var tail = [0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0];
    for (i=0; i<n; i++)
        tail[i>>2] |= a[i] << ((i%4) << 3);
    tail[i>>2] |= 0x80 << ((i%4) << 3);
    if (i > 55) {
        md5cycle(state, tail);
        for (i=0; i<16; i++) tail[i] = 0;
    }
    tail[14] = orig_n*8;
    md5cycle(state, tail);
    return state;
}
window['md51'] = md51;

function md5blk(s) {
    var md5blks = [], i;
    for (i=0; i<64; i+=4) {
        md5blks[i>>2] = s[i]
            + (s[i+1] << 8)
            + (s[i+2] << 16)
            + (s[i+3] << 24);
    }
    return md5blks;
}

var hex_chr = '0123456789abcdef'.split('');

function rhex(n)
{
    var s='', j=0;
    for(; j<4; j++)
        s += hex_chr[(n >> (j * 8 + 4)) & 0x0F]
        + hex_chr[(n >> (j * 8)) & 0x0F];
    return s;
}

function hex(x) {
    for (var i=0; i<x.length; i++)
        x[i] = rhex(x[i]);
    return x.join('');
}

function md5(s, n) {
    return hex(md51(s, n));
}

window['md5'] = md5;

function add32(a, b) {
    return (a + b) & 0xFFFFFFFF;
}

function __hsbase_MD5Init(ctx) {}
// Note that this is a one time "update", since that's all that's used by
// GHC.Fingerprint.
function __hsbase_MD5Update(ctx, s, n) {
    ctx.md5 = md51(s, n);
}
function __hsbase_MD5Final(out, ctx) {
    var a = out['v']['i32'];
    a[0] = ctx.md5[0];
    a[1] = ctx.md5[1];
    a[2] = ctx.md5[2];
    a[3] = ctx.md5[3];
}

// Functions for dealing with arrays.

function newArr(n, x) {
    var arr = new Array(n);
    for(var i = 0; i < n; ++i) {
        arr[i] = x;
    }
    return arr;
}

// Create all views at once; perhaps it's wasteful, but it's better than having
// to check for the right view at each read or write.
function newByteArr(n) {
    // Pad the thing to multiples of 8.
    var padding = 8 - n % 8;
    if(padding < 8) {
        n += padding;
    }
    return new ByteArray(new ArrayBuffer(n));
}

// Wrap a JS ArrayBuffer into a ByteArray. Truncates the array length to the
// closest multiple of 8 bytes.
function wrapByteArr(buffer) {
    var diff = buffer.byteLength % 8;
    if(diff != 0) {
        var buffer = buffer.slice(0, buffer.byteLength-diff);
    }
    return new ByteArray(buffer);
}

function ByteArray(buffer) {
    var views =
        { 'i8' : new Int8Array(buffer)
        , 'i16': new Int16Array(buffer)
        , 'i32': new Int32Array(buffer)
        , 'w8' : new Uint8Array(buffer)
        , 'w16': new Uint16Array(buffer)
        , 'w32': new Uint32Array(buffer)
        , 'f32': new Float32Array(buffer)
        , 'f64': new Float64Array(buffer)
        };
    this['b'] = buffer;
    this['v'] = views;
    this['off'] = 0;
}
window['newArr'] = newArr;
window['newByteArr'] = newByteArr;
window['wrapByteArr'] = wrapByteArr;
window['ByteArray'] = ByteArray;

// An attempt at emulating pointers enough for ByteString and Text to be
// usable without patching the hell out of them.
// The general idea is that Addr# is a byte array with an associated offset.

function plusAddr(addr, off) {
    var newaddr = {};
    newaddr['off'] = addr['off'] + off;
    newaddr['b']   = addr['b'];
    newaddr['v']   = addr['v'];
    return newaddr;
}

function writeOffAddr(type, elemsize, addr, off, x) {
    addr['v'][type][addr.off/elemsize + off] = x;
}

function writeOffAddr64(addr, off, x) {
    addr['v']['w32'][addr.off/8 + off*2] = x.low;
    addr['v']['w32'][addr.off/8 + off*2 + 1] = x.high;
}

function readOffAddr(type, elemsize, addr, off) {
    return addr['v'][type][addr.off/elemsize + off];
}

function readOffAddr64(signed, addr, off) {
    var w64 = hs_mkWord64( addr['v']['w32'][addr.off/8 + off*2]
                         , addr['v']['w32'][addr.off/8 + off*2 + 1]);
    return signed ? hs_word64ToInt64(w64) : w64;
}

// Two addresses are equal if they point to the same buffer and have the same
// offset. For other comparisons, just use the offsets - nobody in their right
// mind would check if one pointer is less than another, completely unrelated,
// pointer and then act on that information anyway.
function addrEq(a, b) {
    if(a == b) {
        return true;
    }
    return a && b && a['b'] == b['b'] && a['off'] == b['off'];
}

function addrLT(a, b) {
    if(a) {
        return b && a['off'] < b['off'];
    } else {
        return (b != 0); 
    }
}

function addrGT(a, b) {
    if(b) {
        return a && a['off'] > b['off'];
    } else {
        return (a != 0);
    }
}

function withChar(f, charCode) {
    return f(String.fromCharCode(charCode)).charCodeAt(0);
}

function u_towlower(charCode) {
    return withChar(function(c) {return c.toLowerCase()}, charCode);
}

function u_towupper(charCode) {
    return withChar(function(c) {return c.toUpperCase()}, charCode);
}

var u_towtitle = u_towupper;

function u_iswupper(charCode) {
    var c = String.fromCharCode(charCode);
    return c == c.toUpperCase() && c != c.toLowerCase();
}

function u_iswlower(charCode) {
    var c = String.fromCharCode(charCode);
    return  c == c.toLowerCase() && c != c.toUpperCase();
}

function u_iswdigit(charCode) {
    return charCode >= 48 && charCode <= 57;
}

function u_iswcntrl(charCode) {
    return charCode <= 0x1f || charCode == 0x7f;
}

function u_iswspace(charCode) {
    var c = String.fromCharCode(charCode);
    return c.replace(/\s/g,'') != c;
}

function u_iswalpha(charCode) {
    var c = String.fromCharCode(charCode);
    return c.replace(__hs_alphare, '') != c;
}

function u_iswalnum(charCode) {
    return u_iswdigit(charCode) || u_iswalpha(charCode);
}

function u_iswprint(charCode) {
    return !u_iswcntrl(charCode);
}

function u_gencat(c) {
    throw 'u_gencat is only supported with --full-unicode.';
}

// Regex that matches any alphabetic character in any language. Horrible thing.
var __hs_alphare = /[\u0041-\u005A\u0061-\u007A\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u1700-\u170C\u170E-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC]/g;

// Simulate handles.
// When implementing new handles, remember that passed strings may be thunks,
// and so need to be evaluated before use.

function jsNewHandle(init, read, write, flush, close, seek, tell) {
    var h = {
        read: read || function() {},
        write: write || function() {},
        seek: seek || function() {},
        tell: tell || function() {},
        close: close || function() {},
        flush: flush || function() {}
    };
    init.call(h);
    return h;
}

function jsReadHandle(h, len) {return h.read(len);}
function jsWriteHandle(h, str) {return h.write(str);}
function jsFlushHandle(h) {return h.flush();}
function jsCloseHandle(h) {return h.close();}

function jsMkConWriter(op) {
    return function(str) {
        str = E(str);
        var lines = (this.buf + str).split('\n');
        for(var i = 0; i < lines.length-1; ++i) {
            op.call(console, lines[i]);
        }
        this.buf = lines[lines.length-1];
    }
}

function jsMkStdout() {
    return jsNewHandle(
        function() {this.buf = '';},
        function(_) {return '';},
        jsMkConWriter(console.log),
        function() {console.log(this.buf); this.buf = '';}
    );
}

function jsMkStderr() {
    return jsNewHandle(
        function() {this.buf = '';},
        function(_) {return '';},
        jsMkConWriter(console.warn),
        function() {console.warn(this.buf); this.buf = '';}
    );
}

function jsMkStdin() {
    return jsNewHandle(
        function() {this.buf = '';},
        function(len) {
            while(this.buf.length < len) {
                this.buf += prompt('[stdin]') + '\n';
            }
            var ret = this.buf.substr(0, len);
            this.buf = this.buf.substr(len);
            return ret;
        }
    );
}

// "Weak Pointers". Mostly useless implementation since
// JS does its own GC.

function mkWeak(key, val, fin) {
    fin = !fin? function() {}: fin;
    return {key: key, val: val, fin: fin};
}

function derefWeak(w) {
    return {_:0, a:1, b:E(w).val};
}

function finalizeWeak(w) {
    return {_:0, a:B(A1(E(w).fin, __Z))};
}

/* For foreign import ccall "wrapper" */
function createAdjustor(args, f, a, b) {
    return function(){
        var x = f.apply(null, arguments);
        while(x instanceof F) {x = x.f();}
        return x;
    };
}

var __apply = function(f,as) {
    var arr = [];
    for(; as._ === 1; as = as.b) {
        arr.push(as.a);
    }
    arr.reverse();
    return f.apply(null, arr);
}
var __app0 = function(f) {return f();}
var __app1 = function(f,a) {return f(a);}
var __app2 = function(f,a,b) {return f(a,b);}
var __app3 = function(f,a,b,c) {return f(a,b,c);}
var __app4 = function(f,a,b,c,d) {return f(a,b,c,d);}
var __app5 = function(f,a,b,c,d,e) {return f(a,b,c,d,e);}
var __jsNull = function() {return null;}
var __eq = function(a,b) {return a===b;}
var __createJSFunc = function(arity, f){
    if(f instanceof Function && arity === f.length) {
        return (function() {
            var x = f.apply(null,arguments);
            if(x instanceof T) {
                if(x.f !== __blackhole) {
                    var ff = x.f;
                    x.f = __blackhole;
                    return x.x = ff();
                }
                return x.x;
            } else {
                while(x instanceof F) {
                    x = x.f();
                }
                return E(x);
            }
        });
    } else {
        return (function(){
            var as = Array.prototype.slice.call(arguments);
            as.push(0);
            return E(B(A(f,as)));
        });
    }
}


function __arr2lst(elem,arr) {
    if(elem >= arr.length) {
        return __Z;
    }
    return {_:1,
            a:arr[elem],
            b:new T(function(){return __arr2lst(elem+1,arr);})};
}

function __lst2arr(xs) {
    var arr = [];
    xs = E(xs);
    for(;xs._ === 1; xs = E(xs.b)) {
        arr.push(E(xs.a));
    }
    return arr;
}

var __new = function() {return ({});}
var __set = function(o,k,v) {o[k]=v;}
var __get = function(o,k) {return o[k];}
var __has = function(o,k) {return o[k]!==undefined;}

var _0=0,_1=function(_){return _0;},_2=function(_3,_4){while(1){var _5=E(_3);if(!_5._){return E(_4);}else{_3=_5.b;_4=_5.a;continue;}}},_6=function(_7,_8,_9){return new F(function(){return _2(_8,_7);});},_a=function(_b,_c){var _d=E(_b);return (_d._==0)?E(_c):new T2(1,_d.a,new T(function(){return B(_a(_d.b,_c));}));},_e=new T(function(){return B(unCStr("!!: negative index"));}),_f=new T(function(){return B(unCStr("Prelude."));}),_g=new T(function(){return B(_a(_f,_e));}),_h=new T(function(){return B(err(_g));}),_i=new T(function(){return B(unCStr("!!: index too large"));}),_j=new T(function(){return B(_a(_f,_i));}),_k=new T(function(){return B(err(_j));}),_l=function(_m,_n){while(1){var _o=E(_m);if(!_o._){return E(_k);}else{var _p=E(_n);if(!_p){return E(_o.a);}else{_m=_o.b;_n=_p-1|0;continue;}}}},_q=function(_r,_s){if(_s>=0){return new F(function(){return _l(_r,_s);});}else{return E(_h);}},_t=function(_u){return E(E(_u).a);},_v=function(_w,_x,_y){while(1){var _z=E(_x);if(!_z._){return (E(_y)._==0)?true:false;}else{var _A=E(_y);if(!_A._){return false;}else{if(!B(A3(_t,_w,_z.a,_A.a))){return false;}else{_x=_z.b;_y=_A.b;continue;}}}}},_B=function(_C,_D,_E,_F,_G,_H){return (_C!=_F)?true:(E(_D)!=E(_G))?true:(E(_E)!=E(_H))?true:false;},_I=function(_J,_K){var _L=E(_J),_M=E(_L.a),_N=E(_K),_O=E(_N.a);return new F(function(){return _B(E(_M.a),_M.b,_L.b,E(_O.a),_O.b,_N.b);});},_P=function(_Q,_R){return E(_Q)==E(_R);},_S=function(_T,_U,_V,_W,_X,_Y){if(_T!=_W){return false;}else{if(E(_U)!=E(_X)){return false;}else{return new F(function(){return _P(_V,_Y);});}}},_Z=function(_10,_11){var _12=E(_10),_13=E(_12.a),_14=E(_11),_15=E(_14.a);return new F(function(){return _S(E(_13.a),_13.b,_12.b,E(_15.a),_15.b,_14.b);});},_16=new T2(0,_Z,_I),_17=function(_18,_19,_1a,_1b,_1c,_1d,_1e,_1f,_1g,_1h){while(1){var _1i=E(_1h);if(!_1i._){return {_:0,a:_18,b:_19,c:_1a,d:_1b,e:_1c,f:_1d,g:_1e,h:_1f,i:_1g};}else{var _1j=_1i.b,_1k=E(_1i.a),_1l=E(_1k.h);if(_1l<=_1f){_1h=_1j;continue;}else{_18=_1k.a;_19=_1k.b;_1a=_1k.c;_1b=_1k.d;_1c=_1k.e;_1d=_1k.f;_1e=_1k.g;_1f=_1l;_1g=_1k.i;_1h=_1j;continue;}}}},_1m=function(_1n,_1o,_1p,_1q,_1r,_1s,_1t,_1u,_1v,_1w){while(1){var _1x=E(_1w);if(!_1x._){return {_:0,a:_1n,b:_1o,c:_1p,d:_1q,e:_1r,f:_1s,g:_1t,h:_1u,i:_1v};}else{var _1y=_1x.b,_1z=E(_1x.a),_1A=E(_1z.h);if(_1A>=_1u){_1w=_1y;continue;}else{_1n=_1z.a;_1o=_1z.b;_1p=_1z.c;_1q=_1z.d;_1r=_1z.e;_1s=_1z.f;_1t=_1z.g;_1u=_1A;_1v=_1z.i;_1w=_1y;continue;}}}},_1B=function(_1C){var _1D=E(_1C);if(!_1D._){return true;}else{var _1E=_1D.b,_1F=E(E(_1D.a).a),_1G=_1F.b,_1H=E(_1F.a),_1I=function(_1J){if(E(_1H)==7){if(E(_1G)==1){return false;}else{return new F(function(){return _1B(_1E);});}}else{return new F(function(){return _1B(_1E);});}};if(E(_1H)==6){if(E(_1G)==1){return false;}else{return new F(function(){return _1I(_);});}}else{return new F(function(){return _1I(_);});}}},_1K=function(_1L,_1M){var _1N=E(E(_1L).a),_1O=_1N.b,_1P=E(_1N.a),_1Q=function(_1R){if(E(_1P)==7){if(E(_1O)==1){return false;}else{return new F(function(){return _1B(_1M);});}}else{return new F(function(){return _1B(_1M);});}};if(E(_1P)==6){if(E(_1O)==1){return false;}else{return new F(function(){return _1Q(_);});}}else{return new F(function(){return _1Q(_);});}},_1S=function(_1T){var _1U=E(_1T);if(!_1U._){return true;}else{var _1V=_1U.b,_1W=E(E(_1U.a).a),_1X=_1W.b,_1Y=E(_1W.a),_1Z=function(_20){var _21=function(_22){if(E(_1Y)==4){if(E(_1X)==1){return false;}else{return new F(function(){return _1S(_1V);});}}else{return new F(function(){return _1S(_1V);});}};if(E(_1Y)==3){if(E(_1X)==1){return false;}else{return new F(function(){return _21(_);});}}else{return new F(function(){return _21(_);});}};if(E(_1Y)==2){if(E(_1X)==1){return false;}else{return new F(function(){return _1Z(_);});}}else{return new F(function(){return _1Z(_);});}}},_23=function(_24,_25){var _26=E(E(_24).a),_27=_26.b,_28=E(_26.a),_29=function(_2a){var _2b=function(_2c){if(E(_28)==4){if(E(_27)==1){return false;}else{return new F(function(){return _1S(_25);});}}else{return new F(function(){return _1S(_25);});}};if(E(_28)==3){if(E(_27)==1){return false;}else{return new F(function(){return _2b(_);});}}else{return new F(function(){return _2b(_);});}};if(E(_28)==2){if(E(_27)==1){return false;}else{return new F(function(){return _29(_);});}}else{return new F(function(){return _29(_);});}},_2d=function(_2e){var _2f=E(_2e);if(!_2f._){return true;}else{var _2g=_2f.b,_2h=E(E(_2f.a).a),_2i=_2h.b,_2j=E(_2h.a),_2k=function(_2l){if(E(_2j)==7){if(E(_2i)==8){return false;}else{return new F(function(){return _2d(_2g);});}}else{return new F(function(){return _2d(_2g);});}};if(E(_2j)==6){if(E(_2i)==8){return false;}else{return new F(function(){return _2k(_);});}}else{return new F(function(){return _2k(_);});}}},_2m=function(_2n,_2o){var _2p=E(E(_2n).a),_2q=_2p.b,_2r=E(_2p.a),_2s=function(_2t){if(E(_2r)==7){if(E(_2q)==8){return false;}else{return new F(function(){return _2d(_2o);});}}else{return new F(function(){return _2d(_2o);});}};if(E(_2r)==6){if(E(_2q)==8){return false;}else{return new F(function(){return _2s(_);});}}else{return new F(function(){return _2s(_);});}},_2u=function(_2v){var _2w=E(_2v);if(!_2w._){return true;}else{var _2x=_2w.b,_2y=E(E(_2w.a).a),_2z=_2y.b,_2A=E(_2y.a),_2B=function(_2C){var _2D=function(_2E){if(E(_2A)==4){if(E(_2z)==8){return false;}else{return new F(function(){return _2u(_2x);});}}else{return new F(function(){return _2u(_2x);});}};if(E(_2A)==3){if(E(_2z)==8){return false;}else{return new F(function(){return _2D(_);});}}else{return new F(function(){return _2D(_);});}};if(E(_2A)==2){if(E(_2z)==1){return false;}else{return new F(function(){return _2B(_);});}}else{return new F(function(){return _2B(_);});}}},_2F=function(_2G,_2H){var _2I=E(E(_2G).a),_2J=_2I.b,_2K=E(_2I.a),_2L=function(_2M){var _2N=function(_2O){if(E(_2K)==4){if(E(_2J)==8){return false;}else{return new F(function(){return _2u(_2H);});}}else{return new F(function(){return _2u(_2H);});}};if(E(_2K)==3){if(E(_2J)==8){return false;}else{return new F(function(){return _2N(_);});}}else{return new F(function(){return _2N(_);});}};if(E(_2K)==2){if(E(_2J)==1){return false;}else{return new F(function(){return _2L(_);});}}else{return new F(function(){return _2L(_);});}},_2P=__Z,_2Q=new T(function(){return B(unCStr("base"));}),_2R=new T(function(){return B(unCStr("Control.Exception.Base"));}),_2S=new T(function(){return B(unCStr("PatternMatchFail"));}),_2T=new T5(0,new Long(18445595,3739165398,true),new Long(52003073,3246954884,true),_2Q,_2R,_2S),_2U=new T5(0,new Long(18445595,3739165398,true),new Long(52003073,3246954884,true),_2T,_2P,_2P),_2V=function(_2W){return E(_2U);},_2X=function(_2Y){return E(E(_2Y).a);},_2Z=function(_30,_31,_32){var _33=B(A1(_30,_)),_34=B(A1(_31,_)),_35=hs_eqWord64(_33.a,_34.a);if(!_35){return __Z;}else{var _36=hs_eqWord64(_33.b,_34.b);return (!_36)?__Z:new T1(1,_32);}},_37=function(_38){var _39=E(_38);return new F(function(){return _2Z(B(_2X(_39.a)),_2V,_39.b);});},_3a=function(_3b){return E(E(_3b).a);},_3c=function(_3d){return new T2(0,_3e,_3d);},_3f=function(_3g,_3h){return new F(function(){return _a(E(_3g).a,_3h);});},_3i=44,_3j=93,_3k=91,_3l=function(_3m,_3n,_3o){var _3p=E(_3n);if(!_3p._){return new F(function(){return unAppCStr("[]",_3o);});}else{var _3q=new T(function(){var _3r=new T(function(){var _3s=function(_3t){var _3u=E(_3t);if(!_3u._){return E(new T2(1,_3j,_3o));}else{var _3v=new T(function(){return B(A2(_3m,_3u.a,new T(function(){return B(_3s(_3u.b));})));});return new T2(1,_3i,_3v);}};return B(_3s(_3p.b));});return B(A2(_3m,_3p.a,_3r));});return new T2(1,_3k,_3q);}},_3w=function(_3x,_3y){return new F(function(){return _3l(_3f,_3x,_3y);});},_3z=function(_3A,_3B,_3C){return new F(function(){return _a(E(_3B).a,_3C);});},_3D=new T3(0,_3z,_3a,_3w),_3e=new T(function(){return new T5(0,_2V,_3D,_3c,_37,_3a);}),_3E=new T(function(){return B(unCStr("Non-exhaustive patterns in"));}),_3F=function(_3G){return E(E(_3G).c);},_3H=function(_3I,_3J){return new F(function(){return die(new T(function(){return B(A2(_3F,_3J,_3I));}));});},_3K=function(_3L,_3M){return new F(function(){return _3H(_3L,_3M);});},_3N=function(_3O,_3P){var _3Q=E(_3P);if(!_3Q._){return new T2(0,_2P,_2P);}else{var _3R=_3Q.a;if(!B(A1(_3O,_3R))){return new T2(0,_2P,_3Q);}else{var _3S=new T(function(){var _3T=B(_3N(_3O,_3Q.b));return new T2(0,_3T.a,_3T.b);});return new T2(0,new T2(1,_3R,new T(function(){return E(E(_3S).a);})),new T(function(){return E(E(_3S).b);}));}}},_3U=32,_3V=new T(function(){return B(unCStr("\n"));}),_3W=function(_3X){return (E(_3X)==124)?false:true;},_3Y=function(_3Z,_40){var _41=B(_3N(_3W,B(unCStr(_3Z)))),_42=_41.a,_43=function(_44,_45){var _46=new T(function(){var _47=new T(function(){return B(_a(_40,new T(function(){return B(_a(_45,_3V));},1)));});return B(unAppCStr(": ",_47));},1);return new F(function(){return _a(_44,_46);});},_48=E(_41.b);if(!_48._){return new F(function(){return _43(_42,_2P);});}else{if(E(_48.a)==124){return new F(function(){return _43(_42,new T2(1,_3U,_48.b));});}else{return new F(function(){return _43(_42,_2P);});}}},_49=function(_4a){return new F(function(){return _3K(new T1(0,new T(function(){return B(_3Y(_4a,_3E));})),_3e);});},_4b=new T(function(){return B(_49("Main.hs:(90,17)-(94,192)|function myrange"));}),_4c=function(_4d,_4e){while(1){var _4f=E(_4d);if(!_4f._){return E(_4e);}else{var _4g=new T2(1,_4f.a,_4e);_4d=_4f.b;_4e=_4g;continue;}}},_4h=new T(function(){return B(_4c(_2P,_2P));}),_4i=function(_4j,_4k,_4l,_4m){var _4n=new T(function(){return _4m>_4k;}),_4o=new T(function(){return _4k>_4m;});if(_4j!=_4l){if(_4k!=_4m){if(_4j>=_4l){if(_4l>=_4j){return E(_4b);}else{if(_4k>=_4m){if(_4l<=_4j){var _4p=function(_4q){var _4r=new T(function(){if(_4q!=_4j){return B(_4p(_4q+1|0));}else{return __Z;}});if(!E(_4n)){var _4s=function(_4t){while(1){var _4u=B((function(_4v){if((_4v-_4q|0)!=(_4k-_4j|0)){if(_4v!=_4k){var _4w=_4v+1|0;_4t=_4w;return __continue;}else{return E(_4r);}}else{return new T2(1,new T2(0,_4q,_4v),new T(function(){if(_4v!=_4k){return B(_4s(_4v+1|0));}else{return E(_4r);}}));}})(_4t));if(_4u!=__continue){return _4u;}}};return new F(function(){return _4s(_4m);});}else{return E(_4r);}};return new F(function(){return _4c(B(_4p(_4l)),_2P);});}else{return E(_4h);}}else{if(_4l<=_4j){var _4x=function(_4y){var _4z=new T(function(){if(_4y!=_4j){return B(_4x(_4y+1|0));}else{return __Z;}});if(!E(_4o)){var _4A=function(_4B){while(1){var _4C=B((function(_4D){if((_4y+_4D|0)!=(_4j+_4k|0)){if(_4D!=_4m){var _4E=_4D+1|0;_4B=_4E;return __continue;}else{return E(_4z);}}else{return new T2(1,new T2(0,_4y,_4D),new T(function(){if(_4D!=_4m){return B(_4A(_4D+1|0));}else{return E(_4z);}}));}})(_4B));if(_4C!=__continue){return _4C;}}};return new F(function(){return _4A(_4k);});}else{return E(_4z);}};return new F(function(){return _4x(_4l);});}else{return __Z;}}}}else{if(_4k>=_4m){if(_4j<=_4l){var _4F=function(_4G){var _4H=new T(function(){if(_4G!=_4l){return B(_4F(_4G+1|0));}else{return __Z;}});if(!E(_4n)){var _4I=function(_4J){while(1){var _4K=B((function(_4L){if((_4G+_4L|0)!=(_4j+_4k|0)){if(_4L!=_4k){var _4M=_4L+1|0;_4J=_4M;return __continue;}else{return E(_4H);}}else{return new T2(1,new T2(0,_4G,_4L),new T(function(){if(_4L!=_4k){return B(_4I(_4L+1|0));}else{return E(_4H);}}));}})(_4J));if(_4K!=__continue){return _4K;}}};return new F(function(){return _4I(_4m);});}else{return E(_4H);}};return new F(function(){return _4c(B(_4F(_4j)),_2P);});}else{return E(_4h);}}else{if(_4j<=_4l){var _4N=function(_4O){var _4P=new T(function(){if(_4O!=_4l){return B(_4N(_4O+1|0));}else{return __Z;}});if(!E(_4o)){var _4Q=function(_4R){while(1){var _4S=B((function(_4T){if((_4T-_4O|0)!=(_4k-_4j|0)){if(_4T!=_4m){var _4U=_4T+1|0;_4R=_4U;return __continue;}else{return E(_4P);}}else{return new T2(1,new T2(0,_4O,_4T),new T(function(){if(_4T!=_4m){return B(_4Q(_4T+1|0));}else{return E(_4P);}}));}})(_4R));if(_4S!=__continue){return _4S;}}};return new F(function(){return _4Q(_4k);});}else{return E(_4P);}};return new F(function(){return _4N(_4j);});}else{return __Z;}}}}else{if(_4j>=_4l){if(_4l<=_4j){var _4V=function(_4W){var _4X=new T(function(){if(_4W!=_4j){return B(_4V(_4W+1|0));}else{return __Z;}});if(!E(_4n)){var _4Y=function(_4Z){return new T2(1,new T2(0,_4W,_4Z),new T(function(){if(_4Z!=_4k){return B(_4Y(_4Z+1|0));}else{return E(_4X);}}));};return new F(function(){return _4Y(_4m);});}else{return E(_4X);}};return new F(function(){return _4c(B(_4V(_4l)),_2P);});}else{return E(_4h);}}else{if(_4j<=_4l){var _50=function(_51){var _52=new T(function(){if(_51!=_4l){return B(_50(_51+1|0));}else{return __Z;}}),_53=function(_54){return new T2(1,new T2(0,_51,_54),new T(function(){if(_54!=_4m){return B(_53(_54+1|0));}else{return E(_52);}}));};return new F(function(){return _53(_4m);});};return new F(function(){return _50(_4j);});}else{return __Z;}}}}else{if(_4k>=_4m){if(_4l<=_4j){var _55=function(_56){var _57=new T(function(){if(_56!=_4j){return B(_55(_56+1|0));}else{return __Z;}});if(!E(_4n)){var _58=function(_59){return new T2(1,new T2(0,_56,_59),new T(function(){if(_59!=_4k){return B(_58(_59+1|0));}else{return E(_57);}}));};return new F(function(){return _58(_4m);});}else{return E(_57);}};return new F(function(){return _4c(B(_55(_4l)),_2P);});}else{return E(_4h);}}else{if(_4j<=_4l){var _5a=function(_5b){var _5c=new T(function(){if(_5b!=_4l){return B(_5a(_5b+1|0));}else{return __Z;}});if(!E(_4o)){var _5d=function(_5e){return new T2(1,new T2(0,_5b,_5e),new T(function(){if(_5e!=_4m){return B(_5d(_5e+1|0));}else{return E(_5c);}}));};return new F(function(){return _5d(_4k);});}else{return E(_5c);}};return new F(function(){return _5a(_4j);});}else{return __Z;}}}},_5f=function(_5g,_5h,_5i,_5j,_5k,_5l,_5m,_5n,_5o,_5p,_5q){var _5r=E(_5q);if(!_5r._){return {_:0,a:_5h,b:_5i,c:_5j,d:_5k,e:_5l,f:_5m,g:_5n,h:_5o,i:_5p};}else{var _5s=_5r.a,_5t=_5r.b;if(!E(_5g)){var _5u=E(_5s),_5v=E(_5u.h),_5w=E(_5o);if(_5v>=_5w){return new F(function(){return _1m(_5h,_5i,_5j,_5k,_5l,_5m,_5n,_5w,_5p,_5t);});}else{return new F(function(){return _1m(_5u.a,_5u.b,_5u.c,_5u.d,_5u.e,_5u.f,_5u.g,_5v,_5u.i,_5t);});}}else{var _5x=E(_5s),_5y=E(_5x.h),_5z=E(_5o);if(_5y<=_5z){return new F(function(){return _17(_5h,_5i,_5j,_5k,_5l,_5m,_5n,_5z,_5p,_5t);});}else{return new F(function(){return _17(_5x.a,_5x.b,_5x.c,_5x.d,_5x.e,_5x.f,_5x.g,_5y,_5x.i,_5t);});}}}},_5A=new T(function(){return B(_49("Main.hs:(198,1)-(200,72)|function replace"));}),_5B=function(_5C,_5D,_5E){var _5F=E(_5C);switch(_5F){case -1:var _5G=E(_5E);return (_5G._==0)?E(_5A):E(_5G);case 0:var _5H=E(_5E);return (_5H._==0)?E(_5A):new T2(1,_5D,_5H.b);default:var _5I=E(_5E);return (_5I._==0)?E(_5A):new T2(1,_5I.a,new T(function(){return B(_5B(_5F-1|0,_5D,_5I.b));}));}},_5J=false,_5K=true,_5L=new T(function(){return B(unCStr(": empty list"));}),_5M=function(_5N){return new F(function(){return err(B(_a(_f,new T(function(){return B(_a(_5N,_5L));},1))));});},_5O=new T(function(){return B(unCStr("head"));}),_5P=new T(function(){return B(_5M(_5O));}),_5Q=function(_5R,_5S){while(1){var _5T=B((function(_5U,_5V){var _5W=E(_5V);if(!_5W._){return __Z;}else{var _5X=_5W.a,_5Y=_5W.b;if(!B(A1(_5U,_5X))){var _5Z=_5U;_5R=_5Z;_5S=_5Y;return __continue;}else{return new T2(1,_5X,new T(function(){return B(_5Q(_5U,_5Y));}));}}})(_5R,_5S));if(_5T!=__continue){return _5T;}}},_60=function(_61){while(1){var _62=B((function(_63){var _64=E(_63);if(!_64._){return true;}else{var _65=_64.b,_66=E(_64.a),_67=u_iswlower(E(_66.b));if(!E(_67)){var _68=E(_66.a),_69=_68.b,_6a=E(_68.a),_6b=function(_6c){var _6d=function(_6e){if(E(_6a)==5){if(E(_69)==8){return false;}else{return new F(function(){return _60(_65);});}}else{return new F(function(){return _60(_65);});}};if(E(_6a)==4){if(E(_69)==8){return false;}else{return new F(function(){return _6d(_);});}}else{return new F(function(){return _6d(_);});}};if(E(_6a)==3){if(E(_69)==8){return false;}else{return new F(function(){return _6b(_);});}}else{return new F(function(){return _6b(_);});}}else{_61=_65;return __continue;}}})(_61));if(_62!=__continue){return _62;}}},_6f=function(_6g){while(1){var _6h=E(_6g);if(!_6h._){return true;}else{if(!B(_60(_6h.a))){return false;}else{_6g=_6h.b;continue;}}}},_6i=function(_6j){while(1){var _6k=B((function(_6l){var _6m=E(_6l);if(!_6m._){return true;}else{var _6n=_6m.b,_6o=E(_6m.a),_6p=u_iswlower(E(_6o.b));if(!E(_6p)){var _6q=E(_6o.a),_6r=_6q.b,_6s=E(_6q.a),_6t=function(_6u){var _6v=function(_6w){if(E(_6s)==7){if(E(_6r)==8){return false;}else{return new F(function(){return _6i(_6n);});}}else{return new F(function(){return _6i(_6n);});}};if(E(_6s)==6){if(E(_6r)==8){return false;}else{return new F(function(){return _6v(_);});}}else{return new F(function(){return _6v(_);});}};if(E(_6s)==5){if(E(_6r)==8){return false;}else{return new F(function(){return _6t(_);});}}else{return new F(function(){return _6t(_);});}}else{_6j=_6n;return __continue;}}})(_6j));if(_6k!=__continue){return _6k;}}},_6x=function(_6y){while(1){var _6z=E(_6y);if(!_6z._){return true;}else{if(!B(_6i(_6z.a))){return false;}else{_6y=_6z.b;continue;}}}},_6A=function(_6B){while(1){var _6C=B((function(_6D){var _6E=E(_6D);if(!_6E._){return true;}else{var _6F=_6E.b,_6G=E(_6E.a),_6H=u_iswupper(E(_6G.b));if(!E(_6H)){var _6I=E(_6G.a),_6J=_6I.b,_6K=E(_6I.a),_6L=function(_6M){var _6N=function(_6O){if(E(_6K)==5){if(E(_6J)==1){return false;}else{return new F(function(){return _6A(_6F);});}}else{return new F(function(){return _6A(_6F);});}};if(E(_6K)==4){if(E(_6J)==1){return false;}else{return new F(function(){return _6N(_);});}}else{return new F(function(){return _6N(_);});}};if(E(_6K)==3){if(E(_6J)==1){return false;}else{return new F(function(){return _6L(_);});}}else{return new F(function(){return _6L(_);});}}else{_6B=_6F;return __continue;}}})(_6B));if(_6C!=__continue){return _6C;}}},_6P=function(_6Q){while(1){var _6R=E(_6Q);if(!_6R._){return true;}else{if(!B(_6A(_6R.a))){return false;}else{_6Q=_6R.b;continue;}}}},_6S=function(_6T){while(1){var _6U=B((function(_6V){var _6W=E(_6V);if(!_6W._){return true;}else{var _6X=_6W.b,_6Y=E(_6W.a),_6Z=u_iswupper(E(_6Y.b));if(!E(_6Z)){var _70=E(_6Y.a),_71=_70.b,_72=E(_70.a),_73=function(_74){var _75=function(_76){if(E(_72)==7){if(E(_71)==1){return false;}else{return new F(function(){return _6S(_6X);});}}else{return new F(function(){return _6S(_6X);});}};if(E(_72)==6){if(E(_71)==1){return false;}else{return new F(function(){return _75(_);});}}else{return new F(function(){return _75(_);});}};if(E(_72)==5){if(E(_71)==1){return false;}else{return new F(function(){return _73(_);});}}else{return new F(function(){return _73(_);});}}else{_6T=_6X;return __continue;}}})(_6T));if(_6U!=__continue){return _6U;}}},_77=function(_78){while(1){var _79=E(_78);if(!_79._){return true;}else{if(!B(_6S(_79.a))){return false;}else{_78=_79.b;continue;}}}},_7a=function(_7b){while(1){var _7c=E(_7b);if(!_7c._){return true;}else{if(!E(_7c.a)){return false;}else{_7b=_7c.b;continue;}}}},_7d=function(_7e,_7f){while(1){var _7g=E(_7e);if(!_7g._){return E(_7f);}else{var _7h=_7g.b;switch(E(E(_7g.a).b)){case 66:var _7i=_7f+3.75;_7e=_7h;_7f=_7i;continue;case 78:var _7i=_7f+3.5;_7e=_7h;_7f=_7i;continue;case 80:var _7i=_7f+1;_7e=_7h;_7f=_7i;continue;case 81:var _7i=_7f+9;_7e=_7h;_7f=_7i;continue;case 82:var _7i=_7f+5;_7e=_7h;_7f=_7i;continue;case 98:var _7i=_7f+(-3.75);_7e=_7h;_7f=_7i;continue;case 110:var _7i=_7f+(-3.5);_7e=_7h;_7f=_7i;continue;case 112:var _7i=_7f+(-1);_7e=_7h;_7f=_7i;continue;case 113:var _7i=_7f+(-9);_7e=_7h;_7f=_7i;continue;case 114:var _7i=_7f+(-5);_7e=_7h;_7f=_7i;continue;default:_7e=_7h;continue;}}}},_7j=function(_7k,_7l){while(1){var _7m=E(_7k);if(!_7m._){return E(_7l);}else{var _7n=_7m.b,_7o=E(_7m.a);if(E(_7o.b)==82){switch(E(E(_7o.a).a)){case 4:var _7p=_7l+0.5;_7k=_7n;_7l=_7p;continue;case 5:var _7p=_7l+0.5;_7k=_7n;_7l=_7p;continue;default:_7k=_7n;continue;}}else{_7k=_7n;continue;}}}},_7q=function(_7r,_7s){while(1){var _7t=E(_7r);if(!_7t._){return E(_7s);}else{var _7u=_7t.b,_7v=E(_7t.a);if(E(_7v.b)==114){switch(E(E(_7v.a).a)){case 4:var _7w=_7s+(-0.5);_7r=_7u;_7s=_7w;continue;case 5:var _7w=_7s+(-0.5);_7r=_7u;_7s=_7w;continue;default:_7r=_7u;continue;}}else{_7r=_7u;continue;}}}},_7x=function(_7y,_7z){while(1){var _7A=E(_7y);if(!_7A._){return E(_7z);}else{var _7B=_7A.b,_7C=E(_7A.a);if(E(_7C.b)==80){var _7D=E(_7C.a),_7E=E(_7D.b);if(_7E<6){switch(E(_7D.a)){case 4:if(_7E<4){_7y=_7B;continue;}else{var _7F=_7z+0.6;_7y=_7B;_7z=_7F;continue;}break;case 5:if(_7E<4){_7y=_7B;continue;}else{var _7F=_7z+0.6;_7y=_7B;_7z=_7F;continue;}break;default:_7y=_7B;continue;}}else{var _7F=_7z+0.6;_7y=_7B;_7z=_7F;continue;}}else{_7y=_7B;continue;}}}},_7G=function(_7H,_7I){while(1){var _7J=E(_7H);if(!_7J._){return E(_7I);}else{var _7K=_7J.b,_7L=E(_7J.a);if(E(_7L.b)==112){var _7M=E(_7L.a),_7N=E(_7M.b);if(_7N>3){switch(E(_7M.a)){case 4:if(_7N>5){_7H=_7K;continue;}else{var _7O=_7I+(-0.6000000238418579);_7H=_7K;_7I=_7O;continue;}break;case 5:if(_7N>5){_7H=_7K;continue;}else{var _7O=_7I+(-0.6000000238418579);_7H=_7K;_7I=_7O;continue;}break;default:_7H=_7K;continue;}}else{var _7O=_7I+(-0.6000000238418579);_7H=_7K;_7I=_7O;continue;}}else{_7H=_7K;continue;}}}},_7P=function(_7Q,_7R){while(1){var _7S=B((function(_7T,_7U){var _7V=E(_7T);if(!_7V._){return E(_7U);}else{var _7W=_7V.b,_7X=E(_7V.a),_7Y=function(_7Z){if(E(E(_7X.a).b)==1){return new F(function(){return _7P(_7W,_7Z+(-0.30000001192092896));});}else{return new F(function(){return _7P(_7W,_7Z);});}};switch(E(_7X.b)){case 66:return new F(function(){return _7Y(_7U);});break;case 78:return new F(function(){return _7Y(_7U);});break;default:var _80=_7U;_7Q=_7W;_7R=_80;return __continue;}}})(_7Q,_7R));if(_7S!=__continue){return _7S;}}},_81=function(_82,_83){while(1){var _84=B((function(_85,_86){var _87=E(_85);if(!_87._){return E(_86);}else{var _88=_87.b,_89=E(_87.a),_8a=function(_8b){if(E(E(_89.a).b)==8){return new F(function(){return _81(_88,_8b+0.3);});}else{return new F(function(){return _81(_88,_8b);});}};switch(E(_89.b)){case 98:return new F(function(){return _8a(_86);});break;case 110:return new F(function(){return _8a(_86);});break;default:var _8c=_86;_82=_88;_83=_8c;return __continue;}}})(_82,_83));if(_84!=__continue){return _84;}}},_8d=function(_8e,_8f,_8g,_8h,_8i,_8j,_8k,_8l){var _8m=new T(function(){var _8n=B(_7d(_8e,0)),_8o=B(_7j(_8e,0)),_8p=B(_7q(_8e,0)),_8q=B(_7x(_8e,0)),_8r=B(_7G(_8e,0)),_8s=B(_7P(_8e,0)),_8t=B(_81(_8e,0)),_8u=function(_8v){return (!B(_q(_8h,2)))?(!B(_q(_8h,3)))?(!B(_q(_8g,2)))?(!B(_q(_8g,3)))?_8n+_8o+_8p+_8q+_8r+_8s+_8t+_8v:_8n+_8o+_8p+_8q+_8r+_8s+_8t+_8v+0.5:(!B(_q(_8g,3)))?_8n+_8o+_8p+_8q+_8r+_8s+_8t+_8v+0.5:_8n+_8o+_8p+_8q+_8r+_8s+_8t+_8v+1:_8n+_8o+_8p+_8q+_8r+_8s+_8t+_8v+(-0.8999999761581421):_8n+_8o+_8p+_8q+_8r+_8s+_8t+_8v+(-0.8999999761581421);};if(!B(_q(_8h,0))){if(!B(_q(_8h,1))){var _8w=function(_8x){if(!B(_q(_8g,1))){return new F(function(){return _8u(_8x);});}else{return new F(function(){return _8u(_8x+(-0.5));});}};if(!B(_q(_8g,0))){return B(_8w(0));}else{return B(_8w(-0.5));}}else{return B(_8u(0.9));}}else{return B(_8u(0.9));}});return {_:0,a:_8e,b:_8f,c:_8g,d:_8h,e:_8i,f:_8j,g:_8m,h:_8k,i:_8l};},_8y=function(_8z){var _8A=E(_8z),_8B=B(_8d(_8A.a,_8A.b,_8A.c,_8A.d,_8A.e,_8A.f,_8A.h,_8A.i));return {_:0,a:_8B.a,b:_8B.b,c:_8B.c,d:_8B.d,e:_8B.e,f:_8B.f,g:_8B.g,h:_8B.h,i:_8B.i};},_8C=function(_8D,_8E){var _8F=E(_8E);return (_8F._==0)?__Z:new T2(1,_8D,new T(function(){return B(_8C(_8F.a,_8F.b));}));},_8G=new T(function(){return B(unCStr("init"));}),_8H=new T(function(){return B(_5M(_8G));}),_8I=function(_8J){return E(E(_8J).a);},_8K=0,_8L=2,_8M=3,_8N=4,_8O=5,_8P=6,_8Q=0,_8R=new T2(0,_8Q,_8Q),_8S=function(_8T,_8U){switch(E(_8T)){case 5:return (E(_8U)==1)?false:true;case 8:return (E(_8U)==1)?false:true;default:return true;}},_8V=function(_8W){var _8X=E(E(_8W).a);return new F(function(){return _8S(E(_8X.a),_8X.b);});},_8Y=82,_8Z=1,_90=new T2(0,_8P,_8Z),_91=new T2(0,_90,_8Y),_92=75,_93=7,_94=new T2(0,_93,_8Z),_95=new T2(0,_94,_92),_96=new T2(0,_8N,_8Z),_97=new T2(0,_96,_8Y),_98=new T2(0,_8M,_8Z),_99=new T2(0,_98,_92),_9a=114,_9b=8,_9c=new T2(0,_8P,_9b),_9d=new T2(0,_9c,_9a),_9e=107,_9f=new T2(0,_93,_9b),_9g=new T2(0,_9f,_9e),_9h=new T2(0,_8N,_9b),_9i=new T2(0,_9h,_8Y),_9j=new T2(0,_8M,_9b),_9k=new T2(0,_9j,_9e),_9l=function(_9m,_9n){if(_9m<=_9n){var _9o=function(_9p){return new T2(1,_9p,new T(function(){if(_9p!=_9n){return B(_9o(_9p+1|0));}else{return __Z;}}));};return new F(function(){return _9o(_9m);});}else{return __Z;}},_9q=new T(function(){return B(_9l(-8,8));}),_9r=function(_9s){var _9t=new T(function(){var _9u=E(_9s);if(_9u==8){return __Z;}else{return B(_9r(_9u+1|0));}}),_9v=function(_9w){return new T2(1,new T2(0,_9s,_9w),new T(function(){var _9x=E(_9w);if(!_9x){return E(_9t);}else{return B(_9v(_9x+1|0));}}));};return new F(function(){return _9v(0);});},_9y=new T(function(){return B(_9r(-8));}),_9z=function(_9A){var _9B=new T(function(){var _9C=E(_9A);if(!_9C){return __Z;}else{return B(_9z(_9C+1|0));}}),_9D=function(_9E){return new T2(1,new T2(0,_9A,_9E),new T(function(){var _9F=E(_9E);if(_9F==8){return E(_9B);}else{return B(_9D(_9F+1|0));}}));};return new F(function(){return _9D(-8);});},_9G=new T(function(){return B(_9z(0));}),_9H=81,_9I=78,_9J=66,_9K=function(_9L){var _9M=new T(function(){var _9N=E(_9L);if(_9N==8){return __Z;}else{return B(_9K(_9N+1|0));}}),_9O=function(_9P){return new T2(1,new T2(0,_9L,_9P),new T(function(){var _9Q=E(_9P);if(!_9Q){return E(_9M);}else{return B(_9O(_9Q+1|0));}}));};return new F(function(){return _9O(0);});},_9R=new T(function(){return B(_9K(-8));}),_9S=function(_9T){var _9U=new T(function(){var _9V=E(_9T);if(!_9V){return __Z;}else{return B(_9S(_9V+1|0));}}),_9W=function(_9X){return new T2(1,new T2(0,_9T,_9X),new T(function(){var _9Y=E(_9X);if(_9Y==8){return E(_9U);}else{return B(_9W(_9Y+1|0));}}));};return new F(function(){return _9W(-8);});},_9Z=new T(function(){return B(_9S(0));}),_a0=80,_a1=function(_a2){var _a3=new T(function(){var _a4=E(_a2);if(_a4==8){return __Z;}else{return B(_a1(_a4+1|0));}}),_a5=function(_a6){return new T2(1,new T2(0,_a2,_a6),new T(function(){var _a7=E(_a6);if(!_a7){return E(_a3);}else{return B(_a5(_a7+1|0));}}));};return new F(function(){return _a5(0);});},_a8=new T(function(){return B(_a1(-8));}),_a9=function(_aa){var _ab=new T(function(){var _ac=E(_aa);if(!_ac){return __Z;}else{return B(_a9(_ac+1|0));}}),_ad=function(_ae){return new T2(1,new T2(0,_aa,_ae),new T(function(){var _af=E(_ae);if(_af==8){return E(_ab);}else{return B(_ad(_af+1|0));}}));};return new F(function(){return _ad(-8);});},_ag=new T(function(){return B(_a9(0));}),_ah=113,_ai=110,_aj=98,_ak=function(_al){var _am=new T(function(){var _an=E(_al);if(_an==8){return __Z;}else{return B(_ak(_an+1|0));}}),_ao=function(_ap){return new T2(1,new T2(0,_al,_ap),new T(function(){var _aq=E(_ap);if(!_aq){return E(_am);}else{return B(_ao(_aq+1|0));}}));};return new F(function(){return _ao(0);});},_ar=new T(function(){return B(_ak(-8));}),_as=function(_at){var _au=new T(function(){var _av=E(_at);if(!_av){return __Z;}else{return B(_as(_av+1|0));}}),_aw=function(_ax){return new T2(1,new T2(0,_at,_ax),new T(function(){var _ay=E(_ax);if(_ay==8){return E(_au);}else{return B(_aw(_ay+1|0));}}));};return new F(function(){return _aw(-8);});},_az=new T(function(){return B(_as(0));}),_aA=112,_aB=-2147268864,_aC=2147268864,_aD=function(_aE,_aF){var _aG=E(_aF);return (_aG._==0)?__Z:new T2(1,new T(function(){return B(A1(_aE,_aG.a));}),new T(function(){return B(_aD(_aE,_aG.b));}));},_aH=function(_aI){return (!E(_aI))?true:false;},_aJ=new T(function(){return B(unCStr("tail"));}),_aK=new T(function(){return B(_5M(_aJ));}),_aL=new T2(1,_2P,_2P),_aM=function(_aN,_aO){var _aP=function(_aQ,_aR){var _aS=E(_aQ);if(!_aS._){return E(_aR);}else{var _aT=_aS.a,_aU=E(_aR);if(!_aU._){return E(_aS);}else{var _aV=_aU.a;return (B(A2(_aN,_aT,_aV))==2)?new T2(1,_aV,new T(function(){return B(_aP(_aS,_aU.b));})):new T2(1,_aT,new T(function(){return B(_aP(_aS.b,_aU));}));}}},_aW=function(_aX){var _aY=E(_aX);if(!_aY._){return __Z;}else{var _aZ=E(_aY.b);return (_aZ._==0)?E(_aY):new T2(1,new T(function(){return B(_aP(_aY.a,_aZ.a));}),new T(function(){return B(_aW(_aZ.b));}));}},_b0=new T(function(){return B(_b1(B(_aW(_2P))));}),_b1=function(_b2){while(1){var _b3=E(_b2);if(!_b3._){return E(_b0);}else{if(!E(_b3.b)._){return E(_b3.a);}else{_b2=B(_aW(_b3));continue;}}}},_b4=new T(function(){return B(_b5(_2P));}),_b6=function(_b7,_b8,_b9){while(1){var _ba=B((function(_bb,_bc,_bd){var _be=E(_bd);if(!_be._){return new T2(1,new T2(1,_bb,_bc),_b4);}else{var _bf=_be.a;if(B(A2(_aN,_bb,_bf))==2){var _bg=new T2(1,_bb,_bc);_b7=_bf;_b8=_bg;_b9=_be.b;return __continue;}else{return new T2(1,new T2(1,_bb,_bc),new T(function(){return B(_b5(_be));}));}}})(_b7,_b8,_b9));if(_ba!=__continue){return _ba;}}},_bh=function(_bi,_bj,_bk){while(1){var _bl=B((function(_bm,_bn,_bo){var _bp=E(_bo);if(!_bp._){return new T2(1,new T(function(){return B(A1(_bn,new T2(1,_bm,_2P)));}),_b4);}else{var _bq=_bp.a,_br=_bp.b;switch(B(A2(_aN,_bm,_bq))){case 0:_bi=_bq;_bj=function(_bs){return new F(function(){return A1(_bn,new T2(1,_bm,_bs));});};_bk=_br;return __continue;case 1:_bi=_bq;_bj=function(_bt){return new F(function(){return A1(_bn,new T2(1,_bm,_bt));});};_bk=_br;return __continue;default:return new T2(1,new T(function(){return B(A1(_bn,new T2(1,_bm,_2P)));}),new T(function(){return B(_b5(_bp));}));}}})(_bi,_bj,_bk));if(_bl!=__continue){return _bl;}}},_b5=function(_bu){var _bv=E(_bu);if(!_bv._){return E(_aL);}else{var _bw=_bv.a,_bx=E(_bv.b);if(!_bx._){return new T2(1,_bv,_2P);}else{var _by=_bx.a,_bz=_bx.b;if(B(A2(_aN,_bw,_by))==2){return new F(function(){return _b6(_by,new T2(1,_bw,_2P),_bz);});}else{return new F(function(){return _bh(_by,function(_bA){return new T2(1,_bw,_bA);},_bz);});}}}};return new F(function(){return _b1(B(_b5(_aO)));});},_bB=2147483647,_bC=-2147483648,_bD=function(_bE,_bF,_bG,_bH,_bI,_bJ,_bK,_bL,_bM,_bN,_bO,_bP){var _bQ=new T(function(){return B(_q(_bK,2));}),_bR=new T(function(){return B(_q(_bK,3));}),_bS=new T(function(){return B(_q(_bK,0));}),_bT=new T(function(){return B(_q(_bK,1));});if(_bE>0){var _bU=E(_bI);if(!_bU._){return {_:0,a:_2P,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:new T(function(){if(!E(_bJ)){return E(_bC);}else{return E(_bB);}}),i:_2P};}else{var _bV=_bU.a,_bW=_bU.b,_bX=new T(function(){var _bY=E(_bV),_bZ=_bY.a,_c0=E(_bY.b);if(!E(_bJ)){if(E(_c0)==107){return new T2(0,_bZ,_c0);}else{var _c1=function(_c2){while(1){var _c3=E(_c2);if(!_c3._){return E(_5P);}else{var _c4=E(_c3.a),_c5=E(_c4.b);if(E(_c5)==107){return new T2(0,_c4.a,_c5);}else{_c2=_c3.b;continue;}}}},_c6=B(_c1(_bW));return new T2(0,_c6.a,_c6.b);}}else{if(E(_c0)==75){return new T2(0,_bZ,_c0);}else{var _c7=function(_c8){while(1){var _c9=E(_c8);if(!_c9._){return E(_5P);}else{var _ca=E(_c9.a),_cb=E(_ca.b);if(E(_cb)==75){return new T2(0,_ca.a,_cb);}else{_c8=_c9.b;continue;}}}},_cc=B(_c7(_bW));return new T2(0,_cc.a,_cc.b);}}}),_cd=new T(function(){if(!B(_7a(_bK))){var _ce=function(_cf){var _cg=function(_ch){var _ci=function(_cj){if(!E(_bJ)){if(!E(_bR)){if(!B(_2F(_bV,_bW))){return __Z;}else{var _ck=new T(function(){var _cl=function(_cm){var _cn=E(_cm),_co=E(_cn.a),_cp=_co.b,_cq=E(_co.a),_cr=function(_cs){var _ct=E(_bX),_cu=E(_ct.a);return (_cq!=E(_cu.a))?true:(E(_cp)!=E(_cu.b))?true:(E(_cn.b)!=E(_ct.b))?true:false;};if(E(_cq)==1){if(E(_cp)==8){return false;}else{return new F(function(){return _cr(_);});}}else{return new F(function(){return _cr(_);});}};return B(_5Q(_cl,_bU));});return new T2(1,{_:0,a:new T2(1,_9k,new T2(1,_9i,_ck)),b:_5K,c:new T(function(){return B(_5B(2,_5K,B(_5B(3,_5K,_bK))));}),d:new T(function(){return B(_5B(3,_5K,_bL));}),e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_2P);}}else{return __Z;}}else{return __Z;}};if(!E(_bJ)){if(!E(_bQ)){if(!B(_2m(_bV,_bW))){return new F(function(){return _ci(_);});}else{var _cv=new T(function(){var _cw=function(_cx){var _cy=E(_cx),_cz=E(_cy.a),_cA=_cz.b,_cB=E(_cz.a),_cC=function(_cD){var _cE=E(_bX),_cF=E(_cE.a);return (_cB!=E(_cF.a))?true:(E(_cA)!=E(_cF.b))?true:(E(_cy.b)!=E(_cE.b))?true:false;};if(E(_cB)==8){if(E(_cA)==8){return false;}else{return new F(function(){return _cC(_);});}}else{return new F(function(){return _cC(_);});}};return B(_5Q(_cw,_bU));});return new T2(1,{_:0,a:new T2(1,_9g,new T2(1,_9d,_cv)),b:_5K,c:new T(function(){return B(_5B(2,_5K,B(_5B(3,_5K,_bK))));}),d:new T(function(){return B(_5B(2,_5K,_bL));}),e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_2P);}}else{return new F(function(){return _ci(_);});}}else{return new F(function(){return _ci(_);});}};if(!E(_bJ)){return new F(function(){return _cg(_);});}else{if(!E(_bT)){if(!B(_23(_bV,_bW))){return new F(function(){return _cg(_);});}else{var _cG=new T(function(){var _cH=function(_cI){var _cJ=E(_cI),_cK=E(_cJ.a),_cL=_cK.b,_cM=E(_cK.a),_cN=function(_cO){var _cP=E(_bX),_cQ=E(_cP.a);return (_cM!=E(_cQ.a))?true:(E(_cL)!=E(_cQ.b))?true:(E(_cJ.b)!=E(_cP.b))?true:false;};if(E(_cM)==1){if(E(_cL)==1){return false;}else{return new F(function(){return _cN(_);});}}else{return new F(function(){return _cN(_);});}};return B(_5Q(_cH,_bU));});return new T2(1,{_:0,a:new T2(1,_99,new T2(1,_97,_cG)),b:_5J,c:new T(function(){return B(_5B(0,_5K,B(_5B(1,_5K,_bK))));}),d:new T(function(){return B(_5B(1,_5K,_bL));}),e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_2P);}}else{return new F(function(){return _cg(_);});}}};if(!E(_bJ)){return B(_ce(_));}else{if(!E(_bS)){if(!B(_1K(_bV,_bW))){return B(_ce(_));}else{return new T2(1,{_:0,a:new T2(1,_95,new T2(1,_91,new T(function(){return B(_5Q(_8V,_bU));}))),b:_5J,c:new T(function(){return B(_5B(0,_5K,B(_5B(1,_5K,_bK))));}),d:new T(function(){return B(_5B(0,_5K,_bL));}),e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_2P);}}else{return B(_ce(_));}}}else{return __Z;}});if(!E(_bJ)){var _cR=new T(function(){var _cS=new T(function(){var _cT=new T(function(){var _cU=new T(function(){var _cV=new T(function(){var _cW=new T(function(){var _cX=new T(function(){var _cY=new T(function(){var _cZ=new T(function(){return B(_5B(3,_5K,B(_5B(2,_5K,_bK))));}),_d0=function(_d1,_d2,_d3){var _d4=E(_bX),_d5=E(_d4.a),_d6=E(_d5.a),_d7=_d6+_d1|0;if(_d7<1){return E(_d3);}else{if(_d7>8){return E(_d3);}else{var _d8=E(_d5.b),_d9=_d8+_d2|0;if(_d9<1){return E(_d3);}else{if(_d9>8){return E(_d3);}else{var _da=function(_db){while(1){var _dc=E(_db);if(!_dc._){return true;}else{var _dd=_dc.b,_de=E(_dc.a),_df=E(_de.a);if(E(_df.a)!=_d7){_db=_dd;continue;}else{if(E(_df.b)!=_d9){_db=_dd;continue;}else{var _dg=u_iswupper(E(_de.b));if(!E(_dg)){return false;}else{_db=_dd;continue;}}}}}};if(!B((function(_dh,_di){var _dj=E(_dh),_dk=E(_dj.a);if(E(_dk.a)!=_d7){return new F(function(){return _da(_di);});}else{if(E(_dk.b)!=_d9){return new F(function(){return _da(_di);});}else{var _dl=u_iswupper(E(_dj.b));if(!E(_dl)){return false;}else{return new F(function(){return _da(_di);});}}}})(_bV,_bW))){return E(_d3);}else{var _dm=new T(function(){var _dn=function(_do){while(1){var _dp=E(_do);if(!_dp._){return false;}else{var _dq=_dp.b,_dr=E(E(_dp.a).a);if(E(_dr.a)!=_d7){_do=_dq;continue;}else{if(E(_dr.b)!=_d9){_do=_dq;continue;}else{return true;}}}}};if(!B((function(_ds,_dt){var _du=E(E(_ds).a);if(E(_du.a)!=_d7){return new F(function(){return _dn(_dt);});}else{if(E(_du.b)!=_d9){return new F(function(){return _dn(_dt);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_dv=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_d7)==8){if(E(_d9)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_d7)==1){if(E(_d9)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_cZ))));}),_dw=new T(function(){var _dx=function(_dy){var _dz=E(_dy),_dA=E(_dz.a),_dB=_dA.b,_dC=E(_dA.a),_dD=function(_dE){return (_dC!=_d6)?true:(E(_dB)!=_d8)?true:(E(_dz.b)!=E(_d4.b))?true:false;};if(_dC!=_d7){return new F(function(){return _dD(_);});}else{if(E(_dB)!=_d9){return new F(function(){return _dD(_);});}else{return false;}}};return B(_5Q(_dx,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_d7,_d9),_9e),_dw),b:_5K,c:_dv,d:_bL,e:_dm,f:_8R,g:_8K,h:_8K,i:_2P},_d3);}}}}}},_dF=new T(function(){var _dG=new T(function(){var _dH=new T(function(){var _dI=new T(function(){var _dJ=new T(function(){var _dK=new T(function(){return B(_d0(-1,-1,new T(function(){return B(_d0(-1,0,_cd));})));});return B(_d0(0,-1,_dK));});return B(_d0(1,-1,_dJ));});return B(_d0(1,0,_dI));});return B(_d0(1,1,_dH));});return B(_d0(0,1,_dG));});return B(_d0(-1,1,_dF));}),_dL=function(_dM){while(1){var _dN=B((function(_dO){var _dP=E(_dO);if(!_dP._){return true;}else{var _dQ=_dP.b,_dR=E(E(_bV).a),_dS=E(_dP.a),_dT=_dS.b,_dU=E(_dS.a);if(E(_dR.a)!=_dU){var _dV=function(_dW){while(1){var _dX=E(_dW);if(!_dX._){return true;}else{var _dY=_dX.b,_dZ=E(E(_dX.a).a);if(E(_dZ.a)!=_dU){_dW=_dY;continue;}else{if(E(_dZ.b)!=E(_dT)){_dW=_dY;continue;}else{return false;}}}}};if(!B(_dV(_bW))){return false;}else{_dM=_dQ;return __continue;}}else{var _e0=E(_dT);if(E(_dR.b)!=_e0){var _e1=function(_e2){while(1){var _e3=E(_e2);if(!_e3._){return true;}else{var _e4=_e3.b,_e5=E(E(_e3.a).a);if(E(_e5.a)!=_dU){_e2=_e4;continue;}else{if(E(_e5.b)!=_e0){_e2=_e4;continue;}else{return false;}}}}};if(!B(_e1(_bW))){return false;}else{_dM=_dQ;return __continue;}}else{return false;}}}})(_dM));if(_dN!=__continue){return _dN;}}},_e6=function(_e7){var _e8=E(_e7);if(!_e8._){return E(_cY);}else{var _e9=E(_e8.a),_ea=_e9.a,_eb=new T(function(){return B(_e6(_e8.b));});if(E(_e9.b)==113){var _ec=function(_ed,_ee,_ef){var _eg=E(_ea),_eh=E(_eg.a),_ei=_eh+_ed|0;if(_ei<1){return E(_ef);}else{if(_ei>8){return E(_ef);}else{var _ej=E(_eg.b),_ek=_ej+_ee|0;if(_ek<1){return E(_ef);}else{if(_ek>8){return E(_ef);}else{var _el=B(_4i(_eh,_ej,_ei,_ek));if(!_el._){return E(_aK);}else{var _em=E(_el.b);if(!_em._){return E(_8H);}else{if(!B(_dL(B(_8C(_em.a,_em.b))))){return E(_ef);}else{var _en=function(_eo){while(1){var _ep=E(_eo);if(!_ep._){return true;}else{var _eq=_ep.b,_er=E(_ep.a),_es=E(_er.a);if(E(_es.a)!=_ei){_eo=_eq;continue;}else{if(E(_es.b)!=_ek){_eo=_eq;continue;}else{var _et=u_iswupper(E(_er.b));if(!E(_et)){return false;}else{_eo=_eq;continue;}}}}}};if(!B((function(_eu,_ev){var _ew=E(_eu),_ex=E(_ew.a);if(E(_ex.a)!=_ei){return new F(function(){return _en(_ev);});}else{if(E(_ex.b)!=_ek){return new F(function(){return _en(_ev);});}else{var _ey=u_iswupper(E(_ew.b));if(!E(_ey)){return false;}else{return new F(function(){return _en(_ev);});}}}})(_bV,_bW))){return E(_ef);}else{var _ez=new T(function(){var _eA=function(_eB){while(1){var _eC=E(_eB);if(!_eC._){return false;}else{var _eD=_eC.b,_eE=E(E(_eC.a).a);if(E(_eE.a)!=_ei){_eB=_eD;continue;}else{if(E(_eE.b)!=_ek){_eB=_eD;continue;}else{return true;}}}}};if(!B((function(_eF,_eG){var _eH=E(E(_eF).a);if(E(_eH.a)!=_ei){return new F(function(){return _eA(_eG);});}else{if(E(_eH.b)!=_ek){return new F(function(){return _eA(_eG);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_eI=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_ei)==8){if(E(_ek)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_ei)==1){if(E(_ek)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_eJ=new T(function(){var _eK=function(_eL){var _eM=E(_eL),_eN=E(_eM.a),_eO=_eN.b,_eP=E(_eN.a),_eQ=function(_eR){return (_eP!=_eh)?true:(E(_eO)!=_ej)?true:(E(_eM.b)==113)?false:true;};if(_eP!=_ei){return new F(function(){return _eQ(_);});}else{if(E(_eO)!=_ek){return new F(function(){return _eQ(_);});}else{return false;}}};return B(_5Q(_eK,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_ei,_ek),_ah),_eJ),b:_5K,c:_eI,d:_bL,e:_ez,f:_8R,g:_8K,h:_8K,i:_2P},_ef);}}}}}}}}},_eS=new T(function(){var _eT=new T(function(){var _eU=function(_eV,_eW,_eX){var _eY=E(_eV);if(!_eY){var _eZ=E(_eW);if(!_eZ){return E(_eX);}else{return new F(function(){return _ec(0,_eZ,_eX);});}}else{var _f0=E(_ea),_f1=E(_f0.a),_f2=_f1+_eY|0;if(_f2<1){return E(_eX);}else{if(_f2>8){return E(_eX);}else{var _f3=E(_f0.b),_f4=_f3+E(_eW)|0;if(_f4<1){return E(_eX);}else{if(_f4>8){return E(_eX);}else{var _f5=B(_4i(_f1,_f3,_f2,_f4));if(!_f5._){return E(_aK);}else{var _f6=E(_f5.b);if(!_f6._){return E(_8H);}else{if(!B(_dL(B(_8C(_f6.a,_f6.b))))){return E(_eX);}else{var _f7=function(_f8){while(1){var _f9=E(_f8);if(!_f9._){return true;}else{var _fa=_f9.b,_fb=E(_f9.a),_fc=E(_fb.a);if(E(_fc.a)!=_f2){_f8=_fa;continue;}else{if(E(_fc.b)!=_f4){_f8=_fa;continue;}else{var _fd=u_iswupper(E(_fb.b));if(!E(_fd)){return false;}else{_f8=_fa;continue;}}}}}};if(!B((function(_fe,_ff){var _fg=E(_fe),_fh=E(_fg.a);if(E(_fh.a)!=_f2){return new F(function(){return _f7(_ff);});}else{if(E(_fh.b)!=_f4){return new F(function(){return _f7(_ff);});}else{var _fi=u_iswupper(E(_fg.b));if(!E(_fi)){return false;}else{return new F(function(){return _f7(_ff);});}}}})(_bV,_bW))){return E(_eX);}else{var _fj=new T(function(){var _fk=function(_fl){while(1){var _fm=E(_fl);if(!_fm._){return false;}else{var _fn=_fm.b,_fo=E(E(_fm.a).a);if(E(_fo.a)!=_f2){_fl=_fn;continue;}else{if(E(_fo.b)!=_f4){_fl=_fn;continue;}else{return true;}}}}};if(!B((function(_fp,_fq){var _fr=E(E(_fp).a);if(E(_fr.a)!=_f2){return new F(function(){return _fk(_fq);});}else{if(E(_fr.b)!=_f4){return new F(function(){return _fk(_fq);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_fs=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_f2)==8){if(E(_f4)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_f2)==1){if(E(_f4)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_ft=new T(function(){var _fu=function(_fv){var _fw=E(_fv),_fx=E(_fw.a),_fy=_fx.b,_fz=E(_fx.a),_fA=function(_fB){return (_fz!=_f1)?true:(E(_fy)!=_f3)?true:(E(_fw.b)==113)?false:true;};if(_fz!=_f2){return new F(function(){return _fA(_);});}else{if(E(_fy)!=_f4){return new F(function(){return _fA(_);});}else{return false;}}};return B(_5Q(_fu,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_f2,_f4),_ah),_ft),b:_5K,c:_fs,d:_bL,e:_fj,f:_8R,g:_8K,h:_8K,i:_2P},_eX);}}}}}}}}}},_fC=new T(function(){var _fD=function(_fE){var _fF=E(_fE);if(!_fF._){return E(_eb);}else{var _fG=E(_fF.a);return new F(function(){return _eU(E(_fG.a),_fG.b,new T(function(){return B(_fD(_fF.b));}));});}};return B(_fD(_ag));}),_fH=function(_fI){var _fJ=E(_fI);if(!_fJ._){return E(_fC);}else{var _fK=E(_fJ.a);return new F(function(){return _eU(E(_fK.a),_fK.b,new T(function(){return B(_fH(_fJ.b));}));});}};return B(_fH(_a8));}),_fL=function(_fM){while(1){var _fN=B((function(_fO){var _fP=E(_fO);if(!_fP._){return E(_eT);}else{var _fQ=_fP.b,_fR=E(_fP.a);if(!_fR){_fM=_fQ;return __continue;}else{return new F(function(){return _ec(_fR, -_fR,new T(function(){return B(_fL(_fQ));}));});}}})(_fM));if(_fN!=__continue){return _fN;}}};return B(_fL(_9q));}),_fS=function(_fT){while(1){var _fU=B((function(_fV){var _fW=E(_fV);if(!_fW._){return E(_eS);}else{var _fX=_fW.b,_fY=E(_fW.a);if(!_fY){_fT=_fX;return __continue;}else{return new F(function(){return _ec(_fY,_fY,new T(function(){return B(_fS(_fX));}));});}}})(_fT));if(_fU!=__continue){return _fU;}}};return new F(function(){return _fS(_9q);});}else{return E(_eb);}}},_fZ=function(_g0,_g1){var _g2=E(_g0),_g3=_g2.a,_g4=new T(function(){return B(_e6(_g1));});if(E(_g2.b)==113){var _g5=function(_g6,_g7,_g8){var _g9=E(_g3),_ga=E(_g9.a),_gb=_ga+_g6|0;if(_gb<1){return E(_g8);}else{if(_gb>8){return E(_g8);}else{var _gc=E(_g9.b),_gd=_gc+_g7|0;if(_gd<1){return E(_g8);}else{if(_gd>8){return E(_g8);}else{var _ge=B(_4i(_ga,_gc,_gb,_gd));if(!_ge._){return E(_aK);}else{var _gf=E(_ge.b);if(!_gf._){return E(_8H);}else{if(!B(_dL(B(_8C(_gf.a,_gf.b))))){return E(_g8);}else{var _gg=function(_gh){while(1){var _gi=E(_gh);if(!_gi._){return true;}else{var _gj=_gi.b,_gk=E(_gi.a),_gl=E(_gk.a);if(E(_gl.a)!=_gb){_gh=_gj;continue;}else{if(E(_gl.b)!=_gd){_gh=_gj;continue;}else{var _gm=u_iswupper(E(_gk.b));if(!E(_gm)){return false;}else{_gh=_gj;continue;}}}}}};if(!B(_gg(_bU))){return E(_g8);}else{var _gn=new T(function(){var _go=function(_gp){while(1){var _gq=E(_gp);if(!_gq._){return false;}else{var _gr=_gq.b,_gs=E(E(_gq.a).a);if(E(_gs.a)!=_gb){_gp=_gr;continue;}else{if(E(_gs.b)!=_gd){_gp=_gr;continue;}else{return true;}}}}};if(!B(_go(_bU))){return E(_8L);}else{return E(_8Z);}}),_gt=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_gb)==8){if(E(_gd)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_gb)==1){if(E(_gd)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_gu=new T(function(){var _gv=function(_gw){var _gx=E(_gw),_gy=E(_gx.a),_gz=_gy.b,_gA=E(_gy.a),_gB=function(_gC){return (_gA!=_ga)?true:(E(_gz)!=_gc)?true:(E(_gx.b)==113)?false:true;};if(_gA!=_gb){return new F(function(){return _gB(_);});}else{if(E(_gz)!=_gd){return new F(function(){return _gB(_);});}else{return false;}}};return B(_5Q(_gv,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_gb,_gd),_ah),_gu),b:_5K,c:_gt,d:_bL,e:_gn,f:_8R,g:_8K,h:_8K,i:_2P},_g8);}}}}}}}}},_gD=new T(function(){var _gE=new T(function(){var _gF=function(_gG,_gH,_gI){var _gJ=E(_gG);if(!_gJ){var _gK=E(_gH);if(!_gK){return E(_gI);}else{return new F(function(){return _g5(0,_gK,_gI);});}}else{var _gL=E(_g3),_gM=E(_gL.a),_gN=_gM+_gJ|0;if(_gN<1){return E(_gI);}else{if(_gN>8){return E(_gI);}else{var _gO=E(_gL.b),_gP=_gO+E(_gH)|0;if(_gP<1){return E(_gI);}else{if(_gP>8){return E(_gI);}else{var _gQ=B(_4i(_gM,_gO,_gN,_gP));if(!_gQ._){return E(_aK);}else{var _gR=E(_gQ.b);if(!_gR._){return E(_8H);}else{if(!B(_dL(B(_8C(_gR.a,_gR.b))))){return E(_gI);}else{var _gS=function(_gT){while(1){var _gU=E(_gT);if(!_gU._){return true;}else{var _gV=_gU.b,_gW=E(_gU.a),_gX=E(_gW.a);if(E(_gX.a)!=_gN){_gT=_gV;continue;}else{if(E(_gX.b)!=_gP){_gT=_gV;continue;}else{var _gY=u_iswupper(E(_gW.b));if(!E(_gY)){return false;}else{_gT=_gV;continue;}}}}}};if(!B((function(_gZ,_h0){var _h1=E(_gZ),_h2=E(_h1.a);if(E(_h2.a)!=_gN){return new F(function(){return _gS(_h0);});}else{if(E(_h2.b)!=_gP){return new F(function(){return _gS(_h0);});}else{var _h3=u_iswupper(E(_h1.b));if(!E(_h3)){return false;}else{return new F(function(){return _gS(_h0);});}}}})(_bV,_bW))){return E(_gI);}else{var _h4=new T(function(){var _h5=function(_h6){while(1){var _h7=E(_h6);if(!_h7._){return false;}else{var _h8=_h7.b,_h9=E(E(_h7.a).a);if(E(_h9.a)!=_gN){_h6=_h8;continue;}else{if(E(_h9.b)!=_gP){_h6=_h8;continue;}else{return true;}}}}};if(!B((function(_ha,_hb){var _hc=E(E(_ha).a);if(E(_hc.a)!=_gN){return new F(function(){return _h5(_hb);});}else{if(E(_hc.b)!=_gP){return new F(function(){return _h5(_hb);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_hd=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_gN)==8){if(E(_gP)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_gN)==1){if(E(_gP)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_he=new T(function(){var _hf=function(_hg){var _hh=E(_hg),_hi=E(_hh.a),_hj=_hi.b,_hk=E(_hi.a),_hl=function(_hm){return (_hk!=_gM)?true:(E(_hj)!=_gO)?true:(E(_hh.b)==113)?false:true;};if(_hk!=_gN){return new F(function(){return _hl(_);});}else{if(E(_hj)!=_gP){return new F(function(){return _hl(_);});}else{return false;}}};return B(_5Q(_hf,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_gN,_gP),_ah),_he),b:_5K,c:_hd,d:_bL,e:_h4,f:_8R,g:_8K,h:_8K,i:_2P},_gI);}}}}}}}}}},_hn=new T(function(){var _ho=function(_hp){var _hq=E(_hp);if(!_hq._){return E(_g4);}else{var _hr=E(_hq.a);return new F(function(){return _gF(E(_hr.a),_hr.b,new T(function(){return B(_ho(_hq.b));}));});}};return B(_ho(_ag));}),_hs=function(_ht){var _hu=E(_ht);if(!_hu._){return E(_hn);}else{var _hv=E(_hu.a);return new F(function(){return _gF(E(_hv.a),_hv.b,new T(function(){return B(_hs(_hu.b));}));});}};return B(_hs(_a8));}),_hw=function(_hx){while(1){var _hy=B((function(_hz){var _hA=E(_hz);if(!_hA._){return E(_gE);}else{var _hB=_hA.b,_hC=E(_hA.a);if(!_hC){_hx=_hB;return __continue;}else{return new F(function(){return _g5(_hC, -_hC,new T(function(){return B(_hw(_hB));}));});}}})(_hx));if(_hy!=__continue){return _hy;}}};return B(_hw(_9q));}),_hD=function(_hE){while(1){var _hF=B((function(_hG){var _hH=E(_hG);if(!_hH._){return E(_gD);}else{var _hI=_hH.b,_hJ=E(_hH.a);if(!_hJ){_hE=_hI;return __continue;}else{return new F(function(){return _g5(_hJ,_hJ,new T(function(){return B(_hD(_hI));}));});}}})(_hE));if(_hF!=__continue){return _hF;}}};return new F(function(){return _hD(_9q);});}else{return E(_g4);}};return B(_fZ(_bV,_bW));}),_hK=function(_hL){while(1){var _hM=B((function(_hN){var _hO=E(_hN);if(!_hO._){return E(_cX);}else{var _hP=_hO.b,_hQ=E(_hO.a);if(E(_hQ.b)==110){var _hR=function(_hS,_hT,_hU){var _hV=E(_hQ.a),_hW=E(_hV.a),_hX=_hW+_hS|0;if(_hX<1){return E(_hU);}else{if(_hX>8){return E(_hU);}else{var _hY=E(_hV.b),_hZ=_hY+_hT|0;if(_hZ<1){return E(_hU);}else{if(_hZ>8){return E(_hU);}else{var _i0=function(_i1){while(1){var _i2=E(_i1);if(!_i2._){return true;}else{var _i3=_i2.b,_i4=E(_i2.a),_i5=E(_i4.a);if(E(_i5.a)!=_hX){_i1=_i3;continue;}else{if(E(_i5.b)!=_hZ){_i1=_i3;continue;}else{var _i6=u_iswupper(E(_i4.b));if(!E(_i6)){return false;}else{_i1=_i3;continue;}}}}}};if(!B((function(_i7,_i8){var _i9=E(_i7),_ia=E(_i9.a);if(E(_ia.a)!=_hX){return new F(function(){return _i0(_i8);});}else{if(E(_ia.b)!=_hZ){return new F(function(){return _i0(_i8);});}else{var _ib=u_iswupper(E(_i9.b));if(!E(_ib)){return false;}else{return new F(function(){return _i0(_i8);});}}}})(_bV,_bW))){return E(_hU);}else{var _ic=new T(function(){var _id=function(_ie){while(1){var _if=E(_ie);if(!_if._){return false;}else{var _ig=_if.b,_ih=E(E(_if.a).a);if(E(_ih.a)!=_hX){_ie=_ig;continue;}else{if(E(_ih.b)!=_hZ){_ie=_ig;continue;}else{return true;}}}}};if(!B((function(_ii,_ij){var _ik=E(E(_ii).a);if(E(_ik.a)!=_hX){return new F(function(){return _id(_ij);});}else{if(E(_ik.b)!=_hZ){return new F(function(){return _id(_ij);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_il=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_hX)==8){if(E(_hZ)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_hX)==1){if(E(_hZ)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_im=new T(function(){var _in=function(_io){var _ip=E(_io),_iq=E(_ip.a),_ir=_iq.b,_is=E(_iq.a),_it=function(_iu){return (_is!=_hW)?true:(E(_ir)!=_hY)?true:(E(_ip.b)==110)?false:true;};if(_is!=_hX){return new F(function(){return _it(_);});}else{if(E(_ir)!=_hZ){return new F(function(){return _it(_);});}else{return false;}}};return B(_5Q(_in,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_hX,_hZ),_ai),_im),b:_5K,c:_il,d:_bL,e:_ic,f:_8R,g:_8K,h:_8K,i:_2P},_hU);}}}}}},_iv=new T(function(){var _iw=new T(function(){var _ix=new T(function(){var _iy=new T(function(){var _iz=new T(function(){var _iA=new T(function(){var _iB=new T(function(){return B(_hR(-2,-1,new T(function(){return B(_hK(_hP));})));});return B(_hR(-1,-2,_iB));});return B(_hR(2,-1,_iA));});return B(_hR(-1,2,_iz));});return B(_hR(-2,1,_iy));});return B(_hR(1,-2,_ix));});return B(_hR(2,1,_iw));});return new F(function(){return _hR(1,2,_iv);});}else{_hL=_hP;return __continue;}}})(_hL));if(_hM!=__continue){return _hM;}}},_iC=function(_iD,_iE){var _iF=E(_iD);if(E(_iF.b)==110){var _iG=function(_iH,_iI,_iJ){var _iK=E(_iF.a),_iL=E(_iK.a),_iM=_iL+_iH|0;if(_iM<1){return E(_iJ);}else{if(_iM>8){return E(_iJ);}else{var _iN=E(_iK.b),_iO=_iN+_iI|0;if(_iO<1){return E(_iJ);}else{if(_iO>8){return E(_iJ);}else{var _iP=function(_iQ){while(1){var _iR=E(_iQ);if(!_iR._){return true;}else{var _iS=_iR.b,_iT=E(_iR.a),_iU=E(_iT.a);if(E(_iU.a)!=_iM){_iQ=_iS;continue;}else{if(E(_iU.b)!=_iO){_iQ=_iS;continue;}else{var _iV=u_iswupper(E(_iT.b));if(!E(_iV)){return false;}else{_iQ=_iS;continue;}}}}}};if(!B(_iP(_bU))){return E(_iJ);}else{var _iW=new T(function(){var _iX=function(_iY){while(1){var _iZ=E(_iY);if(!_iZ._){return false;}else{var _j0=_iZ.b,_j1=E(E(_iZ.a).a);if(E(_j1.a)!=_iM){_iY=_j0;continue;}else{if(E(_j1.b)!=_iO){_iY=_j0;continue;}else{return true;}}}}};if(!B(_iX(_bU))){return E(_8L);}else{return E(_8Z);}}),_j2=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_iM)==8){if(E(_iO)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_iM)==1){if(E(_iO)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_j3=new T(function(){var _j4=function(_j5){var _j6=E(_j5),_j7=E(_j6.a),_j8=_j7.b,_j9=E(_j7.a),_ja=function(_jb){return (_j9!=_iL)?true:(E(_j8)!=_iN)?true:(E(_j6.b)==110)?false:true;};if(_j9!=_iM){return new F(function(){return _ja(_);});}else{if(E(_j8)!=_iO){return new F(function(){return _ja(_);});}else{return false;}}};return B(_5Q(_j4,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_iM,_iO),_ai),_j3),b:_5K,c:_j2,d:_bL,e:_iW,f:_8R,g:_8K,h:_8K,i:_2P},_iJ);}}}}}},_jc=new T(function(){var _jd=new T(function(){var _je=new T(function(){var _jf=new T(function(){var _jg=new T(function(){var _jh=new T(function(){var _ji=new T(function(){return B(_iG(-2,-1,new T(function(){return B(_hK(_iE));})));});return B(_iG(-1,-2,_ji));});return B(_iG(2,-1,_jh));});return B(_iG(-1,2,_jg));});return B(_iG(-2,1,_jf));});return B(_iG(1,-2,_je));});return B(_iG(2,1,_jd));});return new F(function(){return _iG(1,2,_jc);});}else{return new F(function(){return _hK(_iE);});}};return B(_iC(_bV,_bW));}),_jj=function(_jk){while(1){var _jl=B((function(_jm){var _jn=E(_jm);if(!_jn._){return true;}else{var _jo=_jn.b,_jp=E(E(_bV).a),_jq=E(_jn.a),_jr=_jq.b,_js=E(_jq.a);if(E(_jp.a)!=_js){var _jt=function(_ju){while(1){var _jv=E(_ju);if(!_jv._){return true;}else{var _jw=_jv.b,_jx=E(E(_jv.a).a);if(E(_jx.a)!=_js){_ju=_jw;continue;}else{if(E(_jx.b)!=E(_jr)){_ju=_jw;continue;}else{return false;}}}}};if(!B(_jt(_bW))){return false;}else{_jk=_jo;return __continue;}}else{var _jy=E(_jr);if(E(_jp.b)!=_jy){var _jz=function(_jA){while(1){var _jB=E(_jA);if(!_jB._){return true;}else{var _jC=_jB.b,_jD=E(E(_jB.a).a);if(E(_jD.a)!=_js){_jA=_jC;continue;}else{if(E(_jD.b)!=_jy){_jA=_jC;continue;}else{return false;}}}}};if(!B(_jz(_bW))){return false;}else{_jk=_jo;return __continue;}}else{return false;}}}})(_jk));if(_jl!=__continue){return _jl;}}},_jE=function(_jF){var _jG=E(_jF);if(!_jG._){return E(_cW);}else{var _jH=E(_jG.a),_jI=new T(function(){return B(_jE(_jG.b));});if(E(_jH.b)==98){var _jJ=function(_jK,_jL,_jM){var _jN=E(_jH.a),_jO=E(_jN.a),_jP=_jO+_jK|0;if(_jP<1){return E(_jM);}else{if(_jP>8){return E(_jM);}else{var _jQ=E(_jN.b),_jR=_jQ+_jL|0;if(_jR<1){return E(_jM);}else{if(_jR>8){return E(_jM);}else{var _jS=B(_4i(_jO,_jQ,_jP,_jR));if(!_jS._){return E(_aK);}else{var _jT=E(_jS.b);if(!_jT._){return E(_8H);}else{if(!B(_jj(B(_8C(_jT.a,_jT.b))))){return E(_jM);}else{var _jU=function(_jV){while(1){var _jW=E(_jV);if(!_jW._){return true;}else{var _jX=_jW.b,_jY=E(_jW.a),_jZ=E(_jY.a);if(E(_jZ.a)!=_jP){_jV=_jX;continue;}else{if(E(_jZ.b)!=_jR){_jV=_jX;continue;}else{var _k0=u_iswupper(E(_jY.b));if(!E(_k0)){return false;}else{_jV=_jX;continue;}}}}}};if(!B((function(_k1,_k2){var _k3=E(_k1),_k4=E(_k3.a);if(E(_k4.a)!=_jP){return new F(function(){return _jU(_k2);});}else{if(E(_k4.b)!=_jR){return new F(function(){return _jU(_k2);});}else{var _k5=u_iswupper(E(_k3.b));if(!E(_k5)){return false;}else{return new F(function(){return _jU(_k2);});}}}})(_bV,_bW))){return E(_jM);}else{var _k6=new T(function(){var _k7=function(_k8){while(1){var _k9=E(_k8);if(!_k9._){return false;}else{var _ka=_k9.b,_kb=E(E(_k9.a).a);if(E(_kb.a)!=_jP){_k8=_ka;continue;}else{if(E(_kb.b)!=_jR){_k8=_ka;continue;}else{return true;}}}}};if(!B((function(_kc,_kd){var _ke=E(E(_kc).a);if(E(_ke.a)!=_jP){return new F(function(){return _k7(_kd);});}else{if(E(_ke.b)!=_jR){return new F(function(){return _k7(_kd);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_kf=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_jP)==8){if(E(_jR)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_jP)==1){if(E(_jR)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_kg=new T(function(){var _kh=function(_ki){var _kj=E(_ki),_kk=E(_kj.a),_kl=_kk.b,_km=E(_kk.a),_kn=function(_ko){return (_km!=_jO)?true:(E(_kl)!=_jQ)?true:(E(_kj.b)==98)?false:true;};if(_km!=_jP){return new F(function(){return _kn(_);});}else{if(E(_kl)!=_jR){return new F(function(){return _kn(_);});}else{return false;}}};return B(_5Q(_kh,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_jP,_jR),_aj),_kg),b:_5K,c:_kf,d:_bL,e:_k6,f:_8R,g:_8K,h:_8K,i:_2P},_jM);}}}}}}}}},_kp=new T(function(){var _kq=function(_kr){while(1){var _ks=B((function(_kt){var _ku=E(_kt);if(!_ku._){return E(_jI);}else{var _kv=_ku.b,_kw=E(_ku.a);if(!_kw){_kr=_kv;return __continue;}else{return new F(function(){return _jJ(_kw, -_kw,new T(function(){return B(_kq(_kv));}));});}}})(_kr));if(_ks!=__continue){return _ks;}}};return B(_kq(_9q));}),_kx=function(_ky){while(1){var _kz=B((function(_kA){var _kB=E(_kA);if(!_kB._){return E(_kp);}else{var _kC=_kB.b,_kD=E(_kB.a);if(!_kD){_ky=_kC;return __continue;}else{return new F(function(){return _jJ(_kD,_kD,new T(function(){return B(_kx(_kC));}));});}}})(_ky));if(_kz!=__continue){return _kz;}}};return new F(function(){return _kx(_9q);});}else{return E(_jI);}}},_kE=function(_kF,_kG){var _kH=E(_kF),_kI=new T(function(){return B(_jE(_kG));});if(E(_kH.b)==98){var _kJ=function(_kK,_kL,_kM){var _kN=E(_kH.a),_kO=E(_kN.a),_kP=_kO+_kK|0;if(_kP<1){return E(_kM);}else{if(_kP>8){return E(_kM);}else{var _kQ=E(_kN.b),_kR=_kQ+_kL|0;if(_kR<1){return E(_kM);}else{if(_kR>8){return E(_kM);}else{var _kS=B(_4i(_kO,_kQ,_kP,_kR));if(!_kS._){return E(_aK);}else{var _kT=E(_kS.b);if(!_kT._){return E(_8H);}else{if(!B(_jj(B(_8C(_kT.a,_kT.b))))){return E(_kM);}else{var _kU=function(_kV){while(1){var _kW=E(_kV);if(!_kW._){return true;}else{var _kX=_kW.b,_kY=E(_kW.a),_kZ=E(_kY.a);if(E(_kZ.a)!=_kP){_kV=_kX;continue;}else{if(E(_kZ.b)!=_kR){_kV=_kX;continue;}else{var _l0=u_iswupper(E(_kY.b));if(!E(_l0)){return false;}else{_kV=_kX;continue;}}}}}};if(!B(_kU(_bU))){return E(_kM);}else{var _l1=new T(function(){var _l2=function(_l3){while(1){var _l4=E(_l3);if(!_l4._){return false;}else{var _l5=_l4.b,_l6=E(E(_l4.a).a);if(E(_l6.a)!=_kP){_l3=_l5;continue;}else{if(E(_l6.b)!=_kR){_l3=_l5;continue;}else{return true;}}}}};if(!B(_l2(_bU))){return E(_8L);}else{return E(_8Z);}}),_l7=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_kP)==8){if(E(_kR)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_kP)==1){if(E(_kR)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_l8=new T(function(){var _l9=function(_la){var _lb=E(_la),_lc=E(_lb.a),_ld=_lc.b,_le=E(_lc.a),_lf=function(_lg){return (_le!=_kO)?true:(E(_ld)!=_kQ)?true:(E(_lb.b)==98)?false:true;};if(_le!=_kP){return new F(function(){return _lf(_);});}else{if(E(_ld)!=_kR){return new F(function(){return _lf(_);});}else{return false;}}};return B(_5Q(_l9,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_kP,_kR),_aj),_l8),b:_5K,c:_l7,d:_bL,e:_l1,f:_8R,g:_8K,h:_8K,i:_2P},_kM);}}}}}}}}},_lh=new T(function(){var _li=function(_lj){while(1){var _lk=B((function(_ll){var _lm=E(_ll);if(!_lm._){return E(_kI);}else{var _ln=_lm.b,_lo=E(_lm.a);if(!_lo){_lj=_ln;return __continue;}else{return new F(function(){return _kJ(_lo, -_lo,new T(function(){return B(_li(_ln));}));});}}})(_lj));if(_lk!=__continue){return _lk;}}};return B(_li(_9q));}),_lp=function(_lq){while(1){var _lr=B((function(_ls){var _lt=E(_ls);if(!_lt._){return E(_lh);}else{var _lu=_lt.b,_lv=E(_lt.a);if(!_lv){_lq=_lu;return __continue;}else{return new F(function(){return _kJ(_lv,_lv,new T(function(){return B(_lp(_lu));}));});}}})(_lq));if(_lr!=__continue){return _lr;}}};return new F(function(){return _lp(_9q);});}else{return E(_kI);}};return B(_kE(_bV,_bW));}),_lw=function(_lx){while(1){var _ly=B((function(_lz){var _lA=E(_lz);if(!_lA._){return true;}else{var _lB=_lA.b,_lC=E(E(_bV).a),_lD=E(_lA.a),_lE=_lD.b,_lF=E(_lD.a);if(E(_lC.a)!=_lF){var _lG=function(_lH){while(1){var _lI=E(_lH);if(!_lI._){return true;}else{var _lJ=_lI.b,_lK=E(E(_lI.a).a);if(E(_lK.a)!=_lF){_lH=_lJ;continue;}else{if(E(_lK.b)!=E(_lE)){_lH=_lJ;continue;}else{return false;}}}}};if(!B(_lG(_bW))){return false;}else{_lx=_lB;return __continue;}}else{var _lL=E(_lE);if(E(_lC.b)!=_lL){var _lM=function(_lN){while(1){var _lO=E(_lN);if(!_lO._){return true;}else{var _lP=_lO.b,_lQ=E(E(_lO.a).a);if(E(_lQ.a)!=_lF){_lN=_lP;continue;}else{if(E(_lQ.b)!=_lL){_lN=_lP;continue;}else{return false;}}}}};if(!B(_lM(_bW))){return false;}else{_lx=_lB;return __continue;}}else{return false;}}}})(_lx));if(_ly!=__continue){return _ly;}}},_lR=function(_lS){var _lT=E(_lS);if(!_lT._){return E(_cV);}else{var _lU=E(_lT.a),_lV=_lU.a,_lW=new T(function(){return B(_lR(_lT.b));});if(E(_lU.b)==114){var _lX=new T(function(){return B(_5B(2,new T(function(){var _lY=E(_lV);if(E(_lY.a)==8){if(E(_lY.b)==8){return true;}else{return E(_bQ);}}else{return E(_bQ);}}),B(_5B(3,new T(function(){var _lZ=E(_lV);if(E(_lZ.a)==1){if(E(_lZ.b)==8){return true;}else{return E(_bR);}}else{return E(_bR);}}),_bK))));}),_m0=function(_m1,_m2,_m3){var _m4=E(_m1);if(!_m4){var _m5=E(_m2);if(!_m5){return E(_m3);}else{var _m6=E(_lV),_m7=E(_m6.a);if(_m7<1){return E(_m3);}else{if(_m7>8){return E(_m3);}else{var _m8=E(_m6.b),_m9=_m8+_m5|0;if(_m9<1){return E(_m3);}else{if(_m9>8){return E(_m3);}else{var _ma=B(_4i(_m7,_m8,_m7,_m9));if(!_ma._){return E(_aK);}else{var _mb=E(_ma.b);if(!_mb._){return E(_8H);}else{if(!B(_lw(B(_8C(_mb.a,_mb.b))))){return E(_m3);}else{var _mc=function(_md){while(1){var _me=E(_md);if(!_me._){return true;}else{var _mf=_me.b,_mg=E(_me.a),_mh=E(_mg.a);if(E(_mh.a)!=_m7){_md=_mf;continue;}else{if(E(_mh.b)!=_m9){_md=_mf;continue;}else{var _mi=u_iswupper(E(_mg.b));if(!E(_mi)){return false;}else{_md=_mf;continue;}}}}}};if(!B((function(_mj,_mk){var _ml=E(_mj),_mm=E(_ml.a);if(E(_mm.a)!=_m7){return new F(function(){return _mc(_mk);});}else{if(E(_mm.b)!=_m9){return new F(function(){return _mc(_mk);});}else{var _mn=u_iswupper(E(_ml.b));if(!E(_mn)){return false;}else{return new F(function(){return _mc(_mk);});}}}})(_bV,_bW))){return E(_m3);}else{var _mo=new T(function(){var _mp=function(_mq){while(1){var _mr=E(_mq);if(!_mr._){return false;}else{var _ms=_mr.b,_mt=E(E(_mr.a).a);if(E(_mt.a)!=_m7){_mq=_ms;continue;}else{if(E(_mt.b)!=_m9){_mq=_ms;continue;}else{return true;}}}}};if(!B((function(_mu,_mv){var _mw=E(E(_mu).a);if(E(_mw.a)!=_m7){return new F(function(){return _mp(_mv);});}else{if(E(_mw.b)!=_m9){return new F(function(){return _mp(_mv);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_mx=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_m7)==8){if(E(_m9)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_m7)==1){if(E(_m9)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_lX))));}),_my=new T(function(){var _mz=function(_mA){var _mB=E(_mA),_mC=E(_mB.a),_mD=_mC.b,_mE=E(_mC.a),_mF=function(_mG){return (_mE!=_m7)?true:(E(_mD)!=_m8)?true:(E(_mB.b)==114)?false:true;};if(_mE!=_m7){return new F(function(){return _mF(_);});}else{if(E(_mD)!=_m9){return new F(function(){return _mF(_);});}else{return false;}}};return B(_5Q(_mz,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_m7,_m9),_9a),_my),b:_5K,c:_mx,d:_bL,e:_mo,f:_8R,g:_8K,h:_8K,i:_2P},_m3);}}}}}}}}}}else{var _mH=E(_lV),_mI=E(_mH.a),_mJ=_mI+_m4|0;if(_mJ<1){return E(_m3);}else{if(_mJ>8){return E(_m3);}else{var _mK=E(_mH.b),_mL=_mK+E(_m2)|0;if(_mL<1){return E(_m3);}else{if(_mL>8){return E(_m3);}else{var _mM=B(_4i(_mI,_mK,_mJ,_mL));if(!_mM._){return E(_aK);}else{var _mN=E(_mM.b);if(!_mN._){return E(_8H);}else{if(!B(_lw(B(_8C(_mN.a,_mN.b))))){return E(_m3);}else{var _mO=function(_mP){while(1){var _mQ=E(_mP);if(!_mQ._){return true;}else{var _mR=_mQ.b,_mS=E(_mQ.a),_mT=E(_mS.a);if(E(_mT.a)!=_mJ){_mP=_mR;continue;}else{if(E(_mT.b)!=_mL){_mP=_mR;continue;}else{var _mU=u_iswupper(E(_mS.b));if(!E(_mU)){return false;}else{_mP=_mR;continue;}}}}}};if(!B((function(_mV,_mW){var _mX=E(_mV),_mY=E(_mX.a);if(E(_mY.a)!=_mJ){return new F(function(){return _mO(_mW);});}else{if(E(_mY.b)!=_mL){return new F(function(){return _mO(_mW);});}else{var _mZ=u_iswupper(E(_mX.b));if(!E(_mZ)){return false;}else{return new F(function(){return _mO(_mW);});}}}})(_bV,_bW))){return E(_m3);}else{var _n0=new T(function(){var _n1=function(_n2){while(1){var _n3=E(_n2);if(!_n3._){return false;}else{var _n4=_n3.b,_n5=E(E(_n3.a).a);if(E(_n5.a)!=_mJ){_n2=_n4;continue;}else{if(E(_n5.b)!=_mL){_n2=_n4;continue;}else{return true;}}}}};if(!B((function(_n6,_n7){var _n8=E(E(_n6).a);if(E(_n8.a)!=_mJ){return new F(function(){return _n1(_n7);});}else{if(E(_n8.b)!=_mL){return new F(function(){return _n1(_n7);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_n9=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_mJ)==8){if(E(_mL)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_mJ)==1){if(E(_mL)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_lX))));}),_na=new T(function(){var _nb=function(_nc){var _nd=E(_nc),_ne=E(_nd.a),_nf=_ne.b,_ng=E(_ne.a),_nh=function(_ni){return (_ng!=_mI)?true:(E(_nf)!=_mK)?true:(E(_nd.b)==114)?false:true;};if(_ng!=_mJ){return new F(function(){return _nh(_);});}else{if(E(_nf)!=_mL){return new F(function(){return _nh(_);});}else{return false;}}};return B(_5Q(_nb,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_mJ,_mL),_9a),_na),b:_5K,c:_n9,d:_bL,e:_n0,f:_8R,g:_8K,h:_8K,i:_2P},_m3);}}}}}}}}}},_nj=new T(function(){var _nk=function(_nl){var _nm=E(_nl);if(!_nm._){return E(_lW);}else{var _nn=E(_nm.a);return new F(function(){return _m0(E(_nn.a),_nn.b,new T(function(){return B(_nk(_nm.b));}));});}};return B(_nk(_az));}),_no=function(_np){var _nq=E(_np);if(!_nq._){return E(_nj);}else{var _nr=E(_nq.a);return new F(function(){return _m0(E(_nr.a),_nr.b,new T(function(){return B(_no(_nq.b));}));});}};return new F(function(){return _no(_ar);});}else{return E(_lW);}}},_ns=function(_nt,_nu){var _nv=E(_nt),_nw=_nv.a,_nx=new T(function(){return B(_lR(_nu));});if(E(_nv.b)==114){var _ny=new T(function(){return B(_5B(2,new T(function(){var _nz=E(_nw);if(E(_nz.a)==8){if(E(_nz.b)==8){return true;}else{return E(_bQ);}}else{return E(_bQ);}}),B(_5B(3,new T(function(){var _nA=E(_nw);if(E(_nA.a)==1){if(E(_nA.b)==8){return true;}else{return E(_bR);}}else{return E(_bR);}}),_bK))));}),_nB=function(_nC,_nD,_nE){var _nF=E(_nC);if(!_nF){var _nG=E(_nD);if(!_nG){return E(_nE);}else{var _nH=E(_nw),_nI=E(_nH.a);if(_nI<1){return E(_nE);}else{if(_nI>8){return E(_nE);}else{var _nJ=E(_nH.b),_nK=_nJ+_nG|0;if(_nK<1){return E(_nE);}else{if(_nK>8){return E(_nE);}else{var _nL=B(_4i(_nI,_nJ,_nI,_nK));if(!_nL._){return E(_aK);}else{var _nM=E(_nL.b);if(!_nM._){return E(_8H);}else{if(!B(_lw(B(_8C(_nM.a,_nM.b))))){return E(_nE);}else{var _nN=function(_nO){while(1){var _nP=E(_nO);if(!_nP._){return true;}else{var _nQ=_nP.b,_nR=E(_nP.a),_nS=E(_nR.a);if(E(_nS.a)!=_nI){_nO=_nQ;continue;}else{if(E(_nS.b)!=_nK){_nO=_nQ;continue;}else{var _nT=u_iswupper(E(_nR.b));if(!E(_nT)){return false;}else{_nO=_nQ;continue;}}}}}};if(!B(_nN(_bU))){return E(_nE);}else{var _nU=new T(function(){var _nV=function(_nW){while(1){var _nX=E(_nW);if(!_nX._){return false;}else{var _nY=_nX.b,_nZ=E(E(_nX.a).a);if(E(_nZ.a)!=_nI){_nW=_nY;continue;}else{if(E(_nZ.b)!=_nK){_nW=_nY;continue;}else{return true;}}}}};if(!B(_nV(_bU))){return E(_8L);}else{return E(_8Z);}}),_o0=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_nI)==8){if(E(_nK)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_nI)==1){if(E(_nK)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_ny))));}),_o1=new T(function(){var _o2=function(_o3){var _o4=E(_o3),_o5=E(_o4.a),_o6=_o5.b,_o7=E(_o5.a),_o8=function(_o9){return (_o7!=_nI)?true:(E(_o6)!=_nJ)?true:(E(_o4.b)==114)?false:true;};if(_o7!=_nI){return new F(function(){return _o8(_);});}else{if(E(_o6)!=_nK){return new F(function(){return _o8(_);});}else{return false;}}};return B(_5Q(_o2,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_nI,_nK),_9a),_o1),b:_5K,c:_o0,d:_bL,e:_nU,f:_8R,g:_8K,h:_8K,i:_2P},_nE);}}}}}}}}}}else{var _oa=E(_nw),_ob=E(_oa.a),_oc=_ob+_nF|0;if(_oc<1){return E(_nE);}else{if(_oc>8){return E(_nE);}else{var _od=E(_oa.b),_oe=_od+E(_nD)|0;if(_oe<1){return E(_nE);}else{if(_oe>8){return E(_nE);}else{var _of=B(_4i(_ob,_od,_oc,_oe));if(!_of._){return E(_aK);}else{var _og=E(_of.b);if(!_og._){return E(_8H);}else{if(!B(_lw(B(_8C(_og.a,_og.b))))){return E(_nE);}else{var _oh=function(_oi){while(1){var _oj=E(_oi);if(!_oj._){return true;}else{var _ok=_oj.b,_ol=E(_oj.a),_om=E(_ol.a);if(E(_om.a)!=_oc){_oi=_ok;continue;}else{if(E(_om.b)!=_oe){_oi=_ok;continue;}else{var _on=u_iswupper(E(_ol.b));if(!E(_on)){return false;}else{_oi=_ok;continue;}}}}}};if(!B((function(_oo,_op){var _oq=E(_oo),_or=E(_oq.a);if(E(_or.a)!=_oc){return new F(function(){return _oh(_op);});}else{if(E(_or.b)!=_oe){return new F(function(){return _oh(_op);});}else{var _os=u_iswupper(E(_oq.b));if(!E(_os)){return false;}else{return new F(function(){return _oh(_op);});}}}})(_bV,_bW))){return E(_nE);}else{var _ot=new T(function(){var _ou=function(_ov){while(1){var _ow=E(_ov);if(!_ow._){return false;}else{var _ox=_ow.b,_oy=E(E(_ow.a).a);if(E(_oy.a)!=_oc){_ov=_ox;continue;}else{if(E(_oy.b)!=_oe){_ov=_ox;continue;}else{return true;}}}}};if(!B((function(_oz,_oA){var _oB=E(E(_oz).a);if(E(_oB.a)!=_oc){return new F(function(){return _ou(_oA);});}else{if(E(_oB.b)!=_oe){return new F(function(){return _ou(_oA);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_oC=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_oc)==8){if(E(_oe)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_oc)==1){if(E(_oe)==1){return true;}else{return false;}}else{return false;}}else{return true;}}),_ny))));}),_oD=new T(function(){var _oE=function(_oF){var _oG=E(_oF),_oH=E(_oG.a),_oI=_oH.b,_oJ=E(_oH.a),_oK=function(_oL){return (_oJ!=_ob)?true:(E(_oI)!=_od)?true:(E(_oG.b)==114)?false:true;};if(_oJ!=_oc){return new F(function(){return _oK(_);});}else{if(E(_oI)!=_oe){return new F(function(){return _oK(_);});}else{return false;}}};return B(_5Q(_oE,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_oc,_oe),_9a),_oD),b:_5K,c:_oC,d:_bL,e:_ot,f:_8R,g:_8K,h:_8K,i:_2P},_nE);}}}}}}}}}},_oM=new T(function(){var _oN=function(_oO){var _oP=E(_oO);if(!_oP._){return E(_nx);}else{var _oQ=E(_oP.a);return new F(function(){return _nB(E(_oQ.a),_oQ.b,new T(function(){return B(_oN(_oP.b));}));});}};return B(_oN(_az));}),_oR=function(_oS){var _oT=E(_oS);if(!_oT._){return E(_oM);}else{var _oU=E(_oT.a);return new F(function(){return _nB(E(_oU.a),_oU.b,new T(function(){return B(_oR(_oT.b));}));});}};return new F(function(){return _oR(_ar);});}else{return E(_nx);}};return B(_ns(_bV,_bW));}),_oV=function(_oW){while(1){var _oX=B((function(_oY){var _oZ=E(_oY);if(!_oZ._){return E(_cU);}else{var _p0=_oZ.b,_p1=E(_oZ.a),_p2=_p1.a;if(E(_p1.b)==112){var _p3=new T(function(){return E(E(_p2).b)-1|0;}),_p4=function(_p5,_p6){var _p7=E(_bN),_p8=E(_p2),_p9=E(_p8.a),_pa=_p9+_p5|0;if(_pa!=E(_p7.a)){return E(_p6);}else{var _pb=E(_p3);if(_pb!=E(_p7.b)){return E(_p6);}else{var _pc=new T(function(){var _pd=function(_pe){var _pf=E(_pe),_pg=E(_pf.a),_ph=_pg.b,_pi=E(_pg.a),_pj=function(_pk){return (_pi!=_p9)?true:(E(_ph)!=E(_p8.b))?true:(E(_pf.b)==112)?false:true;};if(_pi!=_pa){return new F(function(){return _pj(_);});}else{if(E(_ph)!=(_pb+1|0)){return new F(function(){return _pj(_);});}else{return false;}}};return B(_5Q(_pd,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_pa,_pb),_aA),_pc),b:_5K,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_p6);}}},_pl=new T(function(){return B(_p4(1,new T(function(){return B(_oV(_p0));})));});return new F(function(){return _p4(-1,_pl);});}else{_oW=_p0;return __continue;}}})(_oW));if(_oX!=__continue){return _oX;}}},_pm=function(_pn,_po){var _pp=E(_pn),_pq=_pp.a;if(E(_pp.b)==112){var _pr=new T(function(){return E(E(_pq).b)-1|0;}),_ps=function(_pt,_pu){var _pv=E(_bN),_pw=E(_pq),_px=E(_pw.a),_py=_px+_pt|0;if(_py!=E(_pv.a)){return E(_pu);}else{var _pz=E(_pr);if(_pz!=E(_pv.b)){return E(_pu);}else{var _pA=new T(function(){var _pB=function(_pC){var _pD=E(_pC),_pE=E(_pD.a),_pF=_pE.b,_pG=E(_pE.a),_pH=function(_pI){return (_pG!=_px)?true:(E(_pF)!=E(_pw.b))?true:(E(_pD.b)==112)?false:true;};if(_pG!=_py){return new F(function(){return _pH(_);});}else{if(E(_pF)!=(_pz+1|0)){return new F(function(){return _pH(_);});}else{return false;}}};return B(_5Q(_pB,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_py,_pz),_aA),_pA),b:_5K,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_pu);}}},_pJ=new T(function(){return B(_ps(1,new T(function(){return B(_oV(_po));})));});return new F(function(){return _ps(-1,_pJ);});}else{return new F(function(){return _oV(_po);});}};return B(_pm(_bV,_bW));}),_pK=function(_pL){while(1){var _pM=B((function(_pN){var _pO=E(_pN);if(!_pO._){return E(_cT);}else{var _pP=_pO.b,_pQ=E(_pO.a),_pR=_pQ.a;if(E(_pQ.b)==112){var _pS=new T(function(){return E(E(_pR).b)-1|0;}),_pT=function(_pU,_pV){var _pW=E(_pR),_pX=_pW.b,_pY=E(_pW.a),_pZ=_pY+_pU|0;if(_pZ<1){return E(_pV);}else{if(_pZ>8){return E(_pV);}else{var _q0=E(_pS);if(_q0<1){return E(_pV);}else{if(_q0>8){return E(_pV);}else{var _q1=function(_q2){while(1){var _q3=E(_q2);if(!_q3._){return false;}else{var _q4=_q3.b,_q5=E(_q3.a),_q6=E(_q5.a);if(E(_q6.a)!=_pZ){_q2=_q4;continue;}else{if(E(_q6.b)!=_q0){_q2=_q4;continue;}else{var _q7=u_iswupper(E(_q5.b));if(!E(_q7)){_q2=_q4;continue;}else{return true;}}}}}};if(!B((function(_q8,_q9){var _qa=E(_q8),_qb=E(_qa.a);if(E(_qb.a)!=_pZ){return new F(function(){return _q1(_q9);});}else{if(E(_qb.b)!=_q0){return new F(function(){return _q1(_q9);});}else{var _qc=u_iswupper(E(_qa.b));if(!E(_qc)){return new F(function(){return _q1(_q9);});}else{return true;}}}})(_bV,_bW))){return E(_pV);}else{var _qd=new T2(0,_pZ,_q0),_qe=E(_q0);if(_qe==1){var _qf=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_pZ)==8){return true;}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_pZ)==1){return true;}else{return false;}}else{return true;}}),_bK))));}),_qg=new T(function(){var _qh=function(_qi){var _qj=E(_qi),_qk=E(_qj.a),_ql=_qk.b,_qm=E(_qk.a),_qn=function(_qo){return (_qm!=_pY)?true:(E(_ql)!=E(_pX))?true:(E(_qj.b)==112)?false:true;};if(_qm!=_pZ){return new F(function(){return _qn(_);});}else{if(E(_ql)==1){return false;}else{return new F(function(){return _qn(_);});}}};return B(_5Q(_qh,_bU));}),_qp=new T(function(){var _qq=function(_qr){var _qs=E(_qr),_qt=E(_qs.a),_qu=_qt.b,_qv=E(_qt.a),_qw=function(_qx){return (_qv!=_pY)?true:(E(_qu)!=E(_pX))?true:(E(_qs.b)==112)?false:true;};if(_qv!=_pZ){return new F(function(){return _qw(_);});}else{if(E(_qu)==1){return false;}else{return new F(function(){return _qw(_);});}}};return B(_5Q(_qq,_bU));}),_qy=new T(function(){var _qz=function(_qA){var _qB=E(_qA),_qC=E(_qB.a),_qD=_qC.b,_qE=E(_qC.a),_qF=function(_qG){return (_qE!=_pY)?true:(E(_qD)!=E(_pX))?true:(E(_qB.b)==112)?false:true;};if(_qE!=_pZ){return new F(function(){return _qF(_);});}else{if(E(_qD)==1){return false;}else{return new F(function(){return _qF(_);});}}};return B(_5Q(_qz,_bU));}),_qH=new T(function(){var _qI=function(_qJ){var _qK=E(_qJ),_qL=E(_qK.a),_qM=_qL.b,_qN=E(_qL.a),_qO=function(_qP){return (_qN!=_pY)?true:(E(_qM)!=E(_pX))?true:(E(_qK.b)==112)?false:true;};if(_qN!=_pZ){return new F(function(){return _qO(_);});}else{if(E(_qM)==1){return false;}else{return new F(function(){return _qO(_);});}}};return B(_5Q(_qI,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_qd,_ah),_qH),b:_5K,c:_qf,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_qd,_9a),_qy),b:_5K,c:_qf,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_qd,_aj),_qp),b:_5K,c:_qf,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_qd,_ai),_qg),b:_5K,c:_qf,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},_pV))));}else{var _qQ=new T(function(){var _qR=function(_qS){var _qT=E(_qS),_qU=E(_qT.a),_qV=_qU.b,_qW=E(_qU.a),_qX=function(_qY){return (_qW!=_pY)?true:(E(_qV)!=E(_pX))?true:(E(_qT.b)==112)?false:true;};if(_qW!=_pZ){return new F(function(){return _qX(_);});}else{if(E(_qV)!=_qe){return new F(function(){return _qX(_);});}else{return false;}}};return B(_5Q(_qR,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_qd,_aA),_qQ),b:_5K,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_pV);}}}}}}},_qZ=new T(function(){return B(_pT(1,new T(function(){return B(_pK(_pP));})));});return new F(function(){return _pT(-1,_qZ);});}else{_pL=_pP;return __continue;}}})(_pL));if(_pM!=__continue){return _pM;}}},_r0=function(_r1,_r2){var _r3=E(_r1),_r4=_r3.a;if(E(_r3.b)==112){var _r5=new T(function(){return E(E(_r4).b)-1|0;}),_r6=function(_r7,_r8){var _r9=E(_r4),_ra=_r9.b,_rb=E(_r9.a),_rc=_rb+_r7|0;if(_rc<1){return E(_r8);}else{if(_rc>8){return E(_r8);}else{var _rd=E(_r5);if(_rd<1){return E(_r8);}else{if(_rd>8){return E(_r8);}else{var _re=function(_rf){while(1){var _rg=E(_rf);if(!_rg._){return false;}else{var _rh=_rg.b,_ri=E(_rg.a),_rj=E(_ri.a);if(E(_rj.a)!=_rc){_rf=_rh;continue;}else{if(E(_rj.b)!=_rd){_rf=_rh;continue;}else{var _rk=u_iswupper(E(_ri.b));if(!E(_rk)){_rf=_rh;continue;}else{return true;}}}}}};if(!B((function(_rl,_rm){var _rn=E(_rl),_ro=E(_rn.a);if(E(_ro.a)!=_rc){return new F(function(){return _re(_rm);});}else{if(E(_ro.b)!=_rd){return new F(function(){return _re(_rm);});}else{var _rp=u_iswupper(E(_rn.b));if(!E(_rp)){return new F(function(){return _re(_rm);});}else{return true;}}}})(_bV,_bW))){return E(_r8);}else{var _rq=new T2(0,_rc,_rd),_rr=E(_rd);if(_rr==1){var _rs=new T(function(){return B(_5B(0,new T(function(){if(!E(_bS)){if(E(_rc)==8){return true;}else{return false;}}else{return true;}}),B(_5B(1,new T(function(){if(!E(_bT)){if(E(_rc)==1){return true;}else{return false;}}else{return true;}}),_bK))));}),_rt=new T(function(){var _ru=function(_rv){var _rw=E(_rv),_rx=E(_rw.a),_ry=_rx.b,_rz=E(_rx.a),_rA=function(_rB){return (_rz!=_rb)?true:(E(_ry)!=E(_ra))?true:(E(_rw.b)==112)?false:true;};if(_rz!=_rc){return new F(function(){return _rA(_);});}else{if(E(_ry)==1){return false;}else{return new F(function(){return _rA(_);});}}};return B(_5Q(_ru,_bU));}),_rC=new T(function(){var _rD=function(_rE){var _rF=E(_rE),_rG=E(_rF.a),_rH=_rG.b,_rI=E(_rG.a),_rJ=function(_rK){return (_rI!=_rb)?true:(E(_rH)!=E(_ra))?true:(E(_rF.b)==112)?false:true;};if(_rI!=_rc){return new F(function(){return _rJ(_);});}else{if(E(_rH)==1){return false;}else{return new F(function(){return _rJ(_);});}}};return B(_5Q(_rD,_bU));}),_rL=new T(function(){var _rM=function(_rN){var _rO=E(_rN),_rP=E(_rO.a),_rQ=_rP.b,_rR=E(_rP.a),_rS=function(_rT){return (_rR!=_rb)?true:(E(_rQ)!=E(_ra))?true:(E(_rO.b)==112)?false:true;};if(_rR!=_rc){return new F(function(){return _rS(_);});}else{if(E(_rQ)==1){return false;}else{return new F(function(){return _rS(_);});}}};return B(_5Q(_rM,_bU));}),_rU=new T(function(){var _rV=function(_rW){var _rX=E(_rW),_rY=E(_rX.a),_rZ=_rY.b,_s0=E(_rY.a),_s1=function(_s2){return (_s0!=_rb)?true:(E(_rZ)!=E(_ra))?true:(E(_rX.b)==112)?false:true;};if(_s0!=_rc){return new F(function(){return _s1(_);});}else{if(E(_rZ)==1){return false;}else{return new F(function(){return _s1(_);});}}};return B(_5Q(_rV,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_rq,_ah),_rU),b:_5K,c:_rs,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_rq,_9a),_rL),b:_5K,c:_rs,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_rq,_aj),_rC),b:_5K,c:_rs,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_rq,_ai),_rt),b:_5K,c:_rs,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},_r8))));}else{var _s3=new T(function(){var _s4=function(_s5){var _s6=E(_s5),_s7=E(_s6.a),_s8=_s7.b,_s9=E(_s7.a),_sa=function(_sb){return (_s9!=_rb)?true:(E(_s8)!=E(_ra))?true:(E(_s6.b)==112)?false:true;};if(_s9!=_rc){return new F(function(){return _sa(_);});}else{if(E(_s8)!=_rr){return new F(function(){return _sa(_);});}else{return false;}}};return B(_5Q(_s4,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_rq,_aA),_s3),b:_5K,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_r8);}}}}}}},_sc=new T(function(){return B(_r6(1,new T(function(){return B(_pK(_r2));})));});return new F(function(){return _r6(-1,_sc);});}else{return new F(function(){return _pK(_r2);});}};return B(_r0(_bV,_bW));}),_sd=function(_se){while(1){var _sf=B((function(_sg){var _sh=E(_sg);if(!_sh._){return E(_cS);}else{var _si=_sh.b,_sj=E(_sh.a);if(E(_sj.b)==112){var _sk=E(_sj.a);if(E(_sk.b)==7){var _sl=E(E(_bV).a),_sm=_sl.b,_sn=E(_sl.a),_so=E(_sk.a),_sp=function(_sq){if(_sn!=_so){var _sr=function(_ss){var _st=E(_ss);if(!_st._){return true;}else{var _su=_st.b,_sv=E(E(_st.a).a),_sw=_sv.b,_sx=E(_sv.a),_sy=function(_sz){if(_sx!=_so){return new F(function(){return _sr(_su);});}else{if(E(_sw)==6){return false;}else{return new F(function(){return _sr(_su);});}}};if(_sx!=_so){return new F(function(){return _sy(_);});}else{if(E(_sw)==5){return false;}else{return new F(function(){return _sy(_);});}}}};return new F(function(){return _sr(_bW);});}else{if(E(_sm)==6){return false;}else{var _sA=function(_sB){var _sC=E(_sB);if(!_sC._){return true;}else{var _sD=_sC.b,_sE=E(E(_sC.a).a),_sF=_sE.b,_sG=E(_sE.a),_sH=function(_sI){if(_sG!=_so){return new F(function(){return _sA(_sD);});}else{if(E(_sF)==6){return false;}else{return new F(function(){return _sA(_sD);});}}};if(_sG!=_so){return new F(function(){return _sH(_);});}else{if(E(_sF)==5){return false;}else{return new F(function(){return _sH(_);});}}}};return new F(function(){return _sA(_bW);});}}},_sJ=function(_sK){var _sL=new T(function(){return B(_5Q(function(_sM){var _sN=E(_sM),_sO=E(_sN.a);return (E(_sO.a)!=_so)?true:(E(_sO.b)==7)?(E(_sN.b)==112)?false:true:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_so,_8O),_aA),_sL),b:_5K,c:_bK,d:_bL,e:_8L,f:new T2(0,_so,_8P),g:_8K,h:_8K,i:_2P},new T(function(){return B(_sd(_si));}));};if(_sn!=_so){if(!B(_sp(_))){_se=_si;return __continue;}else{return new F(function(){return _sJ(_);});}}else{if(E(_sm)==5){_se=_si;return __continue;}else{if(!B(_sp(_))){_se=_si;return __continue;}else{return new F(function(){return _sJ(_);});}}}}else{_se=_si;return __continue;}}else{_se=_si;return __continue;}}})(_se));if(_sf!=__continue){return _sf;}}},_sP=function(_sQ,_sR){var _sS=E(_sQ);if(E(_sS.b)==112){var _sT=E(_sS.a);if(E(_sT.b)==7){var _sU=E(E(_bV).a),_sV=_sU.b,_sW=E(_sU.a),_sX=E(_sT.a),_sY=function(_sZ){if(_sW!=_sX){var _t0=function(_t1){var _t2=E(_t1);if(!_t2._){return true;}else{var _t3=_t2.b,_t4=E(E(_t2.a).a),_t5=_t4.b,_t6=E(_t4.a),_t7=function(_t8){if(_t6!=_sX){return new F(function(){return _t0(_t3);});}else{if(E(_t5)==6){return false;}else{return new F(function(){return _t0(_t3);});}}};if(_t6!=_sX){return new F(function(){return _t7(_);});}else{if(E(_t5)==5){return false;}else{return new F(function(){return _t7(_);});}}}};return new F(function(){return _t0(_bW);});}else{if(E(_sV)==6){return false;}else{var _t9=function(_ta){var _tb=E(_ta);if(!_tb._){return true;}else{var _tc=_tb.b,_td=E(E(_tb.a).a),_te=_td.b,_tf=E(_td.a),_tg=function(_th){if(_tf!=_sX){return new F(function(){return _t9(_tc);});}else{if(E(_te)==6){return false;}else{return new F(function(){return _t9(_tc);});}}};if(_tf!=_sX){return new F(function(){return _tg(_);});}else{if(E(_te)==5){return false;}else{return new F(function(){return _tg(_);});}}}};return new F(function(){return _t9(_bW);});}}},_ti=function(_tj){var _tk=new T(function(){return B(_5Q(function(_tl){var _tm=E(_tl),_tn=E(_tm.a);return (E(_tn.a)!=_sX)?true:(E(_tn.b)==7)?(E(_tm.b)==112)?false:true:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_sX,_8O),_aA),_tk),b:_5K,c:_bK,d:_bL,e:_8L,f:new T2(0,_sX,_8P),g:_8K,h:_8K,i:_2P},new T(function(){return B(_sd(_sR));}));};if(_sW!=_sX){if(!B(_sY(_))){return new F(function(){return _sd(_sR);});}else{return new F(function(){return _ti(_);});}}else{if(E(_sV)==5){return new F(function(){return _sd(_sR);});}else{if(!B(_sY(_))){return new F(function(){return _sd(_sR);});}else{return new F(function(){return _ti(_);});}}}}else{return new F(function(){return _sd(_sR);});}}else{return new F(function(){return _sd(_sR);});}};return B(_sP(_bV,_bW));}),_to=function(_tp){while(1){var _tq=B((function(_tr){var _ts=E(_tr);if(!_ts._){return E(_cR);}else{var _tt=_ts.b,_tu=E(_ts.a),_tv=_tu.a;if(E(_tu.b)==112){var _tw=new T(function(){return E(E(_tv).b)-1|0;}),_tx=E(E(_bV).a),_ty=E(_tv),_tz=_ty.b,_tA=E(_ty.a),_tB=function(_tC){var _tD=E(_tw),_tE=new T2(0,_tA,_tD);if(E(_tD)==1){var _tF=new T(function(){return B(_5Q(function(_tG){var _tH=E(_tG),_tI=E(_tH.a);return (E(_tI.a)!=_tA)?true:(E(_tI.b)!=E(_tz))?true:(E(_tH.b)==112)?false:true;},_bU));}),_tJ=new T(function(){return B(_5Q(function(_tK){var _tL=E(_tK),_tM=E(_tL.a);return (E(_tM.a)!=_tA)?true:(E(_tM.b)!=E(_tz))?true:(E(_tL.b)==112)?false:true;},_bU));}),_tN=new T(function(){return B(_5Q(function(_tO){var _tP=E(_tO),_tQ=E(_tP.a);return (E(_tQ.a)!=_tA)?true:(E(_tQ.b)!=E(_tz))?true:(E(_tP.b)==112)?false:true;},_bU));}),_tR=new T(function(){return B(_5Q(function(_tS){var _tT=E(_tS),_tU=E(_tT.a);return (E(_tU.a)!=_tA)?true:(E(_tU.b)!=E(_tz))?true:(E(_tT.b)==112)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_tE,_ah),_tR),b:_5K,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_tE,_9a),_tN),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_tE,_aj),_tJ),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_tE,_ai),_tF),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_to(_tt));})))));}else{var _tV=new T(function(){return B(_5Q(function(_tW){var _tX=E(_tW),_tY=E(_tX.a);return (E(_tY.a)!=_tA)?true:(E(_tY.b)!=E(_tz))?true:(E(_tX.b)==112)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_tE,_aA),_tV),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_to(_tt));}));}};if(E(_tx.a)!=_tA){var _tZ=function(_u0){while(1){var _u1=E(_u0);if(!_u1._){return true;}else{var _u2=_u1.b,_u3=E(E(_u1.a).a);if(E(_u3.a)!=_tA){_u0=_u2;continue;}else{if(E(_u3.b)!=E(_tw)){_u0=_u2;continue;}else{return false;}}}}};if(!B(_tZ(_bW))){_tp=_tt;return __continue;}else{return new F(function(){return _tB(_);});}}else{var _u4=E(_tw);if(E(_tx.b)!=_u4){var _u5=function(_u6){while(1){var _u7=E(_u6);if(!_u7._){return true;}else{var _u8=_u7.b,_u9=E(E(_u7.a).a);if(E(_u9.a)!=_tA){_u6=_u8;continue;}else{if(E(_u9.b)!=_u4){_u6=_u8;continue;}else{return false;}}}}};if(!B(_u5(_bW))){_tp=_tt;return __continue;}else{return new F(function(){return _tB(_);});}}else{_tp=_tt;return __continue;}}}else{_tp=_tt;return __continue;}}})(_tp));if(_tq!=__continue){return _tq;}}},_ua=function(_ub,_uc){var _ud=E(_ub),_ue=_ud.a;if(E(_ud.b)==112){var _uf=new T(function(){return E(E(_ue).b)-1|0;}),_ug=E(E(_bV).a),_uh=E(_ue),_ui=_uh.b,_uj=E(_uh.a),_uk=function(_ul){var _um=E(_uf),_un=new T2(0,_uj,_um);if(E(_um)==1){var _uo=new T(function(){return B(_5Q(function(_up){var _uq=E(_up),_ur=E(_uq.a);return (E(_ur.a)!=_uj)?true:(E(_ur.b)!=E(_ui))?true:(E(_uq.b)==112)?false:true;},_bU));}),_us=new T(function(){return B(_5Q(function(_ut){var _uu=E(_ut),_uv=E(_uu.a);return (E(_uv.a)!=_uj)?true:(E(_uv.b)!=E(_ui))?true:(E(_uu.b)==112)?false:true;},_bU));}),_uw=new T(function(){return B(_5Q(function(_ux){var _uy=E(_ux),_uz=E(_uy.a);return (E(_uz.a)!=_uj)?true:(E(_uz.b)!=E(_ui))?true:(E(_uy.b)==112)?false:true;},_bU));}),_uA=new T(function(){return B(_5Q(function(_uB){var _uC=E(_uB),_uD=E(_uC.a);return (E(_uD.a)!=_uj)?true:(E(_uD.b)!=E(_ui))?true:(E(_uC.b)==112)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_un,_ah),_uA),b:_5K,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_un,_9a),_uw),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_un,_aj),_us),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_un,_ai),_uo),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_to(_uc));})))));}else{var _uE=new T(function(){return B(_5Q(function(_uF){var _uG=E(_uF),_uH=E(_uG.a);return (E(_uH.a)!=_uj)?true:(E(_uH.b)!=E(_ui))?true:(E(_uG.b)==112)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_un,_aA),_uE),b:_5K,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_to(_uc));}));}};if(E(_ug.a)!=_uj){var _uI=function(_uJ){while(1){var _uK=E(_uJ);if(!_uK._){return true;}else{var _uL=_uK.b,_uM=E(E(_uK.a).a);if(E(_uM.a)!=_uj){_uJ=_uL;continue;}else{if(E(_uM.b)!=E(_uf)){_uJ=_uL;continue;}else{return false;}}}}};if(!B(_uI(_bW))){return new F(function(){return _to(_uc);});}else{return new F(function(){return _uk(_);});}}else{var _uN=E(_uf);if(E(_ug.b)!=_uN){var _uO=function(_uP){while(1){var _uQ=E(_uP);if(!_uQ._){return true;}else{var _uR=_uQ.b,_uS=E(E(_uQ.a).a);if(E(_uS.a)!=_uj){_uP=_uR;continue;}else{if(E(_uS.b)!=_uN){_uP=_uR;continue;}else{return false;}}}}};if(!B(_uO(_bW))){return new F(function(){return _to(_uc);});}else{return new F(function(){return _uk(_);});}}else{return new F(function(){return _to(_uc);});}}}else{return new F(function(){return _to(_uc);});}},_uT=B(_ua(_bV,_bW));}else{var _uU=new T(function(){var _uV=new T(function(){var _uW=new T(function(){var _uX=new T(function(){var _uY=new T(function(){var _uZ=new T(function(){var _v0=new T(function(){var _v1=new T(function(){var _v2=new T(function(){return B(_5B(0,_5K,B(_5B(1,_5K,_bK))));}),_v3=function(_v4,_v5,_v6){var _v7=E(_bX),_v8=E(_v7.a),_v9=E(_v8.a),_va=_v9+_v4|0;if(_va<1){return E(_v6);}else{if(_va>8){return E(_v6);}else{var _vb=E(_v8.b),_vc=_vb+_v5|0;if(_vc<1){return E(_v6);}else{if(_vc>8){return E(_v6);}else{var _vd=function(_ve){while(1){var _vf=E(_ve);if(!_vf._){return true;}else{var _vg=_vf.b,_vh=E(_vf.a),_vi=E(_vh.a);if(E(_vi.a)!=_va){_ve=_vg;continue;}else{if(E(_vi.b)!=_vc){_ve=_vg;continue;}else{var _vj=u_iswlower(E(_vh.b));if(!E(_vj)){return false;}else{_ve=_vg;continue;}}}}}};if(!B((function(_vk,_vl){var _vm=E(_vk),_vn=E(_vm.a);if(E(_vn.a)!=_va){return new F(function(){return _vd(_vl);});}else{if(E(_vn.b)!=_vc){return new F(function(){return _vd(_vl);});}else{var _vo=u_iswlower(E(_vm.b));if(!E(_vo)){return false;}else{return new F(function(){return _vd(_vl);});}}}})(_bV,_bW))){return E(_v6);}else{var _vp=new T(function(){var _vq=function(_vr){while(1){var _vs=E(_vr);if(!_vs._){return false;}else{var _vt=_vs.b,_vu=E(E(_vs.a).a);if(E(_vu.a)!=_va){_vr=_vt;continue;}else{if(E(_vu.b)!=_vc){_vr=_vt;continue;}else{return true;}}}}};if(!B((function(_vv,_vw){var _vx=E(E(_vv).a);if(E(_vx.a)!=_va){return new F(function(){return _vq(_vw);});}else{if(E(_vx.b)!=_vc){return new F(function(){return _vq(_vw);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_vy=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_va)==8){if(E(_vc)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_va)==1){if(E(_vc)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_v2))));}),_vz=new T(function(){var _vA=function(_vB){var _vC=E(_vB),_vD=E(_vC.a),_vE=_vD.b,_vF=E(_vD.a),_vG=function(_vH){return (_vF!=_v9)?true:(E(_vE)!=_vb)?true:(E(_vC.b)!=E(_v7.b))?true:false;};if(_vF!=_va){return new F(function(){return _vG(_);});}else{if(E(_vE)!=_vc){return new F(function(){return _vG(_);});}else{return false;}}};return B(_5Q(_vA,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_va,_vc),_92),_vz),b:_5J,c:_vy,d:_bL,e:_vp,f:_8R,g:_8K,h:_8K,i:_2P},_v6);}}}}}},_vI=new T(function(){var _vJ=new T(function(){var _vK=new T(function(){var _vL=new T(function(){var _vM=new T(function(){var _vN=new T(function(){return B(_v3(-1,-1,new T(function(){return B(_v3(-1,0,_cd));})));});return B(_v3(0,-1,_vN));});return B(_v3(1,-1,_vM));});return B(_v3(1,0,_vL));});return B(_v3(1,1,_vK));});return B(_v3(0,1,_vJ));});return B(_v3(-1,1,_vI));}),_vO=function(_vP){while(1){var _vQ=B((function(_vR){var _vS=E(_vR);if(!_vS._){return true;}else{var _vT=_vS.b,_vU=E(E(_bV).a),_vV=E(_vS.a),_vW=_vV.b,_vX=E(_vV.a);if(E(_vU.a)!=_vX){var _vY=function(_vZ){while(1){var _w0=E(_vZ);if(!_w0._){return true;}else{var _w1=_w0.b,_w2=E(E(_w0.a).a);if(E(_w2.a)!=_vX){_vZ=_w1;continue;}else{if(E(_w2.b)!=E(_vW)){_vZ=_w1;continue;}else{return false;}}}}};if(!B(_vY(_bW))){return false;}else{_vP=_vT;return __continue;}}else{var _w3=E(_vW);if(E(_vU.b)!=_w3){var _w4=function(_w5){while(1){var _w6=E(_w5);if(!_w6._){return true;}else{var _w7=_w6.b,_w8=E(E(_w6.a).a);if(E(_w8.a)!=_vX){_w5=_w7;continue;}else{if(E(_w8.b)!=_w3){_w5=_w7;continue;}else{return false;}}}}};if(!B(_w4(_bW))){return false;}else{_vP=_vT;return __continue;}}else{return false;}}}})(_vP));if(_vQ!=__continue){return _vQ;}}},_w9=function(_wa){var _wb=E(_wa);if(!_wb._){return E(_v1);}else{var _wc=E(_wb.a),_wd=_wc.a,_we=new T(function(){return B(_w9(_wb.b));});if(E(_wc.b)==81){var _wf=function(_wg,_wh,_wi){var _wj=E(_wd),_wk=E(_wj.a),_wl=_wk+_wg|0;if(_wl<1){return E(_wi);}else{if(_wl>8){return E(_wi);}else{var _wm=E(_wj.b),_wn=_wm+_wh|0;if(_wn<1){return E(_wi);}else{if(_wn>8){return E(_wi);}else{var _wo=B(_4i(_wk,_wm,_wl,_wn));if(!_wo._){return E(_aK);}else{var _wp=E(_wo.b);if(!_wp._){return E(_8H);}else{if(!B(_vO(B(_8C(_wp.a,_wp.b))))){return E(_wi);}else{var _wq=function(_wr){while(1){var _ws=E(_wr);if(!_ws._){return true;}else{var _wt=_ws.b,_wu=E(_ws.a),_wv=E(_wu.a);if(E(_wv.a)!=_wl){_wr=_wt;continue;}else{if(E(_wv.b)!=_wn){_wr=_wt;continue;}else{var _ww=u_iswlower(E(_wu.b));if(!E(_ww)){return false;}else{_wr=_wt;continue;}}}}}};if(!B((function(_wx,_wy){var _wz=E(_wx),_wA=E(_wz.a);if(E(_wA.a)!=_wl){return new F(function(){return _wq(_wy);});}else{if(E(_wA.b)!=_wn){return new F(function(){return _wq(_wy);});}else{var _wB=u_iswlower(E(_wz.b));if(!E(_wB)){return false;}else{return new F(function(){return _wq(_wy);});}}}})(_bV,_bW))){return E(_wi);}else{var _wC=new T(function(){var _wD=function(_wE){while(1){var _wF=E(_wE);if(!_wF._){return false;}else{var _wG=_wF.b,_wH=E(E(_wF.a).a);if(E(_wH.a)!=_wl){_wE=_wG;continue;}else{if(E(_wH.b)!=_wn){_wE=_wG;continue;}else{return true;}}}}};if(!B((function(_wI,_wJ){var _wK=E(E(_wI).a);if(E(_wK.a)!=_wl){return new F(function(){return _wD(_wJ);});}else{if(E(_wK.b)!=_wn){return new F(function(){return _wD(_wJ);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_wL=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_wl)==8){if(E(_wn)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_wl)==1){if(E(_wn)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_wM=new T(function(){var _wN=function(_wO){var _wP=E(_wO),_wQ=E(_wP.a),_wR=_wQ.b,_wS=E(_wQ.a),_wT=function(_wU){return (_wS!=_wk)?true:(E(_wR)!=_wm)?true:(E(_wP.b)==81)?false:true;};if(_wS!=_wl){return new F(function(){return _wT(_);});}else{if(E(_wR)!=_wn){return new F(function(){return _wT(_);});}else{return false;}}};return B(_5Q(_wN,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_wl,_wn),_9H),_wM),b:_5J,c:_wL,d:_bL,e:_wC,f:_8R,g:_8K,h:_8K,i:_2P},_wi);}}}}}}}}},_wV=new T(function(){var _wW=new T(function(){var _wX=function(_wY,_wZ,_x0){var _x1=E(_wY);if(!_x1){var _x2=E(_wZ);if(!_x2){return E(_x0);}else{return new F(function(){return _wf(0,_x2,_x0);});}}else{var _x3=E(_wd),_x4=E(_x3.a),_x5=_x4+_x1|0;if(_x5<1){return E(_x0);}else{if(_x5>8){return E(_x0);}else{var _x6=E(_x3.b),_x7=_x6+E(_wZ)|0;if(_x7<1){return E(_x0);}else{if(_x7>8){return E(_x0);}else{var _x8=B(_4i(_x4,_x6,_x5,_x7));if(!_x8._){return E(_aK);}else{var _x9=E(_x8.b);if(!_x9._){return E(_8H);}else{if(!B(_vO(B(_8C(_x9.a,_x9.b))))){return E(_x0);}else{var _xa=function(_xb){while(1){var _xc=E(_xb);if(!_xc._){return true;}else{var _xd=_xc.b,_xe=E(_xc.a),_xf=E(_xe.a);if(E(_xf.a)!=_x5){_xb=_xd;continue;}else{if(E(_xf.b)!=_x7){_xb=_xd;continue;}else{var _xg=u_iswlower(E(_xe.b));if(!E(_xg)){return false;}else{_xb=_xd;continue;}}}}}};if(!B((function(_xh,_xi){var _xj=E(_xh),_xk=E(_xj.a);if(E(_xk.a)!=_x5){return new F(function(){return _xa(_xi);});}else{if(E(_xk.b)!=_x7){return new F(function(){return _xa(_xi);});}else{var _xl=u_iswlower(E(_xj.b));if(!E(_xl)){return false;}else{return new F(function(){return _xa(_xi);});}}}})(_bV,_bW))){return E(_x0);}else{var _xm=new T(function(){var _xn=function(_xo){while(1){var _xp=E(_xo);if(!_xp._){return false;}else{var _xq=_xp.b,_xr=E(E(_xp.a).a);if(E(_xr.a)!=_x5){_xo=_xq;continue;}else{if(E(_xr.b)!=_x7){_xo=_xq;continue;}else{return true;}}}}};if(!B((function(_xs,_xt){var _xu=E(E(_xs).a);if(E(_xu.a)!=_x5){return new F(function(){return _xn(_xt);});}else{if(E(_xu.b)!=_x7){return new F(function(){return _xn(_xt);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_xv=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_x5)==8){if(E(_x7)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_x5)==1){if(E(_x7)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_xw=new T(function(){var _xx=function(_xy){var _xz=E(_xy),_xA=E(_xz.a),_xB=_xA.b,_xC=E(_xA.a),_xD=function(_xE){return (_xC!=_x4)?true:(E(_xB)!=_x6)?true:(E(_xz.b)==81)?false:true;};if(_xC!=_x5){return new F(function(){return _xD(_);});}else{if(E(_xB)!=_x7){return new F(function(){return _xD(_);});}else{return false;}}};return B(_5Q(_xx,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_x5,_x7),_9H),_xw),b:_5J,c:_xv,d:_bL,e:_xm,f:_8R,g:_8K,h:_8K,i:_2P},_x0);}}}}}}}}}},_xF=new T(function(){var _xG=function(_xH){var _xI=E(_xH);if(!_xI._){return E(_we);}else{var _xJ=E(_xI.a);return new F(function(){return _wX(E(_xJ.a),_xJ.b,new T(function(){return B(_xG(_xI.b));}));});}};return B(_xG(_9G));}),_xK=function(_xL){var _xM=E(_xL);if(!_xM._){return E(_xF);}else{var _xN=E(_xM.a);return new F(function(){return _wX(E(_xN.a),_xN.b,new T(function(){return B(_xK(_xM.b));}));});}};return B(_xK(_9y));}),_xO=function(_xP){while(1){var _xQ=B((function(_xR){var _xS=E(_xR);if(!_xS._){return E(_wW);}else{var _xT=_xS.b,_xU=E(_xS.a);if(!_xU){_xP=_xT;return __continue;}else{return new F(function(){return _wf(_xU, -_xU,new T(function(){return B(_xO(_xT));}));});}}})(_xP));if(_xQ!=__continue){return _xQ;}}};return B(_xO(_9q));}),_xV=function(_xW){while(1){var _xX=B((function(_xY){var _xZ=E(_xY);if(!_xZ._){return E(_wV);}else{var _y0=_xZ.b,_y1=E(_xZ.a);if(!_y1){_xW=_y0;return __continue;}else{return new F(function(){return _wf(_y1,_y1,new T(function(){return B(_xV(_y0));}));});}}})(_xW));if(_xX!=__continue){return _xX;}}};return new F(function(){return _xV(_9q);});}else{return E(_we);}}},_y2=function(_y3,_y4){var _y5=E(_y3),_y6=_y5.a,_y7=new T(function(){return B(_w9(_y4));});if(E(_y5.b)==81){var _y8=function(_y9,_ya,_yb){var _yc=E(_y6),_yd=E(_yc.a),_ye=_yd+_y9|0;if(_ye<1){return E(_yb);}else{if(_ye>8){return E(_yb);}else{var _yf=E(_yc.b),_yg=_yf+_ya|0;if(_yg<1){return E(_yb);}else{if(_yg>8){return E(_yb);}else{var _yh=B(_4i(_yd,_yf,_ye,_yg));if(!_yh._){return E(_aK);}else{var _yi=E(_yh.b);if(!_yi._){return E(_8H);}else{if(!B(_vO(B(_8C(_yi.a,_yi.b))))){return E(_yb);}else{var _yj=function(_yk){while(1){var _yl=E(_yk);if(!_yl._){return true;}else{var _ym=_yl.b,_yn=E(_yl.a),_yo=E(_yn.a);if(E(_yo.a)!=_ye){_yk=_ym;continue;}else{if(E(_yo.b)!=_yg){_yk=_ym;continue;}else{var _yp=u_iswlower(E(_yn.b));if(!E(_yp)){return false;}else{_yk=_ym;continue;}}}}}};if(!B(_yj(_bU))){return E(_yb);}else{var _yq=new T(function(){var _yr=function(_ys){while(1){var _yt=E(_ys);if(!_yt._){return false;}else{var _yu=_yt.b,_yv=E(E(_yt.a).a);if(E(_yv.a)!=_ye){_ys=_yu;continue;}else{if(E(_yv.b)!=_yg){_ys=_yu;continue;}else{return true;}}}}};if(!B(_yr(_bU))){return E(_8L);}else{return E(_8Z);}}),_yw=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_ye)==8){if(E(_yg)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_ye)==1){if(E(_yg)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_yx=new T(function(){var _yy=function(_yz){var _yA=E(_yz),_yB=E(_yA.a),_yC=_yB.b,_yD=E(_yB.a),_yE=function(_yF){return (_yD!=_yd)?true:(E(_yC)!=_yf)?true:(E(_yA.b)==81)?false:true;};if(_yD!=_ye){return new F(function(){return _yE(_);});}else{if(E(_yC)!=_yg){return new F(function(){return _yE(_);});}else{return false;}}};return B(_5Q(_yy,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_ye,_yg),_9H),_yx),b:_5J,c:_yw,d:_bL,e:_yq,f:_8R,g:_8K,h:_8K,i:_2P},_yb);}}}}}}}}},_yG=new T(function(){var _yH=new T(function(){var _yI=function(_yJ,_yK,_yL){var _yM=E(_yJ);if(!_yM){var _yN=E(_yK);if(!_yN){return E(_yL);}else{return new F(function(){return _y8(0,_yN,_yL);});}}else{var _yO=E(_y6),_yP=E(_yO.a),_yQ=_yP+_yM|0;if(_yQ<1){return E(_yL);}else{if(_yQ>8){return E(_yL);}else{var _yR=E(_yO.b),_yS=_yR+E(_yK)|0;if(_yS<1){return E(_yL);}else{if(_yS>8){return E(_yL);}else{var _yT=B(_4i(_yP,_yR,_yQ,_yS));if(!_yT._){return E(_aK);}else{var _yU=E(_yT.b);if(!_yU._){return E(_8H);}else{if(!B(_vO(B(_8C(_yU.a,_yU.b))))){return E(_yL);}else{var _yV=function(_yW){while(1){var _yX=E(_yW);if(!_yX._){return true;}else{var _yY=_yX.b,_yZ=E(_yX.a),_z0=E(_yZ.a);if(E(_z0.a)!=_yQ){_yW=_yY;continue;}else{if(E(_z0.b)!=_yS){_yW=_yY;continue;}else{var _z1=u_iswlower(E(_yZ.b));if(!E(_z1)){return false;}else{_yW=_yY;continue;}}}}}};if(!B((function(_z2,_z3){var _z4=E(_z2),_z5=E(_z4.a);if(E(_z5.a)!=_yQ){return new F(function(){return _yV(_z3);});}else{if(E(_z5.b)!=_yS){return new F(function(){return _yV(_z3);});}else{var _z6=u_iswlower(E(_z4.b));if(!E(_z6)){return false;}else{return new F(function(){return _yV(_z3);});}}}})(_bV,_bW))){return E(_yL);}else{var _z7=new T(function(){var _z8=function(_z9){while(1){var _za=E(_z9);if(!_za._){return false;}else{var _zb=_za.b,_zc=E(E(_za.a).a);if(E(_zc.a)!=_yQ){_z9=_zb;continue;}else{if(E(_zc.b)!=_yS){_z9=_zb;continue;}else{return true;}}}}};if(!B((function(_zd,_ze){var _zf=E(E(_zd).a);if(E(_zf.a)!=_yQ){return new F(function(){return _z8(_ze);});}else{if(E(_zf.b)!=_yS){return new F(function(){return _z8(_ze);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_zg=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_yQ)==8){if(E(_yS)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_yQ)==1){if(E(_yS)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_zh=new T(function(){var _zi=function(_zj){var _zk=E(_zj),_zl=E(_zk.a),_zm=_zl.b,_zn=E(_zl.a),_zo=function(_zp){return (_zn!=_yP)?true:(E(_zm)!=_yR)?true:(E(_zk.b)==81)?false:true;};if(_zn!=_yQ){return new F(function(){return _zo(_);});}else{if(E(_zm)!=_yS){return new F(function(){return _zo(_);});}else{return false;}}};return B(_5Q(_zi,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_yQ,_yS),_9H),_zh),b:_5J,c:_zg,d:_bL,e:_z7,f:_8R,g:_8K,h:_8K,i:_2P},_yL);}}}}}}}}}},_zq=new T(function(){var _zr=function(_zs){var _zt=E(_zs);if(!_zt._){return E(_y7);}else{var _zu=E(_zt.a);return new F(function(){return _yI(E(_zu.a),_zu.b,new T(function(){return B(_zr(_zt.b));}));});}};return B(_zr(_9G));}),_zv=function(_zw){var _zx=E(_zw);if(!_zx._){return E(_zq);}else{var _zy=E(_zx.a);return new F(function(){return _yI(E(_zy.a),_zy.b,new T(function(){return B(_zv(_zx.b));}));});}};return B(_zv(_9y));}),_zz=function(_zA){while(1){var _zB=B((function(_zC){var _zD=E(_zC);if(!_zD._){return E(_yH);}else{var _zE=_zD.b,_zF=E(_zD.a);if(!_zF){_zA=_zE;return __continue;}else{return new F(function(){return _y8(_zF, -_zF,new T(function(){return B(_zz(_zE));}));});}}})(_zA));if(_zB!=__continue){return _zB;}}};return B(_zz(_9q));}),_zG=function(_zH){while(1){var _zI=B((function(_zJ){var _zK=E(_zJ);if(!_zK._){return E(_yG);}else{var _zL=_zK.b,_zM=E(_zK.a);if(!_zM){_zH=_zL;return __continue;}else{return new F(function(){return _y8(_zM,_zM,new T(function(){return B(_zG(_zL));}));});}}})(_zH));if(_zI!=__continue){return _zI;}}};return new F(function(){return _zG(_9q);});}else{return E(_y7);}};return B(_y2(_bV,_bW));}),_zN=function(_zO){while(1){var _zP=B((function(_zQ){var _zR=E(_zQ);if(!_zR._){return E(_v0);}else{var _zS=_zR.b,_zT=E(_zR.a);if(E(_zT.b)==78){var _zU=function(_zV,_zW,_zX){var _zY=E(_zT.a),_zZ=E(_zY.a),_A0=_zZ+_zV|0;if(_A0<1){return E(_zX);}else{if(_A0>8){return E(_zX);}else{var _A1=E(_zY.b),_A2=_A1+_zW|0;if(_A2<1){return E(_zX);}else{if(_A2>8){return E(_zX);}else{var _A3=function(_A4){while(1){var _A5=E(_A4);if(!_A5._){return true;}else{var _A6=_A5.b,_A7=E(_A5.a),_A8=E(_A7.a);if(E(_A8.a)!=_A0){_A4=_A6;continue;}else{if(E(_A8.b)!=_A2){_A4=_A6;continue;}else{var _A9=u_iswlower(E(_A7.b));if(!E(_A9)){return false;}else{_A4=_A6;continue;}}}}}};if(!B((function(_Aa,_Ab){var _Ac=E(_Aa),_Ad=E(_Ac.a);if(E(_Ad.a)!=_A0){return new F(function(){return _A3(_Ab);});}else{if(E(_Ad.b)!=_A2){return new F(function(){return _A3(_Ab);});}else{var _Ae=u_iswlower(E(_Ac.b));if(!E(_Ae)){return false;}else{return new F(function(){return _A3(_Ab);});}}}})(_bV,_bW))){return E(_zX);}else{var _Af=new T(function(){var _Ag=function(_Ah){while(1){var _Ai=E(_Ah);if(!_Ai._){return false;}else{var _Aj=_Ai.b,_Ak=E(E(_Ai.a).a);if(E(_Ak.a)!=_A0){_Ah=_Aj;continue;}else{if(E(_Ak.b)!=_A2){_Ah=_Aj;continue;}else{return true;}}}}};if(!B((function(_Al,_Am){var _An=E(E(_Al).a);if(E(_An.a)!=_A0){return new F(function(){return _Ag(_Am);});}else{if(E(_An.b)!=_A2){return new F(function(){return _Ag(_Am);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_Ao=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_A0)==8){if(E(_A2)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_A0)==1){if(E(_A2)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_Ap=new T(function(){var _Aq=function(_Ar){var _As=E(_Ar),_At=E(_As.a),_Au=_At.b,_Av=E(_At.a),_Aw=function(_Ax){return (_Av!=_zZ)?true:(E(_Au)!=_A1)?true:(E(_As.b)==78)?false:true;};if(_Av!=_A0){return new F(function(){return _Aw(_);});}else{if(E(_Au)!=_A2){return new F(function(){return _Aw(_);});}else{return false;}}};return B(_5Q(_Aq,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_A0,_A2),_9I),_Ap),b:_5J,c:_Ao,d:_bL,e:_Af,f:_8R,g:_8K,h:_8K,i:_2P},_zX);}}}}}},_Ay=new T(function(){var _Az=new T(function(){var _AA=new T(function(){var _AB=new T(function(){var _AC=new T(function(){var _AD=new T(function(){var _AE=new T(function(){return B(_zU(-2,-1,new T(function(){return B(_zN(_zS));})));});return B(_zU(-1,-2,_AE));});return B(_zU(2,-1,_AD));});return B(_zU(-1,2,_AC));});return B(_zU(-2,1,_AB));});return B(_zU(1,-2,_AA));});return B(_zU(2,1,_Az));});return new F(function(){return _zU(1,2,_Ay);});}else{_zO=_zS;return __continue;}}})(_zO));if(_zP!=__continue){return _zP;}}},_AF=function(_AG,_AH){var _AI=E(_AG);if(E(_AI.b)==78){var _AJ=function(_AK,_AL,_AM){var _AN=E(_AI.a),_AO=E(_AN.a),_AP=_AO+_AK|0;if(_AP<1){return E(_AM);}else{if(_AP>8){return E(_AM);}else{var _AQ=E(_AN.b),_AR=_AQ+_AL|0;if(_AR<1){return E(_AM);}else{if(_AR>8){return E(_AM);}else{var _AS=function(_AT){while(1){var _AU=E(_AT);if(!_AU._){return true;}else{var _AV=_AU.b,_AW=E(_AU.a),_AX=E(_AW.a);if(E(_AX.a)!=_AP){_AT=_AV;continue;}else{if(E(_AX.b)!=_AR){_AT=_AV;continue;}else{var _AY=u_iswlower(E(_AW.b));if(!E(_AY)){return false;}else{_AT=_AV;continue;}}}}}};if(!B(_AS(_bU))){return E(_AM);}else{var _AZ=new T(function(){var _B0=function(_B1){while(1){var _B2=E(_B1);if(!_B2._){return false;}else{var _B3=_B2.b,_B4=E(E(_B2.a).a);if(E(_B4.a)!=_AP){_B1=_B3;continue;}else{if(E(_B4.b)!=_AR){_B1=_B3;continue;}else{return true;}}}}};if(!B(_B0(_bU))){return E(_8L);}else{return E(_8Z);}}),_B5=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_AP)==8){if(E(_AR)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_AP)==1){if(E(_AR)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_B6=new T(function(){var _B7=function(_B8){var _B9=E(_B8),_Ba=E(_B9.a),_Bb=_Ba.b,_Bc=E(_Ba.a),_Bd=function(_Be){return (_Bc!=_AO)?true:(E(_Bb)!=_AQ)?true:(E(_B9.b)==78)?false:true;};if(_Bc!=_AP){return new F(function(){return _Bd(_);});}else{if(E(_Bb)!=_AR){return new F(function(){return _Bd(_);});}else{return false;}}};return B(_5Q(_B7,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_AP,_AR),_9I),_B6),b:_5J,c:_B5,d:_bL,e:_AZ,f:_8R,g:_8K,h:_8K,i:_2P},_AM);}}}}}},_Bf=new T(function(){var _Bg=new T(function(){var _Bh=new T(function(){var _Bi=new T(function(){var _Bj=new T(function(){var _Bk=new T(function(){var _Bl=new T(function(){return B(_AJ(-2,-1,new T(function(){return B(_zN(_AH));})));});return B(_AJ(-1,-2,_Bl));});return B(_AJ(2,-1,_Bk));});return B(_AJ(-1,2,_Bj));});return B(_AJ(-2,1,_Bi));});return B(_AJ(1,-2,_Bh));});return B(_AJ(2,1,_Bg));});return new F(function(){return _AJ(1,2,_Bf);});}else{return new F(function(){return _zN(_AH);});}};return B(_AF(_bV,_bW));}),_Bm=function(_Bn){while(1){var _Bo=B((function(_Bp){var _Bq=E(_Bp);if(!_Bq._){return true;}else{var _Br=_Bq.b,_Bs=E(E(_bV).a),_Bt=E(_Bq.a),_Bu=_Bt.b,_Bv=E(_Bt.a);if(E(_Bs.a)!=_Bv){var _Bw=function(_Bx){while(1){var _By=E(_Bx);if(!_By._){return true;}else{var _Bz=_By.b,_BA=E(E(_By.a).a);if(E(_BA.a)!=_Bv){_Bx=_Bz;continue;}else{if(E(_BA.b)!=E(_Bu)){_Bx=_Bz;continue;}else{return false;}}}}};if(!B(_Bw(_bW))){return false;}else{_Bn=_Br;return __continue;}}else{var _BB=E(_Bu);if(E(_Bs.b)!=_BB){var _BC=function(_BD){while(1){var _BE=E(_BD);if(!_BE._){return true;}else{var _BF=_BE.b,_BG=E(E(_BE.a).a);if(E(_BG.a)!=_Bv){_BD=_BF;continue;}else{if(E(_BG.b)!=_BB){_BD=_BF;continue;}else{return false;}}}}};if(!B(_BC(_bW))){return false;}else{_Bn=_Br;return __continue;}}else{return false;}}}})(_Bn));if(_Bo!=__continue){return _Bo;}}},_BH=function(_BI){var _BJ=E(_BI);if(!_BJ._){return E(_uZ);}else{var _BK=E(_BJ.a),_BL=new T(function(){return B(_BH(_BJ.b));});if(E(_BK.b)==66){var _BM=function(_BN,_BO,_BP){var _BQ=E(_BK.a),_BR=E(_BQ.a),_BS=_BR+_BN|0;if(_BS<1){return E(_BP);}else{if(_BS>8){return E(_BP);}else{var _BT=E(_BQ.b),_BU=_BT+_BO|0;if(_BU<1){return E(_BP);}else{if(_BU>8){return E(_BP);}else{var _BV=B(_4i(_BR,_BT,_BS,_BU));if(!_BV._){return E(_aK);}else{var _BW=E(_BV.b);if(!_BW._){return E(_8H);}else{if(!B(_Bm(B(_8C(_BW.a,_BW.b))))){return E(_BP);}else{var _BX=function(_BY){while(1){var _BZ=E(_BY);if(!_BZ._){return true;}else{var _C0=_BZ.b,_C1=E(_BZ.a),_C2=E(_C1.a);if(E(_C2.a)!=_BS){_BY=_C0;continue;}else{if(E(_C2.b)!=_BU){_BY=_C0;continue;}else{var _C3=u_iswlower(E(_C1.b));if(!E(_C3)){return false;}else{_BY=_C0;continue;}}}}}};if(!B((function(_C4,_C5){var _C6=E(_C4),_C7=E(_C6.a);if(E(_C7.a)!=_BS){return new F(function(){return _BX(_C5);});}else{if(E(_C7.b)!=_BU){return new F(function(){return _BX(_C5);});}else{var _C8=u_iswlower(E(_C6.b));if(!E(_C8)){return false;}else{return new F(function(){return _BX(_C5);});}}}})(_bV,_bW))){return E(_BP);}else{var _C9=new T(function(){var _Ca=function(_Cb){while(1){var _Cc=E(_Cb);if(!_Cc._){return false;}else{var _Cd=_Cc.b,_Ce=E(E(_Cc.a).a);if(E(_Ce.a)!=_BS){_Cb=_Cd;continue;}else{if(E(_Ce.b)!=_BU){_Cb=_Cd;continue;}else{return true;}}}}};if(!B((function(_Cf,_Cg){var _Ch=E(E(_Cf).a);if(E(_Ch.a)!=_BS){return new F(function(){return _Ca(_Cg);});}else{if(E(_Ch.b)!=_BU){return new F(function(){return _Ca(_Cg);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_Ci=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_BS)==8){if(E(_BU)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_BS)==1){if(E(_BU)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_Cj=new T(function(){var _Ck=function(_Cl){var _Cm=E(_Cl),_Cn=E(_Cm.a),_Co=_Cn.b,_Cp=E(_Cn.a),_Cq=function(_Cr){return (_Cp!=_BR)?true:(E(_Co)!=_BT)?true:(E(_Cm.b)==66)?false:true;};if(_Cp!=_BS){return new F(function(){return _Cq(_);});}else{if(E(_Co)!=_BU){return new F(function(){return _Cq(_);});}else{return false;}}};return B(_5Q(_Ck,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_BS,_BU),_9J),_Cj),b:_5J,c:_Ci,d:_bL,e:_C9,f:_8R,g:_8K,h:_8K,i:_2P},_BP);}}}}}}}}},_Cs=new T(function(){var _Ct=function(_Cu){while(1){var _Cv=B((function(_Cw){var _Cx=E(_Cw);if(!_Cx._){return E(_BL);}else{var _Cy=_Cx.b,_Cz=E(_Cx.a);if(!_Cz){_Cu=_Cy;return __continue;}else{return new F(function(){return _BM(_Cz, -_Cz,new T(function(){return B(_Ct(_Cy));}));});}}})(_Cu));if(_Cv!=__continue){return _Cv;}}};return B(_Ct(_9q));}),_CA=function(_CB){while(1){var _CC=B((function(_CD){var _CE=E(_CD);if(!_CE._){return E(_Cs);}else{var _CF=_CE.b,_CG=E(_CE.a);if(!_CG){_CB=_CF;return __continue;}else{return new F(function(){return _BM(_CG,_CG,new T(function(){return B(_CA(_CF));}));});}}})(_CB));if(_CC!=__continue){return _CC;}}};return new F(function(){return _CA(_9q);});}else{return E(_BL);}}},_CH=function(_CI,_CJ){var _CK=E(_CI),_CL=new T(function(){return B(_BH(_CJ));});if(E(_CK.b)==66){var _CM=function(_CN,_CO,_CP){var _CQ=E(_CK.a),_CR=E(_CQ.a),_CS=_CR+_CN|0;if(_CS<1){return E(_CP);}else{if(_CS>8){return E(_CP);}else{var _CT=E(_CQ.b),_CU=_CT+_CO|0;if(_CU<1){return E(_CP);}else{if(_CU>8){return E(_CP);}else{var _CV=B(_4i(_CR,_CT,_CS,_CU));if(!_CV._){return E(_aK);}else{var _CW=E(_CV.b);if(!_CW._){return E(_8H);}else{if(!B(_Bm(B(_8C(_CW.a,_CW.b))))){return E(_CP);}else{var _CX=function(_CY){while(1){var _CZ=E(_CY);if(!_CZ._){return true;}else{var _D0=_CZ.b,_D1=E(_CZ.a),_D2=E(_D1.a);if(E(_D2.a)!=_CS){_CY=_D0;continue;}else{if(E(_D2.b)!=_CU){_CY=_D0;continue;}else{var _D3=u_iswlower(E(_D1.b));if(!E(_D3)){return false;}else{_CY=_D0;continue;}}}}}};if(!B(_CX(_bU))){return E(_CP);}else{var _D4=new T(function(){var _D5=function(_D6){while(1){var _D7=E(_D6);if(!_D7._){return false;}else{var _D8=_D7.b,_D9=E(E(_D7.a).a);if(E(_D9.a)!=_CS){_D6=_D8;continue;}else{if(E(_D9.b)!=_CU){_D6=_D8;continue;}else{return true;}}}}};if(!B(_D5(_bU))){return E(_8L);}else{return E(_8Z);}}),_Da=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_CS)==8){if(E(_CU)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_CS)==1){if(E(_CU)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_bK))));}),_Db=new T(function(){var _Dc=function(_Dd){var _De=E(_Dd),_Df=E(_De.a),_Dg=_Df.b,_Dh=E(_Df.a),_Di=function(_Dj){return (_Dh!=_CR)?true:(E(_Dg)!=_CT)?true:(E(_De.b)==66)?false:true;};if(_Dh!=_CS){return new F(function(){return _Di(_);});}else{if(E(_Dg)!=_CU){return new F(function(){return _Di(_);});}else{return false;}}};return B(_5Q(_Dc,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_CS,_CU),_9J),_Db),b:_5J,c:_Da,d:_bL,e:_D4,f:_8R,g:_8K,h:_8K,i:_2P},_CP);}}}}}}}}},_Dk=new T(function(){var _Dl=function(_Dm){while(1){var _Dn=B((function(_Do){var _Dp=E(_Do);if(!_Dp._){return E(_CL);}else{var _Dq=_Dp.b,_Dr=E(_Dp.a);if(!_Dr){_Dm=_Dq;return __continue;}else{return new F(function(){return _CM(_Dr, -_Dr,new T(function(){return B(_Dl(_Dq));}));});}}})(_Dm));if(_Dn!=__continue){return _Dn;}}};return B(_Dl(_9q));}),_Ds=function(_Dt){while(1){var _Du=B((function(_Dv){var _Dw=E(_Dv);if(!_Dw._){return E(_Dk);}else{var _Dx=_Dw.b,_Dy=E(_Dw.a);if(!_Dy){_Dt=_Dx;return __continue;}else{return new F(function(){return _CM(_Dy,_Dy,new T(function(){return B(_Ds(_Dx));}));});}}})(_Dt));if(_Du!=__continue){return _Du;}}};return new F(function(){return _Ds(_9q);});}else{return E(_CL);}};return B(_CH(_bV,_bW));}),_Dz=function(_DA){while(1){var _DB=B((function(_DC){var _DD=E(_DC);if(!_DD._){return true;}else{var _DE=_DD.b,_DF=E(E(_bV).a),_DG=E(_DD.a),_DH=_DG.b,_DI=E(_DG.a);if(E(_DF.a)!=_DI){var _DJ=function(_DK){while(1){var _DL=E(_DK);if(!_DL._){return true;}else{var _DM=_DL.b,_DN=E(E(_DL.a).a);if(E(_DN.a)!=_DI){_DK=_DM;continue;}else{if(E(_DN.b)!=E(_DH)){_DK=_DM;continue;}else{return false;}}}}};if(!B(_DJ(_bW))){return false;}else{_DA=_DE;return __continue;}}else{var _DO=E(_DH);if(E(_DF.b)!=_DO){var _DP=function(_DQ){while(1){var _DR=E(_DQ);if(!_DR._){return true;}else{var _DS=_DR.b,_DT=E(E(_DR.a).a);if(E(_DT.a)!=_DI){_DQ=_DS;continue;}else{if(E(_DT.b)!=_DO){_DQ=_DS;continue;}else{return false;}}}}};if(!B(_DP(_bW))){return false;}else{_DA=_DE;return __continue;}}else{return false;}}}})(_DA));if(_DB!=__continue){return _DB;}}},_DU=function(_DV){var _DW=E(_DV);if(!_DW._){return E(_uY);}else{var _DX=E(_DW.a),_DY=_DX.a,_DZ=new T(function(){return B(_DU(_DW.b));});if(E(_DX.b)==82){var _E0=new T(function(){return B(_5B(0,new T(function(){var _E1=E(_DY);if(E(_E1.a)==8){if(E(_E1.b)==1){return true;}else{return E(_bS);}}else{return E(_bS);}}),B(_5B(1,new T(function(){var _E2=E(_DY);if(E(_E2.a)==1){if(E(_E2.b)==1){return true;}else{return E(_bT);}}else{return E(_bT);}}),_bK))));}),_E3=function(_E4,_E5,_E6){var _E7=E(_E4);if(!_E7){var _E8=E(_E5);if(!_E8){return E(_E6);}else{var _E9=E(_DY),_Ea=E(_E9.a);if(_Ea<1){return E(_E6);}else{if(_Ea>8){return E(_E6);}else{var _Eb=E(_E9.b),_Ec=_Eb+_E8|0;if(_Ec<1){return E(_E6);}else{if(_Ec>8){return E(_E6);}else{var _Ed=B(_4i(_Ea,_Eb,_Ea,_Ec));if(!_Ed._){return E(_aK);}else{var _Ee=E(_Ed.b);if(!_Ee._){return E(_8H);}else{if(!B(_Dz(B(_8C(_Ee.a,_Ee.b))))){return E(_E6);}else{var _Ef=function(_Eg){while(1){var _Eh=E(_Eg);if(!_Eh._){return true;}else{var _Ei=_Eh.b,_Ej=E(_Eh.a),_Ek=E(_Ej.a);if(E(_Ek.a)!=_Ea){_Eg=_Ei;continue;}else{if(E(_Ek.b)!=_Ec){_Eg=_Ei;continue;}else{var _El=u_iswlower(E(_Ej.b));if(!E(_El)){return false;}else{_Eg=_Ei;continue;}}}}}};if(!B((function(_Em,_En){var _Eo=E(_Em),_Ep=E(_Eo.a);if(E(_Ep.a)!=_Ea){return new F(function(){return _Ef(_En);});}else{if(E(_Ep.b)!=_Ec){return new F(function(){return _Ef(_En);});}else{var _Eq=u_iswlower(E(_Eo.b));if(!E(_Eq)){return false;}else{return new F(function(){return _Ef(_En);});}}}})(_bV,_bW))){return E(_E6);}else{var _Er=new T(function(){var _Es=function(_Et){while(1){var _Eu=E(_Et);if(!_Eu._){return false;}else{var _Ev=_Eu.b,_Ew=E(E(_Eu.a).a);if(E(_Ew.a)!=_Ea){_Et=_Ev;continue;}else{if(E(_Ew.b)!=_Ec){_Et=_Ev;continue;}else{return true;}}}}};if(!B((function(_Ex,_Ey){var _Ez=E(E(_Ex).a);if(E(_Ez.a)!=_Ea){return new F(function(){return _Es(_Ey);});}else{if(E(_Ez.b)!=_Ec){return new F(function(){return _Es(_Ey);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_EA=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_Ea)==8){if(E(_Ec)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_Ea)==1){if(E(_Ec)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_E0))));}),_EB=new T(function(){var _EC=function(_ED){var _EE=E(_ED),_EF=E(_EE.a),_EG=_EF.b,_EH=E(_EF.a),_EI=function(_EJ){return (_EH!=_Ea)?true:(E(_EG)!=_Eb)?true:(E(_EE.b)==82)?false:true;};if(_EH!=_Ea){return new F(function(){return _EI(_);});}else{if(E(_EG)!=_Ec){return new F(function(){return _EI(_);});}else{return false;}}};return B(_5Q(_EC,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_Ea,_Ec),_8Y),_EB),b:_5J,c:_EA,d:_bL,e:_Er,f:_8R,g:_8K,h:_8K,i:_2P},_E6);}}}}}}}}}}else{var _EK=E(_DY),_EL=E(_EK.a),_EM=_EL+_E7|0;if(_EM<1){return E(_E6);}else{if(_EM>8){return E(_E6);}else{var _EN=E(_EK.b),_EO=_EN+E(_E5)|0;if(_EO<1){return E(_E6);}else{if(_EO>8){return E(_E6);}else{var _EP=B(_4i(_EL,_EN,_EM,_EO));if(!_EP._){return E(_aK);}else{var _EQ=E(_EP.b);if(!_EQ._){return E(_8H);}else{if(!B(_Dz(B(_8C(_EQ.a,_EQ.b))))){return E(_E6);}else{var _ER=function(_ES){while(1){var _ET=E(_ES);if(!_ET._){return true;}else{var _EU=_ET.b,_EV=E(_ET.a),_EW=E(_EV.a);if(E(_EW.a)!=_EM){_ES=_EU;continue;}else{if(E(_EW.b)!=_EO){_ES=_EU;continue;}else{var _EX=u_iswlower(E(_EV.b));if(!E(_EX)){return false;}else{_ES=_EU;continue;}}}}}};if(!B((function(_EY,_EZ){var _F0=E(_EY),_F1=E(_F0.a);if(E(_F1.a)!=_EM){return new F(function(){return _ER(_EZ);});}else{if(E(_F1.b)!=_EO){return new F(function(){return _ER(_EZ);});}else{var _F2=u_iswlower(E(_F0.b));if(!E(_F2)){return false;}else{return new F(function(){return _ER(_EZ);});}}}})(_bV,_bW))){return E(_E6);}else{var _F3=new T(function(){var _F4=function(_F5){while(1){var _F6=E(_F5);if(!_F6._){return false;}else{var _F7=_F6.b,_F8=E(E(_F6.a).a);if(E(_F8.a)!=_EM){_F5=_F7;continue;}else{if(E(_F8.b)!=_EO){_F5=_F7;continue;}else{return true;}}}}};if(!B((function(_F9,_Fa){var _Fb=E(E(_F9).a);if(E(_Fb.a)!=_EM){return new F(function(){return _F4(_Fa);});}else{if(E(_Fb.b)!=_EO){return new F(function(){return _F4(_Fa);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_Fc=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_EM)==8){if(E(_EO)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_EM)==1){if(E(_EO)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_E0))));}),_Fd=new T(function(){var _Fe=function(_Ff){var _Fg=E(_Ff),_Fh=E(_Fg.a),_Fi=_Fh.b,_Fj=E(_Fh.a),_Fk=function(_Fl){return (_Fj!=_EL)?true:(E(_Fi)!=_EN)?true:(E(_Fg.b)==82)?false:true;};if(_Fj!=_EM){return new F(function(){return _Fk(_);});}else{if(E(_Fi)!=_EO){return new F(function(){return _Fk(_);});}else{return false;}}};return B(_5Q(_Fe,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_EM,_EO),_8Y),_Fd),b:_5J,c:_Fc,d:_bL,e:_F3,f:_8R,g:_8K,h:_8K,i:_2P},_E6);}}}}}}}}}},_Fm=new T(function(){var _Fn=function(_Fo){var _Fp=E(_Fo);if(!_Fp._){return E(_DZ);}else{var _Fq=E(_Fp.a);return new F(function(){return _E3(E(_Fq.a),_Fq.b,new T(function(){return B(_Fn(_Fp.b));}));});}};return B(_Fn(_9Z));}),_Fr=function(_Fs){var _Ft=E(_Fs);if(!_Ft._){return E(_Fm);}else{var _Fu=E(_Ft.a);return new F(function(){return _E3(E(_Fu.a),_Fu.b,new T(function(){return B(_Fr(_Ft.b));}));});}};return new F(function(){return _Fr(_9R);});}else{return E(_DZ);}}},_Fv=function(_Fw,_Fx){var _Fy=E(_Fw),_Fz=_Fy.a,_FA=new T(function(){return B(_DU(_Fx));});if(E(_Fy.b)==82){var _FB=new T(function(){return B(_5B(0,new T(function(){var _FC=E(_Fz);if(E(_FC.a)==8){if(E(_FC.b)==1){return true;}else{return E(_bS);}}else{return E(_bS);}}),B(_5B(1,new T(function(){var _FD=E(_Fz);if(E(_FD.a)==1){if(E(_FD.b)==1){return true;}else{return E(_bT);}}else{return E(_bT);}}),_bK))));}),_FE=function(_FF,_FG,_FH){var _FI=E(_FF);if(!_FI){var _FJ=E(_FG);if(!_FJ){return E(_FH);}else{var _FK=E(_Fz),_FL=E(_FK.a);if(_FL<1){return E(_FH);}else{if(_FL>8){return E(_FH);}else{var _FM=E(_FK.b),_FN=_FM+_FJ|0;if(_FN<1){return E(_FH);}else{if(_FN>8){return E(_FH);}else{var _FO=B(_4i(_FL,_FM,_FL,_FN));if(!_FO._){return E(_aK);}else{var _FP=E(_FO.b);if(!_FP._){return E(_8H);}else{if(!B(_Dz(B(_8C(_FP.a,_FP.b))))){return E(_FH);}else{var _FQ=function(_FR){while(1){var _FS=E(_FR);if(!_FS._){return true;}else{var _FT=_FS.b,_FU=E(_FS.a),_FV=E(_FU.a);if(E(_FV.a)!=_FL){_FR=_FT;continue;}else{if(E(_FV.b)!=_FN){_FR=_FT;continue;}else{var _FW=u_iswlower(E(_FU.b));if(!E(_FW)){return false;}else{_FR=_FT;continue;}}}}}};if(!B(_FQ(_bU))){return E(_FH);}else{var _FX=new T(function(){var _FY=function(_FZ){while(1){var _G0=E(_FZ);if(!_G0._){return false;}else{var _G1=_G0.b,_G2=E(E(_G0.a).a);if(E(_G2.a)!=_FL){_FZ=_G1;continue;}else{if(E(_G2.b)!=_FN){_FZ=_G1;continue;}else{return true;}}}}};if(!B(_FY(_bU))){return E(_8L);}else{return E(_8Z);}}),_G3=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_FL)==8){if(E(_FN)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_FL)==1){if(E(_FN)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_FB))));}),_G4=new T(function(){var _G5=function(_G6){var _G7=E(_G6),_G8=E(_G7.a),_G9=_G8.b,_Ga=E(_G8.a),_Gb=function(_Gc){return (_Ga!=_FL)?true:(E(_G9)!=_FM)?true:(E(_G7.b)==82)?false:true;};if(_Ga!=_FL){return new F(function(){return _Gb(_);});}else{if(E(_G9)!=_FN){return new F(function(){return _Gb(_);});}else{return false;}}};return B(_5Q(_G5,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_FL,_FN),_8Y),_G4),b:_5J,c:_G3,d:_bL,e:_FX,f:_8R,g:_8K,h:_8K,i:_2P},_FH);}}}}}}}}}}else{var _Gd=E(_Fz),_Ge=E(_Gd.a),_Gf=_Ge+_FI|0;if(_Gf<1){return E(_FH);}else{if(_Gf>8){return E(_FH);}else{var _Gg=E(_Gd.b),_Gh=_Gg+E(_FG)|0;if(_Gh<1){return E(_FH);}else{if(_Gh>8){return E(_FH);}else{var _Gi=B(_4i(_Ge,_Gg,_Gf,_Gh));if(!_Gi._){return E(_aK);}else{var _Gj=E(_Gi.b);if(!_Gj._){return E(_8H);}else{if(!B(_Dz(B(_8C(_Gj.a,_Gj.b))))){return E(_FH);}else{var _Gk=function(_Gl){while(1){var _Gm=E(_Gl);if(!_Gm._){return true;}else{var _Gn=_Gm.b,_Go=E(_Gm.a),_Gp=E(_Go.a);if(E(_Gp.a)!=_Gf){_Gl=_Gn;continue;}else{if(E(_Gp.b)!=_Gh){_Gl=_Gn;continue;}else{var _Gq=u_iswlower(E(_Go.b));if(!E(_Gq)){return false;}else{_Gl=_Gn;continue;}}}}}};if(!B((function(_Gr,_Gs){var _Gt=E(_Gr),_Gu=E(_Gt.a);if(E(_Gu.a)!=_Gf){return new F(function(){return _Gk(_Gs);});}else{if(E(_Gu.b)!=_Gh){return new F(function(){return _Gk(_Gs);});}else{var _Gv=u_iswlower(E(_Gt.b));if(!E(_Gv)){return false;}else{return new F(function(){return _Gk(_Gs);});}}}})(_bV,_bW))){return E(_FH);}else{var _Gw=new T(function(){var _Gx=function(_Gy){while(1){var _Gz=E(_Gy);if(!_Gz._){return false;}else{var _GA=_Gz.b,_GB=E(E(_Gz.a).a);if(E(_GB.a)!=_Gf){_Gy=_GA;continue;}else{if(E(_GB.b)!=_Gh){_Gy=_GA;continue;}else{return true;}}}}};if(!B((function(_GC,_GD){var _GE=E(E(_GC).a);if(E(_GE.a)!=_Gf){return new F(function(){return _Gx(_GD);});}else{if(E(_GE.b)!=_Gh){return new F(function(){return _Gx(_GD);});}else{return true;}}})(_bV,_bW))){return E(_8L);}else{return E(_8Z);}}),_GF=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_Gf)==8){if(E(_Gh)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_Gf)==1){if(E(_Gh)==8){return true;}else{return false;}}else{return false;}}else{return true;}}),_FB))));}),_GG=new T(function(){var _GH=function(_GI){var _GJ=E(_GI),_GK=E(_GJ.a),_GL=_GK.b,_GM=E(_GK.a),_GN=function(_GO){return (_GM!=_Ge)?true:(E(_GL)!=_Gg)?true:(E(_GJ.b)==82)?false:true;};if(_GM!=_Gf){return new F(function(){return _GN(_);});}else{if(E(_GL)!=_Gh){return new F(function(){return _GN(_);});}else{return false;}}};return B(_5Q(_GH,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_Gf,_Gh),_8Y),_GG),b:_5J,c:_GF,d:_bL,e:_Gw,f:_8R,g:_8K,h:_8K,i:_2P},_FH);}}}}}}}}}},_GP=new T(function(){var _GQ=function(_GR){var _GS=E(_GR);if(!_GS._){return E(_FA);}else{var _GT=E(_GS.a);return new F(function(){return _FE(E(_GT.a),_GT.b,new T(function(){return B(_GQ(_GS.b));}));});}};return B(_GQ(_9Z));}),_GU=function(_GV){var _GW=E(_GV);if(!_GW._){return E(_GP);}else{var _GX=E(_GW.a);return new F(function(){return _FE(E(_GX.a),_GX.b,new T(function(){return B(_GU(_GW.b));}));});}};return new F(function(){return _GU(_9R);});}else{return E(_FA);}};return B(_Fv(_bV,_bW));}),_GY=function(_GZ){while(1){var _H0=B((function(_H1){var _H2=E(_H1);if(!_H2._){return E(_uX);}else{var _H3=_H2.b,_H4=E(_H2.a),_H5=_H4.a;if(E(_H4.b)==80){var _H6=new T(function(){return E(E(_H5).b)+1|0;}),_H7=function(_H8,_H9){var _Ha=E(_bN),_Hb=E(_H5),_Hc=E(_Hb.a),_Hd=_Hc+_H8|0;if(_Hd!=E(_Ha.a)){return E(_H9);}else{var _He=E(_H6);if(_He!=E(_Ha.b)){return E(_H9);}else{var _Hf=new T(function(){var _Hg=function(_Hh){var _Hi=E(_Hh),_Hj=E(_Hi.a),_Hk=_Hj.b,_Hl=E(_Hj.a),_Hm=function(_Hn){return (_Hl!=_Hc)?true:(E(_Hk)!=E(_Hb.b))?true:(E(_Hi.b)==80)?false:true;};if(_Hl!=_Hd){return new F(function(){return _Hm(_);});}else{if(E(_Hk)!=(_He-1|0)){return new F(function(){return _Hm(_);});}else{return false;}}};return B(_5Q(_Hg,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_Hd,_He),_a0),_Hf),b:_5J,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_H9);}}},_Ho=new T(function(){return B(_H7(1,new T(function(){return B(_GY(_H3));})));});return new F(function(){return _H7(-1,_Ho);});}else{_GZ=_H3;return __continue;}}})(_GZ));if(_H0!=__continue){return _H0;}}},_Hp=function(_Hq,_Hr){var _Hs=E(_Hq),_Ht=_Hs.a;if(E(_Hs.b)==80){var _Hu=new T(function(){return E(E(_Ht).b)+1|0;}),_Hv=function(_Hw,_Hx){var _Hy=E(_bN),_Hz=E(_Ht),_HA=E(_Hz.a),_HB=_HA+_Hw|0;if(_HB!=E(_Hy.a)){return E(_Hx);}else{var _HC=E(_Hu);if(_HC!=E(_Hy.b)){return E(_Hx);}else{var _HD=new T(function(){var _HE=function(_HF){var _HG=E(_HF),_HH=E(_HG.a),_HI=_HH.b,_HJ=E(_HH.a),_HK=function(_HL){return (_HJ!=_HA)?true:(E(_HI)!=E(_Hz.b))?true:(E(_HG.b)==80)?false:true;};if(_HJ!=_HB){return new F(function(){return _HK(_);});}else{if(E(_HI)!=(_HC-1|0)){return new F(function(){return _HK(_);});}else{return false;}}};return B(_5Q(_HE,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_HB,_HC),_a0),_HD),b:_5J,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_Hx);}}},_HM=new T(function(){return B(_Hv(1,new T(function(){return B(_GY(_Hr));})));});return new F(function(){return _Hv(-1,_HM);});}else{return new F(function(){return _GY(_Hr);});}};return B(_Hp(_bV,_bW));}),_HN=function(_HO){while(1){var _HP=B((function(_HQ){var _HR=E(_HQ);if(!_HR._){return E(_uW);}else{var _HS=_HR.b,_HT=E(_HR.a),_HU=_HT.a;if(E(_HT.b)==80){var _HV=new T(function(){return E(E(_HU).b)+1|0;}),_HW=function(_HX,_HY){var _HZ=E(_HU),_I0=_HZ.b,_I1=E(_HZ.a),_I2=_I1+_HX|0;if(_I2<1){return E(_HY);}else{if(_I2>8){return E(_HY);}else{var _I3=E(_HV);if(_I3<1){return E(_HY);}else{if(_I3>8){return E(_HY);}else{var _I4=function(_I5){while(1){var _I6=E(_I5);if(!_I6._){return false;}else{var _I7=_I6.b,_I8=E(_I6.a),_I9=E(_I8.a);if(E(_I9.a)!=_I2){_I5=_I7;continue;}else{if(E(_I9.b)!=_I3){_I5=_I7;continue;}else{var _Ia=u_iswlower(E(_I8.b));if(!E(_Ia)){_I5=_I7;continue;}else{return true;}}}}}};if(!B((function(_Ib,_Ic){var _Id=E(_Ib),_Ie=E(_Id.a);if(E(_Ie.a)!=_I2){return new F(function(){return _I4(_Ic);});}else{if(E(_Ie.b)!=_I3){return new F(function(){return _I4(_Ic);});}else{var _If=u_iswlower(E(_Id.b));if(!E(_If)){return new F(function(){return _I4(_Ic);});}else{return true;}}}})(_bV,_bW))){return E(_HY);}else{var _Ig=new T2(0,_I2,_I3),_Ih=E(_I3);if(_Ih==8){var _Ii=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_I2)==8){return true;}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_I2)==1){return true;}else{return false;}}else{return true;}}),_bK))));}),_Ij=new T(function(){var _Ik=function(_Il){var _Im=E(_Il),_In=E(_Im.a),_Io=_In.b,_Ip=E(_In.a),_Iq=function(_Ir){return (_Ip!=_I1)?true:(E(_Io)!=E(_I0))?true:(E(_Im.b)==80)?false:true;};if(_Ip!=_I2){return new F(function(){return _Iq(_);});}else{if(E(_Io)==8){return false;}else{return new F(function(){return _Iq(_);});}}};return B(_5Q(_Ik,_bU));}),_Is=new T(function(){var _It=function(_Iu){var _Iv=E(_Iu),_Iw=E(_Iv.a),_Ix=_Iw.b,_Iy=E(_Iw.a),_Iz=function(_IA){return (_Iy!=_I1)?true:(E(_Ix)!=E(_I0))?true:(E(_Iv.b)==80)?false:true;};if(_Iy!=_I2){return new F(function(){return _Iz(_);});}else{if(E(_Ix)==8){return false;}else{return new F(function(){return _Iz(_);});}}};return B(_5Q(_It,_bU));}),_IB=new T(function(){var _IC=function(_ID){var _IE=E(_ID),_IF=E(_IE.a),_IG=_IF.b,_IH=E(_IF.a),_II=function(_IJ){return (_IH!=_I1)?true:(E(_IG)!=E(_I0))?true:(E(_IE.b)==80)?false:true;};if(_IH!=_I2){return new F(function(){return _II(_);});}else{if(E(_IG)==8){return false;}else{return new F(function(){return _II(_);});}}};return B(_5Q(_IC,_bU));}),_IK=new T(function(){var _IL=function(_IM){var _IN=E(_IM),_IO=E(_IN.a),_IP=_IO.b,_IQ=E(_IO.a),_IR=function(_IS){return (_IQ!=_I1)?true:(E(_IP)!=E(_I0))?true:(E(_IN.b)==80)?false:true;};if(_IQ!=_I2){return new F(function(){return _IR(_);});}else{if(E(_IP)==8){return false;}else{return new F(function(){return _IR(_);});}}};return B(_5Q(_IL,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Ig,_9H),_IK),b:_5J,c:_Ii,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Ig,_8Y),_IB),b:_5J,c:_Ii,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Ig,_9J),_Is),b:_5J,c:_Ii,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Ig,_9I),_Ij),b:_5J,c:_Ii,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},_HY))));}else{var _IT=new T(function(){var _IU=function(_IV){var _IW=E(_IV),_IX=E(_IW.a),_IY=_IX.b,_IZ=E(_IX.a),_J0=function(_J1){return (_IZ!=_I1)?true:(E(_IY)!=E(_I0))?true:(E(_IW.b)==80)?false:true;};if(_IZ!=_I2){return new F(function(){return _J0(_);});}else{if(E(_IY)!=_Ih){return new F(function(){return _J0(_);});}else{return false;}}};return B(_5Q(_IU,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Ig,_a0),_IT),b:_5J,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_HY);}}}}}}},_J2=new T(function(){return B(_HW(1,new T(function(){return B(_HN(_HS));})));});return new F(function(){return _HW(-1,_J2);});}else{_HO=_HS;return __continue;}}})(_HO));if(_HP!=__continue){return _HP;}}},_J3=function(_J4,_J5){var _J6=E(_J4),_J7=_J6.a;if(E(_J6.b)==80){var _J8=new T(function(){return E(E(_J7).b)+1|0;}),_J9=function(_Ja,_Jb){var _Jc=E(_J7),_Jd=_Jc.b,_Je=E(_Jc.a),_Jf=_Je+_Ja|0;if(_Jf<1){return E(_Jb);}else{if(_Jf>8){return E(_Jb);}else{var _Jg=E(_J8);if(_Jg<1){return E(_Jb);}else{if(_Jg>8){return E(_Jb);}else{var _Jh=function(_Ji){while(1){var _Jj=E(_Ji);if(!_Jj._){return false;}else{var _Jk=_Jj.b,_Jl=E(_Jj.a),_Jm=E(_Jl.a);if(E(_Jm.a)!=_Jf){_Ji=_Jk;continue;}else{if(E(_Jm.b)!=_Jg){_Ji=_Jk;continue;}else{var _Jn=u_iswlower(E(_Jl.b));if(!E(_Jn)){_Ji=_Jk;continue;}else{return true;}}}}}};if(!B((function(_Jo,_Jp){var _Jq=E(_Jo),_Jr=E(_Jq.a);if(E(_Jr.a)!=_Jf){return new F(function(){return _Jh(_Jp);});}else{if(E(_Jr.b)!=_Jg){return new F(function(){return _Jh(_Jp);});}else{var _Js=u_iswlower(E(_Jq.b));if(!E(_Js)){return new F(function(){return _Jh(_Jp);});}else{return true;}}}})(_bV,_bW))){return E(_Jb);}else{var _Jt=new T2(0,_Jf,_Jg),_Ju=E(_Jg);if(_Ju==8){var _Jv=new T(function(){return B(_5B(2,new T(function(){if(!E(_bQ)){if(E(_Jf)==8){return true;}else{return false;}}else{return true;}}),B(_5B(3,new T(function(){if(!E(_bR)){if(E(_Jf)==1){return true;}else{return false;}}else{return true;}}),_bK))));}),_Jw=new T(function(){var _Jx=function(_Jy){var _Jz=E(_Jy),_JA=E(_Jz.a),_JB=_JA.b,_JC=E(_JA.a),_JD=function(_JE){return (_JC!=_Je)?true:(E(_JB)!=E(_Jd))?true:(E(_Jz.b)==80)?false:true;};if(_JC!=_Jf){return new F(function(){return _JD(_);});}else{if(E(_JB)==8){return false;}else{return new F(function(){return _JD(_);});}}};return B(_5Q(_Jx,_bU));}),_JF=new T(function(){var _JG=function(_JH){var _JI=E(_JH),_JJ=E(_JI.a),_JK=_JJ.b,_JL=E(_JJ.a),_JM=function(_JN){return (_JL!=_Je)?true:(E(_JK)!=E(_Jd))?true:(E(_JI.b)==80)?false:true;};if(_JL!=_Jf){return new F(function(){return _JM(_);});}else{if(E(_JK)==8){return false;}else{return new F(function(){return _JM(_);});}}};return B(_5Q(_JG,_bU));}),_JO=new T(function(){var _JP=function(_JQ){var _JR=E(_JQ),_JS=E(_JR.a),_JT=_JS.b,_JU=E(_JS.a),_JV=function(_JW){return (_JU!=_Je)?true:(E(_JT)!=E(_Jd))?true:(E(_JR.b)==80)?false:true;};if(_JU!=_Jf){return new F(function(){return _JV(_);});}else{if(E(_JT)==8){return false;}else{return new F(function(){return _JV(_);});}}};return B(_5Q(_JP,_bU));}),_JX=new T(function(){var _JY=function(_JZ){var _K0=E(_JZ),_K1=E(_K0.a),_K2=_K1.b,_K3=E(_K1.a),_K4=function(_K5){return (_K3!=_Je)?true:(E(_K2)!=E(_Jd))?true:(E(_K0.b)==80)?false:true;};if(_K3!=_Jf){return new F(function(){return _K4(_);});}else{if(E(_K2)==8){return false;}else{return new F(function(){return _K4(_);});}}};return B(_5Q(_JY,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Jt,_9H),_JX),b:_5J,c:_Jv,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Jt,_8Y),_JO),b:_5J,c:_Jv,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Jt,_9J),_JF),b:_5J,c:_Jv,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Jt,_9I),_Jw),b:_5J,c:_Jv,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},_Jb))));}else{var _K6=new T(function(){var _K7=function(_K8){var _K9=E(_K8),_Ka=E(_K9.a),_Kb=_Ka.b,_Kc=E(_Ka.a),_Kd=function(_Ke){return (_Kc!=_Je)?true:(E(_Kb)!=E(_Jd))?true:(E(_K9.b)==80)?false:true;};if(_Kc!=_Jf){return new F(function(){return _Kd(_);});}else{if(E(_Kb)!=_Ju){return new F(function(){return _Kd(_);});}else{return false;}}};return B(_5Q(_K7,_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Jt,_a0),_K6),b:_5J,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},_Jb);}}}}}}},_Kf=new T(function(){return B(_J9(1,new T(function(){return B(_HN(_J5));})));});return new F(function(){return _J9(-1,_Kf);});}else{return new F(function(){return _HN(_J5);});}};return B(_J3(_bV,_bW));}),_Kg=function(_Kh){while(1){var _Ki=B((function(_Kj){var _Kk=E(_Kj);if(!_Kk._){return E(_uV);}else{var _Kl=_Kk.b,_Km=E(_Kk.a);if(E(_Km.b)==80){var _Kn=E(_Km.a);if(E(_Kn.b)==2){var _Ko=E(E(_bV).a),_Kp=_Ko.b,_Kq=E(_Ko.a),_Kr=E(_Kn.a),_Ks=function(_Kt){if(_Kq!=_Kr){var _Ku=function(_Kv){var _Kw=E(_Kv);if(!_Kw._){return true;}else{var _Kx=_Kw.b,_Ky=E(E(_Kw.a).a),_Kz=_Ky.b,_KA=E(_Ky.a),_KB=function(_KC){if(_KA!=_Kr){return new F(function(){return _Ku(_Kx);});}else{if(E(_Kz)==3){return false;}else{return new F(function(){return _Ku(_Kx);});}}};if(_KA!=_Kr){return new F(function(){return _KB(_);});}else{if(E(_Kz)==4){return false;}else{return new F(function(){return _KB(_);});}}}};return new F(function(){return _Ku(_bW);});}else{if(E(_Kp)==3){return false;}else{var _KD=function(_KE){var _KF=E(_KE);if(!_KF._){return true;}else{var _KG=_KF.b,_KH=E(E(_KF.a).a),_KI=_KH.b,_KJ=E(_KH.a),_KK=function(_KL){if(_KJ!=_Kr){return new F(function(){return _KD(_KG);});}else{if(E(_KI)==3){return false;}else{return new F(function(){return _KD(_KG);});}}};if(_KJ!=_Kr){return new F(function(){return _KK(_);});}else{if(E(_KI)==4){return false;}else{return new F(function(){return _KK(_);});}}}};return new F(function(){return _KD(_bW);});}}},_KM=function(_KN){var _KO=new T(function(){return B(_5Q(function(_KP){var _KQ=E(_KP),_KR=E(_KQ.a);return (E(_KR.a)!=_Kr)?true:(E(_KR.b)==2)?(E(_KQ.b)==80)?false:true:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_Kr,_8N),_a0),_KO),b:_5J,c:_bK,d:_bL,e:_8L,f:new T2(0,_Kr,_8M),g:_8K,h:_8K,i:_2P},new T(function(){return B(_Kg(_Kl));}));};if(_Kq!=_Kr){if(!B(_Ks(_))){_Kh=_Kl;return __continue;}else{return new F(function(){return _KM(_);});}}else{if(E(_Kp)==4){_Kh=_Kl;return __continue;}else{if(!B(_Ks(_))){_Kh=_Kl;return __continue;}else{return new F(function(){return _KM(_);});}}}}else{_Kh=_Kl;return __continue;}}else{_Kh=_Kl;return __continue;}}})(_Kh));if(_Ki!=__continue){return _Ki;}}},_KS=function(_KT,_KU){var _KV=E(_KT);if(E(_KV.b)==80){var _KW=E(_KV.a);if(E(_KW.b)==2){var _KX=E(E(_bV).a),_KY=_KX.b,_KZ=E(_KX.a),_L0=E(_KW.a),_L1=function(_L2){if(_KZ!=_L0){var _L3=function(_L4){var _L5=E(_L4);if(!_L5._){return true;}else{var _L6=_L5.b,_L7=E(E(_L5.a).a),_L8=_L7.b,_L9=E(_L7.a),_La=function(_Lb){if(_L9!=_L0){return new F(function(){return _L3(_L6);});}else{if(E(_L8)==3){return false;}else{return new F(function(){return _L3(_L6);});}}};if(_L9!=_L0){return new F(function(){return _La(_);});}else{if(E(_L8)==4){return false;}else{return new F(function(){return _La(_);});}}}};return new F(function(){return _L3(_bW);});}else{if(E(_KY)==3){return false;}else{var _Lc=function(_Ld){var _Le=E(_Ld);if(!_Le._){return true;}else{var _Lf=_Le.b,_Lg=E(E(_Le.a).a),_Lh=_Lg.b,_Li=E(_Lg.a),_Lj=function(_Lk){if(_Li!=_L0){return new F(function(){return _Lc(_Lf);});}else{if(E(_Lh)==3){return false;}else{return new F(function(){return _Lc(_Lf);});}}};if(_Li!=_L0){return new F(function(){return _Lj(_);});}else{if(E(_Lh)==4){return false;}else{return new F(function(){return _Lj(_);});}}}};return new F(function(){return _Lc(_bW);});}}},_Ll=function(_Lm){var _Ln=new T(function(){return B(_5Q(function(_Lo){var _Lp=E(_Lo),_Lq=E(_Lp.a);return (E(_Lq.a)!=_L0)?true:(E(_Lq.b)==2)?(E(_Lp.b)==80)?false:true:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,new T2(0,_L0,_8N),_a0),_Ln),b:_5J,c:_bK,d:_bL,e:_8L,f:new T2(0,_L0,_8M),g:_8K,h:_8K,i:_2P},new T(function(){return B(_Kg(_KU));}));};if(_KZ!=_L0){if(!B(_L1(_))){return new F(function(){return _Kg(_KU);});}else{return new F(function(){return _Ll(_);});}}else{if(E(_KY)==4){return new F(function(){return _Kg(_KU);});}else{if(!B(_L1(_))){return new F(function(){return _Kg(_KU);});}else{return new F(function(){return _Ll(_);});}}}}else{return new F(function(){return _Kg(_KU);});}}else{return new F(function(){return _Kg(_KU);});}};return B(_KS(_bV,_bW));}),_Lr=function(_Ls){while(1){var _Lt=B((function(_Lu){var _Lv=E(_Lu);if(!_Lv._){return E(_uU);}else{var _Lw=_Lv.b,_Lx=E(_Lv.a),_Ly=_Lx.a;if(E(_Lx.b)==80){var _Lz=new T(function(){return E(E(_Ly).b)+1|0;}),_LA=E(E(_bV).a),_LB=E(_Ly),_LC=_LB.b,_LD=E(_LB.a),_LE=function(_LF){var _LG=E(_Lz),_LH=new T2(0,_LD,_LG);if(E(_LG)==8){var _LI=new T(function(){return B(_5Q(function(_LJ){var _LK=E(_LJ),_LL=E(_LK.a);return (E(_LL.a)!=_LD)?true:(E(_LL.b)!=E(_LC))?true:(E(_LK.b)==80)?false:true;},_bU));}),_LM=new T(function(){return B(_5Q(function(_LN){var _LO=E(_LN),_LP=E(_LO.a);return (E(_LP.a)!=_LD)?true:(E(_LP.b)!=E(_LC))?true:(E(_LO.b)==80)?false:true;},_bU));}),_LQ=new T(function(){return B(_5Q(function(_LR){var _LS=E(_LR),_LT=E(_LS.a);return (E(_LT.a)!=_LD)?true:(E(_LT.b)!=E(_LC))?true:(E(_LS.b)==80)?false:true;},_bU));}),_LU=new T(function(){return B(_5Q(function(_LV){var _LW=E(_LV),_LX=E(_LW.a);return (E(_LX.a)!=_LD)?true:(E(_LX.b)!=E(_LC))?true:(E(_LW.b)==80)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_LH,_9H),_LU),b:_5J,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_LH,_8Y),_LQ),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_LH,_9J),_LM),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_LH,_9I),_LI),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_Lr(_Lw));})))));}else{var _LY=new T(function(){return B(_5Q(function(_LZ){var _M0=E(_LZ),_M1=E(_M0.a);return (E(_M1.a)!=_LD)?true:(E(_M1.b)!=E(_LC))?true:(E(_M0.b)==80)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_LH,_a0),_LY),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_Lr(_Lw));}));}};if(E(_LA.a)!=_LD){var _M2=function(_M3){while(1){var _M4=E(_M3);if(!_M4._){return true;}else{var _M5=_M4.b,_M6=E(E(_M4.a).a);if(E(_M6.a)!=_LD){_M3=_M5;continue;}else{if(E(_M6.b)!=E(_Lz)){_M3=_M5;continue;}else{return false;}}}}};if(!B(_M2(_bW))){_Ls=_Lw;return __continue;}else{return new F(function(){return _LE(_);});}}else{var _M7=E(_Lz);if(E(_LA.b)!=_M7){var _M8=function(_M9){while(1){var _Ma=E(_M9);if(!_Ma._){return true;}else{var _Mb=_Ma.b,_Mc=E(E(_Ma.a).a);if(E(_Mc.a)!=_LD){_M9=_Mb;continue;}else{if(E(_Mc.b)!=_M7){_M9=_Mb;continue;}else{return false;}}}}};if(!B(_M8(_bW))){_Ls=_Lw;return __continue;}else{return new F(function(){return _LE(_);});}}else{_Ls=_Lw;return __continue;}}}else{_Ls=_Lw;return __continue;}}})(_Ls));if(_Lt!=__continue){return _Lt;}}},_Md=function(_Me,_Mf){var _Mg=E(_Me),_Mh=_Mg.a;if(E(_Mg.b)==80){var _Mi=new T(function(){return E(E(_Mh).b)+1|0;}),_Mj=E(E(_bV).a),_Mk=E(_Mh),_Ml=_Mk.b,_Mm=E(_Mk.a),_Mn=function(_Mo){var _Mp=E(_Mi),_Mq=new T2(0,_Mm,_Mp);if(E(_Mp)==8){var _Mr=new T(function(){return B(_5Q(function(_Ms){var _Mt=E(_Ms),_Mu=E(_Mt.a);return (E(_Mu.a)!=_Mm)?true:(E(_Mu.b)!=E(_Ml))?true:(E(_Mt.b)==80)?false:true;},_bU));}),_Mv=new T(function(){return B(_5Q(function(_Mw){var _Mx=E(_Mw),_My=E(_Mx.a);return (E(_My.a)!=_Mm)?true:(E(_My.b)!=E(_Ml))?true:(E(_Mx.b)==80)?false:true;},_bU));}),_Mz=new T(function(){return B(_5Q(function(_MA){var _MB=E(_MA),_MC=E(_MB.a);return (E(_MC.a)!=_Mm)?true:(E(_MC.b)!=E(_Ml))?true:(E(_MB.b)==80)?false:true;},_bU));}),_MD=new T(function(){return B(_5Q(function(_ME){var _MF=E(_ME),_MG=E(_MF.a);return (E(_MG.a)!=_Mm)?true:(E(_MG.b)!=E(_Ml))?true:(E(_MF.b)==80)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Mq,_9H),_MD),b:_5J,c:_bK,d:_bL,e:_8Z,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Mq,_8Y),_Mz),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Mq,_9J),_Mv),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T2(1,{_:0,a:new T2(1,new T2(0,_Mq,_9I),_Mr),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_Lr(_Mf));})))));}else{var _MH=new T(function(){return B(_5Q(function(_MI){var _MJ=E(_MI),_MK=E(_MJ.a);return (E(_MK.a)!=_Mm)?true:(E(_MK.b)!=E(_Ml))?true:(E(_MJ.b)==80)?false:true;},_bU));});return new T2(1,{_:0,a:new T2(1,new T2(0,_Mq,_a0),_MH),b:_5J,c:_bK,d:_bL,e:_8L,f:_8R,g:_8K,h:_8K,i:_2P},new T(function(){return B(_Lr(_Mf));}));}};if(E(_Mj.a)!=_Mm){var _ML=function(_MM){while(1){var _MN=E(_MM);if(!_MN._){return true;}else{var _MO=_MN.b,_MP=E(E(_MN.a).a);if(E(_MP.a)!=_Mm){_MM=_MO;continue;}else{if(E(_MP.b)!=E(_Mi)){_MM=_MO;continue;}else{return false;}}}}};if(!B(_ML(_bW))){return new F(function(){return _Lr(_Mf);});}else{return new F(function(){return _Mn(_);});}}else{var _MQ=E(_Mi);if(E(_Mj.b)!=_MQ){var _MR=function(_MS){while(1){var _MT=E(_MS);if(!_MT._){return true;}else{var _MU=_MT.b,_MV=E(E(_MT.a).a);if(E(_MV.a)!=_Mm){_MS=_MU;continue;}else{if(E(_MV.b)!=_MQ){_MS=_MU;continue;}else{return false;}}}}};if(!B(_MR(_bW))){return new F(function(){return _Lr(_Mf);});}else{return new F(function(){return _Mn(_);});}}else{return new F(function(){return _Lr(_Mf);});}}}else{return new F(function(){return _Lr(_Mf);});}},_uT=B(_Md(_bV,_bW));}var _MW=function(_MX){var _MY=new T(function(){var _MZ=new T(function(){return B(_aM(function(_N0,_N1){var _N2=E(E(_N0).g),_N3=E(E(_N1).g);return (_N2<=_N3)?(_N2>=_N3)?1:(!E(_bJ))?0:2:(!E(_bJ))?2:0;},B(_aD(_8y,_uT))));}),_N4=new T(function(){return (E(_bG)-5.0000011920928955e-2*E(_bO))/0.949999988079071;}),_N5=new T(function(){return E(_N4)-1.0e-5;}),_N6=new T(function(){return (E(_bH)-5.0000011920928955e-2*E(_bO))/0.949999988079071;}),_N7=new T(function(){return E(_N6)+1.0e-5;}),_N8=function(_N9,_Na){var _Nb=E(_Na);if(!_Nb._){return __Z;}else{var _Nc=_Nb.a,_Nd=_Nb.b;if(!E(_bJ)){var _Ne=E(_N9),_Nf=E(_N5);if(_Ne>=_Nf){var _Ng=new T(function(){var _Nh=E(_Nc),_Ni=E(_Nh.e),_Nj=B(_bD(_bE-_Ni|0,_bL,_N4,_Ne,_Nh.a,_Nh.b,_Nh.c,_Nh.d,_Ni,_Nh.f,_Nh.g,_Nh.i));return {_:0,a:_Nj.a,b:_Nj.b,c:_Nj.c,d:_Nj.d,e:_Nj.e,f:_Nj.f,g:_Nj.g,h:_Nj.h,i:_Nj.i};}),_Nk=new T(function(){var _Nl=function(_Nm,_Nn){var _No=E(_Nn);if(!_No._){return __Z;}else{var _Np=E(_Nm);if(_Np>=_Nf){var _Nq=new T(function(){var _Nr=E(_No.a),_Ns=_Nr.a,_Nt=_Nr.b,_Nu=_Nr.c,_Nv=_Nr.d,_Nw=_Nr.f,_Nx=_Nr.g,_Ny=_Nr.i,_Nz=E(_Nr.e),_NA=B(_bD(_bE-_Nz|0,_bL,_Np,_Np,_Ns,_Nt,_Nu,_Nv,_Nz,_Nw,_Nx,_Ny)),_NB=_NA.a,_NC=_NA.b,_ND=_NA.c,_NE=_NA.d,_NF=_NA.e,_NG=_NA.f,_NH=_NA.g,_NI=_NA.i,_NJ=E(_N4),_NK=E(_NA.h);if(_NJ>=_NK){return {_:0,a:_NB,b:_NC,c:_ND,d:_NE,e:_NF,f:_NG,g:_NH,h:_NK,i:_NI};}else{if(_NK>=_Np){return {_:0,a:_NB,b:_NC,c:_ND,d:_NE,e:_NF,f:_NG,g:_NH,h:_NK,i:_NI};}else{var _NL=B(_bD(_bE-_Nz|0,_bL,_NJ,_NK,_Ns,_Nt,_Nu,_Nv,_Nz,_Nw,_Nx,_Ny));return {_:0,a:_NL.a,b:_NL.b,c:_NL.c,d:_NL.d,e:_NL.e,f:_NL.f,g:_NL.g,h:_NL.h,i:_NL.i};}}}),_NM=new T(function(){return B(_Nl(new T(function(){var _NN=E(E(_Nq).h);if(_Np>_NN){return E(_NN);}else{return E(_Np);}},1),_No.b));});return new T2(1,_Nq,_NM);}else{return __Z;}}};return B(_Nl(new T(function(){var _NO=E(E(_Ng).h);if(_Ne>_NO){return E(_NO);}else{return E(_Ne);}},1),_Nd));});return new T2(1,_Ng,_Nk);}else{return __Z;}}else{var _NP=E(_N9),_NQ=E(_N7);if(_NP<=_NQ){var _NR=new T(function(){var _NS=E(_Nc),_NT=E(_NS.e),_NU=B(_bD(_bE-_NT|0,_bL,_NP,_N6,_NS.a,_NS.b,_NS.c,_NS.d,_NT,_NS.f,_NS.g,_NS.i));return {_:0,a:_NU.a,b:_NU.b,c:_NU.c,d:_NU.d,e:_NU.e,f:_NU.f,g:_NU.g,h:_NU.h,i:_NU.i};}),_NV=new T(function(){var _NW=function(_NX,_NY){var _NZ=E(_NY);if(!_NZ._){return __Z;}else{var _O0=E(_NX);if(_O0<=_NQ){var _O1=new T(function(){var _O2=E(_NZ.a),_O3=_O2.a,_O4=_O2.b,_O5=_O2.c,_O6=_O2.d,_O7=_O2.f,_O8=_O2.g,_O9=_O2.i,_Oa=E(_O2.e),_Ob=B(_bD(_bE-_Oa|0,_bL,_O0,_O0,_O3,_O4,_O5,_O6,_Oa,_O7,_O8,_O9)),_Oc=_Ob.a,_Od=_Ob.b,_Oe=_Ob.c,_Of=_Ob.d,_Og=_Ob.e,_Oh=_Ob.f,_Oi=_Ob.g,_Oj=_Ob.i,_Ok=E(_Ob.h);if(_O0>=_Ok){return {_:0,a:_Oc,b:_Od,c:_Oe,d:_Of,e:_Og,f:_Oh,g:_Oi,h:_Ok,i:_Oj};}else{var _Ol=E(_N6);if(_Ok>=_Ol){return {_:0,a:_Oc,b:_Od,c:_Oe,d:_Of,e:_Og,f:_Oh,g:_Oi,h:_Ok,i:_Oj};}else{var _Om=B(_bD(_bE-_Oa|0,_bL,_Ok,_Ol,_O3,_O4,_O5,_O6,_Oa,_O7,_O8,_O9));return {_:0,a:_Om.a,b:_Om.b,c:_Om.c,d:_Om.d,e:_Om.e,f:_Om.f,g:_Om.g,h:_Om.h,i:_Om.i};}}}),_On=new T(function(){return B(_NW(new T(function(){var _Oo=E(E(_O1).h);if(_O0>_Oo){return E(_O0);}else{return E(_Oo);}},1),_NZ.b));});return new T2(1,_O1,_On);}else{return __Z;}}};return B(_NW(new T(function(){var _Op=E(E(_NR).h);if(_NP>_Op){return E(_NP);}else{return E(_Op);}},1),_Nd));});return new T2(1,_NR,_NV);}else{return __Z;}}}},_Oq=E(_bP);if(!_Oq._){var _Or=B(_5f(_bJ,_2P,new T(function(){if(!E(_bJ)){return true;}else{return false;}}),_2P,_2P,_8Q,_8R,_8K,new T(function(){if(!E(_bJ)){return E(_aC);}else{return E(_aB);}}),_2P,B(_N8(new T(function(){if(!E(_bJ)){return E(_N6);}else{return E(_N4);}},1),_MZ))));return {_:0,a:_Or.a,b:_Or.b,c:_Or.c,d:_Or.d,e:_Or.e,f:_Or.f,g:_Or.g,h:_Or.h,i:_Or.i};}else{var _Os=E(_Oq.a),_Ot=_Os.b,_Ou=_Os.c,_Ov=_Os.d,_Ow=_Os.e,_Ox=_Os.f,_Oy=_Os.g,_Oz=_Os.i,_OA=E(_Os.a);if(!_OA._){var _OB=B(_5f(_bJ,_2P,new T(function(){if(!E(_bJ)){return true;}else{return false;}}),_2P,_2P,_8Q,_8R,_8K,new T(function(){if(!E(_bJ)){return E(_aC);}else{return E(_aB);}}),_2P,B(_N8(new T(function(){if(!E(_bJ)){return E(_N6);}else{return E(_N4);}},1),_MZ))));return {_:0,a:_OB.a,b:_OB.b,c:_OB.c,d:_OB.d,e:_OB.e,f:_OB.f,g:_OB.g,h:_OB.h,i:_OB.i};}else{var _OC=new T(function(){return B(_5Q(function(_OD){return (!B(_v(_16,E(_OD).a,_OA)))?true:false;},_MZ));});if(!E(_bJ)){var _OE=E(_N6),_OF=E(_N5);if(_OE>=_OF){var _OG=new T(function(){var _OH=E(_Ow),_OI=B(_bD(_bE-_OH|0,_bL,_N4,_OE,_OA,_Ot,_Ou,_Ov,_OH,_Ox,_Oy,_Oz));return {_:0,a:_OI.a,b:_OI.b,c:_OI.c,d:_OI.d,e:_OI.e,f:_OI.f,g:_OI.g,h:_OI.h,i:_OI.i};}),_OJ=function(_OK,_OL){var _OM=E(_OL);if(!_OM._){return __Z;}else{var _ON=E(_OK);if(_ON>=_OF){var _OO=new T(function(){var _OP=E(_OM.a),_OQ=_OP.a,_OR=_OP.b,_OS=_OP.c,_OT=_OP.d,_OU=_OP.f,_OV=_OP.g,_OW=_OP.i,_OX=E(_OP.e),_OY=B(_bD(_bE-_OX|0,_bL,_ON,_ON,_OQ,_OR,_OS,_OT,_OX,_OU,_OV,_OW)),_OZ=_OY.a,_P0=_OY.b,_P1=_OY.c,_P2=_OY.d,_P3=_OY.e,_P4=_OY.f,_P5=_OY.g,_P6=_OY.i,_P7=E(_N4),_P8=E(_OY.h);if(_P7>=_P8){return {_:0,a:_OZ,b:_P0,c:_P1,d:_P2,e:_P3,f:_P4,g:_P5,h:_P8,i:_P6};}else{if(_P8>=_ON){return {_:0,a:_OZ,b:_P0,c:_P1,d:_P2,e:_P3,f:_P4,g:_P5,h:_P8,i:_P6};}else{var _P9=B(_bD(_bE-_OX|0,_bL,_P7,_P8,_OQ,_OR,_OS,_OT,_OX,_OU,_OV,_OW));return {_:0,a:_P9.a,b:_P9.b,c:_P9.c,d:_P9.d,e:_P9.e,f:_P9.f,g:_P9.g,h:_P9.h,i:_P9.i};}}}),_Pa=new T(function(){return B(_OJ(new T(function(){var _Pb=E(E(_OO).h);if(_ON>_Pb){return E(_Pb);}else{return E(_ON);}},1),_OM.b));});return new T2(1,_OO,_Pa);}else{return __Z;}}},_Pc=B(_OJ(new T(function(){var _Pd=E(E(_OG).h);if(_OE>_Pd){return E(_Pd);}else{return E(_OE);}},1),_OC)),_Pe=E(_OG),_Pf=E(_Pe.h);if(_Pf>=2147268864){var _Pg=B(_1m(_2P,_5K,_2P,_2P,_8Q,_8R,_8K,2147268864,_2P,_Pc));return {_:0,a:_Pg.a,b:_Pg.b,c:_Pg.c,d:_Pg.d,e:_Pg.e,f:_Pg.f,g:_Pg.g,h:_Pg.h,i:_Pg.i};}else{var _Ph=B(_1m(_Pe.a,_Pe.b,_Pe.c,_Pe.d,_Pe.e,_Pe.f,_Pe.g,_Pf,_Pe.i,_Pc));return {_:0,a:_Ph.a,b:_Ph.b,c:_Ph.c,d:_Ph.d,e:_Ph.e,f:_Ph.f,g:_Ph.g,h:_Ph.h,i:_Ph.i};}}else{return {_:0,a:_2P,b:_5K,c:_2P,d:_2P,e:_8Q,f:_8R,g:_8K,h:_aC,i:_2P};}}else{var _Pi=E(_N4),_Pj=E(_N7);if(_Pi<=_Pj){var _Pk=new T(function(){var _Pl=E(_Ow),_Pm=B(_bD(_bE-_Pl|0,_bL,_Pi,_N6,_OA,_Ot,_Ou,_Ov,_Pl,_Ox,_Oy,_Oz));return {_:0,a:_Pm.a,b:_Pm.b,c:_Pm.c,d:_Pm.d,e:_Pm.e,f:_Pm.f,g:_Pm.g,h:_Pm.h,i:_Pm.i};}),_Pn=function(_Po,_Pp){var _Pq=E(_Pp);if(!_Pq._){return __Z;}else{var _Pr=E(_Po);if(_Pr<=_Pj){var _Ps=new T(function(){var _Pt=E(_Pq.a),_Pu=_Pt.a,_Pv=_Pt.b,_Pw=_Pt.c,_Px=_Pt.d,_Py=_Pt.f,_Pz=_Pt.g,_PA=_Pt.i,_PB=E(_Pt.e),_PC=B(_bD(_bE-_PB|0,_bL,_Pr,_Pr,_Pu,_Pv,_Pw,_Px,_PB,_Py,_Pz,_PA)),_PD=_PC.a,_PE=_PC.b,_PF=_PC.c,_PG=_PC.d,_PH=_PC.e,_PI=_PC.f,_PJ=_PC.g,_PK=_PC.i,_PL=E(_PC.h);if(_Pr>=_PL){return {_:0,a:_PD,b:_PE,c:_PF,d:_PG,e:_PH,f:_PI,g:_PJ,h:_PL,i:_PK};}else{var _PM=E(_N6);if(_PL>=_PM){return {_:0,a:_PD,b:_PE,c:_PF,d:_PG,e:_PH,f:_PI,g:_PJ,h:_PL,i:_PK};}else{var _PN=B(_bD(_bE-_PB|0,_bL,_PL,_PM,_Pu,_Pv,_Pw,_Px,_PB,_Py,_Pz,_PA));return {_:0,a:_PN.a,b:_PN.b,c:_PN.c,d:_PN.d,e:_PN.e,f:_PN.f,g:_PN.g,h:_PN.h,i:_PN.i};}}}),_PO=new T(function(){return B(_Pn(new T(function(){var _PP=E(E(_Ps).h);if(_Pr>_PP){return E(_Pr);}else{return E(_PP);}},1),_Pq.b));});return new T2(1,_Ps,_PO);}else{return __Z;}}},_PQ=B(_Pn(new T(function(){var _PR=E(E(_Pk).h);if(_Pi>_PR){return E(_Pi);}else{return E(_PR);}},1),_OC)),_PS=E(_Pk),_PT=E(_PS.h);if(_PT<=(-2147268864)){var _PU=B(_17(_2P,_5J,_2P,_2P,_8Q,_8R,_8K,-2147268864,_2P,_PQ));return {_:0,a:_PU.a,b:_PU.b,c:_PU.c,d:_PU.d,e:_PU.e,f:_PU.f,g:_PU.g,h:_PU.h,i:_PU.i};}else{var _PV=B(_17(_PS.a,_PS.b,_PS.c,_PS.d,_PS.e,_PS.f,_PS.g,_PT,_PS.i,_PQ));return {_:0,a:_PV.a,b:_PV.b,c:_PV.c,d:_PV.d,e:_PV.e,f:_PV.f,g:_PV.g,h:_PV.h,i:_PV.i};}}else{return {_:0,a:_2P,b:_5J,c:_2P,d:_2P,e:_8Q,f:_8R,g:_8K,h:_aB,i:_2P};}}}}}),_PW=new T(function(){var _PX=function(_PY){var _PZ=E(B(_bD(1,_bL,_bC,_bB,_bU,new T(function(){return B(_aH(_bJ));}),_bK,_bL,_bM,_bN,_bO,_bP)).h);return (!E(_bJ))?(_PZ>=2145336192)?2147483647:0:(_PZ<=(-2145336192))?-2147483648:0;};if(!E(_bJ)){var _Q0=E(E(_MY).h);if(_Q0<=2145336192){return 5.0000011920928955e-2*E(_bO)+0.949999988079071*_Q0;}else{return B(_PX(_));}}else{var _Q1=E(E(_MY).h);if(_Q1>=(-2145336192)){return 5.0000011920928955e-2*E(_bO)+0.949999988079071*_Q1;}else{return B(_PX(_));}}});return {_:0,a:_bU,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:_PW,i:new T2(1,_MY,_2P)};},_Q2=function(_Q3){var _Q4=function(_Q5){var _Q6=function(_Q7){var _Q8=function(_Q9){var _Qa=function(_Qb){while(1){var _Qc=B((function(_Qd){var _Qe=E(_Qd);if(!_Qe._){return true;}else{var _Qf=_Qe.b,_Qg=E(_Qe.a);if(!_Qg._){return false;}else{var _Qh=_Qg.b,_Qi=E(E(_Qg.a).b);if(!E(_bJ)){if(E(_Qi)==75){_Qb=_Qf;return __continue;}else{var _Qj=function(_Qk){while(1){var _Ql=E(_Qk);if(!_Ql._){return false;}else{if(E(E(_Ql.a).b)==75){return true;}else{_Qk=_Ql.b;continue;}}}};if(!B(_Qj(_Qh))){return false;}else{_Qb=_Qf;return __continue;}}}else{if(E(_Qi)==107){_Qb=_Qf;return __continue;}else{var _Qm=function(_Qn){while(1){var _Qo=E(_Qn);if(!_Qo._){return false;}else{if(E(E(_Qo.a).b)==107){return true;}else{_Qn=_Qo.b;continue;}}}};if(!B(_Qm(_Qh))){return false;}else{_Qb=_Qf;return __continue;}}}}}})(_Qb));if(_Qc!=__continue){return _Qc;}}};if(!B(_Qa(B(_aD(_8I,_uT))))){return {_:0,a:_bU,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:new T(function(){if(!E(_bJ)){return E(_bC);}else{return E(_bB);}}),i:_2P};}else{return new F(function(){return _MW(_);});}},_Qp=function(_Qq){if(!B(_6f(B(_aD(_8I,_uT))))){return {_:0,a:_bU,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:new T(function(){if(!E(_bJ)){return E(_bC);}else{return E(_bB);}}),i:_2P};}else{return new F(function(){return _MW(_);});}};if(!B(_q(_bF,3))){if(!B(_q(_bL,3))){return new F(function(){return _Q8(_);});}else{return new F(function(){return _Qp(_);});}}else{if(!B(_q(_bL,3))){return new F(function(){return _Qp(_);});}else{return new F(function(){return _Q8(_);});}}},_Qr=function(_Qs){if(!B(_6x(B(_aD(_8I,_uT))))){return {_:0,a:_bU,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:new T(function(){if(!E(_bJ)){return E(_bC);}else{return E(_bB);}}),i:_2P};}else{return new F(function(){return _MW(_);});}};if(!B(_q(_bF,2))){if(!B(_q(_bL,2))){return new F(function(){return _Q6(_);});}else{return new F(function(){return _Qr(_);});}}else{if(!B(_q(_bL,2))){return new F(function(){return _Qr(_);});}else{return new F(function(){return _Q6(_);});}}},_Qt=function(_Qu){if(!B(_6P(B(_aD(_8I,_uT))))){return {_:0,a:_bU,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:new T(function(){if(!E(_bJ)){return E(_bC);}else{return E(_bB);}}),i:_2P};}else{return new F(function(){return _MW(_);});}};if(!B(_q(_bF,1))){if(!B(_q(_bL,1))){return new F(function(){return _Q4(_);});}else{return new F(function(){return _Qt(_);});}}else{if(!B(_q(_bL,1))){return new F(function(){return _Qt(_);});}else{return new F(function(){return _Q4(_);});}}},_Qv=function(_Qw){if(!B(_77(B(_aD(_8I,_uT))))){return {_:0,a:_bU,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:new T(function(){if(!E(_bJ)){return E(_bC);}else{return E(_bB);}}),i:_2P};}else{return new F(function(){return _MW(_);});}};if(!B(_q(_bF,0))){if(!B(_q(_bL,0))){return new F(function(){return _Q2(_);});}else{return new F(function(){return _Qv(_);});}}else{if(!B(_q(_bL,0))){return new F(function(){return _Qv(_);});}else{return new F(function(){return _Q2(_);});}}}}else{return {_:0,a:_bI,b:_bJ,c:_bK,d:_bL,e:_bM,f:_bN,g:_bO,h:_bO,i:_2P};}},_Qx=new T2(1,_5J,_2P),_Qy=new T2(1,_5J,_Qx),_Qz=new T2(1,_5J,_Qy),_QA=new T2(1,_5J,_Qz),_QB=function(_QC,_QD,_QE,_QF,_QG,_QH,_QI,_QJ,_QK){var _QL=E(_QC);if(!_QL){return new F(function(){return _bD(0,_QA,_bC,_bB,_QD,_QE,_QF,_QG,_QH,_QI,_QJ,_QK);});}else{var _QM=B(_QB(_QL-1|0,_QD,_QE,_QF,_QG,_QH,_QI,_QJ,_QK));return new F(function(){return _bD(_QL,_QA,_bC,_bB,_QM.a,_QM.b,_QM.c,_QM.d,_QM.e,_QM.f,_QM.g,_QM.i);});}},_QN=function(_QO,_QP){while(1){var _QQ=E(_QO);if(!_QQ._){return E(_QP);}else{var _QR=_QP+1|0;_QO=_QQ.b;_QP=_QR;continue;}}},_QS=new T(function(){return B(unCStr("ACK"));}),_QT=new T(function(){return B(unCStr("BEL"));}),_QU=new T(function(){return B(unCStr("BS"));}),_QV=new T(function(){return B(unCStr("SP"));}),_QW=new T2(1,_QV,_2P),_QX=new T(function(){return B(unCStr("US"));}),_QY=new T2(1,_QX,_QW),_QZ=new T(function(){return B(unCStr("RS"));}),_R0=new T2(1,_QZ,_QY),_R1=new T(function(){return B(unCStr("GS"));}),_R2=new T2(1,_R1,_R0),_R3=new T(function(){return B(unCStr("FS"));}),_R4=new T2(1,_R3,_R2),_R5=new T(function(){return B(unCStr("ESC"));}),_R6=new T2(1,_R5,_R4),_R7=new T(function(){return B(unCStr("SUB"));}),_R8=new T2(1,_R7,_R6),_R9=new T(function(){return B(unCStr("EM"));}),_Ra=new T2(1,_R9,_R8),_Rb=new T(function(){return B(unCStr("CAN"));}),_Rc=new T2(1,_Rb,_Ra),_Rd=new T(function(){return B(unCStr("ETB"));}),_Re=new T2(1,_Rd,_Rc),_Rf=new T(function(){return B(unCStr("SYN"));}),_Rg=new T2(1,_Rf,_Re),_Rh=new T(function(){return B(unCStr("NAK"));}),_Ri=new T2(1,_Rh,_Rg),_Rj=new T(function(){return B(unCStr("DC4"));}),_Rk=new T2(1,_Rj,_Ri),_Rl=new T(function(){return B(unCStr("DC3"));}),_Rm=new T2(1,_Rl,_Rk),_Rn=new T(function(){return B(unCStr("DC2"));}),_Ro=new T2(1,_Rn,_Rm),_Rp=new T(function(){return B(unCStr("DC1"));}),_Rq=new T2(1,_Rp,_Ro),_Rr=new T(function(){return B(unCStr("DLE"));}),_Rs=new T2(1,_Rr,_Rq),_Rt=new T(function(){return B(unCStr("SI"));}),_Ru=new T2(1,_Rt,_Rs),_Rv=new T(function(){return B(unCStr("SO"));}),_Rw=new T2(1,_Rv,_Ru),_Rx=new T(function(){return B(unCStr("CR"));}),_Ry=new T2(1,_Rx,_Rw),_Rz=new T(function(){return B(unCStr("FF"));}),_RA=new T2(1,_Rz,_Ry),_RB=new T(function(){return B(unCStr("VT"));}),_RC=new T2(1,_RB,_RA),_RD=new T(function(){return B(unCStr("LF"));}),_RE=new T2(1,_RD,_RC),_RF=new T(function(){return B(unCStr("HT"));}),_RG=new T2(1,_RF,_RE),_RH=new T2(1,_QU,_RG),_RI=new T2(1,_QT,_RH),_RJ=new T2(1,_QS,_RI),_RK=new T(function(){return B(unCStr("ENQ"));}),_RL=new T2(1,_RK,_RJ),_RM=new T(function(){return B(unCStr("EOT"));}),_RN=new T2(1,_RM,_RL),_RO=new T(function(){return B(unCStr("ETX"));}),_RP=new T2(1,_RO,_RN),_RQ=new T(function(){return B(unCStr("STX"));}),_RR=new T2(1,_RQ,_RP),_RS=new T(function(){return B(unCStr("SOH"));}),_RT=new T2(1,_RS,_RR),_RU=new T(function(){return B(unCStr("NUL"));}),_RV=new T2(1,_RU,_RT),_RW=92,_RX=new T(function(){return B(unCStr("\\DEL"));}),_RY=new T(function(){return B(unCStr("\\a"));}),_RZ=new T(function(){return B(unCStr("\\\\"));}),_S0=new T(function(){return B(unCStr("\\SO"));}),_S1=new T(function(){return B(unCStr("\\r"));}),_S2=new T(function(){return B(unCStr("\\f"));}),_S3=new T(function(){return B(unCStr("\\v"));}),_S4=new T(function(){return B(unCStr("\\n"));}),_S5=new T(function(){return B(unCStr("\\t"));}),_S6=new T(function(){return B(unCStr("\\b"));}),_S7=function(_S8,_S9){if(_S8<=127){var _Sa=E(_S8);switch(_Sa){case 92:return new F(function(){return _a(_RZ,_S9);});break;case 127:return new F(function(){return _a(_RX,_S9);});break;default:if(_Sa<32){var _Sb=E(_Sa);switch(_Sb){case 7:return new F(function(){return _a(_RY,_S9);});break;case 8:return new F(function(){return _a(_S6,_S9);});break;case 9:return new F(function(){return _a(_S5,_S9);});break;case 10:return new F(function(){return _a(_S4,_S9);});break;case 11:return new F(function(){return _a(_S3,_S9);});break;case 12:return new F(function(){return _a(_S2,_S9);});break;case 13:return new F(function(){return _a(_S1,_S9);});break;case 14:return new F(function(){return _a(_S0,new T(function(){var _Sc=E(_S9);if(!_Sc._){return __Z;}else{if(E(_Sc.a)==72){return B(unAppCStr("\\&",_Sc));}else{return E(_Sc);}}},1));});break;default:return new F(function(){return _a(new T2(1,_RW,new T(function(){return B(_q(_RV,_Sb));})),_S9);});}}else{return new T2(1,_Sa,_S9);}}}else{var _Sd=new T(function(){var _Se=jsShowI(_S8);return B(_a(fromJSStr(_Se),new T(function(){var _Sf=E(_S9);if(!_Sf._){return __Z;}else{var _Sg=E(_Sf.a);if(_Sg<48){return E(_Sf);}else{if(_Sg>57){return E(_Sf);}else{return B(unAppCStr("\\&",_Sf));}}}},1)));});return new T2(1,_RW,_Sd);}},_Sh=new T(function(){return B(unCStr("\'\\\'\'"));}),_Si=39,_Sj=function(_Sk,_Sl){var _Sm=E(_Sk);if(_Sm==39){return new F(function(){return _a(_Sh,_Sl);});}else{return new T2(1,_Si,new T(function(){return B(_S7(_Sm,new T2(1,_Si,_Sl)));}));}},_Sn=function(_So){return new F(function(){return err(B(unAppCStr("Char.digitToInt: not a digit ",new T(function(){return B(_Sj(_So,_2P));}))));});},_Sp=function(_Sq){var _Sr=_Sq-48|0;if(_Sr>>>0>9){var _Ss=_Sq-97|0;if(_Ss>>>0>5){var _St=_Sq-65|0;if(_St>>>0>5){return new F(function(){return _Sn(_Sq);});}else{return _St+10|0;}}else{return _Ss+10|0;}}else{return E(_Sr);}},_Su=function(_Sv){return new F(function(){return err(B(unAppCStr("Char.intToDigit: not a digit ",new T(function(){if(_Sv>=0){var _Sw=jsShowI(_Sv);return fromJSStr(_Sw);}else{var _Sx=jsShowI(_Sv);return fromJSStr(_Sx);}}))));});},_Sy=function(_Sz){var _SA=function(_SB){if(_Sz<10){return new F(function(){return _Su(_Sz);});}else{if(_Sz>15){return new F(function(){return _Su(_Sz);});}else{return (97+_Sz|0)-10|0;}}};if(_Sz<0){return new F(function(){return _SA(_);});}else{if(_Sz>9){return new F(function(){return _SA(_);});}else{return 48+_Sz|0;}}},_SC=function(_SD,_SE,_SF,_SG,_SH,_SI,_SJ,_SK,_SL,_SM,_SN,_SO,_SP){while(1){var _SQ=B((function(_SR,_SS,_ST,_SU,_SV,_SW,_SX,_SY,_SZ,_T0,_T1,_T2,_T3){var _T4=E(_SR),_T5=E(_T4);if(_T5==32){return {_:0,a:_SV,b:_SW,c:_SX,d:_SY,e:_SZ,f:_T0,g:_T1,h:_T2,i:_T3};}else{if((_T5-48|0)>>>0>9){if(E(_T5)==47){return new F(function(){return _T6(_SS,1,_SU-1|0,_SV,_SW,_SX,_SY,_SZ,_T0,_T1,_T2,_T3);});}else{return new F(function(){return _T6(_SS,_ST+1|0,_SU,new T2(1,new T2(0,new T2(0,_ST,_SU),_T4),_SV),_SW,_SX,_SY,_SZ,_T0,_T1,_T2,_T3);});}}else{var _T7=E(_T5);if(_T7==49){return new F(function(){return _T6(_SS,_ST+1|0,_SU,_SV,_SW,_SX,_SY,_SZ,_T0,_T1,_T2,_T3);});}else{var _T8=_SS,_T9=_ST+1|0,_Ta=_SU,_Tb=_SV,_Tc=_SW,_Td=_SX,_Te=_SY,_Tf=_SZ,_Tg=_T0,_Th=_T1,_Ti=_T2,_Tj=_T3;_SD=new T(function(){return B(_Sy(B(_Sp(_T7))-1|0));});_SE=_T8;_SF=_T9;_SG=_Ta;_SH=_Tb;_SI=_Tc;_SJ=_Td;_SK=_Te;_SL=_Tf;_SM=_Tg;_SN=_Th;_SO=_Ti;_SP=_Tj;return __continue;}}}})(_SD,_SE,_SF,_SG,_SH,_SI,_SJ,_SK,_SL,_SM,_SN,_SO,_SP));if(_SQ!=__continue){return _SQ;}}},_T6=function(_Tk,_Tl,_Tm,_Tn,_To,_Tp,_Tq,_Tr,_Ts,_Tt,_Tu,_Tv){while(1){var _Tw=B((function(_Tx,_Ty,_Tz,_TA,_TB,_TC,_TD,_TE,_TF,_TG,_TH,_TI){var _TJ=E(_Tx);if(!_TJ._){return E(_5P);}else{var _TK=_TJ.b,_TL=E(_TJ.a),_TM=E(_TL);if(_TM==32){return {_:0,a:_TA,b:_TB,c:_TC,d:_TD,e:_TE,f:_TF,g:_TG,h:_TH,i:_TI};}else{if((_TM-48|0)>>>0>9){if(E(_TM)==47){var _TN=_Tz-1|0,_TO=_TA,_TP=_TB,_TQ=_TC,_TR=_TD,_TS=_TE,_TT=_TF,_TU=_TG,_TV=_TH,_TW=_TI;_Tk=_TK;_Tl=1;_Tm=_TN;_Tn=_TO;_To=_TP;_Tp=_TQ;_Tq=_TR;_Tr=_TS;_Ts=_TT;_Tt=_TU;_Tu=_TV;_Tv=_TW;return __continue;}else{var _TX=_Ty+1|0,_TN=_Tz,_TO=new T2(1,new T2(0,new T2(0,_Ty,_Tz),_TL),_TA),_TP=_TB,_TQ=_TC,_TR=_TD,_TS=_TE,_TT=_TF,_TU=_TG,_TV=_TH,_TW=_TI;_Tk=_TK;_Tl=_TX;_Tm=_TN;_Tn=_TO;_To=_TP;_Tp=_TQ;_Tq=_TR;_Tr=_TS;_Ts=_TT;_Tt=_TU;_Tu=_TV;_Tv=_TW;return __continue;}}else{var _TY=E(_TM);if(_TY==49){var _TX=_Ty+1|0,_TN=_Tz,_TO=_TA,_TP=_TB,_TQ=_TC,_TR=_TD,_TS=_TE,_TT=_TF,_TU=_TG,_TV=_TH,_TW=_TI;_Tk=_TK;_Tl=_TX;_Tm=_TN;_Tn=_TO;_To=_TP;_Tp=_TQ;_Tq=_TR;_Tr=_TS;_Ts=_TT;_Tt=_TU;_Tu=_TV;_Tv=_TW;return __continue;}else{return new F(function(){return _SC(new T(function(){return B(_Sy(B(_Sp(_TY))-1|0));}),_TK,_Ty+1|0,_Tz,_TA,_TB,_TC,_TD,_TE,_TF,_TG,_TH,_TI);});}}}}})(_Tk,_Tl,_Tm,_Tn,_To,_Tp,_Tq,_Tr,_Ts,_Tt,_Tu,_Tv));if(_Tw!=__continue){return _Tw;}}},_TZ=new T(function(){return B(_49("Main.hs:(173,9)-(179,111)|function castler"));}),_U0=function(_U1,_U2,_U3,_U4,_U5,_U6,_U7,_U8,_U9,_Ua){while(1){var _Ub=B((function(_Uc,_Ud,_Ue,_Uf,_Ug,_Uh,_Ui,_Uj,_Uk,_Ul){var _Um=E(_Uc);if(!_Um._){return E(_5P);}else{var _Un=_Um.b;switch(E(_Um.a)){case 32:return {_:0,a:_Ud,b:_Ue,c:_Uf,d:_Ug,e:_Uh,f:_Ui,g:_Uj,h:_Uk,i:_Ul};case 45:return {_:0,a:_Ud,b:_Ue,c:_Uf,d:_Ug,e:_Uh,f:_Ui,g:_Uj,h:_Uk,i:_Ul};case 75:var _Uo=_Ud,_Up=_Ue,_Uq=_Ug,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul;_U1=_Un;_U2=_Uo;_U3=_Up;_U4=new T(function(){return B(_5B(0,_5J,_Uf));});_U5=_Uq;_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;return __continue;case 81:var _Uo=_Ud,_Up=_Ue,_Uq=_Ug,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul;_U1=_Un;_U2=_Uo;_U3=_Up;_U4=new T(function(){return B(_5B(1,_5J,_Uf));});_U5=_Uq;_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;return __continue;case 107:var _Uo=_Ud,_Up=_Ue,_Uq=_Ug,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul;_U1=_Un;_U2=_Uo;_U3=_Up;_U4=new T(function(){return B(_5B(2,_5J,_Uf));});_U5=_Uq;_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;return __continue;case 113:var _Uo=_Ud,_Up=_Ue,_Uq=_Ug,_Ur=_Uh,_Us=_Ui,_Ut=_Uj,_Uu=_Uk,_Uv=_Ul;_U1=_Un;_U2=_Uo;_U3=_Up;_U4=new T(function(){return B(_5B(3,_5J,_Uf));});_U5=_Uq;_U6=_Ur;_U7=_Us;_U8=_Ut;_U9=_Uu;_Ua=_Uv;return __continue;default:return E(_TZ);}}})(_U1,_U2,_U3,_U4,_U5,_U6,_U7,_U8,_U9,_Ua));if(_Ub!=__continue){return _Ub;}}},_Uw=function(_Ux){while(1){var _Uy=E(_Ux);if(!_Uy._){return E(_5P);}else{var _Uz=_Uy.b;if(E(_Uy.a)==32){return E(_Uz);}else{_Ux=_Uz;continue;}}}},_UA=new T(function(){return B(_49("Main.hs:(162,49)-(170,105)|case"));}),_UB=new T2(1,_5K,_2P),_UC=new T2(1,_5K,_UB),_UD=new T2(1,_5K,_UC),_UE=new T2(1,_5K,_UD),_UF=function(_UG){var _UH=B(_T6(_UG,1,8,_2P,_5K,_UE,_QA,_8Q,_8R,_8K,_8K,_2P)),_UI=B(_Uw(_UG)),_UJ=B(_Uw(_UI)),_UK=B(_U0(_UJ,_UH.a,new T(function(){var _UL=E(_UI);if(!_UL._){return E(_5P);}else{if(E(_UL.a)==119){return true;}else{return false;}}}),_UH.c,_UH.d,_UH.e,_UH.f,_UH.g,_UH.h,_UH.i)),_UM=_UK.a,_UN=_UK.b,_UO=_UK.c,_UP=_UK.d,_UQ=_UK.e,_UR=_UK.h,_US=_UK.i,_UT=B(_Uw(_UJ));if(!_UT._){return E(_5P);}else{var _UU=_UT.b;switch(E(_UT.a)){case 45:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,_UK.f,_UR,_US);});break;case 97:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_8Z,new T(function(){var _UV=E(_UU);if(!_UV._){return E(_5P);}else{return B(_Sp(E(_UV.a)));}})),_UR,_US);});break;case 98:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_8L,new T(function(){var _UW=E(_UU);if(!_UW._){return E(_5P);}else{return B(_Sp(E(_UW.a)));}})),_UR,_US);});break;case 99:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_8M,new T(function(){var _UX=E(_UU);if(!_UX._){return E(_5P);}else{return B(_Sp(E(_UX.a)));}})),_UR,_US);});break;case 100:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_8N,new T(function(){var _UY=E(_UU);if(!_UY._){return E(_5P);}else{return B(_Sp(E(_UY.a)));}})),_UR,_US);});break;case 101:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_8O,new T(function(){var _UZ=E(_UU);if(!_UZ._){return E(_5P);}else{return B(_Sp(E(_UZ.a)));}})),_UR,_US);});break;case 102:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_8P,new T(function(){var _V0=E(_UU);if(!_V0._){return E(_5P);}else{return B(_Sp(E(_V0.a)));}})),_UR,_US);});break;case 103:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_93,new T(function(){var _V1=E(_UU);if(!_V1._){return E(_5P);}else{return B(_Sp(E(_V1.a)));}})),_UR,_US);});break;case 104:return new F(function(){return _8d(_UM,_UN,_UO,_UP,_UQ,new T2(0,_9b,new T(function(){var _V2=E(_UU);if(!_V2._){return E(_5P);}else{return B(_Sp(E(_V2.a)));}})),_UR,_US);});break;default:return E(_UA);}}},_V3=new T(function(){return B(unCStr("(Array.!): undefined array element"));}),_V4=new T(function(){return B(err(_V3));}),_V5=new T(function(){return B(unCStr("Error in array index"));}),_V6=new T(function(){return B(err(_V5));}),_V7=new T2(0,_8Z,_8Z),_V8=new T2(0,_9b,_9b),_V9=95,_Va=new T(function(){return B(_9l(1,8));}),_Vb=function(_Vc){var _Vd=B(A1(_Vc,_));return E(_Vd);},_Ve=function(_Vf){var _Vg=function(_){var _Vh=newArr(64,_V4),_Vi=_Vh,_Vj=function(_Vk,_){while(1){var _Vl=E(_Vk);if(!_Vl._){return new T4(0,E(_V7),E(_V8),64,_Vi);}else{var _Vm=E(_Vl.a),_Vn=E(_Vm.a),_Vo=E(_Vn.a);if(1>_Vo){return E(_V6);}else{if(_Vo>8){return E(_V6);}else{var _Vp=E(_Vn.b);if(1>_Vp){return E(_V6);}else{if(_Vp>8){return E(_V6);}else{var _=_Vi[(imul(_Vo-1|0,8)|0)+(_Vp-1|0)|0]=_Vm.b;_Vk=_Vl.b;continue;}}}}}}},_Vq=function(_Vr,_){while(1){var _Vs=B((function(_Vt,_){var _Vu=E(_Va);if(!_Vu._){var _Vv=E(_Vt);if(_Vv==8){return new F(function(){return _Vj(_Vf,_);});}else{_Vr=_Vv+1|0;return __continue;}}else{if(1>_Vt){return E(_V6);}else{if(_Vt>8){return E(_V6);}else{var _Vw=E(_Vu.a);if(1>_Vw){return E(_V6);}else{if(_Vw>8){return E(_V6);}else{var _=_Vi[(imul(_Vt-1|0,8)|0)+(_Vw-1|0)|0]=_V9,_Vx=function(_Vy,_){while(1){var _Vz=E(_Vy);if(!_Vz._){var _VA=E(_Vt);if(_VA==8){return new F(function(){return _Vj(_Vf,_);});}else{return new F(function(){return _Vq(_VA+1|0,_);});}}else{var _VB=E(_Vz.a);if(1>_VB){return E(_V6);}else{if(_VB>8){return E(_V6);}else{var _=_Vi[(imul(_Vt-1|0,8)|0)+(_VB-1|0)|0]=_V9;_Vy=_Vz.b;continue;}}}}};return new F(function(){return _Vx(_Vu.b,_);});}}}}}})(_Vr,_));if(_Vs!=__continue){return _Vs;}}};return new F(function(){return _Vq(1,_);});};return new F(function(){return _Vb(_Vg);});},_VC=new T(function(){return B(unCStr("last"));}),_VD=new T(function(){return B(_5M(_VC));}),_VE=new T(function(){return B(_9l(0,63));}),_VF=new T(function(){return B(_49("Main.hs:(142,49)-(150,265)|case"));}),_VG=new T(function(){return B(_49("Main.hs:(142,74)-(145,106)|case"));}),_VH=function(_VI,_VJ){var _VK=_VI%_VJ;if(_VI<=0){if(_VI>=0){return E(_VK);}else{if(_VJ<=0){return E(_VK);}else{var _VL=E(_VK);return (_VL==0)?0:_VL+_VJ|0;}}}else{if(_VJ>=0){if(_VI>=0){return E(_VK);}else{if(_VJ<=0){return E(_VK);}else{var _VM=E(_VK);return (_VM==0)?0:_VM+_VJ|0;}}}else{var _VN=E(_VK);return (_VN==0)?0:_VN+_VJ|0;}}},_VO=function(_VP,_VQ){var _VR=new T(function(){var _VS=B(_UF(_VP)),_VT=B(_QB(E(_VQ),_VS.a,_VS.b,_VS.c,_VS.d,_VS.e,_VS.f,_VS.g,_VS.i));return {_:0,a:_VT.a,b:_VT.b,c:_VT.c,d:_VT.d,e:_VT.e,f:_VT.f,g:_VT.g,h:_VT.h,i:_VT.i};}),_VU=new T(function(){var _VV=E(E(_VR).i);if(!_VV._){return E(_5P);}else{var _VW=B(_Ve(E(_VV.a).a)),_VX=_VW.d,_VY=E(_VW.a),_VZ=E(_VW.b),_W0=E(_VY.a),_W1=E(_VZ.a);if(_W0<=_W1){var _W2=E(_VY.b),_W3=E(_VZ.b),_W4=new T(function(){if(_W0!=_W1){var _W5=function(_W6){var _W7=new T(function(){if(_W6!=_W1){return B(_W5(_W6+1|0));}else{return __Z;}});if(_W2<=_W3){var _W8=new T(function(){return _W0<=_W6;}),_W9=new T(function(){return _W6<=_W1;}),_Wa=function(_Wb){return new T2(1,new T2(0,new T2(0,_W6,_Wb),new T(function(){if(!E(_W8)){return E(_V6);}else{if(!E(_W9)){return E(_V6);}else{if(_W2>_Wb){return E(_V6);}else{if(_Wb>_W3){return E(_V6);}else{return E(_VX[(imul(_W6-_W0|0,(_W3-_W2|0)+1|0)|0)+(_Wb-_W2|0)|0]);}}}}})),new T(function(){if(_Wb!=_W3){return B(_Wa(_Wb+1|0));}else{return E(_W7);}}));};return new F(function(){return _Wa(_W2);});}else{return E(_W7);}};return B(_W5(_W0+1|0));}else{return __Z;}});if(_W2<=_W3){var _Wc=new T(function(){return _W0<=_W1;}),_Wd=function(_We){return new T2(1,new T2(0,new T2(0,_W0,_We),new T(function(){if(!E(_Wc)){return E(_V6);}else{if(_W2>_We){return E(_V6);}else{if(_We>_W3){return E(_V6);}else{return E(_VX[_We-_W2|0]);}}}})),new T(function(){if(_We!=_W3){return B(_Wd(_We+1|0));}else{return E(_W4);}}));};return B(_Wd(_W2));}else{return E(_W4);}}else{return __Z;}}}),_Wf=new T(function(){var _Wg=B(_Ve(E(_VR).a)),_Wh=_Wg.d,_Wi=E(_Wg.a),_Wj=E(_Wg.b),_Wk=E(_Wi.a),_Wl=E(_Wj.a);if(_Wk<=_Wl){var _Wm=E(_Wi.b),_Wn=E(_Wj.b),_Wo=new T(function(){if(_Wk!=_Wl){var _Wp=function(_Wq){var _Wr=new T(function(){if(_Wq!=_Wl){return B(_Wp(_Wq+1|0));}else{return __Z;}});if(_Wm<=_Wn){var _Ws=new T(function(){return _Wk<=_Wq;}),_Wt=new T(function(){return _Wq<=_Wl;}),_Wu=function(_Wv){return new T2(1,new T2(0,new T2(0,_Wq,_Wv),new T(function(){if(!E(_Ws)){return E(_V6);}else{if(!E(_Wt)){return E(_V6);}else{if(_Wm>_Wv){return E(_V6);}else{if(_Wv>_Wn){return E(_V6);}else{return E(_Wh[(imul(_Wq-_Wk|0,(_Wn-_Wm|0)+1|0)|0)+(_Wv-_Wm|0)|0]);}}}}})),new T(function(){if(_Wv!=_Wn){return B(_Wu(_Wv+1|0));}else{return E(_Wr);}}));};return new F(function(){return _Wu(_Wm);});}else{return E(_Wr);}};return B(_Wp(_Wk+1|0));}else{return __Z;}});if(_Wm<=_Wn){var _Ww=new T(function(){return _Wk<=_Wl;}),_Wx=function(_Wy){return new T2(1,new T2(0,new T2(0,_Wk,_Wy),new T(function(){if(!E(_Ww)){return E(_V6);}else{if(_Wm>_Wy){return E(_V6);}else{if(_Wy>_Wn){return E(_V6);}else{return E(_Wh[_Wy-_Wm|0]);}}}})),new T(function(){if(_Wy!=_Wn){return B(_Wx(_Wy+1|0));}else{return E(_Wo);}}));};return B(_Wx(_Wm));}else{return E(_Wo);}}else{return __Z;}}),_Wz=B(_5Q(function(_WA){var _WB=E(_WA),_WC=B(_q(_Wf,_WB)),_WD=B(_q(_VU,_WB)),_WE=E(_WC.a),_WF=E(_WD.a);return (E(_WE.a)!=E(_WF.a))?true:(E(_WE.b)!=E(_WF.b))?true:(E(_WC.b)!=E(_WD.b))?true:false;},_VE));switch(B(_QN(_Wz,0))){case 2:var _WG=E(_Wz);return (_WG._==0)?E(_5P):(E(B(_q(_VU,E(_WG.a))).b)==95)?new T4(0,new T(function(){return B(_VH(B(_q(_WG,0)),8))+1|0;}),new T(function(){return quot(B(_q(_WG,0)),8)+1|0;}),new T(function(){return B(_VH(B(_q(_WG,1)),8))+1|0;}),new T(function(){return quot(B(_q(_WG,1)),8)+1|0;})):new T4(0,new T(function(){return B(_VH(B(_q(_WG,1)),8))+1|0;}),new T(function(){return quot(B(_q(_WG,1)),8)+1|0;}),new T(function(){return B(_VH(B(_q(_WG,0)),8))+1|0;}),new T(function(){return quot(B(_q(_WG,0)),8)+1|0;}));case 3:var _WH=E(_Wz);if(!_WH._){return E(_5P);}else{var _WI=E(_WH.a),_WJ=B(_VH(_WI,8));if(_WJ>3){return (B(_VH(B(_6(_WI,_WH.b,_VD)),8))==5)?new T4(0,_WJ+1|0,quot(_WI,8)+1|0,_WJ+2|0,quot(_WI,8)+2|0):new T4(0,_WJ+1|0,quot(_WI,8)+2|0,_WJ+2|0,quot(_WI,8)+1|0);}else{var _WK=E(_WJ);return (_WK==3)?new T4(0,4,quot(_WI,8)+1|0,3,quot(_WI,8)+2|0):new T4(0,_WK+2|0,quot(_WI,8)+2|0,_WK+1|0,quot(_WI,8)+1|0);}}break;case 4:var _WL=E(_Wz);if(!_WL._){return E(_5P);}else{switch(E(_WL.a)){case 0:return new T4(0,_8Z,_8O,_8Z,_8M);case 7:return new T4(0,_9b,_8O,_9b,_8M);case 32:return new T4(0,_8Z,_8O,_8Z,_93);case 39:return new T4(0,_9b,_8O,_9b,_93);default:return E(_VG);}}break;default:return E(_VF);}},_WM=new T(function(){return eval("(function(s,f){Haste[s] = f;})");}),_WN=function(_WO){return E(_WO);},_WP=function(_){var _WQ=function(_WR){var _WS=new T(function(){var _WT=String(E(_WR));return fromJSStr(_WT);}),_WU=function(_WV){var _WW=B(_VO(_WS,new T(function(){var _WX=Number(E(_WV));return jsTrunc(_WX);},1)));return new F(function(){return __lst2arr(B(_aD(_WN,new T2(1,_WW.a,new T2(1,_WW.b,new T2(1,_WW.c,new T2(1,_WW.d,_2P)))))));});};return E(_WU);},_WY=__createJSFunc(2,E(_WQ)),_WZ=__app2(E(_WM),"mover",_WY);return new F(function(){return _1(_);});},_X0=function(_){return new F(function(){return _WP(_);});};
var hasteMain = function() {B(A(_X0, [0]));};window.onload = hasteMain;